import { pgTable, text, serial, integer, boolean, jsonb, timestamp, date, real, varchar, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define subscription tiers
export const SubscriptionTier = {
  FREE: "free",
  PREMIUM: "premium",
  BUSINESS: "business"
} as const;

export type SubscriptionTierType = typeof SubscriptionTier[keyof typeof SubscriptionTier];

// Define payment status types
export const PaymentStatus = {
  PENDING: "pending",
  SUCCEEDED: "succeeded",
  FAILED: "failed",
  REFUNDED: "refunded",
  PARTIALLY_REFUNDED: "partially_refunded"
} as const;

export type PaymentStatusType = typeof PaymentStatus[keyof typeof PaymentStatus];

// Define payment method types
export const PaymentMethod = {
  CARD: "card",
  BANK_TRANSFER: "bank_transfer",
  WALLET: "wallet",
  POINTS: "loyalty_points"
} as const;

export type PaymentMethodType = typeof PaymentMethod[keyof typeof PaymentMethod];

// Define the preferences schema first for reuse
export const userPreferencesSchema = z.object({
  preferredClass: z.string().optional(),
  budget: z.number().optional(),
  cuisinePreferences: z.array(z.string()).optional(),
  travelStyle: z.array(z.string()).optional(),
  favoriteDestinations: z.array(z.string()).optional(),
  accommodationPreferences: z.array(z.string()).optional(),
  interests: z.array(z.string()).optional(),
  transportPreferences: z.array(z.string()).optional(),
  climatePreference: z.string().optional(),
  tripDurationPreference: z.string().optional(),
}).optional();

// Add location type
export type Location = {
  lat: number;
  lng: number;
};

// Add expense type
export type Expense = {
  id: string;
  title: string;
  category: 'accommodation' | 'transportation' | 'food' | 'activities' | 'other';
  amount: number;
  date: string;
  location: string;
  paymentMethod: string;
  status: 'completed' | 'pending' | 'refunded';
  receiptUrl?: string;
  tags?: string[];
  bookingType?: BookingType;
  bookingId?: string;
  icon?: string;
};

// Add OnlineUser type for presence tracking
export type OnlineUser = {
  id: number;
  username: string;
  isTyping: boolean;
  lastActive?: string;
  location?: Location;
};

// Add location to users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  phone_number: text("phone_number"),
  phone_verified: boolean("phone_verified").default(false),
  otp: text("otp"),
  otp_expires: timestamp("otp_expires"),
  // Add email verification fields
  email_otp: text("email_otp"),
  email_otp_expires: timestamp("email_otp_expires"),
  preferences: jsonb("preferences").$type<z.infer<typeof userPreferencesSchema>>(),
  last_location: jsonb("last_location").$type<Location>(),
  last_active: timestamp("last_active"),
  // Add Google auth fields - using nullable() instead of optional()
  google_id: text("google_id"),
  display_name: text("display_name"),
  avatar_url: text("avatar_url"),
  // Add business model fields
  email: text("email"),
  email_verified: boolean("email_verified").default(false),
  subscription_tier: text("subscription_tier").default(SubscriptionTier.FREE),
  subscription_expires: timestamp("subscription_expires"),
  stripe_customer_id: text("stripe_customer_id"),
  referral_code: text("referral_code"),
  referred_by: integer("referred_by").references(() => users.id),
  business_account_id: integer("business_account_id"),
});

// Create base schema from the table
const baseUserSchema = createInsertSchema(users);

// Phone number validation regex
const phoneRegex = /^\+[1-9]\d{1,14}$/;

// Extend the base schema with preferences and phone
export const insertUserSchema = baseUserSchema.extend({
  preferences: userPreferencesSchema,
  phone_number: z.string()
    .regex(phoneRegex, 'Phone number must be in E.164 format (e.g. +1234567890)')
    .optional(),
  google_id: z.string().optional(),
  display_name: z.string().optional(),
  avatar_url: z.string().optional(),
  email: z.string().email().optional(),
  subscription_tier: z.enum([SubscriptionTier.FREE, SubscriptionTier.PREMIUM, SubscriptionTier.BUSINESS]).optional(),
  subscription_expires: z.date().optional(),
  stripe_customer_id: z.string().optional(),
  referral_code: z.string().optional(),
  referred_by: z.number().optional(),
  business_account_id: z.number().optional(),
});

// Schema for verification via phone or email
export const verificationSchema = z.object({
  recipient: z.string().refine(
    val => val.match(phoneRegex) || val.match(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/),
    {
      message: 'Please provide a valid phone number (E.164 format) or email address'
    }
  ),
  otp: z.string().min(6).max(8),
});

// Kept for backwards compatibility
export const phoneVerificationSchema = z.object({
  phone_number: z.string().regex(phoneRegex),
  otp: z.string().length(6),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type PhoneVerification = z.infer<typeof phoneVerificationSchema>;
export type Verification = z.infer<typeof verificationSchema>;

export type BookingType = "flight" | "hotel" | "ride" | "dining";

export type Seat = {
  id: string;
  row: number;
  column: string;
  type: "window" | "middle" | "aisle";
  status: "available" | "occupied" | "selected";
  price?: number;
};

export type FlightBooking = {
  id: string;
  airline: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  price: number | string;
  class: string;
  amenities?: string[];
  availableSeats?: Seat[];
  selectedSeat?: Seat;
  stops?: number;
  isFavorite?: boolean;
};

export type HotelBooking = {
  id: string;
  name: string;
  location: string;
  checkIn: string;
  checkOut: string;
  price: number | string;
  rating: number;
  image: string;
  amenities?: string[];
  isFavorite?: boolean;
  roomsAvailable: number;
  lastUpdated: string;
};

export type RideStatus = 'pending' | 'accepted' | 'arriving' | 'in_progress' | 'completed' | 'cancelled';

export type RideBooking = {
  id: string;
  type: string;
  from: string;
  to: string;
  price: number | string;
  driver?: string;
  pickupTime: string;
  status: RideStatus;
  currentLocation?: {
    lat: number;
    lng: number;
  };
  estimatedArrival?: string;
  trackingId?: string;
};

export type DiningBooking = {
  id: string;
  restaurant: string;
  cuisine: string;
  date: string;
  time: string;
  guests: number;
  price: number | string;
  rating?: number;
  location?: string;
  image?: string;
  reservationTime: string;
};

export type TravelMemory = {
  id: string;
  title: string;
  location: string;
  date: string;
  description: string;
  imageUrl?: string;
  tags: string[];
  animation: {
    type: "flip" | "fade" | "slide";
    duration: number;
  };
};

export type PackingItem = {
  id: string;
  name: string;
  category: string;
  quantity: number;
  isEssential: boolean;
  weather: string[];
  tripType: string[];
  notes?: string;
};

export type PackingList = {
  id: string;
  userId: number;
  destination: string;
  tripStartDate: string;
  tripEndDate: string;
  weather: string;
  activities: string[];
  items: PackingItem[];
  recommendations: string[];
  lastUpdated: string;
};

// Trip Planning Schema
export type Activity = {
  id: string;
  title: string;
  type: string;
  startTime: string;
  endTime: string;
  location: string;
  description: string;
  cost?: number | string;
};

// Define emotional weather type
export type EmotionalWeather = {
  primary: {
    emotion: string;
    intensity: number; // 0-100
  };
  secondary?: {
    emotion: string;
    intensity: number; // 0-100
  };
  description: string;
};

export type DayPlan = {
  date: string;
  activities: Activity[];
  weatherForecast?: {
    condition: 'sunny' | 'cloudy' | 'rainy' | 'stormy' | string;
    temperature: number;
    chanceOfRain: number;
  };
  emotionalWeather?: EmotionalWeather;
};

export type TripPlan = {
  destination: string;
  startDate: string;
  endDate: string;
  days: DayPlan[];
  totalEstimatedCost?: number;
  notes?: string[];
  currencyCode?: string;
};

// Add passenger details schema
export type PassengerDetails = {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  nationality: string;
  passportNumber?: string;
  specialRequirements?: string;
};

// Add itinerary schema
export type Itinerary = {
  id: string;
  userId: number;
  bookingDate: string;
  totalAmount: number;
  passengers: PassengerDetails[];
  paymentStatus: 'pending' | 'completed' | 'failed';
  bookingDetails: {
    flight?: FlightBooking;
    hotel?: HotelBooking;
    ride?: RideBooking;
    dining?: DiningBooking;
  };
};

// Add PaymentFormProps type
export type PaymentFormProps = {
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
  bookingType?: 'flight' | 'hotel' | 'dining' | 'ride';
  details: {
    flight?: FlightBooking | null;
    hotel?: HotelBooking | null;
    dining?: DiningBooking | null;
    ride?: RideBooking | null;
    seat?: Seat | null;
    passengers?: PassengerDetails[] | number;
  };
};

// Add Drizzle table definitions
export const passengers = pgTable("passengers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  nationality: text("nationality").notNull(),
  passportNumber: text("passport_number"),
  specialRequirements: text("special_requirements"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const itineraries = pgTable("itineraries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  bookingDate: timestamp("booking_date").defaultNow(),
  totalAmount: integer("total_amount").notNull(),
  paymentStatus: text("payment_status").notNull(),
  bookingDetails: jsonb("booking_details").notNull(),
  passengers: jsonb("passengers").notNull().$type<PassengerDetails[]>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Create insert schemas
export const insertPassengerSchema = createInsertSchema(passengers, {
  passportNumber: z.string().optional(),
  specialRequirements: z.string().optional(),
});

export const insertItinerarySchema = createInsertSchema(itineraries);

// Export types
export type InsertPassenger = z.infer<typeof insertPassengerSchema>;
export type Passenger = typeof passengers.$inferSelect;
export type InsertItinerary = z.infer<typeof insertItinerarySchema>;
export type DbItinerary = typeof itineraries.$inferSelect;


// Add RideHistory table
export const rideHistory = pgTable("ride_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  rideId: text("ride_id").notNull(),
  fromLocation: text("from_location").notNull(),
  toLocation: text("to_location").notNull(),
  price: integer("price").notNull(),
  driverName: text("driver_name"),
  pickupTime: timestamp("pickup_time").notNull(),
  dropoffTime: timestamp("dropoff_time"),
  status: text("status").notNull(),
  rating: integer("rating"),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Add tracking table
export const rideTracking = pgTable("ride_tracking", {
  id: serial("id").primaryKey(),
  rideId: text("ride_id").notNull(),
  currentLat: text("current_lat").notNull(),
  currentLng: text("current_lng").notNull(),
  estimatedArrival: timestamp("estimated_arrival"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Business account table
export const businessAccounts = pgTable("business_accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address"),
  taxId: text("tax_id"),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone"),
  maxUsers: integer("max_users").default(5),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Subscription table
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  tier: text("tier").notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  autoRenew: boolean("auto_renew").default(true),
  stripeSubscriptionId: text("stripe_subscription_id"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Commission records table
export const commissionRecords = pgTable("commission_records", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id").references(() => itineraries.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  bookingType: text("booking_type").notNull(),
  commissionAmount: real("commission_amount").notNull(),
  baseAmount: real("base_amount").notNull(),
  commissionRate: real("commission_rate").notNull(),
  status: text("status").notNull().default("pending"),
  partnerName: text("partner_name"),
  partnerReferenceId: text("partner_reference_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Referral table
export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").references(() => users.id).notNull(),
  referredId: integer("referred_id").references(() => users.id).notNull(), 
  status: text("status").notNull().default("pending"),
  rewardAmount: real("reward_amount"),
  rewardIssued: boolean("reward_issued").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Affiliate link tracking
export const affiliateLinks = pgTable("affiliate_links", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  code: text("code").notNull().unique(),
  description: text("description"),
  destination: text("destination").notNull(),
  clicks: integer("clicks").default(0),
  conversions: integer("conversions").default(0),
  commission: real("commission").default(0),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Create insert schemas
export const insertRideHistorySchema = createInsertSchema(rideHistory);
export const insertRideTrackingSchema = createInsertSchema(rideTracking);
export const insertBusinessAccountSchema = createInsertSchema(businessAccounts);
export const insertSubscriptionSchema = createInsertSchema(subscriptions);
export const insertCommissionRecordSchema = createInsertSchema(commissionRecords);
export const insertReferralSchema = createInsertSchema(referrals);
export const insertAffiliateLinkSchema = createInsertSchema(affiliateLinks);

// Add payment records table
export const paymentRecords = pgTable("payment_records", {
  id: text("id").primaryKey(), // Stripe payment intent ID
  userId: integer("user_id").references(() => users.id).notNull(),
  bookingType: text("booking_type").notNull(),
  bookingId: integer("booking_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("usd").notNull(),
  status: text("status").notNull(), // pending, succeeded, failed, refunded
  paymentMethod: text("payment_method"), // card, bank_transfer, wallet, etc.
  metadata: jsonb("metadata"),
  receiptUrl: text("receipt_url"),
  refundId: text("refund_id"),
  refundAmount: decimal("refund_amount", { precision: 10, scale: 2 }),
  customerEmail: text("customer_email"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Add saved payment methods
export const savedPaymentMethods = pgTable("saved_payment_methods", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  paymentMethodId: text("payment_method_id").notNull(), // Stripe payment method ID
  type: text("type").notNull(), // card, bank_account
  last4: text("last4"),
  brand: text("brand"), // visa, mastercard, etc.
  expiryMonth: integer("expiry_month"),
  expiryYear: integer("expiry_year"),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Create insert schemas for payment tables
export const insertPaymentRecordSchema = createInsertSchema(paymentRecords);
export const insertSavedPaymentMethodSchema = createInsertSchema(savedPaymentMethods);

// Export types
export type InsertRideHistory = z.infer<typeof insertRideHistorySchema>;
export type RideHistoryRecord = typeof rideHistory.$inferSelect;
export type InsertRideTracking = z.infer<typeof insertRideTrackingSchema>;
export type RideTrackingRecord = typeof rideTracking.$inferSelect;
export type InsertBusinessAccount = z.infer<typeof insertBusinessAccountSchema>;
export type BusinessAccount = typeof businessAccounts.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertCommissionRecord = z.infer<typeof insertCommissionRecordSchema>;
export type CommissionRecord = typeof commissionRecords.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referrals.$inferSelect;
export type InsertAffiliateLink = z.infer<typeof insertAffiliateLinkSchema>;
export type AffiliateLink = typeof affiliateLinks.$inferSelect;
// UPI Payment Records
export const upiPaymentRecords = pgTable("upi_payment_records", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  bookingType: text("booking_type").notNull(),
  amount: integer("amount").notNull(),
  status: text("status").notNull().default("pending"),
  upiId: text("upi_id"),
  referenceId: text("reference_id").notNull().unique(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export type InsertPaymentRecord = z.infer<typeof insertPaymentRecordSchema>;
export type PaymentRecord = typeof paymentRecords.$inferSelect;
export type InsertSavedPaymentMethod = z.infer<typeof insertSavedPaymentMethodSchema>;
export type SavedPaymentMethod = typeof savedPaymentMethods.$inferSelect;
export const insertUpiPaymentRecordSchema = createInsertSchema(upiPaymentRecords);
export type InsertUpiPaymentRecord = z.infer<typeof insertUpiPaymentRecordSchema>;
export type UpiPaymentRecord = typeof upiPaymentRecords.$inferSelect;