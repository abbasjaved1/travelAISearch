import { apiRequest } from './api';
import { User, FlightBooking, HotelBooking } from '@shared/schema';

// Add new trip planning interfaces
export interface TripPlan {
  destination: string;
  duration: number;
  preferences?: TripPreferences;
  schedule?: Array<{
    day: number;
    date: string;
    activities: Array<{
      title: string;
      description: string;
      location: string;
      startTime: string;
      endTime: string;
    }>;
  }>;
  recommendations?: {
    packingList: string[];
    localTips: string[];
  };
}

export interface TripPreferences {
  pace: 'relaxed' | 'moderate' | 'intensive';
  interests?: string[];
  mustSeeAttractions?: string[];
  avoidTypes?: string[];
  mealPreferences?: string[];
  budgetLevel?: string;
  transportationPreferences?: string[];
}

// Add new booking-related interfaces
export interface BookingRecommendation {
  type: 'flight' | 'hotel' | 'package';
  destination: string;
  startDate: string;
  endDate: string;
  price: number;
  confidence: number;
  reason: string;
  flightDetails?: {
    airline: string;
    stops: number;
    duration: string;
    departureTime: string;
    arrivalTime: string;
  };
  hotelDetails?: {
    name: string;
    rating: number;
    amenities: string[];
    location: string;
  };
}

export interface TravelRecommendation {
  destination: string;
  reason: string;
  bestTimeToVisit: string;
  estimatedBudget: number;
  activities: string[];
  confidence: number;
  localInsights?: {
    culturalNotes: string[];
    bestTimeToVisit: string;
    localCustoms: string[];
    weatherTips: string[];
  };
  practicalInfo?: {
    visaRequirements: string;
    transportationOptions: string[];
    safetyTips: string[];
    recommendedAreas: string[];
  };
}

export interface TravelPreferences {
  flight: {
    seatPreference: 'window' | 'aisle' | 'any';
    cabinClass: 'economy' | 'premium_economy' | 'business' | 'first';
    mealPreference: string[];
    airlines: string[];
    maxLayovers: number;
  };
  hotel: {
    roomType: string[];
    amenities: string[];
    location: string[];
    priceRange: { min: number; max: number };
    starRating: number;
  };
  ride: {
    vehicleType: string[];
    maxPrice: number;
    preferredProviders: string[];
    accessibility: string[];
  };
}

export interface PricePrediction {
  trend: "rising" | "falling" | "stable";
  confidence: number;
  bestTimeToBook: string;
  predictedLowestPrice: number;
  priceRange: {
    min: number;
    max: number;
  };
}

export interface BudgetPrediction {
  monthlySpending: Array<{
    month: string;
    predicted: number;
    actual?: number;
  }>;
  recommendations: string[];
  savingsPotential: number;
  riskFactors: string[];
}

export interface BudgetPredictionParams {
  destination: string;
  duration: number;
  budget: number;
}

export interface CulturalContext {
  customs: string[];
  etiquette: string[];
  localTips: string[];
  significance: string;
  doAndDonts: {
    do: string[];
    dont: string[];
  };
}

export interface ChatbotResponse {
  message: string;
  type: "general" | "recommendation" | "booking" | "planning" | "cultural" | "practical";
  suggestions?: string[];
  entities?: {
    locations?: string[];
    dates?: string[];
    activities?: string[];
    preferences?: string[];
  };
  recommendations?: TravelRecommendation[];
  context?: {
    previousQuery?: string;
    relatedTopics?: string[];
    followUpQuestions?: string[];
  };
}

export interface LocalEvent {
  name: string;
  type: 'sport' | 'cultural' | 'entertainment';
  date: string;
  venue: string;
  description: string;
  ticketPrice?: number;
  category: string;
}

export interface ProactiveSuggestion {
  destination: string;
  reason: string;
  timing: string;
  confidence: number;
  estimatedBudget: number;
  activities: string[];
  weatherPrediction: string;
  localEvents: LocalEvent[];
  popularAttractions: string[];
  seasonalHighlights: string[];
  eventHighlight?: {
    name: string;
    date: string;
    type: string;
    description: string;
    significance: string;
  };
}

// Define the interface for AI Service Response
export interface AIServiceResponse {
  suggestions: ProactiveSuggestion[];
  userAnalysis?: any;
  note?: string;
  error?: string;
}

class AIService {
  private INTELLIGENT_RESPONSES = {
    greeting: {
      message: "👋 Welcome to your Smart Travel Assistant!\n\n" +
        "I'm here to help create your perfect travel experience with:\n\n" +
        "✈️ Trip Planning\n" +
        "• Personalized itineraries\n" +
        "• Flight and accommodation recommendations\n" +
        "• Transportation arrangements\n\n" +
        "🌍 Destination Insights\n" +
        "• Local attractions and hidden gems\n" +
        "• Cultural experiences\n" +
        "• Weather and best times to visit\n\n" +
        "💰 Smart Travel Management\n" +
        "• Budget optimization\n" +
        "• Booking assistance\n" +
        "• Money-saving tips\n\n" +
        "How can I assist with your travel plans today?",
      type: "general",
      suggestions: [
        "✈️ Plan my next trip",
        "🌟 Popular destinations",
        "💰 Budget planning",
        "🎨 Local experiences"
      ]
    },
    destination_planning: {
      message: (destination: string) => 
        `🌟 Let me help you plan an amazing trip to ${destination}!\n\n` +
        "🏨 Recommended Areas to Stay:\n" +
        "• City Center: Perfect for first-time visitors, close to attractions\n" +
        "• Local Districts: Authentic experience, better prices\n" +
        "• Tourist Zones: Convenient amenities, English widely spoken\n\n" +
        "📅 Ideal Trip Duration:\n" +
        "• Quick Visit: 3-4 days for main highlights\n" +
        "• Full Experience: 7 days to explore thoroughly\n" +
        "• Deep Dive: 10+ days for complete immersion\n\n" +
        "💡 Essential Travel Tips:\n" +
        "• Best time for booking: 3-4 months ahead\n" +
        "• Local transport: Get a tourist pass\n" +
        "• Must-try experiences: Local food tours, cultural shows\n" +
        "• Safety: Keep valuables secure, use registered taxis\n\n" +
        "Would you like specific details about any of these aspects?",
      type: "planning"
    },
    budget_advice: {
      message: (budget: string) => 
        `💰 Smart Budget Planning for Your Trip\n\n` +
        "Daily Cost Breakdown:\n" +
        "🏨 Accommodation (35%)\n" +
        "• Budget: Hostels & guesthouses\n" +
        "• Mid-range: 3-star hotels\n" +
        "• Luxury: 4-5 star resorts\n\n" +
        "🍽️ Food & Dining (25%)\n" +
        "• Breakfast: $5-15\n" +
        "• Lunch: $10-20\n" +
        "• Dinner: $15-30\n\n" +
        "🎯 Activities (20%)\n" +
        "• Tours: $30-100\n" +
        "• Attractions: $15-25\n" +
        "• Entertainment: $20-40\n\n" +
        "🚗 Transportation (15%)\n" +
        "• Local transit: $5-10/day\n" +
        "• Taxis/Uber: $10-30/day\n\n" +
        "💡 Money-Saving Tips:\n" +
        "• Book flights on Tuesdays/Wednesdays\n" +
        "• Use local transport apps\n" +
        "• Get city tourist cards\n" +
        "• Eat at local markets\n" +
        "• Book accommodations in advance\n\n" +
        "Would you like a detailed budget plan for specific destinations?",
      type: "practical"
    },
    local_experience: {
      message: (location: string) => 
        `🌟 Experience ${location} Like a Local!\n\n` +
        "🍳 Authentic Food Adventures:\n" +
        "• Morning markets: Fresh local breakfast\n" +
        "• Street food tours: Traditional snacks\n" +
        "• Family restaurants: Home-style cooking\n" +
        "• Cooking classes: Learn local recipes\n\n" +
        "🎭 Cultural Immersion:\n" +
        "• Traditional performances\n" +
        "• Local festivals and events\n" +
        "• Artisan workshops\n" +
        "• Community meetups\n\n" +
        "🗺️ Hidden Gems:\n" +
        "• Secret viewpoints\n" +
        "• Local-favorite cafes\n" +
        "• Authentic craft shops\n" +
        "• Neighborhood parks\n\n" +
        "💡 Local Tips:\n" +
        "• Best times to visit attractions\n" +
        "• Local customs and etiquette\n" +
        "• Transportation shortcuts\n" +
        "• Safety recommendations\n\n" +
        "Would you like specific recommendations for any of these categories?",
      type: "cultural"
    }
  };

  private generateIntelligentResponse(message: string, context?: any): ChatbotResponse {
    const terms = message.toLowerCase().split(' ');

    // Budget queries
    if (terms.some(term => ['budget', 'cost', 'price', 'expensive', 'cheap', 'money', 'spend'].includes(term))) {
      return {
        message: this.INTELLIGENT_RESPONSES.budget_advice.message("your planned"),
        type: "practical",
        suggestions: [
          "💰 Daily budget breakdown",
          "🏨 Accommodation costs",
          "✈️ Transportation expenses",
          "🍽️ Dining costs"
        ],
        context: {
          followUpQuestions: [
            "What's your total budget range?",
            "How long are you planning to stay?",
            "What's your preferred accommodation type?",
            "Are you interested in luxury or budget options?"
          ]
        }
      };
    }

    // Destination planning
    if (terms.some(term => ['visit', 'go', 'travel', 'destination', 'where', 'place', 'country', 'city'].includes(term))) {
      const destination = terms.find(term => 
        term.length > 3 && 
        !['visit', 'go', 'travel', 'destination', 'want', 'plan', 'where', 'place'].includes(term)
      ) || 'your destination';

      return {
        message: this.INTELLIGENT_RESPONSES.destination_planning.message(destination),
        type: "planning",
        suggestions: [
          "🗺️ Best areas to stay",
          "📅 Trip duration advice",
          "🎯 Must-see attractions",
          "🚗 Getting around"
        ],
        context: {
          followUpQuestions: [
            "When are you planning to visit?",
            "What's your preferred travel style?",
            "Are you interested in specific attractions?",
            "Do you have any dietary requirements?"
          ]
        }
      };
    }

    // Local experiences and culture
    if (terms.some(term => ['local', 'culture', 'food', 'experience', 'authentic', 'traditional'].includes(term))) {
      return {
        message: this.INTELLIGENT_RESPONSES.local_experience.message(context?.location || 'your destination'),
        type: "cultural",
        suggestions: [
          "🍳 Local food guide",
          "🎭 Cultural activities",
          "🗺️ Hidden gems",
          "🎨 Traditional arts"
        ],
        context: {
          followUpQuestions: [
            "What types of local experiences interest you most?",
            "Would you like to learn about local festivals?",
            "Are you interested in cooking classes or food tours?",
            "Would you like to meet local artisans?"
          ]
        }
      };
    }

    // Default welcome response
    return this.INTELLIGENT_RESPONSES.greeting;
  }

  async getChatbotResponse(
    message: string,
    currentLocation?: string,
    chatHistory?: Array<{ role: "user" | "assistant"; content: string }>,
    preferences?: any
  ): Promise<ChatbotResponse> {
    try {
      return this.generateIntelligentResponse(message, {
        location: currentLocation,
        history: chatHistory,
        preferences
      });
    } catch (error) {
      console.error('Chatbot error:', error);
      return this.INTELLIGENT_RESPONSES.greeting;
    }
  }
  
  async getPersonalizedRecommendations(
    user: User,
    pastBookings: (FlightBooking | HotelBooking)[]
  ): Promise<TravelRecommendation[]> {
    const response = await apiRequest('POST', '/api/ai/recommendations', {
      userPreferences: user.preferences,
      pastBookings,
    });

    if (!response.ok) {
      throw new Error('Failed to get travel recommendations');
    }

    const data = await response.json();
    return data.recommendations;
  }

  async predictPrices(
    origin: string,
    destination: string,
    date: string,
    preferences?: TravelPreferences
  ): Promise<PricePrediction> {
    const response = await apiRequest('POST', '/api/ai/predict-prices', {
      origin,
      destination,
      date,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Price prediction failed');
    }

    const data = await response.json();
    return data.prediction;
  }

  async generateTravelTips(
    destination: string,
    travelDates: { start: string; end: string },
    preferences: TravelPreferences
  ): Promise<string[]> {
    const response = await apiRequest('POST', '/api/ai/travel-tips', {
      destination,
      travelDates,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Failed to generate travel tips');
    }

    const data = await response.json();
    return data.tips;
  }

  async optimizeItinerary(
    bookings: (FlightBooking | HotelBooking)[],
    preferences: TravelPreferences
  ): Promise<{
    optimizedBookings: (FlightBooking | HotelBooking)[];
    suggestedChanges: string[];
    potentialSavings: number;
  }> {
    const response = await apiRequest('POST', '/api/ai/optimize-itinerary', {
      bookings,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Itinerary optimization failed');
    }

    const data = await response.json();
    return data.optimization;
  }

  async translateText(text: string, targetLanguage: string): Promise<string> {
    const response = await apiRequest('POST', '/api/translate', {
      text,
      targetLanguage,
    });

    if (!response.ok) {
      throw new Error('Translation failed');
    }

    const data = await response.json();
    return data.translation;
  }

  async analyzeSentiment(feedback: string): Promise<{
    sentiment: "positive" | "negative" | "neutral";
    score: number;
    keyTopics: string[];
  }> {
    const response = await apiRequest('POST', '/api/ai/analyze-sentiment', {
      feedback,
    });

    if (!response.ok) {
      throw new Error('Sentiment analysis failed');
    }

    const data = await response.json();
    return data.analysis;
  }

  async predictBudget(params: BudgetPredictionParams): Promise<BudgetPrediction> {
    const response = await apiRequest('POST', '/api/ai/predict-budget', {
      ...params,
      timestamp: new Date().toISOString(),
      currency: 'USD',
    });

    if (!response.ok) {
      throw new Error('Budget prediction failed');
    }

    const data = await response.json();
    return data.prediction;
  }

  async getCulturalInsights(location: string): Promise<CulturalContext> {
    try {
      const response = await apiRequest('POST', '/api/ai/cultural-insights', {
        location,
        timestamp: new Date().toISOString(),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to get cultural insights');
      }

      const data = await response.json();
      return data.insights;
    } catch (error) {
      console.error('Cultural insights error:', error);
      throw new Error(error instanceof Error ? error.message : 'Failed to get cultural insights');
    }
  }

  // Define the return type for getProactiveSuggestions to match frontend expectations
  async getProactiveSuggestions(): Promise<AIServiceResponse> {
    try {
      const response = await apiRequest('GET', '/api/ai/proactive-suggestions');

      if (!response.ok) {
        // Check for specific error types
        if (response.status === 429) {
          throw new Error('AI service rate limit exceeded. Please try again later.');
        } else if (response.status === 403) {
          throw new Error('API key or authorization error. Contact support for assistance.');
        }
        
        // Try to parse error details from response
        try {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to get proactive suggestions');
        } catch (jsonError) {
          // If we can't parse JSON, throw a generic error with the status
          throw new Error(`Failed to get proactive suggestions (Status: ${response.status})`);
        }
      }

      const data = await response.json();
      
      // If the server returns the data in the expected format, use it
      if (data.suggestions) {
        return data;
      }
      
      // Otherwise, format the data to match our interface
      return {
        suggestions: Array.isArray(data) ? data : [],
        note: data.note || '',
        userAnalysis: data.userAnalysis
      };
    } catch (error) {
      console.error('Error fetching proactive suggestions:', error);
      // Return an object with empty suggestions and the error message
      return {
        suggestions: [],
        note: error instanceof Error ? error.message : 'Unknown error occurred',
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }

  async getLocalEvents(location: string, dates: { start: string; end: string }): Promise<LocalEvent[]> {
    const response = await apiRequest('POST', '/api/ai/local-events', {
      location,
      dates,
    });

    if (!response.ok) {
      throw new Error('Failed to get local events');
    }

    const data = await response.json();
    return data.events;
  }

  async getSmartBookingRecommendations(
    destination: string,
    dates: { start: string; end: string },
    preferences: TravelPreferences
  ): Promise<BookingRecommendation[]> {
    const response = await apiRequest('POST', '/api/ai/smart-booking', {
      destination,
      dates,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Failed to get smart booking recommendations');
    }

    const data = await response.json();
    return data.recommendations;
  }

  async analyzeTravelTrends(destination: string): Promise<{
    bestTimeToBook: string;
    priceHistory: Array<{ date: string; price: number }>;
    pricePrediction: {
      nextWeek: number;
      nextMonth: number;
      trend: 'rising' | 'falling' | 'stable';
    };
  }> {
    const response = await apiRequest('POST', '/api/ai/travel-trends', {
      destination,
      timestamp: new Date().toISOString(),
    });

    if (!response.ok) {
      throw new Error('Failed to analyze travel trends');
    }

    const data = await response.json();
    return data.trends;
  }
}

export const aiService = new AIService();