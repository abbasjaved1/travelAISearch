export interface Airport {
  code: string;
  name: string;
  city: string;
  country: string;
  continent?: string;
  latitude?: number;
  longitude?: number;
  timezone?: string;
}

export const airports: Airport[] = [
  {
    code: "JFK",
    name: "John F. Kennedy International Airport",
    city: "New York",
    country: "United States",
    continent: "North America",
    latitude: 40.6413,
    longitude: -73.7781,
    timezone: "America/New_York"
  },
  {
    code: "LAX",
    name: "Los Angeles International Airport",
    city: "Los Angeles",
    country: "United States",
    continent: "North America",
    latitude: 33.9416,
    longitude: -118.4085,
    timezone: "America/Los_Angeles"
  },
  {
    code: "SFO",
    name: "San Francisco International Airport",
    city: "San Francisco",
    country: "United States",
    continent: "North America",
    latitude: 37.6213,
    longitude: -122.3790,
    timezone: "America/Los_Angeles"
  },
  {
    code: "ORD",
    name: "O'Hare International Airport",
    city: "Chicago",
    country: "United States",
    continent: "North America",
    latitude: 41.9742,
    longitude: -87.9073,
    timezone: "America/Chicago"
  },
  {
    code: "MIA",
    name: "Miami International Airport",
    city: "Miami",
    country: "United States",
    continent: "North America",
    latitude: 25.7932,
    longitude: -80.2906,
    timezone: "America/New_York"
  },
  {
    code: "LHR",
    name: "Heathrow Airport",
    city: "London",
    country: "United Kingdom",
    continent: "Europe",
    latitude: 51.4700,
    longitude: -0.4543,
    timezone: "Europe/London"
  },
  {
    code: "CDG",
    name: "Charles de Gaulle Airport",
    city: "Paris",
    country: "France",
    continent: "Europe",
    latitude: 49.0097,
    longitude: 2.5479,
    timezone: "Europe/Paris"
  },
  {
    code: "FRA",
    name: "Frankfurt Airport",
    city: "Frankfurt",
    country: "Germany",
    continent: "Europe",
    latitude: 50.0379,
    longitude: 8.5622,
    timezone: "Europe/Berlin"
  },
  {
    code: "AMS",
    name: "Amsterdam Airport Schiphol",
    city: "Amsterdam",
    country: "Netherlands",
    continent: "Europe",
    latitude: 52.3105,
    longitude: 4.7683,
    timezone: "Europe/Amsterdam"
  },
  {
    code: "MAD",
    name: "Adolfo Suárez Madrid–Barajas Airport",
    city: "Madrid",
    country: "Spain",
    continent: "Europe",
    latitude: 40.4983,
    longitude: -3.5676,
    timezone: "Europe/Madrid"
  },
  {
    code: "BCN",
    name: "Barcelona–El Prat Airport",
    city: "Barcelona",
    country: "Spain",
    continent: "Europe",
    latitude: 41.2974,
    longitude: 2.0833,
    timezone: "Europe/Madrid"
  },
  {
    code: "FCO",
    name: "Leonardo da Vinci–Fiumicino Airport",
    city: "Rome",
    country: "Italy",
    continent: "Europe",
    latitude: 41.8045,
    longitude: 12.2508,
    timezone: "Europe/Rome"
  },
  {
    code: "ATH",
    name: "Athens International Airport",
    city: "Athens",
    country: "Greece",
    continent: "Europe",
    latitude: 37.9364,
    longitude: 23.9445,
    timezone: "Europe/Athens"
  },
  {
    code: "IST",
    name: "Istanbul Airport",
    city: "Istanbul",
    country: "Turkey",
    continent: "Europe",
    latitude: 41.2608,
    longitude: 28.7418,
    timezone: "Europe/Istanbul"
  },
  {
    code: "HND",
    name: "Haneda Airport",
    city: "Tokyo",
    country: "Japan",
    continent: "Asia",
    latitude: 35.5494,
    longitude: 139.7798,
    timezone: "Asia/Tokyo"
  },
  {
    code: "NRT",
    name: "Narita International Airport",
    city: "Tokyo",
    country: "Japan",
    continent: "Asia",
    latitude: 35.7647,
    longitude: 140.3864,
    timezone: "Asia/Tokyo"
  },
  {
    code: "PEK",
    name: "Beijing Capital International Airport",
    city: "Beijing",
    country: "China",
    continent: "Asia",
    latitude: 40.0799,
    longitude: 116.6031,
    timezone: "Asia/Shanghai"
  },
  {
    code: "PVG",
    name: "Shanghai Pudong International Airport",
    city: "Shanghai",
    country: "China",
    continent: "Asia",
    latitude: 31.1443,
    longitude: 121.8083,
    timezone: "Asia/Shanghai"
  },
  {
    code: "HKG",
    name: "Hong Kong International Airport",
    city: "Hong Kong",
    country: "Hong Kong",
    continent: "Asia",
    latitude: 22.3080,
    longitude: 113.9185,
    timezone: "Asia/Hong_Kong"
  },
  {
    code: "SIN",
    name: "Singapore Changi Airport",
    city: "Singapore",
    country: "Singapore",
    continent: "Asia",
    latitude: 1.3644,
    longitude: 103.9915,
    timezone: "Asia/Singapore"
  },
  {
    code: "BKK",
    name: "Suvarnabhumi Airport",
    city: "Bangkok",
    country: "Thailand",
    continent: "Asia",
    latitude: 13.6900,
    longitude: 100.7501,
    timezone: "Asia/Bangkok"
  },
  {
    code: "KUL",
    name: "Kuala Lumpur International Airport",
    city: "Kuala Lumpur",
    country: "Malaysia",
    continent: "Asia",
    latitude: 2.7456,
    longitude: 101.7099,
    timezone: "Asia/Kuala_Lumpur"
  },
  {
    code: "DEL",
    name: "Indira Gandhi International Airport",
    city: "Delhi",
    country: "India",
    continent: "Asia",
    latitude: 28.5562,
    longitude: 77.1000,
    timezone: "Asia/Kolkata"
  },
  {
    code: "BOM",
    name: "Chhatrapati Shivaji Maharaj International Airport",
    city: "Mumbai",
    country: "India",
    continent: "Asia",
    latitude: 19.0896,
    longitude: 72.8656,
    timezone: "Asia/Kolkata"
  },
  {
    code: "DXB",
    name: "Dubai International Airport",
    city: "Dubai",
    country: "United Arab Emirates",
    continent: "Asia",
    latitude: 25.2532,
    longitude: 55.3657,
    timezone: "Asia/Dubai"
  },
  {
    code: "DOH",
    name: "Hamad International Airport",
    city: "Doha",
    country: "Qatar",
    continent: "Asia",
    latitude: 25.2609,
    longitude: 51.6138,
    timezone: "Asia/Qatar"
  },
  {
    code: "SYD",
    name: "Sydney Airport",
    city: "Sydney",
    country: "Australia",
    continent: "Oceania",
    latitude: -33.9399,
    longitude: 151.1753,
    timezone: "Australia/Sydney"
  },
  {
    code: "MEL",
    name: "Melbourne Airport",
    city: "Melbourne",
    country: "Australia",
    continent: "Oceania",
    latitude: -37.6690,
    longitude: 144.8410,
    timezone: "Australia/Melbourne"
  },
  {
    code: "AKL",
    name: "Auckland Airport",
    city: "Auckland",
    country: "New Zealand",
    continent: "Oceania",
    latitude: -37.0082,
    longitude: 174.7850,
    timezone: "Pacific/Auckland"
  },
  {
    code: "JNB",
    name: "O. R. Tambo International Airport",
    city: "Johannesburg",
    country: "South Africa",
    continent: "Africa",
    latitude: -26.1367,
    longitude: 28.2411,
    timezone: "Africa/Johannesburg"
  },
  {
    code: "CPT",
    name: "Cape Town International Airport",
    city: "Cape Town",
    country: "South Africa",
    continent: "Africa",
    latitude: -33.9715,
    longitude: 18.6021,
    timezone: "Africa/Johannesburg"
  },
  {
    code: "CAI",
    name: "Cairo International Airport",
    city: "Cairo",
    country: "Egypt",
    continent: "Africa",
    latitude: 30.1219,
    longitude: 31.4056,
    timezone: "Africa/Cairo"
  },
  {
    code: "LOS",
    name: "Murtala Muhammed International Airport",
    city: "Lagos",
    country: "Nigeria",
    continent: "Africa",
    latitude: 6.5774,
    longitude: 3.3215,
    timezone: "Africa/Lagos"
  },
  {
    code: "NBO",
    name: "Jomo Kenyatta International Airport",
    city: "Nairobi",
    country: "Kenya",
    continent: "Africa",
    latitude: -1.3192,
    longitude: 36.9278,
    timezone: "Africa/Nairobi"
  },
  {
    code: "GRU",
    name: "São Paulo–Guarulhos International Airport",
    city: "São Paulo",
    country: "Brazil",
    continent: "South America",
    latitude: -23.4356,
    longitude: -46.4731,
    timezone: "America/Sao_Paulo"
  },
  {
    code: "EZE",
    name: "Ministro Pistarini International Airport",
    city: "Buenos Aires",
    country: "Argentina",
    continent: "South America",
    latitude: -34.8222,
    longitude: -58.5358,
    timezone: "America/Argentina/Buenos_Aires"
  },
  {
    code: "SCL",
    name: "Santiago International Airport",
    city: "Santiago",
    country: "Chile",
    continent: "South America",
    latitude: -33.3930,
    longitude: -70.7858,
    timezone: "America/Santiago"
  },
  {
    code: "BOG",
    name: "El Dorado International Airport",
    city: "Bogotá",
    country: "Colombia",
    continent: "South America",
    latitude: 4.7016,
    longitude: -74.1469,
    timezone: "America/Bogota"
  },
  {
    code: "LIM",
    name: "Jorge Chávez International Airport",
    city: "Lima",
    country: "Peru",
    continent: "South America",
    latitude: -12.0219,
    longitude: -77.1143,
    timezone: "America/Lima"
  },
  {
    code: "MEX",
    name: "Mexico City International Airport",
    city: "Mexico City",
    country: "Mexico",
    continent: "North America",
    latitude: 19.4363,
    longitude: -99.0721,
    timezone: "America/Mexico_City"
  },
  {
    code: "YYZ",
    name: "Toronto Pearson International Airport",
    city: "Toronto",
    country: "Canada",
    continent: "North America",
    latitude: 43.6777,
    longitude: -79.6248,
    timezone: "America/Toronto"
  },
  {
    code: "YVR",
    name: "Vancouver International Airport",
    city: "Vancouver",
    country: "Canada",
    continent: "North America",
    latitude: 49.1967,
    longitude: -123.1815,
    timezone: "America/Vancouver"
  },
  {
    code: "YUL",
    name: "Montréal–Trudeau International Airport",
    city: "Montreal",
    country: "Canada",
    continent: "North America",
    latitude: 45.4706,
    longitude: -73.7408,
    timezone: "America/Toronto"
  },
  {
    code: "ATL",
    name: "Hartsfield–Jackson Atlanta International Airport",
    city: "Atlanta",
    country: "United States",
    continent: "North America",
    latitude: 33.6407,
    longitude: -84.4277,
    timezone: "America/New_York"
  },
  {
    code: "DFW",
    name: "Dallas/Fort Worth International Airport",
    city: "Dallas",
    country: "United States",
    continent: "North America",
    latitude: 32.8998,
    longitude: -97.0403,
    timezone: "America/Chicago"
  },
  {
    code: "DEN",
    name: "Denver International Airport",
    city: "Denver",
    country: "United States",
    continent: "North America",
    latitude: 39.8561,
    longitude: -104.6737,
    timezone: "America/Denver"
  },
  {
    code: "SEA",
    name: "Seattle-Tacoma International Airport",
    city: "Seattle",
    country: "United States",
    continent: "North America",
    latitude: 47.4502,
    longitude: -122.3088,
    timezone: "America/Los_Angeles"
  },
  {
    code: "BOS",
    name: "Boston Logan International Airport",
    city: "Boston",
    country: "United States",
    continent: "North America",
    latitude: 42.3656,
    longitude: -71.0096,
    timezone: "America/New_York"
  },
  {
    code: "LAS",
    name: "Harry Reid International Airport",
    city: "Las Vegas",
    country: "United States",
    continent: "North America",
    latitude: 36.0840,
    longitude: -115.1537,
    timezone: "America/Los_Angeles"
  },
  {
    code: "MCO",
    name: "Orlando International Airport",
    city: "Orlando",
    country: "United States",
    continent: "North America",
    latitude: 28.4312,
    longitude: -81.3081,
    timezone: "America/New_York"
  },
  {
    code: "SXR",
    name: "Sheikh ul-Alam International Airport",
    city: "Srinagar",
    country: "India",
    continent: "Asia",
    latitude: 33.9871,
    longitude: 74.7747,
    timezone: "Asia/Kolkata"
  },
  {
    code: "JAI",
    name: "Jaipur International Airport",
    city: "Jaipur",
    country: "India",
    continent: "Asia",
    latitude: 26.8240,
    longitude: 75.8120,
    timezone: "Asia/Kolkata"
  },
  {
    code: "BLR",
    name: "Kempegowda International Airport",
    city: "Bangalore",
    country: "India",
    continent: "Asia",
    latitude: 13.1979,
    longitude: 77.7063,
    timezone: "Asia/Kolkata"
  },
  {
    code: "HYD",
    name: "Rajiv Gandhi International Airport",
    city: "Hyderabad",
    country: "India",
    continent: "Asia",
    latitude: 17.2403,
    longitude: 78.4294,
    timezone: "Asia/Kolkata"
  },
  {
    code: "CCU",
    name: "Netaji Subhas Chandra Bose International Airport",
    city: "Kolkata",
    country: "India",
    continent: "Asia",
    latitude: 22.6520,
    longitude: 88.4467,
    timezone: "Asia/Kolkata"
  },
  {
    code: "MAA",
    name: "Chennai International Airport",
    city: "Chennai",
    country: "India",
    continent: "Asia",
    latitude: 12.9941,
    longitude: 80.1709,
    timezone: "Asia/Kolkata"
  },
  {
    code: "GOI",
    name: "Goa International Airport",
    city: "Goa",
    country: "India",
    continent: "Asia",
    latitude: 15.3808,
    longitude: 73.8314,
    timezone: "Asia/Kolkata"
  }
];