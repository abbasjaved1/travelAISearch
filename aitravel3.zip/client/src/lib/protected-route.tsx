import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route, useLocation } from "wouter";
import { ReactNode, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

interface ProtectedRouteProps {
  path: string;
  component: () => React.JSX.Element;
}

export function ProtectedRoute({ path, component: Component }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const [loadingTimeout, setLoadingTimeout] = useState(false);
  const [, setLocation] = useLocation();

  // Set a timeout to prevent infinite loading
  useEffect(() => {
    if (isLoading) {
      const timer = setTimeout(() => {
        setLoadingTimeout(true);
      }, 5000); // 5 seconds timeout

      return () => clearTimeout(timer);
    }
  }, [isLoading]);

  // If still loading but not timed out yet
  if (isLoading && !loadingTimeout) {
    return (
      <Route path={path}>
        <div className="flex flex-col items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-border mb-4" />
          <p className="text-lg font-medium mb-2">Loading your travel experience...</p>
          <p className="text-sm text-muted-foreground">Please wait while we prepare your journey</p>
        </div>
      </Route>
    );
  }

  // If loading timed out, show options to continue
  if (loadingTimeout) {
    return (
      <Route path={path}>
        <div className="flex flex-col items-center justify-center min-h-screen p-4">
          <div className="max-w-md w-full bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-lg">
            <h2 className="text-xl font-bold mb-4">Taking longer than expected...</h2>
            <p className="mb-6">We're having trouble connecting to our servers. You can:</p>
            
            <div className="space-y-4">
              <Button 
                className="w-full" 
                variant="default"
                onClick={() => setLocation("/auth")}
              >
                Sign In
              </Button>
              
              <Button 
                className="w-full" 
                variant="outline"
                onClick={() => setLocation("/destinations/explore")}
              >
                Explore Destinations Without Logging In
              </Button>
              
              <Button 
                className="w-full" 
                variant="ghost"
                onClick={() => window.location.reload()}
              >
                Try Again
              </Button>
            </div>
          </div>
        </div>
      </Route>
    );
  }

  // If not logged in, redirect to auth page
  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  // User is authenticated, render the protected component
  return <Route path={path} component={Component} />;
}