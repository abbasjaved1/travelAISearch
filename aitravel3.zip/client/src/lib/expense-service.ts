import { apiRequest } from './api';
import { Expense } from '@shared/schema';

interface ExpenseAnalytics {
  totalSpent: number;
  categorySummary: Record<string, number>;
  timeframeSummary: Array<{ date: string, amount: number }>;
  topCategories: Array<{ category: string, amount: number, percentage: number }>;
}

interface ExpenseAnalyticsResponse {
  expenses: Expense[];
  analytics: ExpenseAnalytics;
}

/**
 * Fetch user expenses from flight, hotel, and ride bookings
 */
export async function getUserExpenses(
  startDate?: string,
  endDate?: string
): Promise<Expense[]> {
  let url = '/api/expenses';
  
  // Add query parameters if provided
  if (startDate || endDate) {
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    url = `${url}?${params.toString()}`;
  }
  
  try {
    const response = await apiRequest('GET', url);
    const data = await response.json();
    return data as Expense[];
  } catch (error) {
    console.error('Error fetching user expenses:', error);
    return [];
  }
}

/**
 * Fetch both expenses and analytics data in a single request
 */
export async function getExpenseAnalytics(
  startDate?: string,
  endDate?: string,
  timeframe: 'daily' | 'weekly' | 'monthly' = 'monthly'
): Promise<ExpenseAnalyticsResponse> {
  let url = '/api/expenses/analytics';
  
  // Add query parameters if provided
  const params = new URLSearchParams();
  if (startDate) params.append('startDate', startDate);
  if (endDate) params.append('endDate', endDate);
  params.append('timeframe', timeframe);
  url = `${url}?${params.toString()}`;
  
  try {
    const response = await apiRequest('GET', url);
    const data = await response.json();
    return data as ExpenseAnalyticsResponse;
  } catch (error) {
    console.error('Error fetching expense analytics:', error);
    // Return default empty structure
    return {
      expenses: [],
      analytics: {
        totalSpent: 0,
        categorySummary: {
          accommodation: 0,
          transportation: 0,
          food: 0,
          activities: 0,
          other: 0
        },
        timeframeSummary: [],
        topCategories: []
      }
    };
  }
}

/**
 * Group expenses by category
 */
export function groupExpensesByCategory(expenses: Expense[]): Record<string, number> {
  const categories = {
    accommodation: 0,
    transportation: 0,
    food: 0,
    activities: 0,
    other: 0
  };
  
  expenses.forEach(expense => {
    if (expense.category in categories) {
      categories[expense.category as keyof typeof categories] += expense.amount;
    } else {
      categories.other += expense.amount;
    }
  });
  
  return categories;
}

/**
 * Get expenses by timeframe (daily, weekly, monthly)
 */
export function getExpensesByTimeframe(
  expenses: Expense[],
  timeframe: 'daily' | 'weekly' | 'monthly'
): Array<{ date: string, amount: number }> {
  const sortedExpenses = [...expenses].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  if (timeframe === 'daily') {
    // Group by day
    const dailyData: {[key: string]: number} = {};
    sortedExpenses.forEach(expense => {
      const date = new Date(expense.date).toISOString().split('T')[0];
      dailyData[date] = (dailyData[date] || 0) + expense.amount;
    });
    
    return Object.entries(dailyData).map(([date, amount]) => ({ date, amount }));
  } else if (timeframe === 'weekly') {
    // Group by week
    const weeklyData: {[key: string]: number} = {};
    sortedExpenses.forEach(expense => {
      const date = new Date(expense.date);
      const weekNumber = getWeekNumber(date);
      const weekLabel = `Week ${weekNumber}`;
      weeklyData[weekLabel] = (weeklyData[weekLabel] || 0) + expense.amount;
    });
    
    return Object.entries(weeklyData).map(([date, amount]) => ({ date, amount }));
  } else {
    // Group by month
    const monthlyData: {[key: string]: number} = {};
    sortedExpenses.forEach(expense => {
      const date = new Date(expense.date);
      const monthLabel = date.toLocaleString('default', { month: 'short' });
      monthlyData[monthLabel] = (monthlyData[monthLabel] || 0) + expense.amount;
    });
    
    return Object.entries(monthlyData).map(([date, amount]) => ({ date, amount }));
  }
}

/**
 * Helper function to get week number from date
 */
function getWeekNumber(d: Date): number {
  const date = new Date(d.getTime());
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  const week1 = new Date(date.getFullYear(), 0, 4);
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}