import { toast } from "@/hooks/use-toast";

class WebSocketManager {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private messageHandlers: Map<string, (data: any) => void> = new Map();

  connect(userId?: number, username?: string) {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/chat`;

      console.log('Connecting to WebSocket:', wsUrl);
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('WebSocket connected');
        this.reconnectAttempts = 0;

        // Send authentication message if user credentials are provided
        if (userId && username) {
          this.sendMessage('auth', {
            senderId: userId,
            senderName: username,
            timestamp: new Date().toISOString()
          });
        }

        toast({
          title: "Connected",
          description: "Chat connection established"
        });
      };

      this.ws.onclose = () => {
        console.log('WebSocket disconnected');
        this.attemptReconnect(userId, username);
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast({
          title: "Connection Error",
          description: "Having trouble connecting to the server. Retrying...",
          variant: "destructive",
        });
      };

      this.ws.onmessage = this.handleMessage.bind(this);
    } catch (error) {
      console.error('WebSocket connection error:', error);
      this.attemptReconnect(userId, username);
    }
  }

  private handleMessage(event: MessageEvent) {
    try {
      const data = JSON.parse(event.data);
      console.log('Received message:', data.type);

      // Handle different message types
      switch (data.type) {
        case 'status':
          // Handle status updates (online users, typing status)
          window.dispatchEvent(new CustomEvent('chatStatus', { detail: data }));
          break;
        case 'message':
          // Handle chat messages
          window.dispatchEvent(new CustomEvent('chatMessage', { detail: data }));
          break;
        case 'location':
          // Handle location updates
          window.dispatchEvent(new CustomEvent('locationUpdate', { detail: data }));
          break;
        case 'receipt':
          // Handle message receipts
          window.dispatchEvent(new CustomEvent('messageReceipt', { detail: data }));
          break;
        case 'error':
          this.handleError(data);
          break;
      }

      // Call any registered handlers for this message type
      const handler = this.messageHandlers.get(data.type);
      if (handler) {
        handler(data);
      }
    } catch (error) {
      console.error('Error handling message:', error);
    }
  }

  private handleError(data: any) {
    toast({
      title: "Error",
      description: data.message || "An error occurred",
      variant: "destructive",
    });
  }

  private attemptReconnect(userId?: number, username?: string) {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      toast({
        title: "Connection Failed",
        description: "Could not reconnect to the server. Please refresh the page.",
        variant: "destructive",
      });
      return;
    }

    this.reconnectTimeout = setTimeout(() => {
      this.reconnectAttempts++;
      console.log(`Attempting reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
      this.connect(userId, username);
    }, Math.min(1000 * Math.pow(2, this.reconnectAttempts), 10000));
  }

  sendMessage(type: string, data: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      try {
        const message = JSON.stringify({ type, ...data });
        console.log('Sending message:', type);
        this.ws.send(message);
      } catch (error) {
        console.error('Error sending message:', error);
        toast({
          title: "Error",
          description: "Failed to send message",
          variant: "destructive",
        });
      }
    } else {
      console.error('WebSocket is not connected');
      toast({
        title: "Not Connected",
        description: "Please wait while we reconnect...",
        variant: "destructive",
      });
    }
  }

  registerHandler(type: string, handler: (data: any) => void) {
    this.messageHandlers.set(type, handler);
  }

  unregisterHandler(type: string) {
    this.messageHandlers.delete(type);
  }

  disconnect() {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.messageHandlers.clear();
  }

  isConnected() {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}

export const websocketManager = new WebSocketManager();