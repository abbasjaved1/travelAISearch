import { io } from 'socket.io-client';

// Add TypeScript declaration for window property
declare global {
  interface Window {
    __socketConnectionInfo: {
      isCustomDomain: boolean;
      isReplit: boolean;
      protocol: string;
      hostname: string;
      port: string;
      timestamp: string;
    };
  }
}

// Get the socket URL based on environment with improved custom domain support
const getSocketUrl = () => {
  // Force secure connection for custom domain and production
  const isCustomDomain = window.location.hostname.includes('aitravelglobe.com') || 
                         !window.location.hostname.includes('.replit');
  const isReplit = window.location.hostname.includes('.replit.app') || 
                  window.location.hostname.includes('.replit.dev') || 
                  window.location.hostname.includes('.repl.co');
  
  // Always use the protocol from the current window location
  const protocol = window.location.protocol;
  
  // Store the detection results for debugging
  window.__socketConnectionInfo = {
    isCustomDomain,
    isReplit,
    protocol,
    hostname: window.location.hostname,
    port: window.location.port || (protocol === 'https:' ? '443' : '80'),
    timestamp: new Date().toISOString()
  };
  
  console.log('Socket connection info:', window.__socketConnectionInfo);
  
  // Custom domain handling for aitravelglobe.com with explicit port removal
  if (window.location.hostname.includes('aitravelglobe.com')) {
    return `${protocol}//aitravelglobe.com`;
  }
  
  // For all other domains, including custom and Replit domains
  // When running in Replit, use the current window.location.host which already has the correct port
  return window.location.origin;
};

// Log socket URL for debugging
const socketUrl = getSocketUrl();
console.log('Connecting to socket URL:', socketUrl);

// Create socket instance with reconnection options
export const socket = io(socketUrl, {
  reconnectionDelayMax: 10000,      // Maximum delay between reconnection attempts
  reconnectionDelay: 1000,          // Initial delay between reconnection attempts
  reconnectionAttempts: Infinity,   // Keep trying to reconnect indefinitely
  timeout: 20000,                   // Increase connection timeout further
  transports: ['polling', 'websocket'], // Start with polling for better compatibility
  path: '/socket.io',
  autoConnect: true,                // Connect automatically
  withCredentials: true,            // Allow credentials for cross-origin requests
  forceNew: false,                  // Reuse existing connection if possible
  multiplex: true,                  // Allow multiplexing
  extraHeaders: {                   // Additional headers for authentication
    'X-Client-Version': '1.0.0',
    'X-Client-Type': 'browser'
  }
});

// Add connection event listeners
socket.on('connect', () => {
  console.log('Socket connected with ID:', socket.id);
  
  // Send a heartbeat every 30 seconds to keep the connection alive
  const heartbeatInterval = setInterval(() => {
    if (socket.connected) {
      const userId = localStorage.getItem('userId');
      if (userId) {
        socket.emit('heartbeat', { userId: parseInt(userId, 10) });
      }
    } else {
      clearInterval(heartbeatInterval);
    }
  }, 30000);
  
  // Clear interval on disconnect
  socket.on('disconnect', () => clearInterval(heartbeatInterval));
});

socket.on('connect_error', (error) => {
  console.error('Socket connection error:', error.message || 'Unknown error');
  
  // Don't attempt reconnect more than once every 5 seconds to prevent flooding
  const lastReconnectAttempt = parseInt(sessionStorage.getItem('lastReconnectAttempt') || '0', 10);
  const now = Date.now();
  
  if (now - lastReconnectAttempt > 5000) {
    console.log('Attempting to reconnect socket after error...');
    sessionStorage.setItem('lastReconnectAttempt', now.toString());
    
    // Smart reconnection strategy
    socket.disconnect();
    
    // Try alternate connection approach after a delay
    setTimeout(() => {
      console.log('Trying to reconnect with alternate transport settings...');
      socket.connect();
    }, 1000);
  }
});

socket.on('disconnect', (reason) => {
  console.log('Socket disconnected:', reason);
  
  // Don't attempt reconnect more than once every 5 seconds
  const lastReconnectAttempt = parseInt(sessionStorage.getItem('lastReconnectAttempt') || '0', 10);
  const now = Date.now();
  
  // If the disconnection was not initiated by the client, try to reconnect
  if ((reason === 'io server disconnect' || reason === 'transport close' || reason === 'transport error') && 
      (now - lastReconnectAttempt > 5000)) {
    console.log('Attempting to reconnect after disconnect...');
    sessionStorage.setItem('lastReconnectAttempt', now.toString());
    socket.connect();
  }
});

// Handle error messages from the server
socket.on('error', (errorData) => {
  console.error('Server socket error:', errorData);
});

// Export helper functions for socket state and control
export const isConnected = () => socket.connected;
export const disconnect = () => socket.disconnect();
export const connect = () => socket.connect();

// Utility function to authenticate the socket connection with user info
export const authenticateSocket = (userId: number, username: string) => {
  if (socket.connected) {
    console.log('Authenticating socket for user:', username);
    socket.emit('auth', { id: userId, username });
    return true;
  } else {
    console.warn('Cannot authenticate: Socket not connected');
    // Try to connect and then authenticate
    socket.connect();
    socket.once('connect', () => {
      console.log('Socket connected, now authenticating');
      socket.emit('auth', { id: userId, username });
    });
    return false;
  }
};

// Utility function to join a chat room
export const joinRoom = (roomId: string, roomName: string) => {
  if (!socket.connected) {
    console.warn('Cannot join room: Socket not connected');
    return false;
  }
  socket.emit('join_room', { roomId, roomName });
  return true;
};

// Utility function to send a location update
export const updateLocation = (userId: number, location: { lat: number; lng: number }) => {
  if (!socket.connected) {
    console.warn('Cannot update location: Socket not connected');
    return false;
  }
  socket.emit('update_location', { userId, location });
  return true;
};
