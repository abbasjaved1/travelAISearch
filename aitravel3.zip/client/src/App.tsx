import { useState, useEffect, lazy, Suspense } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import { Footer } from "@/components/layout/footer";
import { SplashScreen } from "@/components/ui/splash-screen";
import { LoginSplash } from "@/components/ui/login-splash";
import { OnboardingTutorial } from "@/components/ui/onboarding-tutorial";
import { TranslationBubble } from "@/components/ui/translation-bubble";
import { QuickDialWidget } from "@/components/ui/quick-dial-widget";
import { LoadingIndicator } from "@/components/ui/loading-indicator";
import { usePreloadComponents } from "./hooks/use-preload";
import errorLogger from './lib/errorLogger';

// Lazily load page components to improve initial load time
const NotFound = lazy(() => import("@/pages/not-found"));
const AuthPage = lazy(() => import("@/pages/auth-page"));
const Dashboard = lazy(() => import("@/pages/dashboard"));
const FlightsPage = lazy(() => import("@/pages/flights"));
const NewFlightsPage = lazy(() => import("@/pages/new-flights"));
const MakeMyTripFlightsPage = lazy(() => import("@/pages/makemytrip-flights"));
const TripInspirationPage = lazy(() => import("@/pages/inspiration"));
const FlightSearchPage = lazy(() => import("@/pages/flight-search"));
const FlightDetailsPage = lazy(() => import("@/pages/flight-details"));
const HotelsPage = lazy(() => import("@/pages/hotels"));
const RidesPage = lazy(() => import("@/pages/rides"));
const DiningPage = lazy(() => import("@/pages/dining"));
const ProfilePage = lazy(() => import("@/pages/profile"));
const ProfileCreationPage = lazy(() => import("@/pages/profile-creation"));
const MemoriesPage = lazy(() => import("@/pages/memories"));
const ChatbotPage = lazy(() => import("@/pages/chatbot"));
const BudgetForecastPage = lazy(() => import("@/pages/budget-forecast"));
const TripPlannerPage = lazy(() => import("@/pages/trip-planner"));
const TripPlanningCompletePage = lazy(() => import("@/pages/trip-planning-complete"));
const QuickPlanPage = lazy(() => import("@/pages/trip-planner/quick"));
const DestinationPage = lazy(() => import("@/pages/destinations/[destination]"));
const ExplorePage = lazy(() => import("@/pages/destinations/explore"));
const SoundtrackPage = lazy(() => import("@/pages/soundtrack"));
const InspirationPage = lazy(() => import("@/pages/inspiration"));
const ForgotPasswordPage = lazy(() => import("@/pages/forgot-password"));
const BookingConfirmation = lazy(() => import("@/pages/booking-confirmation"));
const GoogleCallbackHandler = lazy(() => import("@/components/auth/google-callback-handler"));

function Router() {
  console.log('Rendering Router component');
  // Create route components as functions that render the lazy components
  // This fixes TypeScript issues with lazy loaded components
  const renderAuthPage = () => <AuthPage />;
  const renderForgotPassword = () => <ForgotPasswordPage />;
  const renderGoogleCallback = () => <GoogleCallbackHandler />;
  const renderDashboard = () => <Dashboard />;
  const renderFlights = () => <FlightsPage />;
  const renderNewFlights = () => <NewFlightsPage />;
  const renderMakeMyTripFlights = () => <MakeMyTripFlightsPage />;
  const renderFlightSearch = () => <FlightSearchPage />;
  const renderFlightDetails = () => <FlightDetailsPage />;
  const renderHotels = () => <HotelsPage />;
  const renderRides = () => <RidesPage />;
  const renderDining = () => <DiningPage />;
  const renderProfile = () => <ProfilePage />;
  const renderProfileCreation = () => <ProfileCreationPage />;
  const renderMemories = () => <MemoriesPage />;
  const renderChatbot = () => <ChatbotPage />;
  const renderBudgetForecast = () => <BudgetForecastPage />;
  const renderTripPlanner = () => <TripPlannerPage />;
  const renderTripPlanningComplete = () => <TripPlanningCompletePage />;
  const renderQuickPlan = () => <QuickPlanPage />;
  const renderBookingConfirmation = () => <BookingConfirmation />;
  const renderSoundtrack = () => <SoundtrackPage />;
  const renderExplore = () => <ExplorePage />;
  const renderDestination = () => <DestinationPage />;
  const renderInspiration = () => <InspirationPage />;
  const renderNotFound = () => <NotFound />;

  return (
    <Switch>
      <Route path="/auth" component={renderAuthPage} />
      <Route path="/forgot-password" component={renderForgotPassword} />
      <Route path="/google-callback" component={renderGoogleCallback} />
      <ProtectedRoute path="/" component={renderDashboard} />
      <ProtectedRoute path="/flights" component={renderFlights} />
      {/* Temporarily disabled due to issues */}
      {/* <ProtectedRoute path="/new-flights" component={renderNewFlights} /> */}
      <Route path="/makemytrip-flights" component={renderMakeMyTripFlights} />
      <Route path="/flight-search" component={renderFlightSearch} />
      <ProtectedRoute path="/flights/details/:flightNumber" component={renderFlightDetails} />
      <ProtectedRoute path="/hotels" component={renderHotels} />
      <ProtectedRoute path="/rides" component={renderRides} />
      <ProtectedRoute path="/dining" component={renderDining} />
      <ProtectedRoute path="/profile" component={renderProfile} />
      <ProtectedRoute path="/profile/create" component={renderProfileCreation} />
      <ProtectedRoute path="/memories" component={renderMemories} />
      <Route path="/memories/share/:id" component={renderMemories} />
      <ProtectedRoute path="/chatbot" component={renderChatbot} />
      <ProtectedRoute path="/budget-forecast" component={renderBudgetForecast} />
      <ProtectedRoute path="/trip-planner" component={renderTripPlanner} />
      <ProtectedRoute path="/trip-planner/quick" component={renderQuickPlan} />
      <ProtectedRoute path="/trip-planner/complete" component={renderTripPlanningComplete} />
      <ProtectedRoute path="/start-planning" component={renderTripPlanner} />
      <ProtectedRoute path="/booking-confirmation" component={renderBookingConfirmation} />
      <ProtectedRoute path="/soundtrack" component={renderSoundtrack} />
      <ProtectedRoute path="/inspiration" component={renderInspiration} />
      <Route path="/destinations/explore" component={renderExplore} />
      <Route path="/destinations/:destination" component={renderDestination} />
      <Route component={renderNotFound} />
    </Switch>
  );
}

export default function App() {
  const [showSplash, setShowSplash] = useState(() => {
    const hasSeenSplash = sessionStorage.getItem('hasSeenSplash');
    return !hasSeenSplash;
  });

  const [showLoginSplash, setShowLoginSplash] = useState(() => {
    const hasSeenLoginSplash = sessionStorage.getItem('hasSeenLoginSplash');
    return !hasSeenLoginSplash;
  });

  const [showOnboarding, setShowOnboarding] = useState(() => {
    const hasCompletedOnboarding = localStorage.getItem('hasCompletedOnboarding');
    return !hasCompletedOnboarding;
  });

  const [, setLocation] = useLocation();

  // Preload commonly used pages to improve performance after initial load
  usePreloadComponents([
    () => import("@/pages/auth-page"),
    () => import("@/pages/dashboard"),
    () => import("@/pages/destinations/explore"),
    () => import("@/pages/trip-planner"),
  ]);

  useEffect(() => {
    console.log('App component mounted');
    errorLogger.init();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10">
          {/* Emergency Services - Compact top right corner */}
          <div className="fixed top-2 right-2 z-50">
            <QuickDialWidget />
          </div>

          <Suspense fallback={
            <div className="flex flex-col items-center justify-center min-h-screen">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
              <p className="text-lg font-medium">Loading your travel experience...</p>
            </div>
          }>
            <Router />
          </Suspense>

          {/* Other UI components */}
          <div className="fixed bottom-20 right-4 space-y-4 z-40">
            <TranslationBubble />
          </div>

          <Toaster />
          {showSplash && (
            <SplashScreen 
              onDismiss={() => {
                setShowSplash(false);
                sessionStorage.setItem('hasSeenSplash', 'true');
              }}
            />
          )}
          {!showSplash && showLoginSplash && (
            <LoginSplash 
              onDismiss={() => {
                setShowLoginSplash(false);
                sessionStorage.setItem('hasSeenLoginSplash', 'true');
              }}
            />
          )}
          {!showSplash && !showLoginSplash && showOnboarding && (
            <OnboardingTutorial
              onComplete={() => {
                setShowOnboarding(false);
                localStorage.setItem('hasCompletedOnboarding', 'true');
              }}
              onDismiss={() => {
                setShowOnboarding(false);
                localStorage.setItem('hasCompletedOnboarding', 'true');
              }}
            />
          )}
        </div>
        <Footer />
      </AuthProvider>
    </QueryClientProvider>
  );
}