import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const passengerSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  dateOfBirth: z.string().min(1, "Date of birth is required"),
  nationality: z.string().min(2, "Nationality must be at least 2 characters"),
  passportNumber: z.string().min(6, "Passport number must be at least 6 characters"),
  specialRequirements: z.string().optional(),
});

type PassengerFormData = z.infer<typeof passengerSchema>;

interface PassengerDetailsFormProps {
  onSubmit: (data: PassengerFormData[]) => void;
  passengerCount: number;
}

export function PassengerDetailsForm({ onSubmit, passengerCount }: PassengerDetailsFormProps) {
  const [currentPassenger, setCurrentPassenger] = useState(1);
  const [passengers, setPassengers] = useState<PassengerFormData[]>([]);
  const { toast } = useToast();

  const form = useForm<PassengerFormData>({
    resolver: zodResolver(passengerSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      dateOfBirth: "",
      nationality: "",
      passportNumber: "",
      specialRequirements: "",
    },
  });

  const handleSubmit = (data: PassengerFormData) => {
    const updatedPassengers = [...passengers, data];

    if (currentPassenger < passengerCount) {
      setPassengers(updatedPassengers);
      setCurrentPassenger(prev => prev + 1);
      form.reset();
      toast({
        title: `Passenger ${currentPassenger} details saved`,
        description: `Please enter details for passenger ${currentPassenger + 1}`,
      });
    } else {
      onSubmit(updatedPassengers);
    }
  };

  return (
    <Card className="p-6">
      <h2 className="text-2xl font-bold mb-4">
        Passenger {currentPassenger} of {passengerCount}
      </h2>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>First Name</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-white" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Last Name</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-white" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="dateOfBirth"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date of Birth</FormLabel>
                <FormControl>
                  <Input type="date" {...field} className="bg-white" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="nationality"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nationality</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-white" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="passportNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Passport Number</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-white" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="specialRequirements"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Special Requirements (Optional)</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-white" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full bg-[#003580] hover:bg-[#00224f]">
            {currentPassenger === passengerCount ? "Proceed to Payment" : "Next Passenger"}
          </Button>
        </form>
      </Form>
    </Card>
  );
}