import { useState, useEffect } from 'react';
import { Button } from "./button";
import { toast } from "@/hooks/use-toast";
import { 
  Loader2, 
  MapPin, 
  Calendar, 
  Sparkles, 
  Clock, 
  Briefcase, 
  Users, 
  Phone,
  Shield,
  Flame,
  Ambulance,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipTrigger,
  TooltipProvider 
} from "@/components/ui/tooltip";

interface EmergencyContact {
  country: string;
  police: string;
  ambulance: string;
  fire: string;
  general?: string;
}

interface ValidationStatus {
  isValid: boolean;
  correctedNumber?: string;
  message?: string;
  lastVerified: string;
}

// Comprehensive emergency numbers database
const emergencyNumbers: Record<string, EmergencyContact> = {
  'US': {
    country: 'United States',
    police: '911',
    ambulance: '911',
    fire: '911',
    general: '911'
  },
  'GB': {
    country: 'United Kingdom',
    police: '999',
    ambulance: '999',
    fire: '999',
    general: '112'
  },
  'AU': {
    country: 'Australia',
    police: '000',
    ambulance: '000',
    fire: '000',
    general: '112'
  },
  'CA': {
    country: 'Canada',
    police: '911',
    ambulance: '911',
    fire: '911',
    general: '112'
  },
  'NZ': {
    country: 'New Zealand',
    police: '111',
    ambulance: '111',
    fire: '111',
    general: '112'
  },
  'IN': {
    country: 'India',
    police: '100',
    ambulance: '102',
    fire: '101',
    general: '112'
  },
  'JP': {
    country: 'Japan',
    police: '110',
    ambulance: '119',
    fire: '119',
    general: '110'
  },
  'CN': {
    country: 'China',
    police: '110',
    ambulance: '120',
    fire: '119',
    general: '112'
  },
  'SG': {
    country: 'Singapore',
    police: '999',
    ambulance: '995',
    fire: '995',
    general: '112'
  },
  'EU': {
    country: 'European Union',
    police: '112',
    ambulance: '112',
    fire: '112',
    general: '112'
  },
  'default': {
    country: 'International',
    police: '112',
    ambulance: '112',
    fire: '112',
    general: '112'
  }
};

// EU country codes mapping
const euCountries = new Set([
  'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 
  'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 
  'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE'
]);

export function QuickDialWidget() {
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [countryCode, setCountryCode] = useState<string>('default');
  const [validationStatus, setValidationStatus] = useState<Record<string, ValidationStatus>>({});
  const [validating, setValidating] = useState(false);

  useEffect(() => {
    const getLocation = async () => {
      try {
        // Check if geolocation is supported
        if (!navigator.geolocation) {
          console.log('Geolocation is not supported');
          setLoading(false);
          return;
        }

        // Get position with a timeout of 5 seconds
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          const timeoutId = setTimeout(() => {
            reject(new Error('Location request timed out'));
          }, 5000);

          navigator.geolocation.getCurrentPosition(
            (pos) => {
              clearTimeout(timeoutId);
              resolve(pos);
            },
            (err) => {
              clearTimeout(timeoutId);
              reject(err);
            },
            { enableHighAccuracy: false, timeout: 5000, maximumAge: 300000 }
          );
        });

        const { latitude, longitude } = position.coords;
        setLocation({ lat: latitude, lng: longitude });

        try {
          // Use reverse geocoding with a timeout
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);

          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`,
            { signal: controller.signal }
          );
          clearTimeout(timeoutId);

          if (!response.ok) {
            throw new Error('Failed to fetch location details');
          }

          const data = await response.json();
          let country = data.address?.country_code?.toUpperCase() || 'default';

          // Check if it's an EU country
          if (euCountries.has(country)) {
            country = 'EU';
          }

          // Set the country code if we have emergency numbers for it, otherwise use default
          setCountryCode(country in emergencyNumbers ? country : 'default');

          // After setting country code, validate the numbers
          if (country) {
            await validateEmergencyNumbers(country);
          }

          // Show location found toast
          toast({
            title: "Location Found",
            description: `Emergency numbers set for ${emergencyNumbers[country in emergencyNumbers ? country : 'default'].country}`,
          });
        } catch (error) {
          // Handle reverse geocoding failure silently
          setCountryCode('default');
        }
      } catch (error) {
        // Set default country code silently without console logging
        setCountryCode('default');
        toast({
          title: "Location Services Unavailable",
          description: "Using international emergency numbers",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    getLocation();
  }, []);

  const validateEmergencyNumbers = async (country: string) => {
    try {
      setValidating(true);
      const response = await fetch('/api/validate-emergency-numbers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ countryCode: country })
      });

      if (!response.ok) {
        throw new Error('Failed to validate emergency numbers');
      }

      const results = await response.json();
      setValidationStatus(results);

      // Show validation completion toast
      const invalidNumbers = Object.values(results).filter((r: any) => !r.isValid).length;
      if (invalidNumbers > 0) {
        toast({
          title: "Emergency Numbers Verified",
          description: `Found ${invalidNumbers} number(s) that need updating`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Emergency Numbers Verified",
          description: "All numbers are valid and up-to-date",
        });
      }
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        title: "Validation Error",
        description: "Could not verify emergency numbers",
        variant: "destructive",
      });
    } finally {
      setValidating(false);
    }
  };

  const handleEmergencyCall = async (number: string, service: string) => {
    try {
      // Validate the number before calling
      const response = await fetch('/api/validate-emergency-number', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          number,
          type: service.toLowerCase(),
          countryCode
        })
      });

      if (!response.ok) {
        // If validation fails, use the original number
        window.location.href = `tel:${number}`;
        return;
      }

      const validation = await response.json();

      if (!validation.isValid && validation.correctedNumber) {
        // Use the corrected number instead
        number = validation.correctedNumber;
        toast({
          title: "Updated Emergency Number",
          description: `Using correct number: ${number}`,
        });
      }

      window.location.href = `tel:${number}`;
      toast({
        title: `Calling ${service}`,
        description: `Dialing emergency number: ${number}`,
      });
    } catch (error) {
      console.error('Error making emergency call:', error);
      // If there's any error in validation, default to using the original number
      window.location.href = `tel:${number}`;
      toast({
        title: "Emergency Contact",
        description: `Emergency number for ${service}: ${number}`,
      });
    }
  };

  const getValidationIcon = (service: string) => {
    const status = validationStatus[service.toLowerCase()];
    if (!status) return null;

    return (
      <Tooltip>
        <TooltipTrigger>
          {status.isValid ? (
            <CheckCircle2 className="h-3 w-3 ml-1 text-green-500" />
          ) : (
            <AlertCircle className="h-3 w-3 ml-1 text-yellow-500" />
          )}
        </TooltipTrigger>
        <TooltipContent>
          <p>{status.message}</p>
          <p className="text-xs text-muted-foreground">
            Verified: {new Date(status.lastVerified).toLocaleString()}
          </p>
        </TooltipContent>
      </Tooltip>
    );
  };

  if (loading || validating) {
    return (
      <Button variant="ghost" size="icon" className="w-8 h-8">
        <Loader2 className="h-4 w-4 animate-spin" />
      </Button>
    );
  }

  const currentEmergencyNumbers = emergencyNumbers[countryCode] || emergencyNumbers.default;

  return (
    <TooltipProvider>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="w-8 h-8 hover:bg-destructive hover:text-destructive-foreground"
          >
            <Phone className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuGroup>
            <DropdownMenuItem
              className="flex items-center gap-2 py-2 cursor-pointer"
              onClick={() => handleEmergencyCall(currentEmergencyNumbers.ambulance, 'Ambulance')}
            >
              <Ambulance className="h-4 w-4 text-red-600" />
              <span className="text-sm">{currentEmergencyNumbers.ambulance}</span>
              {getValidationIcon('ambulance')}
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center gap-2 py-2 cursor-pointer"
              onClick={() => handleEmergencyCall(currentEmergencyNumbers.police, 'Police')}
            >
              <Shield className="h-4 w-4 text-blue-600" />
              <span className="text-sm">{currentEmergencyNumbers.police}</span>
              {getValidationIcon('police')}
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center gap-2 py-2 cursor-pointer"
              onClick={() => handleEmergencyCall(currentEmergencyNumbers.fire, 'Fire')}
            >
              <Flame className="h-4 w-4 text-orange-600" />
              <span className="text-sm">{currentEmergencyNumbers.fire}</span>
              {getValidationIcon('fire')}
            </DropdownMenuItem>
          </DropdownMenuGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    </TooltipProvider>
  );
}