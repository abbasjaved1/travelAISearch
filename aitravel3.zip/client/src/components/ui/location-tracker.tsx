import { useState, useEffect } from 'react';
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Badge } from "./badge";
import { MapPin, Battery, Signal } from "lucide-react";
import { socket } from '@/lib/socket';

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
  speed?: number;
}

export function LocationTracker() {
  const [tracking, setTracking] = useState(false);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [watchId, setWatchId] = useState<number | null>(null);

  // Battery monitoring
  useEffect(() => {
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setBatteryLevel(battery.level * 100);
        
        battery.addEventListener('levelchange', () => {
          setBatteryLevel(battery.level * 100);
        });
      });
    }
  }, []);

  // Optimize tracking settings based on battery level
  const getTrackingOptions = (): PositionOptions => {
    const baseOptions: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0
    };

    if (batteryLevel && batteryLevel < 20) {
      // Battery saving mode
      return {
        ...baseOptions,
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 30000
      };
    }

    return baseOptions;
  };

  const startTracking = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    setTracking(true);
    const options = getTrackingOptions();

    const id = navigator.geolocation.watchPosition(
      (position) => {
        const locationData: LocationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp,
          speed: position.coords.speed || undefined
        };

        setLocation(locationData);
        setError(null);

        // Emit location update through WebSocket
        socket.emit('locationUpdate', locationData);
      },
      (error) => {
        console.error('Location error:', error);
        setError(getLocationErrorMessage(error.code));
      },
      options
    );

    setWatchId(id);
  };

  const stopTracking = () => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }
    setTracking(false);
  };

  const getLocationErrorMessage = (code: number): string => {
    switch (code) {
      case 1:
        return 'Location access denied';
      case 2:
        return 'Location unavailable';
      case 3:
        return 'Location request timeout';
      default:
        return 'Unknown error';
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Location Tracker
          </CardTitle>
          {batteryLevel !== null && (
            <div className="flex items-center gap-2">
              <Battery className="h-4 w-4" />
              <span className="text-sm">{Math.round(batteryLevel)}%</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-center">
          <Button
            onClick={tracking ? stopTracking : startTracking}
            variant={tracking ? "destructive" : "default"}
          >
            {tracking ? 'Stop Tracking' : 'Start Tracking'}
          </Button>
        </div>

        {error && (
          <div className="bg-destructive/10 text-destructive p-3 rounded-md text-sm">
            {error}
          </div>
        )}

        {location && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Status</span>
              <Badge variant="outline" className="flex items-center gap-1">
                <Signal className="h-3 w-3" />
                {location.accuracy < 20 ? 'High' : location.accuracy < 50 ? 'Medium' : 'Low'} Accuracy
              </Badge>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>Latitude: {location.latitude.toFixed(6)}</div>
              <div>Longitude: {location.longitude.toFixed(6)}</div>
              <div>Accuracy: ±{Math.round(location.accuracy)}m</div>
              {location.speed && <div>Speed: {Math.round(location.speed * 3.6)}km/h</div>}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
