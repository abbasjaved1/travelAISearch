import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Button } from "./button";
import { Badge } from "./badge";
import { Skeleton } from "./skeleton";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Users, Star, Clock, Navigation } from "lucide-react";
import { apiRequest } from '@/lib/api';
import { socket, isConnected } from '@/lib/socket';

interface ChatRecommendation {
  roomId: string;
  roomName: string;
  category: string;
  participantCount: number;
  distance: number;
  matchScore: number;
  localTimeZone: string;
  commonInterests: string[];
  locationContext: {
    city: string;
    country: string;
    landmarks: string[];
  };
}

export function ChatRecommendations() {
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [joiningRoom, setJoiningRoom] = useState<string | null>(null);
  const { toast } = useToast();
  
  const handleJoinRoom = (room: ChatRecommendation) => {
    if (!isConnected()) {
      toast({
        title: "Connection Error",
        description: "Not connected to chat server. Please try again.",
        variant: "destructive"
      });
      return;
    }
    
    setJoiningRoom(room.roomId);
    
    // Emit join_room event to the server
    socket.emit('join_room', {
      roomId: room.roomId,
      roomName: room.roomName
    });
    
    toast({
      title: "Joined Room",
      description: `You've joined ${room.roomName}`,
    });
    
    setJoiningRoom(null);
  };

  const {
    data: recommendations,
    isLoading,
    error,
    refetch
  } = useQuery<ChatRecommendation[]>({
    queryKey: ['/api/chat-recommendations', location],
    queryFn: async () => {
      if (!location) return [];
      const response = await apiRequest('POST', '/api/chat-recommendations', { location });
      return response.json();
    },
    enabled: !!location
  });

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          toast({
            title: "Location Error",
            description: "Unable to get your location. Showing general recommendations.",
            variant: "destructive"
          });
        }
      );
    }
  }, [toast]);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>
            <Skeleton className="h-6 w-48" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="text-destructive">Error Loading Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Unable to load chat recommendations. Please try again later.
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            className="mt-4"
          >
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Navigation className="h-5 w-5" />
          Recommended Chat Rooms
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations?.map((room) => (
            <Card key={room.roomId} className="hover:bg-accent/50 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold">{room.roomName}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <MapPin className="h-4 w-4" />
                      {room.locationContext.city}, {room.locationContext.country}
                    </div>
                  </div>
                  <Badge variant="secondary">
                    <Users className="h-3 w-3 mr-1" />
                    {room.participantCount}
                  </Badge>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {room.commonInterests.map((interest, i) => (
                    <Badge key={i} variant="outline" className="capitalize">
                      {interest}
                    </Badge>
                  ))}
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 mr-1 text-yellow-500" />
                      {(room.matchScore * 100).toFixed(0)}% match
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {room.localTimeZone}
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => handleJoinRoom(room)} 
                    disabled={joiningRoom === room.roomId}
                  >
                    {joiningRoom === room.roomId ? 'Joining...' : 'Join Room'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
