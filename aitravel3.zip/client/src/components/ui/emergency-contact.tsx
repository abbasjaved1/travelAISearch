import { useState, useEffect } from 'react';
import { Button } from "./button";
import { Card, CardHeader, CardTitle, CardContent } from "./card";
import { toast } from "@/hooks/use-toast";
import { Phone, Ambulance, Shield, Flame, AlertTriangle, Loader2 } from "lucide-react";

interface EmergencyContact {
  country: string;
  police: string;
  ambulance: string;
  fire: string;
}

const emergencyNumbers: Record<string, EmergencyContact> = {
  'US': {
    country: 'United States',
    police: '911',
    ambulance: '911',
    fire: '911'
  },
  'GB': {
    country: 'United Kingdom',
    police: '999',
    ambulance: '999',
    fire: '999'
  },
  'default': {
    country: 'International',
    police: '112',
    ambulance: '112',
    fire: '112'
  }
};

export function EmergencyContact() {
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [countryCode, setCountryCode] = useState<string>('default');
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const getLocation = async () => {
      try {
        // Check if geolocation is supported
        if (!navigator.geolocation) {
          console.log('Geolocation is not supported');
          setLoading(false);
          return;
        }

        // Get position with a timeout of 5 seconds
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          const timeoutId = setTimeout(() => {
            reject(new Error('Location request timed out'));
          }, 5000);

          navigator.geolocation.getCurrentPosition(
            (pos) => {
              clearTimeout(timeoutId);
              resolve(pos);
            },
            (err) => {
              clearTimeout(timeoutId);
              reject(err);
            },
            { enableHighAccuracy: false, timeout: 5000, maximumAge: 300000 }
          );
        });

        const { latitude, longitude } = position.coords;
        setLocation({ lat: latitude, lng: longitude });

        try {
          // Use reverse geocoding with a timeout
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);

          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`,
            { signal: controller.signal }
          );
          clearTimeout(timeoutId);

          if (!response.ok) {
            throw new Error('Failed to fetch location details');
          }

          const data = await response.json();
          const country = data.address?.country_code?.toUpperCase() || 'default';
          setCountryCode(country in emergencyNumbers ? country : 'default');
        } catch (error) {
          console.log('Reverse geocoding failed, using default numbers');
          setCountryCode('default');
        }
      } catch (error) {
        // Handle error silently without console logging
        setCountryCode('default');
      } finally {
        setLoading(false);
      }
    };

    getLocation();

    // Cleanup function
    return () => {
      setLoading(false);
    };
  }, []);

  const handleEmergencyCall = (number: string, service: string) => {
    try {
      window.location.href = `tel:${number}`;
      toast({
        title: `Calling ${service}`,
        description: `Dialing emergency number: ${number}`,
      });
    } catch (error) {
      console.error('Error making emergency call:', error);
      toast({
        title: "Emergency Contact",
        description: `Emergency number for ${service}: ${number}`,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Button variant="ghost" size="icon" className="w-8 h-8">
        <Loader2 className="h-4 w-4 animate-spin" />
      </Button>
    );
  }

  const currentEmergencyNumbers = emergencyNumbers[countryCode] || emergencyNumbers.default;

  return (
    <Button
      variant="ghost"
      size="icon"
      className="relative w-8 h-8 hover:bg-destructive hover:text-destructive-foreground"
      onClick={() => setIsExpanded(!isExpanded)}
    >
      <AlertTriangle className="h-4 w-4" />
      {isExpanded && (
        <Card className="absolute top-full right-0 mt-2 w-[280px]">
          <CardHeader className="p-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-4 w-4" />
              Emergency Numbers
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 grid grid-cols-3 gap-2">
            <Button
              variant="destructive"
              size="sm"
              className="flex flex-col items-center gap-1 h-auto py-2"
              onClick={(e) => {
                e.stopPropagation();
                handleEmergencyCall(currentEmergencyNumbers.ambulance, 'Ambulance');
              }}
            >
              <Ambulance className="h-4 w-4" />
              <span className="text-xs">{currentEmergencyNumbers.ambulance}</span>
            </Button>
            <Button
              variant="destructive"
              size="sm"
              className="flex flex-col items-center gap-1 h-auto py-2"
              onClick={(e) => {
                e.stopPropagation();
                handleEmergencyCall(currentEmergencyNumbers.police, 'Police');
              }}
            >
              <Shield className="h-4 w-4" />
              <span className="text-xs">{currentEmergencyNumbers.police}</span>
            </Button>
            <Button
              variant="destructive"
              size="sm"
              className="flex flex-col items-center gap-1 h-auto py-2"
              onClick={(e) => {
                e.stopPropagation();
                handleEmergencyCall(currentEmergencyNumbers.fire, 'Fire');
              }}
            >
              <Flame className="h-4 w-4" />
              <span className="text-xs">{currentEmergencyNumbers.fire}</span>
            </Button>
          </CardContent>
        </Card>
      )}
    </Button>
  );
}