import { useState, useEffect } from 'react';
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Progress } from "./progress";
import { toast } from "@/hooks/use-toast";
import { websocketManager } from "@/lib/websocketManager";
import {
  MapPin,
  Trophy,
  Compass,
  Heart,
  Star,
  Map,
  Target,
  LucideIcon
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Clue {
  id: string;
  text: string;
  hint: string;
  location: {
    lat: number;
    lng: number;
    radius: number; // meters
  };
  points: number;
  icon: LucideIcon;
}

export function LocationTreasureHunt() {
  const [currentLocation, setCurrentLocation] = useState<GeolocationPosition | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [currentClue, setCurrentClue] = useState<Clue | null>(null);
  const [score, setScore] = useState(0);
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Initialize WebSocket connection
    websocketManager.connect();

    // Listen for game events
    const handleGameEvent = (event: CustomEvent) => {
      const { type, data } = event.detail;
      switch (type) {
        case 'clueUpdate':
          setCurrentClue(data.clue);
          break;
        case 'scoreUpdate':
          setScore(data.score);
          break;
      }
    };

    window.addEventListener('gameEvent', handleGameEvent as EventListener);

    return () => {
      window.removeEventListener('gameEvent', handleGameEvent as EventListener);
      websocketManager.disconnect();
    };
  }, []);

  // Watch user's location when game is active
  useEffect(() => {
    let watchId: number;

    if (gameStarted && currentClue) {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          setCurrentLocation(position);
          checkProximity(position);

          // Send location update through WebSocket
          websocketManager.sendMessage('location', {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error('Location error:', error);
          toast({
            title: "Location Error",
            description: "Please enable location services to play the game",
            variant: "destructive",
          });
        },
        {
          enableHighAccuracy: true,
          maximumAge: 0,
          timeout: 5000
        }
      );
    }

    return () => {
      if (watchId) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [gameStarted, currentClue]);

  const checkProximity = (position: GeolocationPosition) => {
    if (!currentClue) return;

    const distance = calculateDistance(
      position.coords.latitude,
      position.coords.longitude,
      currentClue.location.lat,
      currentClue.location.lng
    );

    // Convert distance to meters
    const distanceInMeters = distance * 1000;

    // Update progress based on proximity
    const newProgress = Math.max(0, Math.min(100, 
      100 - (distanceInMeters / currentClue.location.radius) * 100
    ));
    setProgress(newProgress);

    // If user is within the target radius
    if (distanceInMeters <= currentClue.location.radius) {
      handleLocationFound();
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const toRad = (degrees: number): number => {
    return degrees * (Math.PI / 180);
  };

  const startGame = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/games/treasure-hunt/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentLocation: currentLocation ? {
            lat: currentLocation.coords.latitude,
            lng: currentLocation.coords.longitude
          } : null
        })
      });

      if (!response.ok) {
        throw new Error('Failed to start game');
      }

      const { clue } = await response.json();
      setCurrentClue(clue);
      setGameStarted(true);
      toast({
        title: "Adventure Begins!",
        description: "Your treasure hunt has started. Follow the clues!",
      });
    } catch (error) {
      console.error('Game start error:', error);
      toast({
        title: "Error",
        description: "Failed to start the game. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLocationFound = async () => {
    try {
      // Update score locally
      setScore(prev => prev + (currentClue?.points || 0));

      // Send score update through WebSocket
      websocketManager.sendMessage('gameProgress', {
        clueId: currentClue?.id,
        score: score + (currentClue?.points || 0)
      });

      toast({
        title: "Location Found! 🎉",
        description: `You earned ${currentClue?.points} points!`,
      });

      // Get next clue
      const response = await fetch('/api/games/treasure-hunt/next-clue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentClueId: currentClue?.id })
      });

      if (!response.ok) {
        throw new Error('Failed to get next clue');
      }

      const { clue, gameComplete } = await response.json();

      if (gameComplete) {
        setGameStarted(false);
        setCurrentClue(null);
        toast({
          title: "Congratulations! 🏆",
          description: `You completed the treasure hunt with ${score} points!`,
        });
      } else {
        setCurrentClue(clue);
        setProgress(0);
      }
    } catch (error) {
      console.error('Next clue error:', error);
      toast({
        title: "Error",
        description: "Failed to get next clue. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getDirectionHint = (): string => {
    if (!currentLocation || !currentClue) return "Getting your location...";

    const distance = calculateDistance(
      currentLocation.coords.latitude,
      currentLocation.coords.longitude,
      currentClue.location.lat,
      currentClue.location.lng
    );

    const bearing = calculateBearing(
      currentLocation.coords.latitude,
      currentLocation.coords.longitude,
      currentClue.location.lat,
      currentClue.location.lng
    );

    const direction = getCardinalDirection(bearing);
    return `About ${(distance * 1000).toFixed(0)}m ${direction}`;
  };

  const calculateBearing = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const y = Math.sin(toRad(lon2 - lon1)) * Math.cos(toRad(lat2));
    const x = Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
              Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(toRad(lon2 - lon1));
    let bearing = Math.atan2(y, x);
    bearing = toDeg(bearing);
    return (bearing + 360) % 360;
  };

  const toDeg = (rad: number): number => {
    return rad * (180 / Math.PI);
  };

  const getCardinalDirection = (bearing: number): string => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(bearing / 45) % 8;
    return directions[index];
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Map className="h-5 w-5" />
            Location Treasure Hunt
          </span>
          {gameStarted && (
            <span className="text-sm font-normal">
              Score: {score}
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!gameStarted ? (
          <Button
            onClick={startGame}
            disabled={loading}
            className="w-full"
          >
            {loading ? (
              <>
                <Target className="mr-2 h-4 w-4 animate-spin" />
                Starting Game...
              </>
            ) : (
              <>
                <Compass className="mr-2 h-4 w-4" />
                Start Adventure
              </>
            )}
          </Button>
        ) : currentClue ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              {currentClue.icon && (
                <currentClue.icon className="h-5 w-5 text-primary" />
              )}
              <p className="font-medium">{currentClue.text}</p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Distance to location</span>
                <span>{getDirectionHint()}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => toast({
                title: "Hint",
                description: currentClue.hint,
              })}
              className="w-full"
            >
              <Star className="mr-2 h-4 w-4" />
              Get Hint
            </Button>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}