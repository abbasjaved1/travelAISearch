import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { Badge } from "./badge";
import { aiService, type ProactiveSuggestion, type LocalEvent, type AIServiceResponse } from "@/lib/ai-service";
import { Calendar as CalendarIcon, MapPin, Sun, Users, Coins, Trophy, Music, Ticket, Flag, Camera, Hotel, Globe2, Star, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Alert, AlertDescription, AlertTitle } from "./alert";

// Define destination images and info
const destinationInfo: Record<string, { 
  images: string[],
  country: string,
  backgroundImage: string
}> = {
  "Tokyo": {
    images: [
      "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&q=80",
    ],
    country: "Japan",
    backgroundImage: "https://images.unsplash.com/photo-1542931287-023b922fa89b?auto=format&fit=crop&q=80"
  },
  "Paris": {
    images: [
      "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&q=80",
    ],
    country: "France",
    backgroundImage: "https://images.unsplash.com/photo-1502602148707-77069488e870?auto=format&fit=crop&q=80"
  },
  "New York": {
    images: [
      "https://images.unsplash.com/photo-1522083165195-3424ed129620?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&q=80",
    ],
    country: "United States",
    backgroundImage: "https://images.unsplash.com/photo-1485871981521-5b1fd3805eee?auto=format&fit=crop&q=80"
  },
  "Dubai": {
    images: [
      "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1526495124232-a04e1849168c?auto=format&fit=crop&q=80",
    ],
    country: "United Arab Emirates",
    backgroundImage: "https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&q=80"
  },
  "London": {
    images: [
      "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1486299267070-83823f5448dd?auto=format&fit=crop&q=80",
    ],
    country: "United Kingdom",
    backgroundImage: "https://images.unsplash.com/photo-1487530811176-3780de880c2d?auto=format&fit=crop&q=80"
  }
};

function EventTypeIcon({ type }: { type: LocalEvent['type'] }) {
  switch (type) {
    case 'sport':
      return <Trophy className="w-4 h-4 text-green-500" />;
    case 'cultural':
      return <Music className="w-4 h-4 text-purple-500" />;
    case 'entertainment':
      return <Ticket className="w-4 h-4 text-blue-500" />;
    default:
      return <Ticket className="w-4 h-4 text-gray-500" />;
  }
}

// Using AIServiceResponse interface imported from @/lib/ai-service

export function ProactiveSuggestions() {
  const [, setLocation] = useLocation();
  const { data: aiResponse, isLoading, error: queryError } = useQuery<AIServiceResponse>({
    queryKey: ["/api/ai/proactive-suggestions"],
    queryFn: async () => {
      try {
        return await aiService.getProactiveSuggestions();
      } catch (err) {
        console.error('Error fetching AI suggestions:', err);
        throw err;
      }
    },
    refetchInterval: 1000 * 60 * 30, // Refetch every 30 minutes
    retry: 2, // Retry failed requests up to 2 times
    retryDelay: (attemptIndex: number) => Math.min(1000 * 2 ** attemptIndex, 30000), // Exponential backoff
    // Prevent cached errors from causing stale UI content
    staleTime: 1000 * 60 * 5 // 5 minutes
  });

  // Process the AI response to get suggestions and any error messages
  const suggestions = aiResponse?.suggestions || [];
  const errorNote = aiResponse?.note || '';
  const analysisData = aiResponse?.userAnalysis;

  // Log API notes if present for debugging
  if (errorNote) {
    console.log('AI Service note:', errorNote);
  }

  const handleExploreDestination = (suggestion: ProactiveSuggestion) => {
    const destinationSlug = encodeURIComponent(suggestion.destination);
    const params = new URLSearchParams({
      timing: suggestion.timing || '',
      budget: suggestion.estimatedBudget?.toString() || '0',
      weather: suggestion.weatherPrediction || '',
      activities: suggestion.activities?.join(',') || ''
    });

    if (suggestion.localEvents?.length > 0) {
      params.append('events', suggestion.localEvents.map(e => e.name).join(','));
    }

    setLocation(`/destinations/${destinationSlug}?${params.toString()}`);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-48 bg-gray-200 rounded-lg mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (queryError) {
    // Get error message if available
    const errorMessage = queryError instanceof Error ? queryError.message : 'Unknown error occurred';
    
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>AI Service Unavailable</AlertTitle>
        <AlertDescription>
          We're having trouble generating personalized travel recommendations at the moment. 
          {errorMessage.includes('429') ? (
            <span className="block mt-2">
              Our AI service is experiencing high demand. Please try again in a few minutes.
            </span>
          ) : errorMessage.includes('quota') ? (
            <span className="block mt-2">
              We've reached our AI service quota. Try again later or contact support.
            </span>
          ) : (
            <span className="block mt-2">
              This might be due to a service issue. Please try again later.
            </span>
          )}
        </AlertDescription>
      </Alert>
    );
  }
  
  // Show note from server if there was one (partial service disruption)
  if (errorNote && suggestions.length > 0) {
    return (
      <>
        <Alert className="mb-6 border-amber-500 bg-amber-50 text-amber-900">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Limited Recommendations Available</AlertTitle>
          <AlertDescription>
            We're experiencing some limitations with our AI service.
            The recommendations below are based on your profile but may have limited details.
          </AlertDescription>
        </Alert>
        
        {/* Continue to render suggestions below */}
        <AnimatePresence>
          {suggestions.map((suggestion, index) => (
            <motion.div
              key={`${suggestion.destination}-${index}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4, delay: index * 0.15 }}
            >
              <Card className={cn(
                "mb-6 overflow-hidden border-2 hover:border-[#003580] transition-all duration-300",
                "hover:shadow-xl transform hover:-translate-y-1"
              )}>
                {/* Card content identical to the main return statement */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={destinationInfo[suggestion.destination]?.backgroundImage || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&q=80'}
                    alt={suggestion.destination}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent">
                    <div className="absolute bottom-0 left-0 p-6 text-white">
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2">
                          <Globe2 className="w-6 h-6" />
                          <h3 className="text-3xl font-bold">
                            {suggestion.destination}
                          </h3>
                        </div>
                        <div className="flex items-center gap-2 text-white/80">
                          <MapPin className="w-4 h-4" />
                          <span className="text-lg">
                            {destinationInfo[suggestion.destination]?.country || suggestion.destination}
                          </span>
                        </div>
                        <p className="text-white/90 mt-2">{suggestion.reason}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-6">
                    <Badge
                      variant={suggestion.confidence > 0.8 ? "default" : suggestion.confidence > 0.6 ? "secondary" : "outline"}
                      className="animate-pulse"
                    >
                      {Math.round(suggestion.confidence * 100)}% Match
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 bg-gray-50 p-4 rounded-lg">
                    <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                      <CalendarIcon className="w-5 h-5 text-[#003580]" />
                      <span className="text-sm font-medium">{suggestion.timing}</span>
                    </div>
                    <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                      <Sun className="w-5 h-5 text-[#003580]" />
                      <span className="text-sm font-medium">{suggestion.weatherPrediction}</span>
                    </div>
                    <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                      <Coins className="w-5 h-5 text-[#003580]" />
                      <span className="text-sm font-medium">${suggestion.estimatedBudget}</span>
                    </div>
                    <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                      <Flag className="w-5 h-5 text-[#003580]" />
                      <span className="text-sm font-medium">{suggestion.activities.length} Activities</span>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end">
                    <Button
                      className="bg-[#003580] hover:bg-[#002255] gap-2"
                      size="lg"
                      onClick={() => handleExploreDestination(suggestion)}
                    >
                      <Hotel className="w-5 h-5" />
                      Explore This Destination
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </>
    );
  }
  
  if (!suggestions || suggestions.length === 0) {
    return (
      <Alert className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>No Recommendations Available</AlertTitle>
        <AlertDescription>
          We couldn't find any travel recommendations matching your profile at the moment.
          Try updating your travel preferences or checking back later.
          {errorNote && (
            <span className="block mt-2 italic text-sm">
              Note: {errorNote}
            </span>
          )}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <AnimatePresence>
      {suggestions.map((suggestion, index) => (
        <motion.div
          key={`${suggestion.destination}-${index}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4, delay: index * 0.15 }}
        >
          <Card className={cn(
            "mb-6 overflow-hidden border-2 hover:border-[#003580] transition-all duration-300",
            "hover:shadow-xl transform hover:-translate-y-1"
          )}>
            <div className="relative h-64 overflow-hidden">
              <img
                src={destinationInfo[suggestion.destination]?.backgroundImage || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&q=80'}
                alt={suggestion.destination}
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent">
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <Globe2 className="w-6 h-6" />
                      <h3 className="text-3xl font-bold">
                        {suggestion.destination}
                      </h3>
                    </div>
                    <div className="flex items-center gap-2 text-white/80">
                      <MapPin className="w-4 h-4" />
                      <span className="text-lg">
                        {destinationInfo[suggestion.destination]?.country || suggestion.destination}
                      </span>
                    </div>
                    <p className="text-white/90 mt-2">{suggestion.reason}</p>
                  </div>
                </div>
              </div>
            </div>

            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-6">
                <Badge
                  variant={suggestion.confidence > 0.8 ? "default" : suggestion.confidence > 0.6 ? "secondary" : "outline"}
                  className="animate-pulse"
                >
                  {Math.round(suggestion.confidence * 100)}% Match
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 bg-gray-50 p-4 rounded-lg">
                <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                  <CalendarIcon className="w-5 h-5 text-[#003580]" />
                  <span className="text-sm font-medium">{suggestion.timing}</span>
                </div>
                <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                  <Sun className="w-5 h-5 text-[#003580]" />
                  <span className="text-sm font-medium">{suggestion.weatherPrediction}</span>
                </div>
                <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                  <Coins className="w-5 h-5 text-[#003580]" />
                  <span className="text-sm font-medium">${suggestion.estimatedBudget}</span>
                </div>
                <div className="flex flex-col items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                  <Flag className="w-5 h-5 text-[#003580]" />
                  <span className="text-sm font-medium">{suggestion.activities.length} Activities</span>
                </div>
              </div>

              {suggestion.eventHighlight && (
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Star className="w-5 h-5 text-yellow-500" />
                    <h4 className="font-semibold text-[#003580]">Featured Event</h4>
                  </div>
                  <div className="space-y-3">
                    <p className="font-medium text-lg">{suggestion.eventHighlight.name}</p>
                    <p className="text-gray-600">{suggestion.eventHighlight.description}</p>
                    <div className="flex items-center gap-3 text-sm">
                      <div className="flex items-center gap-1 text-gray-500">
                        <CalendarIcon className="w-4 h-4" />
                        <span>{suggestion.eventHighlight.date}</span>
                      </div>
                      <div className="flex items-center gap-1 text-gray-500">
                        <MapPin className="w-4 h-4" />
                        <span>{suggestion.destination}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4 mb-6">
                <div className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-[#003580]" />
                  <h4 className="font-semibold text-lg">Local Events & Activities</h4>
                </div>
                <div className="grid gap-3">
                  {suggestion.localEvents.map((event, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-start gap-3 p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                    >
                      <EventTypeIcon type={event.type} />
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <p className="font-medium">{event.name}</p>
                          {event.ticketPrice && (
                            <Badge variant="outline" className="ml-2">
                              ${event.ticketPrice}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <CalendarIcon className="w-3 h-3" />
                            <span>{format(new Date(event.date), 'MMM d, yyyy')}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{event.venue}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button
                  className="bg-[#003580] hover:bg-[#002255] gap-2"
                  size="lg"
                  onClick={() => handleExploreDestination(suggestion)}
                >
                  <Hotel className="w-5 h-5" />
                  Explore This Destination
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </AnimatePresence>
  );
}