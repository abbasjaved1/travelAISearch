import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "./card";
import { Button } from "./button";
import { Alert, AlertTitle, AlertDescription } from "./alert";
import { Badge } from "./badge";
import { Skeleton } from "./skeleton";
import { useToast } from "@/hooks/use-toast";
import { Shield, AlertTriangle, Loader2, MapPin, ThermometerSun, RefreshCw } from "lucide-react";
import { apiRequest } from '@/lib/api';

interface SafetyRecommendation {
  category: 'general' | 'transportation' | 'health' | 'crime' | 'natural_disaster';
  severity: 'low' | 'medium' | 'high';
  recommendation: string;
  actionItems: string[];
  relevantContacts?: string[];
  updatedAt: string;
}

interface SafetyAnalysis {
  location: string;
  timestamp: string;
  overallRiskLevel: 'low' | 'medium' | 'high';
  recommendations: SafetyRecommendation[];
  safeAreas: string[];
  areasToAvoid: string[];
  localEmergencyContacts: {
    police: string;
    ambulance: string;
    fire: string;
  };
}

export function SafetyRecommendations() {
  const [safetyData, setSafetyData] = useState<SafetyAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [location, setLocation] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const response = await fetch(
              `https://api.openweathermap.org/geo/1.0/reverse?lat=${position.coords.latitude}&lon=${position.coords.longitude}&limit=1&appid=demo`
            );
            const [locationData] = await response.json();
            setLocation(locationData.name);
            fetchSafetyRecommendations(locationData.name);
          } catch (error) {
            // Handle error silently
            setError('Failed to determine your location');
          }
        },
        (error) => {
          // Handle error silently without console logging
          setError('Please enable location services to get safety recommendations');
        }
      );
    }
  }, []);

  const fetchSafetyRecommendations = async (locationName: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await apiRequest('POST', '/api/ai/safety-recommendations', {
        location: locationName
      });

      if (!response.ok) {
        throw new Error('Failed to fetch safety recommendations');
      }

      const data = await response.json();
      setSafetyData(data);
    } catch (error) {
      console.error('Error fetching safety recommendations:', error);
      setError('Failed to load safety recommendations');
      toast({
        title: "Error",
        description: "Could not load safety recommendations. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-destructive text-destructive-foreground';
      case 'medium':
        return 'bg-warning text-warning-foreground';
      case 'low':
        return 'bg-success text-success-foreground';
      default:
        return 'bg-secondary text-secondary-foreground';
    }
  };

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            <Skeleton className="h-4 w-48" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-5/6" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!safetyData) {
    return null;
  }

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Safety Recommendations
          <Badge className={getSeverityColor(safetyData.overallRiskLevel)}>
            {safetyData.overallRiskLevel.toUpperCase()} RISK
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />
            {location}
          </div>

          {safetyData.recommendations.map((rec, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold capitalize">{rec.category.replace('_', ' ')}</h3>
                <Badge className={getSeverityColor(rec.severity)}>
                  {rec.severity.toUpperCase()}
                </Badge>
              </div>
              <p>{rec.recommendation}</p>
              <ul className="list-disc list-inside space-y-1">
                {rec.actionItems.map((item, i) => (
                  <li key={i} className="text-sm">{item}</li>
                ))}
              </ul>
            </div>
          ))}

          <div className="mt-4 space-y-2">
            <h4 className="font-semibold">Safe Areas</h4>
            <ul className="list-disc list-inside">
              {safetyData.safeAreas.map((area, i) => (
                <li key={i} className="text-sm text-success">{area}</li>
              ))}
            </ul>
          </div>

          <div className="mt-4 space-y-2">
            <h4 className="font-semibold">Areas to Avoid</h4>
            <ul className="list-disc list-inside">
              {safetyData.areasToAvoid.map((area, i) => (
                <li key={i} className="text-sm text-destructive">{area}</li>
              ))}
            </ul>
          </div>

          <Button
            variant="outline"
            className="w-full mt-4"
            onClick={() => fetchSafetyRecommendations(location!)}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Recommendations
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
