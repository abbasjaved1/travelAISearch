import { motion } from "framer-motion";
import { Plane, Hotel, Car, UtensilsCrossed, Sun, Map, Briefcase, Globe } from "lucide-react";

export function SplashScreen({ onDismiss }: { onDismiss: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onDismiss}
      className="fixed inset-0 bg-gradient-to-br from-background via-primary/5 to-secondary/10 flex items-center justify-center z-50 backdrop-blur-sm cursor-pointer"
    >
      <div className="text-center space-y-12 max-w-4xl px-4">
        <motion.div 
          className="flex items-center justify-center gap-8 flex-wrap"
          variants={{
            show: {
              transition: {
                staggerChildren: 0.1
              }
            }
          }}
          initial="hidden"
          animate="show"
        >
          {[
            { icon: Plane, name: "Flights", rotate: -45, gradient: "from-[#FF6B6B] via-[#4ECDC4] to-[#FF6B6B]", image: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&q=80&w=200" },
            { icon: Hotel, name: "Hotels", rotate: 0, gradient: "from-[#A8E6CF] via-[#DCEDC1] to-[#A8E6CF]", image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=200" },
            { icon: Car, name: "Rides", rotate: 0, gradient: "from-[#FFD93D] via-[#FF6B6B] to-[#FFD93D]", image: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&q=80&w=200" },
            { icon: UtensilsCrossed, name: "Dining", rotate: 0, gradient: "from-[#6C5B7B] via-[#C06C84] to-[#6C5B7B]", image: "https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&q=80&w=200" },
            { icon: Sun, name: "Weather", rotate: 0, gradient: "from-[#4ECDC4] via-[#A8E6CF] to-[#4ECDC4]", image: "https://images.unsplash.com/photo-1592210454359-9043f067919b?auto=format&fit=crop&q=80&w=200" },
            { icon: Map, name: "Explore", rotate: 0, gradient: "from-[#FF6B6B] via-[#FFD93D] to-[#FF6B6B]", image: "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&q=80&w=200" },
            { icon: Briefcase, name: "Business", rotate: 0, gradient: "from-[#C06C84] via-[#6C5B7B] to-[#C06C84]", image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=200" },
            { icon: Globe, name: "Global", rotate: 0, gradient: "from-[#DCEDC1] via-[#A8E6CF] to-[#DCEDC1]", image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&q=80&w=200" }
          ].map((Item, index) => (
            <motion.div
              key={index}
              className="relative group"
              variants={{
                hidden: { y: 50, opacity: 0 },
                show: { y: 0, opacity: 1 }
              }}
              transition={{ duration: 0.5 }}
            >
              <motion.div 
                className={`absolute -inset-1 bg-gradient-to-r ${Item.gradient} rounded-full blur opacity-75`}
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5],
                  rotate: [0, 180, 360]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: index * 0.2
                }}
              />
              <motion.div 
                className="relative rounded-lg overflow-hidden group-hover:scale-105 transition-transform duration-300"
                whileHover={{ scale: 1.1 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <div className="relative w-32 h-32">
                  <img
                    src={Item.image}
                    alt={Item.name}
                    className="absolute inset-0 w-full h-full object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col items-center justify-end p-2">
                    <Item.icon className="w-8 h-8 text-white mb-1" />
                    <span className="text-white text-sm font-medium">{Item.name}</span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-6"
        >
          <motion.h1 
            className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent px-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            Welcome to TravelAI
          </motion.h1>
          <motion.p 
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed px-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
          >
            Experience the future of travel with AI-powered personalization and seamless booking
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="text-sm text-muted-foreground mt-8"
          >
            Click anywhere to continue
          </motion.p>
        </motion.div>
      </div>
    </motion.div>
  );
}
