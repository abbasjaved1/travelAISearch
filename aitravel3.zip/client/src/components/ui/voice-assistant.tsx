import { useState, useEffect, useCallback } from 'react';
import { Player } from '@lottiefiles/react-lottie-player';
import { Button } from "./button";
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { ErrorBoundary } from "./error-boundary";

interface VoiceAssistantProps {
  onMessage: (message: string) => void;
  isProcessing: boolean;
  isSpeaking: boolean;
}

export function VoiceAssistant({ onMessage, isProcessing, isSpeaking }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [muted, setMuted] = useState(false);
  const [transcript, setTranscript] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    // Check browser support
    if (!('webkitSpeechRecognition' in window)) {
      toast({
        title: "Browser Support",
        description: "Your browser doesn't support voice recognition.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const startListening = useCallback(async () => {
    try {
      setIsListening(true);
      setTranscript("");

      const SpeechRecognition = window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();

      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0])
          .map(result => result.transcript)
          .join('');
        setTranscript(transcript);
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast({
          title: "Voice Recognition Error",
          description: "Failed to recognize speech. Please try again.",
          variant: "destructive"
        });
      };

      recognition.start();
    } catch (error) {
      console.error('Failed to start listening:', error);
      setIsListening(false);
      toast({
        title: "Voice Recognition Error",
        description: "Failed to start voice recognition. Please try again.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const stopListening = useCallback(() => {
    setIsListening(false);
    if (transcript) {
      onMessage(transcript);
      setTranscript("");
    }
  }, [transcript, onMessage]);

  const toggleMute = () => {
    setMuted(!muted);
    if (!muted) {
      window.speechSynthesis?.cancel();
    }
  };

  return (
    <ErrorBoundary>
      <div className="relative">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="flex flex-col items-center"
        >
          <div className="w-32 h-32 relative">
            <Player
              autoplay
              loop
              src="/animations/travel-assistant.json"
              style={{ width: '100%', height: '100%' }}
            />
          </div>

          <div className="flex gap-2 mt-4">
            <Button
              variant={isListening ? "destructive" : "default"}
              size="icon"
              onClick={isListening ? stopListening : startListening}
              disabled={isProcessing}
            >
              {isListening ? (
                <MicOff className="h-4 w-4" />
              ) : (
                <Mic className="h-4 w-4" />
              )}
            </Button>

            <Button
              variant="outline"
              size="icon"
              onClick={toggleMute}
            >
              {muted ? (
                <VolumeX className="h-4 w-4" />
              ) : (
                <Volume2 className="h-4 w-4" />
              )}
            </Button>
          </div>

          {isListening && transcript && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-3 bg-muted rounded-lg text-sm"
            >
              {transcript}
            </motion.div>
          )}
        </motion.div>
      </div>
    </ErrorBoundary>
  );
}