import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Info } from "lucide-react";

interface TravelTip {
  title: string;
  description: string;
  category: 'culture' | 'weather' | 'transport' | 'food';
}

interface TravelTipsProps {
  destination: string;
  destinationCode: string;
}

const destinationTips: Record<string, TravelTip[]> = {
  "SFO": [
    {
      title: "Weather Guide",
      description: "Pack layers! SF's microclimate means temperatures can vary significantly throughout the day.",
      category: 'weather'
    },
    {
      title: "Transport Tip",
      description: "BART is the fastest way to/from the airport to downtown. Get a Clipper card for public transit.",
      category: 'transport'
    },
    {
      title: "Local Customs",
      description: "Locals never call it 'Frisco' - stick to 'SF' or 'San Francisco'.",
      category: 'culture'
    }
  ],
  "JFK": [
    {
      title: "Transport Tip",
      description: "Take the AirTrain to connect with the subway system. Get a MetroCard upon arrival.",
      category: 'transport'
    },
    {
      title: "Food Guide",
      description: "Try the classic NY pizza and bagels - they're iconic for a reason!",
      category: 'food'
    },
    {
      title: "Weather Note",
      description: "Winters can be harsh and summers humid. Pack accordingly!",
      category: 'weather'
    }
  ],
  "LHR": [
    {
      title: "Transport Tip",
      description: "The Heathrow Express is the fastest way to central London. Get an Oyster card for the Tube.",
      category: 'transport'
    },
    {
      title: "Weather Note",
      description: "London weather is unpredictable. Always carry an umbrella!",
      category: 'weather'
    },
    {
      title: "Culture Tip",
      description: "Stand on the right on escalators, and queue (line up) is a sacred custom.",
      category: 'culture'
    }
  ],
  // Add more destinations as needed
};

export function TravelTips({ destination, destinationCode }: TravelTipsProps) {
  const tips = destinationTips[destinationCode] || [];

  if (tips.length === 0) return null;

  return (
    <HoverCard>
      <HoverCardTrigger asChild>
        <button className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800">
          <Info className="h-4 w-4 mr-1" />
          Travel Tips
        </button>
      </HoverCardTrigger>
      <HoverCardContent className="w-80">
        <div className="space-y-4">
          <h3 className="font-semibold">Tips for {destination}</h3>
          <div className="space-y-2">
            {tips.map((tip, index) => (
              <div key={index} className="space-y-1">
                <h4 className="text-sm font-medium">{tip.title}</h4>
                <p className="text-sm text-muted-foreground">{tip.description}</p>
              </div>
            ))}
          </div>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
