import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Badge } from "./badge";

export type Seat = {
  id: string;
  row: number;
  column: string;
  type: "window" | "middle" | "aisle";
  status: "available" | "occupied" | "selected";
  price?: number;
};

interface SeatMapProps {
  seats: Seat[];
  selectedSeat?: Seat | null;
  onSeatSelect: (seat: Seat) => void;
  className?: string;
}

export function SeatMap({ seats, selectedSeat, onSeatSelect, className }: SeatMapProps) {
  const rows = Math.max(...seats.map(s => s.row));
  const columns = Array.from(new Set(seats.map(s => s.column))).sort();

  const getSeatByPosition = (row: number, col: string) => 
    seats.find(s => s.row === row && s.column === col);

  const getSeatColor = (seat: Seat) => {
    if (seat.status === "occupied") return "bg-muted text-muted-foreground cursor-not-allowed opacity-50";
    if (selectedSeat?.id === seat.id) return "bg-primary/20 border-primary text-primary hover:bg-primary/30";
    if (seat.type === "window") return "bg-blue-100 hover:bg-blue-200 border-blue-200";
    if (seat.type === "aisle") return "bg-green-100 hover:bg-green-200 border-green-200";
    return "bg-background hover:bg-accent border-accent/20";
  };

  return (
    <Card className={cn("w-full", className)}>
      <CardHeader className="space-y-2">
        <CardTitle className="flex items-center justify-between">
          <span>Select Your Seat</span>
          <div className="flex gap-2 text-sm font-normal">
            <Badge variant="outline" className="bg-blue-100">Window</Badge>
            <Badge variant="outline" className="bg-green-100">Aisle</Badge>
            <Badge variant="outline">Middle</Badge>
          </div>
        </CardTitle>
        <div className="text-sm text-muted-foreground">
          {selectedSeat ? (
            <p>Selected seat: {selectedSeat.row}{selectedSeat.column} ({selectedSeat.type})</p>
          ) : (
            <p>Click on an available seat to select it</p>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          {/* Plane nose */}
          <div className="w-24 h-24 bg-muted rounded-full mx-auto mb-8 flex items-center justify-center">
            <span className="rotate-90 text-muted-foreground">FRONT</span>
          </div>

          <div className="grid gap-4">
            {Array.from({ length: rows }, (_, i) => i + 1).map(row => (
              <div key={row} className="flex items-center gap-3 justify-center">
                <span className="w-6 text-sm text-muted-foreground font-medium">{row}</span>
                {columns.map((col, idx) => {
                  const seat = getSeatByPosition(row, col);
                  if (!seat) return <div key={`${row}${col}`} className="w-12 h-12" />;

                  // Add aisle gap
                  const isAisle = idx === Math.floor(columns.length / 2) - 1;

                  return (
                    <>
                      <Button
                        key={seat.id}
                        variant="outline"
                        size="lg"
                        className={cn(
                          "w-12 h-12 p-0 font-medium border-2 transition-all duration-200",
                          getSeatColor(seat),
                          seat.status === "occupied" && "cursor-not-allowed",
                          selectedSeat?.id === seat.id && "ring-2 ring-primary ring-offset-2"
                        )}
                        disabled={seat.status === "occupied"}
                        onClick={() => onSeatSelect(seat)}
                      >
                        <div className="flex flex-col items-center justify-center">
                          <span className="text-xs">{col}</span>
                          {seat.price && (
                            <span className="text-[10px] opacity-70">${seat.price}</span>
                          )}
                        </div>
                      </Button>
                      {isAisle && <div className="w-6" />}
                    </>
                  );
                })}
                <span className="w-6 text-sm text-muted-foreground font-medium">{row}</span>
              </div>
            ))}
          </div>

          {/* Plane tail */}
          <div className="w-32 h-16 bg-muted mx-auto mt-8 rounded-t-lg flex items-center justify-center">
            <span className="rotate-90 text-muted-foreground">BACK</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}