import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Mail, Users, CheckCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { SiGoogle } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";

/**
 * Component to display in the chat interface to inform users about
 * the Gmail contacts communication policy
 */
export function GmailContactsNotice() {
  const { user } = useAuth();
  const { toast } = useToast();
  const isGoogleUser = !!user?.google_id;

  const handleSignInWithGoogle = () => {
    toast({
      title: "Google Sign-In Required",
      description: "To enable Gmail contacts filtering, please sign in with your Google account.",
      duration: 5000,
    });
    // In a real implementation, this would redirect to Google OAuth
    window.location.href = "/auth/google";
  };

  return (
    <Card className="mb-4 bg-blue-50 border-blue-200">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-blue-700">
          <Mail className="h-5 w-5" />
          Gmail Contacts Privacy Feature
        </CardTitle>
        <CardDescription className="text-blue-600">
          For your privacy, chat is restricted to people in your Gmail contacts
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          {isGoogleUser ? (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle className="h-4 w-4" />
              <span>
                You're signed in with Google. You'll only see and chat with people in your contacts.
              </span>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 text-sm text-amber-600">
                <AlertCircle className="h-4 w-4" />
                <span>
                  You're not using Gmail contacts filtering. To enable this privacy feature, sign in with Google.
                </span>
              </div>
              <Button
                variant="outline" 
                size="sm"
                className="flex items-center gap-2 border-blue-300 hover:bg-blue-100"
                onClick={handleSignInWithGoogle}
              >
                <SiGoogle className="h-4 w-4 text-blue-600" />
                <span>Sign in with Google</span>
              </Button>
            </>
          )}
          <div className="flex items-start gap-2 pt-2 text-xs text-blue-600">
            <Users className="h-4 w-4 mt-0.5" />
            <div>
              This means only people who are in your Gmail contacts list will be able to see 
              you online and exchange messages with you. This adds an extra layer of privacy 
              to your chat experience.
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}