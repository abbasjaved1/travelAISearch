import { useState } from "react";
import { useForm } from "react-hook-form";
import { useQuery, useMutation } from "@tanstack/react-query";
import { PackingList, PackingItem } from "@shared/schema";
import { Button } from "./button";
import { Input } from "./input";
import { Label } from "./label";
import { Card } from "./card";
import { Checkbox } from "./checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./select";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type PackingAssistantForm = {
  destination: string;
  tripStartDate: string;
  tripEndDate: string;
  activities: string[];
};

export function PackingAssistant() {
  const { toast } = useToast();
  const [currentList, setCurrentList] = useState<PackingList | null>(null);

  const form = useForm<PackingAssistantForm>({
    defaultValues: {
      destination: "",
      tripStartDate: "",
      tripEndDate: "",
      activities: [],
    },
  });

  const { data: packingList, isLoading: isLoadingList } = useQuery<PackingList>({
    queryKey: ["/api/packing-list"],
    enabled: false,
  });

  const generateRecommendationsMutation = useMutation({
    mutationFn: async (data: PackingAssistantForm) => {
      const response = await fetch("/api/packing-assistant/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to generate recommendations");
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentList(data);
      toast({
        title: "Recommendations Generated",
        description: "Your packing list has been created based on your trip details.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate packing recommendations.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PackingAssistantForm) => {
    generateRecommendationsMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold mb-4">Smart Packing Assistant</h2>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label htmlFor="destination">Destination</Label>
              <Input
                id="destination"
                placeholder="Enter your destination"
                {...form.register("destination")}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tripStartDate">Start Date</Label>
                <Input
                  id="tripStartDate"
                  type="date"
                  {...form.register("tripStartDate")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tripEndDate">End Date</Label>
                <Input
                  id="tripEndDate"
                  type="date"
                  {...form.register("tripEndDate")}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Activities</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select activities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beach">Beach</SelectItem>
                  <SelectItem value="hiking">Hiking</SelectItem>
                  <SelectItem value="skiing">Skiing</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="sightseeing">Sightseeing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={generateRecommendationsMutation.isPending}
          >
            {generateRecommendationsMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Packing List"
            )}
          </Button>
        </form>
      </Card>

      {currentList && (
        <Card className="p-6">
          <h3 className="text-xl font-bold mb-4">Your Packing List</h3>
          <div className="space-y-4">
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">AI Recommendations</h4>
              <ul className="list-disc list-inside space-y-1">
                {currentList.recommendations.map((rec, index) => (
                  <li key={index} className="text-sm text-muted-foreground">
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Items to Pack</h4>
              <ul className="space-y-2">
                {currentList.items.map((item) => (
                  <li
                    key={item.id}
                    className="flex items-center justify-between p-2 bg-card rounded-lg border"
                  >
                    <div className="flex items-center space-x-2">
                      <Checkbox checked={false} />
                      <span>{item.name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        value={item.quantity}
                        className="w-20"
                        min={1}
                      />
                      <Button variant="ghost" size="icon">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
