import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./button";
import { Card, CardContent } from "./card";
import {
  Brain,
  MessageCircle,
  Calendar,
  Compass,
  ChevronRight,
  ChevronLeft,
  X,
} from "lucide-react";

interface OnboardingStep {
  title: string;
  description: string;
  Icon: typeof Brain;
  color: string;
}

const steps: OnboardingStep[] = [
  {
    title: "AI Trip Planning",
    description: "Let our advanced AI create personalized travel itineraries just for you. Get smart recommendations based on your preferences.",
    Icon: Brain,
    color: "from-blue-500 to-purple-500",
  },
  {
    title: "Chat & Connect",
    description: "Connect with fellow travelers in real-time. Share experiences and get instant help from our AI assistant.",
    Icon: MessageCircle,
    color: "from-green-500 to-teal-500",
  },
  {
    title: "Smart Booking",
    description: "Book flights, hotels, and experiences seamlessly. Our AI ensures you get the best deals at the right time.",
    Icon: Calendar,
    color: "from-orange-500 to-red-500",
  },
  {
    title: "Personal Recommendations",
    description: "Discover places and experiences tailored to your interests. Our AI learns your preferences to make better suggestions.",
    Icon: Compass,
    color: "from-purple-500 to-pink-500",
  },
];

interface OnboardingTutorialProps {
  onComplete: () => void;
  onDismiss: () => void;
}

export function OnboardingTutorial({ onComplete, onDismiss }: OnboardingTutorialProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(0);

  const goToNextStep = () => {
    if (currentStep === steps.length - 1) {
      onComplete();
      return;
    }
    setDirection(1);
    setCurrentStep((prev) => prev + 1);
  };

  const goToPrevStep = () => {
    if (currentStep === 0) return;
    setDirection(-1);
    setCurrentStep((prev) => prev - 1);
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const CurrentIcon = steps[currentStep].Icon;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <Card className="w-full max-w-2xl bg-white/95 backdrop-blur border-0 shadow-2xl">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-8">
            <div className="w-8" /> {/* Spacer */}
            <div className="flex gap-2">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 w-2 rounded-full transition-colors ${
                    index === currentStep
                      ? "bg-primary"
                      : "bg-gray-200"
                  }`}
                />
              ))}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8"
              onClick={onDismiss}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <AnimatePresence custom={direction} mode="wait">
            <motion.div
              key={currentStep}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
            >
              <div className="text-center space-y-6">
                <div className={`inline-flex p-4 rounded-full bg-gradient-to-r ${steps[currentStep].color}`}>
                  <CurrentIcon className="w-12 h-12 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-3">{steps[currentStep].title}</h2>
                  <p className="text-gray-600 text-lg leading-relaxed">
                    {steps[currentStep].description}
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-between items-center mt-8">
            <Button
              variant="ghost"
              onClick={goToPrevStep}
              disabled={currentStep === 0}
              className={currentStep === 0 ? "invisible" : ""}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>
            <Button onClick={goToNextStep}>
              {currentStep === steps.length - 1 ? (
                "Get Started"
              ) : (
                <>
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}