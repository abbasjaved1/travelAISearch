import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/hooks/use-auth';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  MapPin,
  Clock,
  DollarSign,
  Star,
  Search,
  Compass,
  Coffee,
  Palette,
  Mountain,
  ShoppingBag,
  Loader2,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface LocalExperience {
  title: string;
  category: 'food' | 'culture' | 'adventure' | 'relaxation' | 'shopping';
  description: string;
  why_recommended: string;
  best_time: string;
  duration: string;
  price_range: 'budget' | 'moderate' | 'luxury';
  location: string;
  rating: number;
}

interface LocalExperiencesResponse {
  experiences: LocalExperience[];
}

const categoryIcons = {
  food: Coffee,
  culture: Palette,
  adventure: Mountain,
  relaxation: Compass,
  shopping: ShoppingBag,
};

const priceRangeSymbols = {
  budget: '💰',
  moderate: '💰💰',
  luxury: '💰💰💰',
};

export function LocalExperiences() {
  const { user } = useAuth();
  const [location, setLocation] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  const {
    data: recommendations,
    isLoading,
    error,
    refetch,
  } = useQuery<LocalExperiencesResponse>({
    queryKey: ['/api/local-experiences', location],
    enabled: false,
  });

  const handleSearch = async () => {
    if (!location.trim()) return;
    setIsSearching(true);
    await refetch();
    setIsSearching(false);
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  // Assumed useIsMobile hook
  const useIsMobile = () => {
    const userAgent = typeof window !== 'undefined' ? window.navigator.userAgent : '';
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
  };


  const isMobile = useIsMobile();
  
  return (
    <div className={`w-full mx-auto ${isMobile ? 'p-3' : 'p-6 max-w-6xl'}`}>
      <div className="text-center mb-8">
        <h2 className={`${isMobile ? 'text-2xl' : 'text-3xl'} font-bold mb-3 gradient-heading`}>
          Local Experience Recommender
        </h2>
        <p className="text-muted-foreground mb-4 max-w-2xl mx-auto">
          Discover unique experiences tailored to your preferences that capture the essence of your destinationences
        </p>

        <div className="flex gap-4 max-w-xl mx-auto">
          <Input
            placeholder="Enter a location..."
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="flex-1"
          />
          <Button
            onClick={handleSearch}
            disabled={isSearching || !location.trim()}
            className="min-w-[120px]"
          >
            {isSearching ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Search className="w-4 h-4 mr-2" />
            )}
            Search
          </Button>
        </div>
      </div>

      {isLoading && (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}

      {error && (
        <div className="text-center text-destructive py-8">
          Failed to load recommendations. Please try again.
        </div>
      )}

      <AnimatePresence>
        {recommendations?.experiences && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6"
            style={{ padding: useIsMobile() ? '0.5rem' : '1rem' }}
          >
            {recommendations.experiences.map((experience, index) => {
              const Icon = categoryIcons[experience.category];
              return (
                <motion.div
                  key={experience.title}
                  variants={cardVariants}
                  initial="hidden"
                  animate="visible"
                  exit="hidden"
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="capitalize">
                          <Icon className="w-4 h-4 mr-1" />
                          {experience.category}
                        </Badge>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-400 mr-1" />
                          <span className="text-sm">{experience.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <CardTitle className="line-clamp-2">{experience.title}</CardTitle>
                      <CardDescription className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        {experience.location}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm mb-4 line-clamp-3">
                        {experience.description}
                      </p>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>{experience.duration}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4" />
                          <span>{priceRangeSymbols[experience.price_range]}</span>
                        </div>
                      </div>
                      <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                        <p className="text-sm font-medium mb-1">Why we recommend this:</p>
                        <p className="text-sm text-muted-foreground">
                          {experience.why_recommended}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}