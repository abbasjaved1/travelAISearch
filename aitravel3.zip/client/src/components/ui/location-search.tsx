import React, { useState, useEffect } from 'react';
import { useDebounce } from '@/hooks/use-debounce';
import { Input } from '@/components/ui/input';
import { 
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { GlobeIcon, Loader2, MapPin, CheckIcon } from 'lucide-react';
import axios from 'axios';

interface Location {
  id: string;
  name: string;
  country: string;
}

interface LocationSearchProps extends React.ComponentPropsWithoutRef<typeof Input> {
  onLocationSelect: (location: string) => void;
  initialValue?: string;
}

export function LocationSearch({ 
  onLocationSelect,
  initialValue = '',
  className,
  ...props
}: LocationSearchProps) {
  const [open, setOpen] = useState(false);
  const [inputValue, setInputValue] = useState(initialValue);
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Pre-populated popular destinations
  const popularDestinations: Location[] = [
    { id: 'london', name: 'London', country: 'United Kingdom' },
    { id: 'paris', name: 'Paris', country: 'France' },
    { id: 'newyork', name: 'New York', country: 'United States' },
    { id: 'tokyo', name: 'Tokyo', country: 'Japan' },
    { id: 'bali', name: 'Bali', country: 'Indonesia' },
    { id: 'rome', name: 'Rome', country: 'Italy' },
  ];
  
  // Debounce the search input to reduce API calls
  const debouncedSearch = useDebounce(inputValue, 300);
  
  // Function to search for locations
  const searchLocations = async (query: string) => {
    if (!query || query.length < 2) {
      return popularDestinations;
    }

    try {
      setLoading(true);
      
      // In production, replace with an actual API call to a location/places service
      // For demo, simulate API latency and return filtered popular destinations
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Simulate server response or API call (use a real API in production)
      const filteredResults = popularDestinations.filter(loc => 
        loc.name.toLowerCase().includes(query.toLowerCase()) || 
        loc.country.toLowerCase().includes(query.toLowerCase())
      );
      
      // Add some additional simulated results for common searches
      const additionalResults: Location[] = [];
      const lowercaseQuery = query.toLowerCase();
      
      if (lowercaseQuery.includes('new') && !lowercaseQuery.includes('york')) {
        additionalResults.push({ id: 'neworleans', name: 'New Orleans', country: 'United States' });
      }
      
      if (lowercaseQuery.includes('san')) {
        additionalResults.push({ id: 'sanfrancisco', name: 'San Francisco', country: 'United States' });
        additionalResults.push({ id: 'sandiego', name: 'San Diego', country: 'United States' });
      }
      
      if (lowercaseQuery.includes('hong')) {
        additionalResults.push({ id: 'hongkong', name: 'Hong Kong', country: 'China' });
      }
      
      if (lowercaseQuery.includes('bang')) {
        additionalResults.push({ id: 'bangkok', name: 'Bangkok', country: 'Thailand' });
      }
      
      if (lowercaseQuery.includes('syd')) {
        additionalResults.push({ id: 'sydney', name: 'Sydney', country: 'Australia' });
      }
      
      if (lowercaseQuery.includes('dub')) {
        additionalResults.push({ id: 'dubai', name: 'Dubai', country: 'United Arab Emirates' });
        additionalResults.push({ id: 'dublin', name: 'Dublin', country: 'Ireland' });
      }

      return [...filteredResults, ...additionalResults];
      
    } catch (error) {
      console.error('Error searching for locations:', error);
      return popularDestinations;
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    const fetchLocations = async () => {
      const results = await searchLocations(debouncedSearch);
      setLocations(results);
    };
    
    fetchLocations();
  }, [debouncedSearch]);
  
  // Handle location selection
  const handleLocationSelect = (location: Location) => {
    setInputValue(`${location.name}, ${location.country}`);
    onLocationSelect(`${location.name}, ${location.country}`);
    setOpen(false);
  };
  
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div className="relative w-full">
          <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onFocus={() => setOpen(true)}
            className="pl-9 pr-4"
            placeholder="Search destinations..."
            {...props}
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-full" align="start">
        <Command>
          <CommandInput 
            placeholder="Search destinations..."
            value={inputValue}
            onValueChange={setInputValue}
            className="border-none focus:ring-0"
          />
          <CommandList>
            {loading && (
              <div className="flex items-center justify-center py-6">
                <Loader2 className="h-6 w-6 animate-spin text-primary/70" />
              </div>
            )}
            
            {!loading && locations.length === 0 && (
              <CommandEmpty>No locations found</CommandEmpty>
            )}
            
            {!loading && locations.length > 0 && (
              <CommandGroup>
                {locations.map((location) => (
                  <CommandItem
                    key={location.id}
                    onSelect={() => handleLocationSelect(location)}
                    className="flex items-center gap-2 px-4 py-2"
                  >
                    <div className="flex h-7 w-7 items-center justify-center rounded-full border">
                      <GlobeIcon className="h-3.5 w-3.5 text-primary/70" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm font-medium">{location.name}</span>
                      <span className="text-xs text-muted-foreground">{location.country}</span>
                    </div>
                    {inputValue === `${location.name}, ${location.country}` && (
                      <CheckIcon className="ml-auto h-4 w-4 text-primary" />
                    )}
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}