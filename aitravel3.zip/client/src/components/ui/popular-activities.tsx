import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "./button";
import { Skeleton } from "./skeleton";
import { Link } from "wouter";
import { MapPin, ArrowRight, Filter, Activity } from "lucide-react";
import { ActivityCard, ActivityData } from "./activity-card";

export function PopularActivities() {
  const [currentCity, setCurrentCity] = useState("New York");
  const [filter, setFilter] = useState<string | null>(null);
  const cities = ["New York", "London", "Paris", "Tokyo", "Rome"];
  
  // Fetch activities data for the selected city
  const { data, isLoading, error, refetch } = useQuery<ActivityData[]>({
    queryKey: ["/api/activities", currentCity],
    retry: 2,
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  // Category filters
  const categories = [
    { id: "museum", label: "Museums" },
    { id: "historic", label: "Historic" },
    { id: "outdoors", label: "Outdoors" },
    { id: "entertainment", label: "Entertainment" }
  ];
  
  // Filter activities by category if a filter is selected
  const activities = data ? data.filter(activity => 
    !filter || activity.category.toLowerCase().includes(filter.toLowerCase())
  ) : [];
  
  const topActivities = activities
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);
  
  const handleCityChange = (city: string) => {
    setCurrentCity(city);
  };
  
  const handleFilterChange = (category: string | null) => {
    setFilter(category === filter ? null : category);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl md:text-2xl font-bold">Popular Activities</h2>
          <div className="skeleton-loader"></div>
        </div>
        
        <div className="flex gap-2 overflow-auto pb-2 hide-scrollbar">
          {cities.map((city) => (
            <Button
              key={city}
              variant="outline"
              size="sm"
              className="flex-shrink-0"
              disabled
            >
              <Skeleton className="h-4 w-16" />
            </Button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-40 w-full rounded-lg" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Error state
  if (error || !data) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl md:text-2xl font-bold">Popular Activities</h2>
        <div className="p-6 text-center rounded-lg border border-dashed">
          <p className="text-gray-500 mb-4">Unable to load activities at this time</p>
          <Button onClick={() => refetch()} variant="outline" size="sm">
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-bold">Popular Activities</h2>
        <Link href="/activities">
          <Button variant="outline" size="sm">
            <Activity className="w-4 h-4 mr-2" />
            View All
          </Button>
        </Link>
      </div>
      
      <div className="flex flex-wrap gap-2">
        <div className="flex gap-2 overflow-auto pb-2 hide-scrollbar mr-4">
          {cities.map((city) => (
            <Button
              key={city}
              variant={city === currentCity ? "default" : "outline"}
              size="sm"
              className="flex-shrink-0"
              onClick={() => handleCityChange(city)}
            >
              <MapPin className="w-3.5 h-3.5 mr-1.5" />
              {city}
            </Button>
          ))}
        </div>
        
        <div className="flex gap-2 ml-auto">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={filter === category.id ? "default" : "outline"}
              size="sm"
              className="flex-shrink-0"
              onClick={() => handleFilterChange(category.id)}
            >
              <Filter className="w-3.5 h-3.5 mr-1.5" />
              {category.label}
            </Button>
          ))}
        </div>
      </div>
      
      {topActivities.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {topActivities.map((activity, index) => (
            <ActivityCard key={activity.id} activity={activity} index={index} compact />
          ))}
        </div>
      ) : (
        <div className="p-6 text-center rounded-lg border border-dashed">
          <p className="text-gray-500 mb-4">No activities found for {currentCity} {filter ? `in ${filter} category` : ""}</p>
          <div className="flex gap-3 justify-center">
            <Button 
              onClick={() => setFilter(null)}
              variant="outline" 
              size="sm"
              className="gap-2"
            >
              <Filter className="w-4 h-4" />
              Clear Filters
            </Button>
            
            <Button 
              onClick={() => setCurrentCity("London")}
              variant="outline" 
              size="sm"
              className="gap-2"
            >
              <ArrowRight className="w-4 h-4" />
              Try Another City
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}