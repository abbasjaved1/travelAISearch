import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "./card";
import { Input } from "./input";
import { Button } from "./button";
import { ScrollArea } from "./scroll-area";
import { Skeleton } from "./skeleton";
import { DestinationSkeletonGrid } from "./destination-skeleton";
import {
  MapPin,
  Search,
  Calendar,
  Globe,
  Users,
  Star,
  DollarSign,
  Filter,
  Play,
  Pause,
  Loader2,
  AlertCircle,
  SunMedium,
  Cloud,
  CloudSnow,
  Wind,
  Info,
  ExternalLink,
  Award,
  Compass
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { Player } from "@lottiefiles/react-lottie-player";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";

interface Destination {
  id: string;
  name: string;
  description: string;
  region: string;
  country: string;
  weather: string;
  rating: number;
  priceRange: string;
  crowdLevel: string;
  bestTimeToVisit: string;
  type: string;
  events: Array<{
    id: string;
    name: string;
    date: string;
    location: string;
    description: string;
  }>;
  image: string;
  videoUrl?: string;
  latitude?: number;
  longitude?: number;
  webUrl?: string;
  subcategories?: string;
  ranking?: string;
  reviewCount?: number;
  video?: {
    url: string;
    previewUrl: string;
    type: 'lottie' | 'video';
  };
}

const popularDestinations = [
  {
    name: "Paris",
    region: "France",
    rating: 4.8,
    priceRange: "$$$$",
    type: "city",
    image: "https://source.unsplash.com/800x600/?paris,eiffel",
    bestTimeToVisit: "April to October",
    video: {
      url: "https://assets2.lottiefiles.com/packages/lf20_jR229r.json",
      previewUrl: "https://source.unsplash.com/800x600/?paris,eiffel",
      type: "lottie"
    }
  },
  {
    name: "Bali",
    region: "Indonesia",
    rating: 4.6,
    priceRange: "$$$",
    type: "beach",
    image: "https://source.unsplash.com/800x600/?bali,beach",
    bestTimeToVisit: "April to October",
    video: {
      url: "https://assets5.lottiefiles.com/packages/lf20_UW8DlGLe5h.json",
      previewUrl: "https://source.unsplash.com/800x600/?bali,beach",
      type: "lottie"
    }
  },
  {
    name: "Tokyo",
    region: "Japan",
    rating: 4.9,
    priceRange: "$$$$",
    type: "city",
    image: "https://source.unsplash.com/800x600/?tokyo,japan",
    bestTimeToVisit: "March to May"
  },
  {
    name: "Santorini",
    region: "Greece",
    rating: 4.7,
    priceRange: "$$$$",
    type: "island",
    image: "https://source.unsplash.com/800x600/?santorini",
    bestTimeToVisit: "June to September"
  },
  {
    name: "Swiss Alps",
    region: "Switzerland",
    rating: 4.8,
    priceRange: "$$$$",
    type: "mountain",
    image: "https://source.unsplash.com/800x600/?swiss,alps",
    bestTimeToVisit: "December to March"
  },
  {
    name: "Maldives",
    region: "Maldives",
    rating: 4.9,
    priceRange: "$$$$$",
    type: "beach",
    image: "https://source.unsplash.com/800x600/?maldives",
    bestTimeToVisit: "November to April"
  }
];

export function ExploreDestinations({ id }: { id?: string }) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [priceRange, setPriceRange] = useState("all");
  const [hoveredDestination, setHoveredDestination] = useState<string | null>(null);
  const [isTourMode, setIsTourMode] = useState(false);
  const [currentTourIndex, setCurrentTourIndex] = useState(0);
  const [isSearching, setIsSearching] = useState(false);
  const [showDetailedView, setShowDetailedView] = useState<string | null>(null);
  const [isHovering, setIsHovering] = useState(false);
  const componentRef = useRef<HTMLDivElement>(null);

  // Optimized caching strategy for destination data with immediate responsiveness
  const { data: destinations = [], isLoading, error, isError, refetch } = useQuery<Destination[]>({
    queryKey: ["/api/destinations", searchQuery, selectedType, priceRange],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("q", searchQuery);
      if (selectedType !== "all") params.append("type", selectedType);
      if (priceRange !== "all") params.append("price", priceRange);

      try {
        setIsSearching(true);

        // Performance optimization: Check memory cache first (fastest)
        const cacheKey = `destinations_${searchQuery}_${selectedType}_${priceRange}`;
        const cachedData = localStorage.getItem(cacheKey);

        if (cachedData) {
          try {
            const parsed = JSON.parse(cachedData);
            const cacheTime = parsed.timestamp;

            // Use cache if it's less than 30 minutes old - immediate response
            if (Date.now() - cacheTime < 30 * 60 * 1000) {
              setIsSearching(false);

              // Still fetch in background for fresh data if cache is older than 5 minutes
              if (Date.now() - cacheTime > 5 * 60 * 1000) {
                setTimeout(() => {
                  fetch(`/api/destinations?${params}`)
                    .then(res => res.json())
                    .then(data => {
                      // Update cache silently
                      const enhancedData = enhanceDestinationsWithVideo(data);
                      localStorage.setItem(cacheKey, JSON.stringify({
                        data: enhancedData,
                        timestamp: Date.now()
                      }));
                    })
                    .catch(e => console.warn('Background refresh failed:', e));
                }, 100);
              }

              return parsed.data;
            }
          } catch (e) {
            // Invalid cache data, proceed with fetching
            console.warn('Invalid cache data, fetching from API');
          }
        }

        // For blank or short searches, respond immediately with popular destinations
        if (!searchQuery || searchQuery.length < 3) {
          setIsSearching(false);
          return popularDestinations as any;
        }

        // Fetch fresh data - use AbortController for timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

        try {
          const res = await fetch(`/api/destinations?${params}`, {
            signal: controller.signal
          });

          clearTimeout(timeoutId);

          if (!res.ok) {
            throw new Error(`Failed to fetch destinations: ${res.statusText}`);
          }

          const data = await res.json();

          // Add video preview for certain destinations with helper function
          const enhancedData = enhanceDestinationsWithVideo(data);

          // Store in cache
          try {
            localStorage.setItem(cacheKey, JSON.stringify({
              data: enhancedData,
              timestamp: Date.now()
            }));
          } catch (e) {
            console.warn('Failed to cache destination data:', e);
          }

          setIsSearching(false);
          return enhancedData;
        } catch (error: unknown) {
          if (error instanceof Error && error.name === 'AbortError') {
            console.warn('Destination fetch timed out, using fallback data');
            setIsSearching(false);
            return popularDestinations as any;
          }
          throw error;
        }
      } catch (error: unknown) {
        console.error('Error fetching destinations:', error instanceof Error ? error.message : String(error));
        setIsSearching(false);
        throw error;
      }
    },
    enabled: !searchQuery || searchQuery.length > 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
    initialData: popularDestinations as any,
    refetchOnWindowFocus: false
  });

  // Helper function to add video data to destinations
  // Add a global timeout effect for all animations
  useEffect(() => {
    // If any animation is shown (either during tour or on hover), set up a safety timeout
    if (hoveredDestination !== null) {
      const timeoutId = setTimeout(() => {
        // Find all visible loading spinners and hide them
        const spinners = document.querySelectorAll('.animate-pulse');
        spinners.forEach(spinner => {
          if (spinner instanceof HTMLElement && spinner.style.display !== 'none') {
            spinner.style.display = 'none';

            // Find the parent card and show the fallback image
            const card = spinner.closest('.relative')?.parentElement;
            if (card) {
              const fallbackImg = card.querySelector('img');
              if (fallbackImg instanceof HTMLImageElement) {
                fallbackImg.style.opacity = '1';
              }
            }
          }
        });
      }, 3000); // 3 second timeout

      return () => clearTimeout(timeoutId);
    }
  }, [hoveredDestination, currentTourIndex]);

  // Helper function to add video data to destinations
  const enhanceDestinationsWithVideo = (data: Destination[]) => {
    // Simple, reliable animations that are less likely to fail
    const reliableAnimations = [
      "https://assets3.lottiefiles.com/packages/lf20_AMBEWz.json", // Simple globe
      "https://assets2.lottiefiles.com/private_files/lf30_LOw4AL.json", // Earth
      "https://assets6.lottiefiles.com/private_files/lf30_bin48etr.json", // Location pin
      "https://assets7.lottiefiles.com/temp/lf20_nXwOJj.json", // Map marker
      "https://assets2.lottiefiles.com/private_files/lf30_t26law.json", // Waves
    ];

    return data.map((dest: Destination) => {
      // If destination already has a regular video, keep it
      if (dest.video && dest.video.type !== 'lottie') {
        return dest;
      }

      // Always use reliable animations
      // Generate a consistent animation index based on destination name
      const nameSum = dest.name.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
      const animationIndex = nameSum % reliableAnimations.length;

      return {
        ...dest,
        video: {
          url: reliableAnimations[animationIndex],
          previewUrl: dest.image,
          type: 'lottie' as const
        }
      };
    });
  };

  // Event listener for external search requests (from popular searches)
  useEffect(() => {
    if (!componentRef.current || !id) return;

    const handleExternalSearch = (event: CustomEvent) => {
      const { type, term } = event.detail;
      if (type) {
        setSelectedType(type);
      }
      if (term) {
        setSearchQuery(term);
      }
      // Trigger search with the new parameters
      setTimeout(() => refetch(), 100);
    };

    componentRef.current.id = id;
    componentRef.current.addEventListener('setSearchType', handleExternalSearch as EventListener);

    return () => {
      if (componentRef.current) {
        componentRef.current.removeEventListener('setSearchType', handleExternalSearch as EventListener);
      }
    };
  }, [id, refetch]);

  // Tour mode functionality
  useEffect(() => {
    console.log("Tour mode effect running:", { 
      isTourMode, 
      destinationsLength: destinations.length,
      currentTourIndex,
      hoveredDestination
    });

    if (isTourMode && destinations.length > 0) {
      console.log("Starting/continuing tour mode");

      // Set initial destination immediately when tour mode starts
      if (hoveredDestination === null || hoveredDestination === undefined) {
        console.log("Setting initial tour destination:", destinations[0].name);
        setCurrentTourIndex(0);
        setHoveredDestination(destinations[0].name);
      }

      // Set timer for next destination
      const timer = setTimeout(() => {
        console.log("Tour timer triggered, moving to next destination");
        const nextIndex = (currentTourIndex + 1) % destinations.length;
        console.log("Next destination index:", nextIndex);
        setCurrentTourIndex(nextIndex);
        setHoveredDestination(destinations[nextIndex].name);
      }, 5000); // Switch every 5 seconds

      return () => {
        console.log("Clearing tour timer");
        clearTimeout(timer);
      };
    }

    // Clear hovered destination when tour mode is turned off
    if (!isTourMode && hoveredDestination !== null && !isHovering) {
      console.log("Tour mode off, clearing hovered destination");
      setHoveredDestination(null);
    }
  }, [isTourMode, currentTourIndex, destinations, hoveredDestination, isHovering]);

  // Handle search
  const handleSearch = () => {
    refetch();
  };

  // Show more info about a destination
  const handleShowDetails = (destination: Destination) => {
    setShowDetailedView(destination.id);
  };

  // Generate weather icon based on weather type
  const getWeatherIcon = (weather?: string) => {
    if (!weather) {
      return <Cloud className="w-4 h-4 text-gray-400" />;
    }

    switch (weather.toLowerCase()) {
      case 'tropical':
        return <SunMedium className="w-4 h-4 text-yellow-500" />;
      case 'mediterranean':
        return <SunMedium className="w-4 h-4 text-orange-400" />;
      case 'hot and dry':
        return <SunMedium className="w-4 h-4 text-red-500" />;
      case 'alpine':
        return <CloudSnow className="w-4 h-4 text-blue-300" />;
      case 'maritime':
        return <Wind className="w-4 h-4 text-blue-400" />;
      default:
        return <Cloud className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div ref={componentRef} className="space-y-6">
      <Card className="bg-white shadow-lg border-0">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-4">
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search destinations..."
                  className="pl-10 h-12"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>
            </div>

            <div className="md:col-span-3">
              <Select
                value={selectedType}
                onValueChange={setSelectedType}
              >
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Destination Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="beach">Beaches</SelectItem>
                  <SelectItem value="city">Cities</SelectItem>
                  <SelectItem value="mountain">Mountains</SelectItem>
                  <SelectItem value="island">Islands</SelectItem>
                  <SelectItem value="cultural">Cultural</SelectItem>
                  <SelectItem value="adventure">Adventure</SelectItem>
                  <SelectItem value="nature">Nature & Parks</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-3">
              <Select
                value={priceRange}
                onValueChange={setPriceRange}
              >
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Price Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Prices</SelectItem>
                  <SelectItem value="$">Budget</SelectItem>
                  <SelectItem value="$$">Moderate</SelectItem>
                  <SelectItem value="$$$">Luxury</SelectItem>
                  <SelectItem value="$$$$">Ultra Luxury</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-2">
              <Button
                className="w-full h-12 bg-[#003580] hover:bg-[#002255]"
                onClick={handleSearch}
                disabled={isLoading || isSearching}
              >
                {isLoading || isSearching ? (
                  <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Searching</>
                ) : (
                  <><Search className="w-5 h-5 mr-2" /> Search</>
                )}
              </Button>
            </div>
          </div>

          {/* Tour mode toggle */}
          <div className="flex items-center justify-between mt-4 px-1">
            <div className="flex gap-2 items-center">
              <Button
                variant="outline" 
                size="sm" 
                onClick={() => {
                  console.log("Tour button clicked, current state:", isTourMode);
                  if (!isTourMode) {
                    // Starting tour
                    console.log("Starting tour from the beginning");
                    setCurrentTourIndex(0);
                    setHoveredDestination(destinations[0]?.name || null);
                  } else {
                    // Pausing tour
                    console.log("Pausing tour");
                  }
                  // Toggle tour mode
                  setIsTourMode(!isTourMode);
                }}
                className={isTourMode ? "bg-blue-50 text-blue-800 border-blue-200" : ""}
              >
                {isTourMode ? (
                  <><Pause className="w-4 h-4 mr-1" /> Pause Tour</>
                ) : (
                  <><Play className="w-4 h-4 mr-1" /> Start Tour</>
                )}
              </Button>

              {destinations.length > 0 && (
                <span className="text-sm text-muted-foreground">
                  Showing {destinations.length} destinations
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setSelectedType("all")}
                className="text-xs"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {isError && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <p>Failed to load destinations. {error instanceof Error ? error.message : "Please try again."}</p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-1">
        {isLoading ? (
          <DestinationSkeletonGrid />
        ) : (
          destinations.map((destination, index) => (
            <div key={index}>
              <Link href={`/destinations/${encodeURIComponent(destination.name)}`}>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  onHoverStart={() => {
                    setIsHovering(true);
                    setHoveredDestination(destination.name);
                  }}
                  onHoverEnd={() => {
                    setIsHovering(false);
                    if (!isTourMode) {
                      setHoveredDestination(null);
                    }
                  }}
                  onClick={(e) => {
                    if (isTourMode) {
                      e.preventDefault();
                      setIsTourMode(false);
                    }
                  }}
                >
                  <Card className="group hover:shadow-elevated hover:shadow-primary/20 transition-all duration-300 ease-out transform hover:-translate-y-2 hover:scale-[1.02] bg-gradient-to-br from-background via-background/98 to-background/95">
                    <div className="relative h-52 rounded-t-lg overflow-hidden transform-gpu will-change-transform">
                      <AnimatePresence mode="crossfade">
                        {/* 
                          Show video/animation when:
                          1. The destination is being hovered over manually, OR
                          2. Tour mode is active AND this is the current tour destination
                        */}
                        {((hoveredDestination === destination.name) || 
                          (isTourMode && currentTourIndex === index)) && 
                          destination.video ? (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.3 }}
                            className="absolute inset-0 bg-black"
                          >
                            {destination.video.type === 'lottie' ? (
                              <>
                                {/* Show loading state while Lottie animation loads */}
                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10 animate-pulse">
                                  <div className="w-6 h-6 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                                </div>

                                <div className="relative z-20">
                                  <Player
                                    autoplay
                                    loop
                                    src={destination.video.url}
                                    style={{ width: '100%', height: '100%' }}
                                    onEvent={event => {
                                      if (event === 'ready') {
                                        // Hide loading indicator when animation is ready
                                        const playerElement = document.querySelector('.lottie-player');
                                        if (playerElement) {
                                          const loadingElement = playerElement.closest('.relative')?.previousElementSibling;
                                          if (loadingElement instanceof HTMLElement) {
                                            loadingElement.style.display = 'none';
                                          }
                                        }
                                        console.log(`Lottie animation for ${destination.name} loaded successfully`);
                                      } else if (event === 'error') {
                                        console.error(`Lottie animation error for ${destination.name}`);
                                        // Show fallback image on error
                                        const playerElement = document.querySelector('.lottie-player');
                                        if (playerElement) {
                                          // Hide the player
                                          (playerElement as HTMLElement).style.opacity = '0';

                                          // Show fallback image
                                          const fallbackImg = playerElement.closest('.relative')?.parentElement?.querySelector('img');
                                          if (fallbackImg instanceof HTMLImageElement) {
                                            fallbackImg.style.opacity = '1';

                                            // Hide loading spinner
                                            const loadingElement = playerElement.closest('.relative')?.previousElementSibling;
                                            if (loadingElement instanceof HTMLElement) {
                                              loadingElement.style.display = 'none';
                                            }
                                          }
                                        }
                                      }
                                    }}
                                    rendererSettings={{
                                      preserveAspectRatio: 'xMidYMid slice',
                                      progressiveLoad: true,
                                    }}
                                  />
                                </div>

                                {/* Fallback in case Lottie fails to load or takes too long */}
                                <img
                                  src={destination.image}
                                  alt={destination.name}
                                  className="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity"
                                  style={{ opacity: 0 }}
                                  onError={(e) => {
                                    // Make visible only if Lottie fails
                                    (e.target as HTMLImageElement).style.opacity = '1';
                                    // Hide loading indicator
                                    const loadingEl = (e.target as HTMLElement).parentElement?.querySelector('.animate-pulse');
                                    if (loadingEl) loadingEl.remove();
                                  }}
                                />
                              </>
                            ) : (
                              <>
                                {/* Show loading state while video loads */}
                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10">
                                  <div className="w-6 h-6 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                                </div>

                                <video
                                  autoPlay
                                  loop
                                  muted
                                  playsInline
                                  className="w-full h-full object-cover z-20"
                                  onLoadedData={(e) => {
                                    // Hide loading indicator when video is ready
                                    const videoElement = e.target as HTMLVideoElement;
                                    const loadingEl = videoElement.previousElementSibling;
                                    if (loadingEl instanceof HTMLElement) {
                                      loadingEl.style.display = 'none';
                                    }
                                    // Ensure the video is visible
                                    videoElement.style.opacity = '1';
                                  }}
                                  onError={(e) => {
                                    console.error("Video loading error:", e);
                                    // Show the fallback image if video fails to load
                                    const videoElement = e.target as HTMLVideoElement;
                                    // Hide the video element that failed
                                    videoElement.style.display = 'none';

                                    const parent = videoElement.parentElement;
                                    if (parent) {
                                      // Show fallback image immediately
                                      const fallbackImg = parent.querySelector('img');
                                      if (fallbackImg instanceof HTMLImageElement) {
                                        fallbackImg.style.opacity = '1';
                                      }
                                      // Hide loading indicator
                                      const loadingEl = parent.querySelector('div.animate-pulse');
                                      if (loadingEl) {
                                        loadingEl.remove();
                                      }
                                    }
                                  }}
                                  crossOrigin="anonymous"
                                >
                                  <source src={destination.video.url} type="video/mp4" />
                                </video>

                                {/* Fallback image in case video fails to load */}
                                <img
                                  src={destination.image}
                                  alt={destination.name}
                                  className="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-300"
                                  style={{ opacity: 0 }}
                                  onError={(e) => {
                                    console.error("Fallback image loading error:", e);
                                    // Hide broken image
                                    (e.target as HTMLImageElement).style.display = 'none';
                                  }}
                                  loading="eager"
                                />
                              </>
                            )}
                          </motion.div>
                        ) : (
                          <img
                            src={destination.image}
                            alt={destination.name}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                            onError={(e) => {
                              // Fallback image in case the main one fails
                              (e.target as HTMLImageElement).src = `https://source.unsplash.com/800x600/?${destination.type},travel`;
                            }}
                          />
                        )}
                      </AnimatePresence>
                      <div className="absolute bottom-0 left-0 right-0 h-full bg-gradient-to-t from-black/70 via-black/30 to-transparent opacity-80 group-hover:opacity-90 transition-all duration-300" />
                      <h3 className="absolute bottom-4 left-4 text-white font-semibold text-lg drop-shadow-md group-hover:translate-x-1 transition-transform duration-300">{destination.name}</h3>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>Best: {destination.bestTimeToVisit}</span>
                          </div>
                          <div className="flex items-center gap-1 text-primary font-semibold">
                            <DollarSign className="w-4 h-4" />
                            <span>{destination.priceRange}</span>
                          </div>
                        </div>

                        {/* Additional destination info */}
                        <div className="flex items-center justify-between text-xs text-muted-foreground mt-1">
                          <div className="flex items-center gap-2">
                            {getWeatherIcon(destination.weather)}
                            <span>{destination.weather || 'N/A'}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            <span>{destination.crowdLevel}</span>
                          </div>
                        </div>
                      </div>

                      {/* Show this on hover */}
                      {hoveredDestination === destination.name && (
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="mt-2 pt-2 border-t border-gray-100"
                        >
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full text-xs text-blue-600 hover:text-blue-800"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              handleShowDetails(destination);
                            }}
                          >
                            <Info className="w-3 h-3 mr-1" />
                            Quick View
                          </Button>
                        </motion.div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              </Link>
            </div>
          ))
        )}
      </div>

      {/* Detailed view dialog */}
      {showDetailedView && (
        <Dialog open={!!showDetailedView} onOpenChange={() => setShowDetailedView(null)}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            {destinations.filter(d => d.id === showDetailedView).map(dest => (
              <div key={dest.id}>
                <DialogHeader>
                  <DialogTitle className="text-2xl flex items-center gap-2">
                    {dest.name}
                    <span className="ml-2 text-sm font-normal bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                      {dest.type.charAt(0).toUpperCase() + dest.type.slice(1)}
                    </span>
                  </DialogTitle>
                </DialogHeader>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <img 
                      src={dest.image} 
                      alt={dest.name}
                      className="w-full h-64 object-cover rounded-lg"
                    />

                    <div className="mt-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span>{dest.region}, {dest.country}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span>Best time to visit: {dest.bestTimeToVisit}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        {getWeatherIcon(dest.weather)}
                        <span>Weather: {dest.weather || 'N/A'}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-gray-500" />
                        <span>Price range: {dest.priceRange}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span>Crowd level: {dest.crowdLevel}</span>
                      </div>

                      {dest.ranking && (
                        <div className="flex items-center gap-2">
                          <Award className="w-4 h-4 text-gray-500" />
                          <span>Ranking: {dest.ranking}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary/90 to-primary/70 mb-3">{dest.name}</h3>
                    <p className="text-muted-foreground leading-relaxed">{dest.description}</p>

                    {dest.subcategories && (
                      <div className="mt-4">
                        <h4 className="text-sm font-medium mb-2">Known For</h4>
                        <div className="flex flex-wrap gap-1">
                          {dest.subcategories.split(',').map((cat, i) => (
                            <span key={i} className="bg-gray-100 px-2 py-0.5 rounded-full text-xs">
                              {cat.trim()}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {dest.latitude && dest.longitude && (
                      <div className="mt-4 h-40 bg-gray-100 rounded-lg flex items-center justify-center text-center p-4">
                        <div>
                          <MapPin className="w-6 h-6 mx-auto mb-2 text-primary" />
                          <p className="text-sm text-gray-500">
                            Located at {dest.latitude.toFixed(6)}, {dest.longitude.toFixed(6)}
                          </p>
                        </div>
                      </div>
                    )}

                    {dest.webUrl && (
                      <Button 
                        className="w-full mt-6 transition-all duration-300 hover:scale-[1.02]" 
                        variant="outline"
                        onClick={() => window.open(dest.webUrl, '_blank')}
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Visit Official Website
                      </Button>
                    )}
                  </div>
                </div>

                <DialogFooter className="mt-6">
                  <Link href={`/destinations/${encodeURIComponent(dest.name)}`}>
                    <Button className="bg-[#003580] hover:bg-[#002255]">
                      <Compass className="w-4 h-4 mr-2" />
                      Visit {dest.name} Page
                    </Button>
                  </Link>
                </DialogFooter>
              </div>
            ))}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}