import { Card, CardContent } from "./card";
import { Button } from "./button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "./skeleton";
import { Link } from "wouter";
import { CalendarDays, Sun, Cloud, CloudRain, DollarSign, MapPin, Zap } from "lucide-react";
import { Badge } from "./badge";

interface Destination {
  id: string;
  name: string;
  type: 'domestic' | 'international' | 'region' | 'country';
  image: string;
  description: string;
  rating: number;
  priceRange: string;
  propertyCount: number;
  bestTimeToVisit?: string[];
  weather?: {
    current?: string;
    temperature?: number;
    condition?: 'sunny' | 'cloudy' | 'rainy' | 'stormy' | 'snowy';
    forecast?: {
      min: number;
      max: number;
      condition: string;
    }[];
  };
  budget?: {
    perDay: number;
    currency: string;
    costLevel: 'low' | 'medium' | 'high';
  };
  activities?: {
    count: number;
    popular: string[];
  };
}

interface FeaturedCountry {
  name: string;
  capital: string;
  code: string;
  continent: string;
  featured: boolean;
  lastFeaturedDate?: string;
  flagUrl?: string;
  provider?: string;
}

interface FeaturedResponse {
  name: string;
  provider: string;
  featuredCountry: string;
  featuredCountryCode: string;
  eventCount: number;
  destinations: any[];
}

const POPULAR_DESTINATIONS: Destination[] = [
  {
    id: "nyc",
    name: "New York City",
    type: "domestic",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9",
    description: "The city that never sleeps",
    rating: 4.5,
    priceRange: "$$$",
    propertyCount: 1234,
    bestTimeToVisit: ["Spring", "Fall"],
    weather: {
      current: "Sunny",
      temperature: 72,
      condition: "sunny",
      forecast: [
        { min: 68, max: 75, condition: "sunny" },
        { min: 65, max: 72, condition: "cloudy" }
      ]
    },
    budget: {
      perDay: 150,
      currency: "USD",
      costLevel: "high"
    },
    activities: {
      count: 18,
      popular: ["Broadway Shows", "Central Park", "Times Square", "Museum Tours"]
    }
  },
  {
    id: "paris",
    name: "Paris",
    type: "international",
    image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
    description: "The city of love",
    rating: 4.7,
    priceRange: "$$$",
    propertyCount: 2345,
    bestTimeToVisit: ["Spring", "Summer", "Fall"],
    weather: {
      current: "Cloudy",
      temperature: 68,
      condition: "cloudy",
      forecast: [
        { min: 63, max: 69, condition: "cloudy" },
        { min: 64, max: 70, condition: "rainy" }
      ]
    },
    budget: {
      perDay: 130,
      currency: "EUR",
      costLevel: "high"
    },
    activities: {
      count: 24,
      popular: ["Eiffel Tower", "Louvre Museum", "River Seine Cruise", "Notre Dame"]
    }
  },
  {
    id: "tokyo",
    name: "Tokyo",
    type: "international",
    image: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26",
    description: "The ultimate modern metropolis",
    rating: 4.8,
    priceRange: "$$$$",
    propertyCount: 3120,
    bestTimeToVisit: ["Spring", "Fall"],
    weather: {
      current: "Sunny",
      temperature: 74,
      condition: "sunny",
      forecast: [
        { min: 70, max: 78, condition: "sunny" },
        { min: 68, max: 75, condition: "cloudy" }
      ]
    },
    budget: {
      perDay: 120,
      currency: "USD",
      costLevel: "high"
    },
    activities: {
      count: 32,
      popular: ["Shibuya Crossing", "Tokyo Tower", "Imperial Palace", "Senso-ji Temple"]
    }
  },
  {
    id: "bali",
    name: "Bali",
    type: "international",
    image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4",
    description: "Island paradise with rich culture",
    rating: 4.6,
    priceRange: "$$",
    propertyCount: 1870,
    bestTimeToVisit: ["May", "June", "July", "August", "September"],
    weather: {
      current: "Sunny",
      temperature: 82,
      condition: "sunny",
      forecast: [
        { min: 78, max: 85, condition: "sunny" },
        { min: 77, max: 84, condition: "sunny" }
      ]
    },
    budget: {
      perDay: 60,
      currency: "USD",
      costLevel: "medium"
    },
    activities: {
      count: 22,
      popular: ["Ubud Monkey Forest", "Rice Terraces", "Uluwatu Temple", "Kuta Beach"]
    }
  },
  {
    id: "rome",
    name: "Rome",
    type: "international",
    image: "https://images.unsplash.com/photo-1552832230-c0197dd311b5",
    description: "The Eternal City",
    rating: 4.7,
    priceRange: "$$$",
    propertyCount: 2100,
    bestTimeToVisit: ["Spring", "Fall"],
    weather: {
      current: "Sunny",
      temperature: 76,
      condition: "sunny",
      forecast: [
        { min: 70, max: 78, condition: "sunny" },
        { min: 68, max: 75, condition: "sunny" }
      ]
    },
    budget: {
      perDay: 110,
      currency: "EUR",
      costLevel: "high"
    },
    activities: {
      count: 28,
      popular: ["Colosseum", "Vatican Museums", "Roman Forum", "Trevi Fountain"]
    }
  },
  {
    id: "cancun",
    name: "Cancun",
    type: "international",
    image: "https://images.unsplash.com/photo-1570737044899-a7095263ee19",
    description: "Caribbean paradise",
    rating: 4.5,
    priceRange: "$$$",
    propertyCount: 1540,
    bestTimeToVisit: ["December", "January", "February", "March", "April"],
    weather: {
      current: "Sunny",
      temperature: 85,
      condition: "sunny",
      forecast: [
        { min: 80, max: 87, condition: "sunny" },
        { min: 79, max: 86, condition: "cloudy" }
      ]
    },
    budget: {
      perDay: 90,
      currency: "USD",
      costLevel: "medium"
    },
    activities: {
      count: 15,
      popular: ["Beaches", "Chichen Itza", "Underwater Museum", "Xcaret Park"]
    }
  }
];

export function PopularDestinations() {
  // Fetch regular popular destinations
  const { data: destinations, isLoading } = useQuery({
    queryKey: ["/api/destinations/popular"],
    initialData: POPULAR_DESTINATIONS,
  });
  
  // Fetch featured country
  const { data: featuredCountry, isLoading: isLoadingFeaturedCountry } = useQuery<FeaturedCountry>({
    queryKey: ["/api/destinations/featured-country"],
    retry: 1,
  });
  
  // Fetch featured destinations for the featured country
  const { data: featuredResponse, isLoading: isLoadingFeatured } = useQuery<FeaturedResponse>({
    queryKey: ["/api/destinations/featured"],
    retry: 1,
  });
  
  // Loading state
  if (isLoading || isLoadingFeaturedCountry || isLoadingFeatured) {
    return (
      <div className="space-y-8">
        {/* Featured country skeleton */}
        <section className="space-y-4">
          <Card className="overflow-hidden border-2 border-primary/20">
            <div className="flex flex-col md:flex-row">
              <Skeleton className="h-48 w-full md:w-1/3" />
              <div className="p-6 w-full md:w-2/3">
                <Skeleton className="h-8 w-3/4 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </div>
          </Card>
        </section>
        
        {/* Destinations skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-48" />
              <CardContent className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }
  
  // Group regular destinations by type
  const groupedDestinations = {
    featured: featuredResponse?.destinations || [],
    domestic: destinations.filter(d => d.type === 'domestic'),
    international: destinations.filter(d => d.type === 'international'),
    regions: destinations.filter(d => d.type === 'region'),
    countries: destinations.filter(d => d.type === 'country')
  };

  return (
    <div className="space-y-8">
      {/* Featured Country Banner */}
      {featuredCountry && (
        <section className="space-y-4">
          <Card className="overflow-hidden border-2 border-primary/20">
            <div className="flex flex-col md:flex-row">
              <div className="h-48 w-full md:w-1/3 bg-gradient-to-r from-primary/80 to-primary relative overflow-hidden">
                {featuredCountry.flagUrl && (
                  <div 
                    className="absolute inset-0 bg-center bg-cover opacity-30"
                    style={{ backgroundImage: `url(${featuredCountry.flagUrl})` }}
                  />
                )}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white p-6">
                    <h2 className="text-3xl font-bold mb-2">Featured Country</h2>
                    <div className="text-xl">{featuredCountry.name}</div>
                    <Badge className="mt-2 bg-white/20 hover:bg-white/30 text-white">
                      {featuredCountry.continent}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="p-6 w-full md:w-2/3">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold">Discover {featuredCountry.name}</h2>
                  <Badge variant="outline" className="text-xs">
                    Daily Featured
                  </Badge>
                </div>
                <p className="mb-4">
                  Explore the beauty and culture of {featuredCountry.name}, our featured destination of the day! 
                  From the vibrant capital of {featuredCountry.capital} to scenic landscapes and rich cultural 
                  experiences, {featuredCountry.name} offers unforgettable adventures for every traveler.
                </p>
                <div className="flex items-center gap-3">
                  <Button asChild>
                    <Link href={`/destinations/${encodeURIComponent(featuredCountry.name)}`}>
                      Explore {featuredCountry.name}
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <a href={`https://en.wikipedia.org/wiki/${encodeURIComponent(featuredCountry.name)}`} target="_blank" rel="noopener noreferrer">
                      Learn More
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </section>
      )}
      
      {/* Destination Categories */}
      {Object.entries(groupedDestinations).map(([category, items]) => {
        if (items.length === 0) return null;
        
        return (
          <section key={category} className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold capitalize">
                {category === 'featured' 
                  ? `Featured: ${featuredResponse?.featuredCountry || 'Top Destinations'}`
                  : category.replace('_', ' ')}
              </h2>
              <Button variant="ghost" asChild>
                <Link href={`/destinations/${category}`}>
                  View all
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {items.map((destination) => (
                <Link key={destination.id} href={`/destinations/${encodeURIComponent(destination.name)}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                    <div 
                      className="h-48 bg-cover bg-center relative"
                      style={{ 
                        backgroundImage: `url(${destination.image}?auto=format&fit=crop&w=800&q=60)`
                      }}
                    >
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
                      <div className="absolute bottom-0 left-0 right-0 p-4 text-white bg-gradient-to-t from-black/60">
                        <h3 className="text-xl font-semibold">{destination.name}</h3>
                        <p className="text-sm text-white/90">{destination.description}</p>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-sm text-muted-foreground">
                          {destination.propertyCount ? `${destination.propertyCount.toLocaleString()} properties` : 'Multiple properties'}
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-sm font-medium">{destination.rating || 4.5}</span>
                          <span className="text-yellow-400">★</span>
                        </div>
                      </div>
                      
                      {/* Best Time to Visit */}
                      {destination.bestTimeToVisit && (
                        <div className="flex items-start gap-2 mb-2">
                          <CalendarDays className="h-4 w-4 mt-0.5 text-primary" />
                          <div>
                            <p className="text-xs font-semibold">Best Time</p>
                            <p className="text-sm">
                              {Array.isArray(destination.bestTimeToVisit) 
                                ? destination.bestTimeToVisit.join(", ") 
                                : typeof destination.bestTimeToVisit === 'string'
                                  ? destination.bestTimeToVisit
                                  : 'Year round'}
                            </p>
                          </div>
                        </div>
                      )}
                      
                      {/* Weather */}
                      {destination.weather && (
                        <div className="flex items-start gap-2 mb-2">
                          {destination.weather.condition === 'sunny' && <Sun className="h-4 w-4 mt-0.5 text-yellow-500" />}
                          {destination.weather.condition === 'cloudy' && <Cloud className="h-4 w-4 mt-0.5 text-blue-400" />}
                          {destination.weather.condition === 'rainy' && <CloudRain className="h-4 w-4 mt-0.5 text-blue-500" />}
                          {(!destination.weather.condition || 
                            (destination.weather.condition !== 'sunny' && 
                             destination.weather.condition !== 'cloudy' && 
                             destination.weather.condition !== 'rainy')) && 
                            <Cloud className="h-4 w-4 mt-0.5 text-blue-400" />}
                          <div>
                            <p className="text-xs font-semibold">Weather</p>
                            <p className="text-sm">
                              {destination.weather.current || 'Pleasant'}{destination.weather.temperature ? `, ${destination.weather.temperature}°F` : ''}
                            </p>
                          </div>
                        </div>
                      )}
                      
                      {/* Budget */}
                      {destination.budget && (
                        <div className="flex items-start gap-2 mb-2">
                          <DollarSign className="h-4 w-4 mt-0.5 text-green-500" />
                          <div>
                            <p className="text-xs font-semibold">Budget</p>
                            <div className="flex items-center gap-1">
                              <p className="text-sm">
                                ${destination.budget.perDay || 100}/{destination.budget.currency || 'USD'} per day
                              </p>
                              <Badge 
                                variant={
                                  destination.budget.costLevel === 'low' 
                                    ? 'secondary' 
                                    : destination.budget.costLevel === 'medium' 
                                      ? 'outline' 
                                      : 'default'
                                } 
                                className="text-[10px] px-1 py-0 h-4"
                              >
                                {destination.budget.costLevel || 'medium'}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Activities */}
                      {destination.activities && (
                        <div className="flex items-start gap-2">
                          <Zap className="h-4 w-4 mt-0.5 text-purple-500" />
                          <div>
                            <p className="text-xs font-semibold">Activities</p>
                            <p className="text-sm">{destination.activities.count || 'Multiple'} Activities Available</p>
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-3 text-sm font-medium border-t pt-3 border-muted">
                        From {destination.priceRange || '$$$'} per night
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}