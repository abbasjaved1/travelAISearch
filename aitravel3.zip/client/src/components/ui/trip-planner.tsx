import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from './button';
import { Input } from './input';
import { Card, CardContent } from './card';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { TripPlanView } from './trip-plan-view';
import { format, addDays } from 'date-fns';

export function TripPlanner() {
  const { toast } = useToast();
  const [destination, setDestination] = useState('');

  // Initialize dates with proper format
  const today = format(new Date(), 'yyyy-MM-dd');
  const [startDate, setStartDate] = useState(today);
  const [endDate, setEndDate] = useState(format(addDays(new Date(), 7), 'yyyy-MM-dd'));

  const tripPlanMutation = useMutation({
    mutationFn: async () => {
      if (!destination || !startDate || !endDate) {
        throw new Error('Please fill in all required fields');
      }

      const start = new Date(startDate);
      const end = new Date(endDate);

      if (end < start) {
        throw new Error('End date cannot be before start date');
      }

      const response = await fetch('/api/ai/trip-plan', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          destination,
          dates: {
            start: startDate,
            end: endDate
          },
          preferences: {
            includeImages: true
          }
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to generate trip plan');
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Trip Plan Generated",
        description: "Your personalized trip plan is ready!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate trip plan",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    tripPlanMutation.mutate();
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              placeholder="Enter destination..."
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="w-full"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              min={today}
              className="w-full"
            />
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              min={startDate}
              className="w-full"
            />
          </div>
          <Button 
            type="submit" 
            className="w-full"
            disabled={tripPlanMutation.isPending || !destination}
          >
            {tripPlanMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Plan...
              </>
            ) : (
              'Generate Trip Plan'
            )}
          </Button>
        </form>

        {tripPlanMutation.data && (
          <div className="mt-6">
            <TripPlanView plan={{
              ...tripPlanMutation.data.plan,
              destination,
              startDate,
              endDate
            }} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}