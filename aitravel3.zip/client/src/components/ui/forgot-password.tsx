import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeftIcon, 
  AtSign, 
  KeyIcon, 
  LockKeyhole, 
  Loader2, 
  Mail, 
  UserCircle,
  Copy as CopyIcon
} from "lucide-react";

// Step 1: Request password reset with username or email (preferred)
const requestResetSchema = z.object({
  identifier: z.string().min(1, "Username or email is required"),
});

// Step 2: Verify OTP
const verifyOTPSchema = z.object({
  otp: z.string().min(6, "Verification code must be at least 6 characters"),
});

// Step 3: Set new password
const newPasswordSchema = z.object({
  password: z
    .string()
    .min(6, "Password must be at least 6 characters")
    .max(100, "Password is too long"),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

interface ForgotPasswordProps {
  onCancel: () => void;
  onComplete: () => void;
}

export function ForgotPassword({ onCancel, onComplete }: ForgotPasswordProps) {
  const [step, setStep] = useState<'request' | 'verify' | 'reset'>('request');
  const [identifier, setIdentifier] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [testOtp, setTestOtp] = useState<string | null>(null);
  const [channel, setChannel] = useState<'email' | 'phone'>('email');
  const { toast } = useToast();

  // Step 1: Request password reset
  const requestForm = useForm<z.infer<typeof requestResetSchema>>({
    resolver: zodResolver(requestResetSchema),
    defaultValues: {
      identifier: "",
    },
  });

  // Step 2: Verify OTP
  const verifyForm = useForm<z.infer<typeof verifyOTPSchema>>({
    resolver: zodResolver(verifyOTPSchema),
    defaultValues: {
      otp: "",
    },
  });

  // Step 3: Set new password
  const resetForm = useForm<z.infer<typeof newPasswordSchema>>({
    resolver: zodResolver(newPasswordSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });

  // Mutation for requesting password reset
  const requestResetMutation = useMutation({
    mutationFn: async (data: { identifier: string }) => {
      const res = await apiRequest("POST", "/api/forgot-password", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to request password reset");
      }
      return res.json();
    },
    onSuccess: (data) => {
      // Determine which channel was used (email or phone)
      const verificationChannel = data.channel || (identifier.includes('@') ? 'email' : 'phone');
      setChannel(verificationChannel);
      
      // Check if we're in test mode and have a test OTP code
      if (data.isTestMode && data.testOtp) {
        setTestOtp(data.testOtp);
        toast({
          title: "Test Mode Active",
          description: `Test verification code: ${data.testOtp}`,
          duration: 10000, // Show for 10 seconds
        });
      } else {
        toast({
          title: "Verification Code Sent",
          description: `Please check your ${verificationChannel === 'email' ? 'email inbox' : 'phone'} for the verification code.`,
        });
        setTestOtp(null);
      }
      setStep("verify");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Send Request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation for verifying OTP
  const verifyOTPMutation = useMutation({
    mutationFn: async (data: { identifier: string; otp: string }) => {
      const res = await apiRequest("POST", "/api/verify-reset-token", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to verify code");
      }
      const result = await res.json();
      return result.token;
    },
    onSuccess: (token: string) => {
      toast({
        title: "Code Verified",
        description: "You can now reset your password.",
      });
      setResetToken(token);
      setStep("reset");
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation for resetting password
  const resetPasswordMutation = useMutation({
    mutationFn: async (data: { 
      identifier: string; 
      token: string; 
      password: string 
    }) => {
      const res = await apiRequest("POST", "/api/reset-password", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to reset password");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Password Reset",
        description: "Your password has been reset successfully.",
      });
      onComplete();
    },
    onError: (error: Error) => {
      toast({
        title: "Reset Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle request password reset form submission
  const handleRequestReset = (data: z.infer<typeof requestResetSchema>) => {
    setIdentifier(data.identifier);
    requestResetMutation.mutate({ identifier: data.identifier });
  };

  // Handle verify OTP form submission
  const handleVerifyOTP = (data: z.infer<typeof verifyOTPSchema>) => {
    verifyOTPMutation.mutate({
      identifier: identifier,
      otp: data.otp,
    });
  };

  // Handle reset password form submission
  const handleResetPassword = (data: z.infer<typeof newPasswordSchema>) => {
    resetPasswordMutation.mutate({
      identifier: identifier,
      token: resetToken,
      password: data.password,
    });
  };

  return (
    <div className="space-y-6">
      {/* Step 1: Request Password Reset */}
      {step === "request" && (
        <>
          <div className="space-y-2">
            <h2 className="text-xl font-semibold">Reset Your Password</h2>
            <p className="text-sm text-gray-500">
              Enter your email address or username to reset your password
            </p>
          </div>

          <Form {...requestForm}>
            <form onSubmit={requestForm.handleSubmit(handleRequestReset)} className="space-y-4">
              <FormField
                control={requestForm.control}
                name="identifier"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email or Username</FormLabel>
                    <FormControl>
                      <div className="relative">
                        {field.value && field.value.includes('@') ? (
                          <AtSign className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        ) : (
                          <UserCircle className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        )}
                        <Input 
                          {...field} 
                          className="pl-10 h-12" 
                          placeholder="Enter your email address or username"
                          disabled={requestResetMutation.isPending}
                          autoFocus
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-between space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  className="w-1/3"
                  disabled={requestResetMutation.isPending}
                >
                  <ArrowLeftIcon className="mr-2 h-4 w-4" />
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="bg-[#003580] hover:bg-[#002255] w-2/3"
                  disabled={requestResetMutation.isPending}
                >
                  {requestResetMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending Code...
                    </>
                  ) : (
                    <>
                      <Mail className="mr-2 h-4 w-4" />
                      Send Reset Code
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </>
      )}

      {/* Step 2: Verify OTP */}
      {step === "verify" && (
        <>
          <div className="space-y-2">
            <h2 className="text-xl font-semibold">Verify Code</h2>
            <p className="text-sm text-gray-500">
              Enter the verification code sent to your {channel === 'email' ? 'email address' : 'phone number'}
            </p>
            {testOtp && (
              <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded-md">
                <p className="text-sm font-medium text-blue-700 flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  Test Mode Active
                </p>
                <p className="text-sm mt-1">Your verification code is: <span className="font-bold text-blue-800">{testOtp}</span></p>
                <div className="mt-2 flex justify-between items-center">
                  <p className="text-xs text-gray-500">In production, this code would be sent via {channel === 'email' ? 'email' : 'SMS'}</p>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => {
                      verifyForm.setValue('otp', testOtp);
                    }}
                  >
                    <CopyIcon className="mr-1 h-3 w-3" />
                    Auto-fill
                  </Button>
                </div>
              </div>
            )}
          </div>

          <Form {...verifyForm}>
            <form onSubmit={verifyForm.handleSubmit(handleVerifyOTP)} className="space-y-4">
              <FormField
                control={verifyForm.control}
                name="otp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Code</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <KeyIcon className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <Input 
                          {...field} 
                          className="pl-10 h-12" 
                          placeholder="Enter verification code"
                          disabled={verifyOTPMutation.isPending}
                          value={field.value}
                          onChange={(e) => {
                            field.onChange(e);
                            // Auto fill if test OTP is available and input is empty
                            if (testOtp && e.target.value === '') {
                              setTimeout(() => field.onChange({ target: { value: testOtp } } as any), 100);
                            }
                          }}
                          autoFocus
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-between space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep("request")}
                  className="w-1/3"
                  disabled={verifyOTPMutation.isPending}
                >
                  <ArrowLeftIcon className="mr-2 h-4 w-4" />
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="bg-[#003580] hover:bg-[#002255] w-2/3"
                  disabled={verifyOTPMutation.isPending}
                >
                  {verifyOTPMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      <KeyIcon className="mr-2 h-4 w-4" />
                      Verify Code
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </>
      )}

      {/* Step 3: Reset Password */}
      {step === "reset" && (
        <>
          <div className="space-y-2">
            <h2 className="text-xl font-semibold">Set New Password</h2>
            <p className="text-sm text-gray-500">
              Enter and confirm your new password
            </p>
          </div>

          <Form {...resetForm}>
            <form onSubmit={resetForm.handleSubmit(handleResetPassword)} className="space-y-4">
              <FormField
                control={resetForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <Input 
                          type="password"
                          {...field} 
                          className="pl-10 h-12" 
                          placeholder="Enter new password"
                          disabled={resetPasswordMutation.isPending}
                          autoFocus
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={resetForm.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <Input 
                          type="password"
                          {...field} 
                          className="pl-10 h-12" 
                          placeholder="Confirm new password"
                          disabled={resetPasswordMutation.isPending}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-between space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep("verify")}
                  className="w-1/3"
                  disabled={resetPasswordMutation.isPending}
                >
                  <ArrowLeftIcon className="mr-2 h-4 w-4" />
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="bg-[#003580] hover:bg-[#002255] w-2/3"
                  disabled={resetPasswordMutation.isPending}
                >
                  {resetPasswordMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Resetting...
                    </>
                  ) : (
                    <>
                      <KeyIcon className="mr-2 h-4 w-4" />
                      Reset Password
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </>
      )}
    </div>
  );
}