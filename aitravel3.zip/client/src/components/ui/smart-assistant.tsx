import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Brain } from "lucide-react";
import { AIChat } from "./ai-chat";

interface SmartAssistantProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SmartAssistant({ open, onOpenChange }: SmartAssistantProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] h-[600px] flex flex-col p-0">
        <DialogHeader className="px-6 py-4 border-b">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            <DialogTitle>Travel Assistant</DialogTitle>
          </div>
        </DialogHeader>

        <div className="flex-1 relative">
          <AIChat />
        </div>
      </DialogContent>
    </Dialog>
  );
}