import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "./skeleton";
import { Button } from "./button";
import { Calendar, MapPin, Filter, Ticket, Trophy, BookOpen, Film } from "lucide-react";
import { Link } from "wouter";
import { EventCard, EventData } from "./event-card";

export function LocalEvents() {
  const [currentCity, setCurrentCity] = useState("New York");
  const [filter, setFilter] = useState<'all' | 'sport' | 'cultural' | 'entertainment'>('all');
  const cities = ["New York", "London", "Paris", "Tokyo", "Rome"];
  
  // Fetch events data for the selected city
  const { data, isLoading, error, refetch } = useQuery<EventData[]>({
    queryKey: ["/api/events", currentCity],
    retry: 2,
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  // Filter events by type if a filter is selected
  const events = data ? data.filter(event => 
    filter === 'all' || event.type === filter
  ) : [];

  // Get only upcoming events and sort by date
  const upcomingEvents = events
    .filter(event => new Date(event.date) > new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 4);

  const handleCityChange = (city: string) => {
    setCurrentCity(city);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl md:text-2xl font-bold">Local Events</h2>
          <div className="skeleton-loader"></div>
        </div>
        
        <div className="flex gap-2 overflow-auto pb-2 hide-scrollbar">
          {cities.map((city) => (
            <Button
              key={city}
              variant="outline"
              size="sm"
              className="flex-shrink-0"
              disabled
            >
              <Skeleton className="h-4 w-16" />
            </Button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-40 w-full rounded-lg" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Error state
  if (error || !data) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl md:text-2xl font-bold">Local Events</h2>
        <div className="p-6 text-center rounded-lg border border-dashed">
          <p className="text-gray-500 mb-4">Unable to load events at this time</p>
          <Button onClick={() => refetch()} variant="outline" size="sm">
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-bold">Local Events</h2>
        <Link href="/events">
          <Button variant="outline" size="sm">
            <Calendar className="w-4 h-4 mr-2" />
            View All
          </Button>
        </Link>
      </div>
      
      <div className="flex flex-wrap gap-2">
        <div className="flex gap-2 overflow-auto pb-2 hide-scrollbar mr-4">
          {cities.map((city) => (
            <Button
              key={city}
              variant={city === currentCity ? "default" : "outline"}
              size="sm"
              className="flex-shrink-0"
              onClick={() => handleCityChange(city)}
            >
              <MapPin className="w-3.5 h-3.5 mr-1.5" />
              {city}
            </Button>
          ))}
        </div>
        
        <div className="flex gap-2 ml-auto">
          {[
            { id: 'all', label: 'All', icon: Filter },
            { id: 'sport', label: 'Sports', icon: Trophy },
            { id: 'cultural', label: 'Cultural', icon: BookOpen },
            { id: 'entertainment', label: 'Entertainment', icon: Film },
          ].map((type) => (
            <Button
              key={type.id}
              variant={filter === type.id ? "default" : "outline"}
              size="sm"
              className="flex-shrink-0"
              onClick={() => setFilter(type.id as any)}
            >
              <type.icon className="w-3.5 h-3.5 mr-1.5" />
              {type.label}
            </Button>
          ))}
        </div>
      </div>
      
      {upcomingEvents.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {upcomingEvents.map((event, index) => (
            <EventCard key={event.id} event={event} index={index} compact />
          ))}
        </div>
      ) : (
        <div className="p-6 text-center rounded-lg border border-dashed">
          <p className="text-gray-500 mb-4">No upcoming events found for {currentCity}</p>
          <div className="flex gap-3 justify-center">
            <Button 
              onClick={() => setFilter('all')}
              variant="outline" 
              size="sm"
              className="gap-2"
            >
              <Filter className="w-4 h-4" />
              Show All Types
            </Button>
            
            <Button 
              onClick={() => setCurrentCity("New York")}
              variant="outline" 
              size="sm"
              className="gap-2"
            >
              <Ticket className="w-4 h-4" />
              Try Popular City
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}