import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sun, Cloud, CloudRain, CloudLightning, Heart, Smile, Frown, CloudFog } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

export interface EmotionalWeather {
  primary: {
    emotion: string;
    intensity: number; // 0-100
  };
  secondary?: {
    emotion: string;
    intensity: number; // 0-100
  };
  description: string;
}

interface EmotionalWeatherProps {
  data: EmotionalWeather;
  className?: string;
}

export function EmotionalWeatherView({ data, className = '' }: EmotionalWeatherProps) {
  const { primary, secondary, description } = data;

  // Get appropriate icon based on emotional state
  const getEmotionIcon = (emotion: string) => {
    const emotionLower = emotion.toLowerCase();
    
    if (emotionLower.includes('joy') || emotionLower.includes('happy') || emotionLower.includes('excitement')) {
      return <Sun className="h-6 w-6 text-amber-500" />;
    }
    if (emotionLower.includes('calm') || emotionLower.includes('peaceful') || emotionLower.includes('serene')) {
      return <Cloud className="h-6 w-6 text-sky-300" />;
    }
    if (emotionLower.includes('romance') || emotionLower.includes('love')) {
      return <Heart className="h-6 w-6 text-rose-500" />;
    }
    if (emotionLower.includes('melancholy') || emotionLower.includes('sadness') || emotionLower.includes('nostalgia')) {
      return <CloudRain className="h-6 w-6 text-blue-400" />;
    }
    if (emotionLower.includes('tense') || emotionLower.includes('stress') || emotionLower.includes('anxiety')) {
      return <CloudLightning className="h-6 w-6 text-purple-500" />;
    }
    if (emotionLower.includes('mysterious') || emotionLower.includes('wonder')) {
      return <CloudFog className="h-6 w-6 text-slate-400" />;
    }
    if (emotionLower.includes('delight') || emotionLower.includes('pleasant')) {
      return <Smile className="h-6 w-6 text-green-500" />;
    }
    if (emotionLower.includes('disappointment') || emotionLower.includes('frustration')) {
      return <Frown className="h-6 w-6 text-orange-500" />;
    }
    
    // Default
    return <Smile className="h-6 w-6 text-sky-500" />;
  };

  // Get appropriate color based on emotional state
  const getEmotionColor = (emotion: string) => {
    const emotionLower = emotion.toLowerCase();
    
    if (emotionLower.includes('joy') || emotionLower.includes('happy') || emotionLower.includes('excitement')) {
      return 'bg-amber-100 text-amber-800';
    }
    if (emotionLower.includes('calm') || emotionLower.includes('peaceful') || emotionLower.includes('serene')) {
      return 'bg-sky-100 text-sky-800';
    }
    if (emotionLower.includes('romance') || emotionLower.includes('love')) {
      return 'bg-rose-100 text-rose-800';
    }
    if (emotionLower.includes('melancholy') || emotionLower.includes('sadness') || emotionLower.includes('nostalgia')) {
      return 'bg-blue-100 text-blue-800';
    }
    if (emotionLower.includes('tense') || emotionLower.includes('stress') || emotionLower.includes('anxiety')) {
      return 'bg-purple-100 text-purple-800';
    }
    if (emotionLower.includes('mysterious') || emotionLower.includes('wonder')) {
      return 'bg-slate-100 text-slate-800';
    }
    if (emotionLower.includes('delight') || emotionLower.includes('pleasant')) {
      return 'bg-green-100 text-green-800';
    }
    if (emotionLower.includes('disappointment') || emotionLower.includes('frustration')) {
      return 'bg-orange-100 text-orange-800';
    }
    
    // Default
    return 'bg-sky-100 text-sky-800';
  };

  return (
    <Card className={`overflow-hidden ${className}`}>
      <CardHeader className="pb-2 bg-gradient-to-r from-primary/10 to-primary/5">
        <CardTitle className="text-lg flex items-center">
          <span className="mr-2">Emotional Weather</span>
          {getEmotionIcon(primary.emotion)}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Badge className={`${getEmotionColor(primary.emotion)}`}>
              {primary.emotion}
            </Badge>
            <div className="text-sm text-muted-foreground">
              {primary.intensity}% intensity
            </div>
          </div>
          
          <Progress value={primary.intensity} className="h-2" />
          
          {secondary && (
            <>
              <div className="flex items-center justify-between mt-4">
                <Badge className={`${getEmotionColor(secondary.emotion)}`}>
                  {secondary.emotion}
                </Badge>
                <div className="text-sm text-muted-foreground">
                  {secondary.intensity}% intensity
                </div>
              </div>
              
              <Progress value={secondary.intensity} className="h-2" />
            </>
          )}
          
          <p className="text-sm text-muted-foreground mt-3">
            {description}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}