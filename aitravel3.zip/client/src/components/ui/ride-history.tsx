import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { RideHistoryRecord } from "@shared/schema";

export function RideHistory() {
  const { toast } = useToast();
  const [selectedRide, setSelectedRide] = useState<string | null>(null);

  const { data: rides, isLoading, error } = useQuery<RideHistoryRecord[]>({
    queryKey: ['/api/rides/history'],
    retry: 1
  });

  const { data: tracking } = useQuery({
    queryKey: ['/api/rides', selectedRide, 'tracking'],
    enabled: !!selectedRide,
    refetchInterval: selectedRide ? 10000 : false // Refresh every 10 seconds for active ride
  });

  if (isLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-3">
              <div className="h-20 bg-gray-200 rounded"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-6">
          <div className="text-center text-red-500">
            Failed to load ride history
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500',
      accepted: 'bg-blue-500',
      arriving: 'bg-purple-500',
      in_progress: 'bg-green-500',
      completed: 'bg-gray-500',
      cancelled: 'bg-red-500'
    };
    return colors[status] || 'bg-gray-500';
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Ride History</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {rides?.map((ride) => (
          <Card 
            key={ride.id} 
            className={`p-4 cursor-pointer transition-shadow hover:shadow-md ${
              selectedRide === ride.rideId ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => setSelectedRide(ride.rideId)}
          >
            <div className="flex justify-between items-start">
              <div className="space-y-2">
                <div className="font-medium">
                  {ride.fromLocation} → {ride.toLocation}
                </div>
                <div className="text-sm text-muted-foreground">
                  {new Date(ride.pickupTime).toLocaleString()}
                </div>
                <div className="text-sm">
                  Driver: {ride.driverName || 'Not assigned'}
                </div>
              </div>
              <div className="text-right">
                <Badge className={getStatusColor(ride.status)}>
                  {ride.status.replace('_', ' ').toUpperCase()}
                </Badge>
                <div className="mt-2 font-medium">
                  ${(ride.price / 100).toFixed(2)}
                </div>
              </div>
            </div>

            {selectedRide === ride.rideId && tracking && (
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <div className="text-sm font-medium">Live Tracking</div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <div>Current Location:</div>
                  <div>{tracking.currentLat}, {tracking.currentLng}</div>
                  <div>Estimated Arrival:</div>
                  <div>
                    {tracking.estimatedArrival 
                      ? new Date(tracking.estimatedArrival).toLocaleTimeString()
                      : 'Calculating...'}
                  </div>
                  <div>Last Updated:</div>
                  <div>
                    {new Date(tracking.lastUpdated).toLocaleTimeString()}
                  </div>
                </div>
              </div>
            )}
          </Card>
        ))}

        {rides?.length === 0 && (
          <div className="text-center text-muted-foreground py-8">
            No ride history available
          </div>
        )}
      </CardContent>
    </Card>
  );
}
