import { useState, useRef, useEffect } from "react";
import { useAuth } from '@/hooks/use-auth';
import { useMutation } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  SendHorizonal, 
  Loader2, 
  Bot, 
  User, 
  MapPin, 
  Calendar, 
  Activity, 
  Info, 
  Mic, 
  MicOff, 
  Globe, 
  Clock, 
  DollarSign, 
  Plane 
} from 'lucide-react';
import { Input } from './input';
import { Button } from './button';
import { ScrollArea } from './scroll-area';
import { apiRequest } from '@/lib/api';

interface ChatMessage {
  role: 'assistant' | 'user';
  content: string;
  timestamp: Date;
  suggestions?: string[];
  entities?: {
    locations?: string[];
    dates?: string[];
    activities?: string[];
    preferences?: string[];
  };
  recommendations?: {
    destination: string;
    reason: string;
    bestTimeToVisit: string;
    estimatedBudget: number;
    activities: string[];
    localInsights?: {
      culturalNotes: string[];
      bestTimeToVisit: string;
      localCustoms: string[];
      weatherTips: string[];
    };
    practicalInfo?: {
      visaRequirements: string;
      transportationOptions: string[];
      safetyTips: string[];
      recommendedAreas: string[];
    };
  }[];
  context?: {
    previousQuery?: string;
    relatedTopics?: string[];
    followUpQuestions?: string[];
  };
}

export function TravelChatbot() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: "👋 Hello! I'm your AI travel companion. I specialize in:\n\n" +
        "🌍 Creating personalized travel plans\n" +
        "🏨 Finding perfect accommodations\n" +
        "🍴 Recommending local cuisine\n" +
        "🎭 Sharing cultural insights\n" +
        "💰 Managing travel budgets\n" +
        "✈️ Booking transportation\n\n" +
        "You can either type or use voice commands. How may I assist with your travel plans today?",
      timestamp: new Date(),
      suggestions: [
        "✈️ Plan a trip",
        "🌟 Best destinations",
        "🎭 Local experiences",
        "💰 Budget advice"
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognition = useRef<any>(null);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.webkitSpeechRecognition;
      recognition.current = new SpeechRecognition();
      recognition.current.continuous = false;
      recognition.current.interimResults = false;
      recognition.current.lang = 'en-US';

      recognition.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        handleSend(transcript);
      };

      recognition.current.onend = () => {
        setIsListening(false);
      };

      recognition.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
    }
  }, []);

  const toggleVoiceInput = () => {
    if (!recognition.current) {
      console.warn('Speech recognition not supported');
      return;
    }

    if (isListening) {
      recognition.current.stop();
    } else {
      recognition.current.start();
      setIsListening(true);
    }
  };

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const chatHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      const response = await apiRequest('POST', '/api/chatbot', {
        message,
        chatHistory,
        preferences: user?.preferences
      });
      return response.json();
    },
    onSuccess: (data) => {
      const newMessage: ChatMessage = {
        role: 'assistant',
        content: data.response.message,
        timestamp: new Date(),
        suggestions: data.response.suggestions,
        entities: data.response.entities,
        recommendations: data.response.recommendations,
        context: data.response.context
      };
      setMessages(prev => [...prev, newMessage]);

      if (data.response.context?.followUpQuestions?.length > 0) {
        speakResponse(data.response.message);
      }
    }
  });

  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 1;
      utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleSend = async (text?: string) => {
    const messageToSend = text || inputValue;
    if (!messageToSend.trim()) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: messageToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    await chatMutation.mutate(messageToSend);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
    inputRef.current?.focus();
  };

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="absolute inset-0 flex flex-col">
      <ScrollArea ref={scrollAreaRef} className="flex-1 px-8 py-6">
        <AnimatePresence initial={false}>
          {messages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`flex gap-4 mb-8 ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`flex gap-4 max-w-[85%] ${
                  message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    message.role === 'user' ? 'bg-primary' : 'bg-primary/10'
                  }`}
                >
                  {message.role === 'user' ? (
                    <User className="w-6 h-6 text-primary-foreground" />
                  ) : (
                    <Bot className="w-6 h-6 text-primary" />
                  )}
                </div>
                <div
                  className={`rounded-lg p-6 ${
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted/50'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>

                  {message.entities && (
                    <div className="mt-4 space-y-2 text-sm opacity-90">
                      {message.entities.locations && message.entities.locations.length > 0 && (
                        <div className="flex items-center gap-2">
                          <Globe className="w-4 h-4" />
                          <span>{message.entities.locations.join(', ')}</span>
                        </div>
                      )}
                      {message.entities.dates && message.entities.dates.length > 0 && (
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>{message.entities.dates.join(', ')}</span>
                        </div>
                      )}
                      {message.entities.activities && message.entities.activities.length > 0 && (
                        <div className="flex items-center gap-2">
                          <Activity className="w-4 h-4" />
                          <span>{message.entities.activities.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {message.recommendations && message.recommendations.length > 0 && (
                    <div className="mt-6 space-y-4">
                      {message.recommendations.map((rec, idx) => (
                        <div key={idx} className="bg-background/5 rounded-lg p-4">
                          <div className="flex items-center gap-2 text-base font-medium">
                            <Globe className="w-5 h-5" />
                            {rec.destination}
                          </div>
                          <p className="mt-2 text-sm opacity-90">{rec.reason}</p>
                          <div className="mt-3 flex items-center gap-6 text-sm">
                            <span className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              {rec.bestTimeToVisit}
                            </span>
                            <span className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4" />
                              {rec.estimatedBudget}
                            </span>
                          </div>
                          {rec.localInsights && (
                            <div className="mt-4 text-sm">
                              <div className="flex items-center gap-2 mb-2">
                                <Info className="w-4 h-4" />
                                <span className="font-medium">Local Insights</span>
                              </div>
                              <ul className="list-disc list-inside space-y-1 opacity-90">
                                {rec.localInsights.culturalNotes.slice(0, 2).map((note, i) => (
                                  <li key={i}>{note}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {message.suggestions && (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {message.suggestions.map((suggestion, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="text-sm px-4 py-2 rounded-full bg-background/10 hover:bg-background/20 transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}

                  {message.context?.followUpQuestions && (
                    <div className="mt-4 text-sm">
                      <p className="font-medium opacity-75">Related questions:</p>
                      <ul className="mt-2 space-y-2">
                        {message.context.followUpQuestions.map((q, i) => (
                          <li
                            key={i}
                            className="cursor-pointer hover:underline opacity-90 flex items-center gap-2"
                            onClick={() => handleSuggestionClick(q)}
                          >
                            <Plane className="w-3 h-3" />
                            {q}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
          {chatMutation.isPending && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-4 mb-4"
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Loader2 className="w-6 h-6 text-primary animate-spin" />
              </div>
              <div className="rounded-lg p-6 bg-muted/50">
                <div className="flex gap-2">
                  <span className="animate-bounce">•</span>
                  <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>•</span>
                  <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>•</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </ScrollArea>

      <div className="p-6 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex gap-2">
          <Input
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask me anything about your travel plans..."
            className="flex-1"
          />
          <Button
            variant="outline"
            size="icon"
            className={`transition-colors ${isListening ? 'bg-red-100 hover:bg-red-200' : ''}`}
            onClick={toggleVoiceInput}
          >
            {isListening ? (
              <MicOff className="w-4 h-4" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </Button>
          <Button
            onClick={() => handleSend()}
            disabled={chatMutation.isPending || !inputValue.trim()}
            size="icon"
          >
            {chatMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <SendHorizonal className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}