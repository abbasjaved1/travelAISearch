import React from 'react';
import { Card, CardContent, CardFooter } from './card';
import { Skeleton } from './skeleton';

export const DestinationSkeleton = () => {
  return (
    <Card className="overflow-hidden">
      <div className="h-48 bg-gray-200 animate-pulse" />
      <CardContent className="p-4">
        <Skeleton className="h-6 w-2/3 mb-2" />
        <Skeleton className="h-4 w-full mb-1" />
        <Skeleton className="h-4 w-4/5" />
      </CardContent>
      <CardFooter className="flex justify-between p-4 pt-0">
        <Skeleton className="h-8 w-20 rounded-md" />
        <Skeleton className="h-8 w-8 rounded-full" />
      </CardFooter>
    </Card>
  );
};

export const DestinationSkeletonGrid = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {Array(6).fill(0).map((_, i) => (
        <DestinationSkeleton key={i} />
      ))}
    </div>
  );
};