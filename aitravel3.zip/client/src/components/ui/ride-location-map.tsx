import { useState } from 'react';
import { Card } from "./card";
import { MapPin, Car, ArrowRight } from 'lucide-react';
import type { RideBooking } from '@shared/schema';

interface RideLocationMapProps {
  ride: RideBooking;
}

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return Math.round(R * c);
};

const mockLocations = {
  'San Francisco Airport': { lat: 37.6213, lng: -122.3790 },
  'Downtown SF': { lat: 37.7749, lng: -122.4194 },
  'Golden Gate Bridge': { lat: 37.8199, lng: -122.4783 },
  'Silicon Valley': { lat: 37.3875, lng: -122.0575 },
  'Berkeley': { lat: 37.8715, lng: -122.2730 },
  'Oakland': { lat: 37.8044, lng: -122.2711 }
};

export function RideLocationMap({ ride }: RideLocationMapProps) {
  const [expanded, setExpanded] = useState(false);

  // Mock pickup and dropoff locations
  const pickupLocation = mockLocations[ride.pickupLocation as keyof typeof mockLocations] || mockLocations['San Francisco Airport'];
  const dropoffLocation = mockLocations[ride.dropoffLocation as keyof typeof mockLocations] || mockLocations['Downtown SF'];

  const distance = calculateDistance(
    pickupLocation.lat,
    pickupLocation.lng,
    dropoffLocation.lat,
    dropoffLocation.lng
  );

  const estimatedTime = Math.round((distance / 40) * 60); // Assuming average speed of 40 km/h

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Car className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Ride Details (Mock Map)</h3>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-green-500" />
              <div>
                <p className="font-medium">{ride.pickupLocation}</p>
                <p className="text-sm text-muted-foreground">
                  Lat: {pickupLocation.lat.toFixed(4)}, Lng: {pickupLocation.lng.toFixed(4)}
                </p>
              </div>
            </div>
          </div>

          <ArrowRight className="w-4 h-4 text-muted-foreground" />

          <div className="flex-1">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-red-500" />
              <div>
                <p className="font-medium">{ride.dropoffLocation}</p>
                <p className="text-sm text-muted-foreground">
                  Lat: {dropoffLocation.lat.toFixed(4)}, Lng: {dropoffLocation.lng.toFixed(4)}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2 border-t">
          <div>
            <p className="text-sm text-muted-foreground">Distance</p>
            <p className="font-medium">{distance} km</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Estimated Time</p>
            <p className="font-medium">{estimatedTime} minutes</p>
          </div>
        </div>

        <div className="text-xs text-muted-foreground text-center pt-2 border-t">
          Note: This is a mock implementation using predefined Bay Area locations.
          <br />
          Real implementation will use Google Maps API when available.
        </div>
      </div>
    </Card>
  );
}
