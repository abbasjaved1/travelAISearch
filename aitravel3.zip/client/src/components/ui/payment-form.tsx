import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CreditCard,
  CheckCircle,
  XCircle,
  Loader2,
  Plane,
  Lock,
  Wallet,
  Building,
  RefreshCcw,
  Receipt,
  ShieldCheck,
  Fingerprint,
  LandmarkIcon,
  CreditCard as CreditCardIcon,
  LandmarkIcon as Bank
} from 'lucide-react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from './card';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './tabs';
import { apiRequest } from '@/lib/api';
import { useAuth } from '@/hooks/use-auth';
import { Input } from './input';
import { Label } from './label';
import { Separator } from './separator';
import { RadioGroup, RadioGroupItem } from './radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select';
import { BookingType } from '@shared/schema';

interface PaymentMethod {
  id: string;
  type: string;
  card?: {
    brand: string;
    last4: string;
    expMonth: number;
    expYear: number;
  }
}

interface PaymentFormProps {
  amount: number;
  onSuccess: () => void;
  onError?: (message: string) => void;
  bookingType: BookingType;
  metadata?: Record<string, any>;
  bookingDetails?: {
    type: string;
    description: string;
    image?: string;
    title?: string;
    subtitle?: string;
  };
}

export function PaymentForm({ 
  amount, 
  onSuccess, 
  onError, 
  metadata, 
  bookingDetails,
  bookingType 
}: PaymentFormProps) {
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'card' | 'bank' | 'savedCard'>('card');
  const [savedPaymentMethods, setSavedPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedSavedMethod, setSelectedSavedMethod] = useState<string>('');
  const [saveCard, setSaveCard] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expMonth: '',
    expYear: '',
    cvc: '',
    name: '',
  });

  const { toast } = useToast();
  const { user } = useAuth();

  // Get any saved payment methods if user is logged in
  useEffect(() => {
    if (user) {
      fetchSavedPaymentMethods();
    }
  }, [user]);

  // Initialize payment intent
  useEffect(() => {
    if (status === 'idle' && amount > 0) {
      createPaymentIntent();
    }
  }, [amount, bookingType]);

  // Handle status changes
  useEffect(() => {
    if (status === 'error' && onError) {
      onError(errorMessage);
    } else if (status === 'success') {
      onSuccess();
    }
  }, [status, errorMessage, onError, onSuccess]);

  const fetchSavedPaymentMethods = async () => {
    try {
      setIsLoading(true);
      const response = await apiRequest('GET', '/api/payment/methods');
      const data = await response.json();
      
      if (data.paymentMethods && data.paymentMethods.length > 0) {
        setSavedPaymentMethods(data.paymentMethods);
        // Auto-select the first saved method
        setSelectedSavedMethod(data.paymentMethods[0].id);
      }
    } catch (error) {
      console.error('Failed to fetch saved payment methods:', error);
      toast({
        title: "Couldn't load saved payment methods",
        description: "We'll use a new payment method instead",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createPaymentIntent = async () => {
    try {
      setIsLoading(true);
      const response = await apiRequest('POST', '/api/payment/create-intent', {
        amount,
        bookingType,
        metadata: {
          ...metadata,
          bookingDetails: bookingDetails ? JSON.stringify(bookingDetails) : undefined
        }
      });

      if (!response.ok) {
        throw new Error('Failed to initialize payment');
      }

      const data = await response.json();
      setClientSecret(data.clientSecret);
    } catch (error) {
      console.error('Payment initialization error:', error);
      toast({
        title: "Payment Initialization Failed",
        description: "There was a problem setting up your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const processRealPayment = async () => {
    try {
      // This would normally integrate with Stripe Elements or another payment processor
      // For now, we'll simulate a server call to our payment API
      setStatus('processing');
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // For demo purposes, simulate success
      const response = {
        ok: true,
        json: async () => ({ status: 'succeeded' })
      };

      // If we were using a real payment processor like Stripe, we'd do something like:
      // const { paymentMethod } = await stripe.createPaymentMethod({
      //   type: 'card',
      //   card: cardElement,
      // });
      // 
      // const confirmResponse = await apiRequest('POST', '/api/payment/confirm', {
      //   paymentIntentId: clientSecret.split('_secret')[0],
      //   paymentMethodId: paymentMethod.id
      // });

      if (!response.ok) {
        throw new Error('Payment processing failed');
      }

      const result = await response.json();
      
      if (result.status === 'succeeded') {
        setStatus('success');
        toast({
          title: "Payment Successful",
          description: "Your payment has been processed successfully!",
        });
      } else {
        throw new Error('Payment not completed');
      }
    } catch (error: any) {
      console.error('Payment processing error:', error);
      setStatus('error');
      setErrorMessage(error.message || 'Payment failed');
      toast({
        title: "Payment Failed",
        description: error.message || "There was a problem processing your payment",
        variant: "destructive",
      });
    }
  };

  const handlePayment = async () => {
    // Validate form based on selected payment method
    if (selectedPaymentMethod === 'card') {
      if (!validateCardDetails()) {
        return;
      }
    } else if (selectedPaymentMethod === 'savedCard' && !selectedSavedMethod) {
      toast({
        title: "Select a Card",
        description: "Please select a saved payment method",
        variant: "destructive",
      });
      return;
    }

    await processRealPayment();
  };

  const validateCardDetails = () => {
    // Basic validation - would be more comprehensive in a real app
    if (!cardDetails.number || cardDetails.number.length < 16) {
      toast({
        title: "Invalid Card Number",
        description: "Please enter a valid card number",
        variant: "destructive",
      });
      return false;
    }
    
    if (!cardDetails.expMonth || !cardDetails.expYear) {
      toast({
        title: "Invalid Expiration Date",
        description: "Please enter a valid expiration date",
        variant: "destructive",
      });
      return false;
    }
    
    if (!cardDetails.cvc || cardDetails.cvc.length < 3) {
      toast({
        title: "Invalid CVC",
        description: "Please enter a valid security code",
        variant: "destructive",
      });
      return false;
    }
    
    return true;
  };

  const handleCardChange = (field: keyof typeof cardDetails) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setCardDetails({
      ...cardDetails,
      [field]: e.target.value
    });
  };

  const renderPaymentMethodIcon = (method: PaymentMethod) => {
    if (method.card) {
      switch (method.card.brand.toLowerCase()) {
        case 'visa':
          return <CreditCardIcon className="text-blue-600" />;
        case 'mastercard':
          return <CreditCardIcon className="text-red-600" />;
        case 'amex':
          return <CreditCardIcon className="text-purple-600" />;
        default:
          return <CreditCardIcon />;
      }
    }
    return <CreditCardIcon />;
  };

  return (
    <Card className="w-full bg-card/95 backdrop-blur-sm border-2 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Secure Checkout
          </span>
          <Lock className="w-6 h-6 text-primary" />
        </CardTitle>
        <CardDescription>
          Complete your {bookingDetails?.type || 'booking'} securely
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Booking Summary with animations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 p-4 bg-primary/5 rounded-lg border border-primary/10"
        >
          <div className="flex items-start gap-4">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-16 h-16 rounded-md bg-primary/10 flex items-center justify-center"
            >
              {bookingType === 'flight' ? (
                <Plane className="w-8 h-8 text-primary" />
              ) : bookingType === 'hotel' ? (
                <Building className="w-8 h-8 text-primary" />
              ) : bookingType === 'ride' ? (
                <Wallet className="w-8 h-8 text-primary" />
              ) : (
                <Receipt className="w-8 h-8 text-primary" />
              )}
            </motion.div>
            <div className="flex-1">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-sm text-foreground"
              >
                <div className="font-semibold text-base">{bookingDetails?.title || `${bookingType.charAt(0).toUpperCase() + bookingType.slice(1)} Booking`}</div>
                <div className="text-muted-foreground">{bookingDetails?.subtitle || bookingDetails?.description || 'Complete your reservation'}</div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-2 text-2xl font-bold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent"
              >
                ${amount.toFixed(2)}
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* Payment Status */}
        <AnimatePresence mode="wait">
          {status === 'processing' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex flex-col items-center justify-center py-8"
            >
              <Loader2 className="w-12 h-12 animate-spin text-primary" />
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-lg font-medium text-primary"
              >
                Processing your payment...
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-sm text-muted-foreground text-center mt-2 max-w-xs"
              >
                Please don't close or refresh this page while we confirm your payment.
              </motion.p>
            </motion.div>
          )}

          {status === 'success' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-8"
            >
              <div className="relative">
                <CheckCircle className="w-16 h-16 text-green-500" />
                <motion.div
                  initial={{ scale: 1.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 0.2 }}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0 rounded-full bg-green-500"
                />
              </div>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-4 text-xl font-semibold text-green-500"
              >
                Payment successful!
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-sm text-muted-foreground text-center mt-2 max-w-xs"
              >
                Your {bookingType} is confirmed. A receipt has been sent to your email address. Thank you for your business!
              </motion.p>
            </motion.div>
          )}

          {status === 'error' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-8"
            >
              <div className="relative">
                <XCircle className="w-16 h-16 text-destructive" />
                <motion.div
                  initial={{ scale: 1.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 0.2 }}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0 rounded-full bg-destructive"
                />
              </div>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-xl font-semibold text-destructive"
              >
                Payment failed
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-sm text-muted-foreground text-center mt-2 max-w-xs"
              >
                {errorMessage}
              </motion.p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setStatus('idle')}
              >
                <RefreshCcw className="w-4 h-4 mr-2" />
                Try again
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Payment Form */}
        {status === 'idle' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-2"
          >
            <Tabs defaultValue={savedPaymentMethods.length > 0 ? "savedCard" : "card"} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                {savedPaymentMethods.length > 0 && (
                  <TabsTrigger 
                    value="savedCard" 
                    onClick={() => setSelectedPaymentMethod('savedCard')}
                    className="flex items-center gap-2"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Saved Cards</span>
                  </TabsTrigger>
                )}
                <TabsTrigger 
                  value="card" 
                  onClick={() => setSelectedPaymentMethod('card')}
                  className="flex items-center gap-2"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Credit Card</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="bank" 
                  onClick={() => setSelectedPaymentMethod('bank')}
                  className="flex items-center gap-2"
                >
                  <Bank className="w-4 h-4" />
                  <span>Bank Transfer</span>
                </TabsTrigger>
              </TabsList>
              
              {savedPaymentMethods.length > 0 && (
                <TabsContent value="savedCard" className="space-y-4">
                  <div className="space-y-4">
                    <Label>Select a saved payment method</Label>
                    <RadioGroup 
                      value={selectedSavedMethod}
                      onValueChange={setSelectedSavedMethod}
                      className="flex flex-col space-y-3"
                    >
                      {savedPaymentMethods.map(method => (
                        <div key={method.id} className="flex items-center space-x-2 border p-3 rounded-md">
                          <RadioGroupItem value={method.id} id={method.id} />
                          <Label htmlFor={method.id} className="flex items-center gap-2 cursor-pointer">
                            {renderPaymentMethodIcon(method)}
                            <span className="font-medium">
                              {method.card?.brand} •••• {method.card?.last4}
                            </span>
                            <span className="text-muted-foreground text-sm">
                              Exp. {method.card?.expMonth}/{method.card?.expYear}
                            </span>
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </TabsContent>
              )}
              
              <TabsContent value="card" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input 
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={cardDetails.number}
                      onChange={handleCardChange('number')}
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="cardName">Cardholder Name</Label>
                    <Input 
                      id="cardName"
                      placeholder="John Smith"
                      value={cardDetails.name}
                      onChange={handleCardChange('name')}
                      className="mt-1"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="expiration">Expiration</Label>
                      <div className="flex gap-2 mt-1">
                        <Input 
                          id="expMonth"
                          placeholder="MM"
                          value={cardDetails.expMonth}
                          onChange={handleCardChange('expMonth')}
                          maxLength={2}
                        />
                        <span className="flex items-center text-muted-foreground">/</span>
                        <Input 
                          id="expYear"
                          placeholder="YY"
                          value={cardDetails.expYear}
                          onChange={handleCardChange('expYear')}
                          maxLength={2}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="cvc">CVC</Label>
                      <Input 
                        id="cvc"
                        placeholder="123"
                        value={cardDetails.cvc}
                        onChange={handleCardChange('cvc')}
                        className="mt-1"
                        maxLength={4}
                      />
                    </div>
                  </div>
                  
                  <div className="col-span-2 flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="saveCard"
                      checked={saveCard}
                      onChange={(e) => setSaveCard(e.target.checked)}
                      className="rounded border-gray-300"
                    />
                    <Label htmlFor="saveCard" className="text-sm text-muted-foreground cursor-pointer">
                      Save this card for future payments
                    </Label>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="bank" className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="bankCountry">Country</Label>
                    <Select defaultValue="us">
                      <SelectTrigger id="bankCountry" className="mt-1">
                        <SelectValue placeholder="Select Country" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us">United States</SelectItem>
                        <SelectItem value="ca">Canada</SelectItem>
                        <SelectItem value="uk">United Kingdom</SelectItem>
                        <SelectItem value="au">Australia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="accountName">Account Holder Name</Label>
                    <Input id="accountName" placeholder="John Smith" className="mt-1" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="routingNumber">Routing Number</Label>
                      <Input id="routingNumber" placeholder="123456789" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="accountNumber">Account Number</Label>
                      <Input id="accountNumber" placeholder="1234567890" className="mt-1" />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="accountType">Account Type</Label>
                    <Select defaultValue="checking">
                      <SelectTrigger id="accountType" className="mt-1">
                        <SelectValue placeholder="Select Account Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="checking">Checking</SelectItem>
                        <SelectItem value="savings">Savings</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <Separator className="my-6" />
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>${(amount * 0.9).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Taxes & Fees</span>
                <span>${(amount * 0.1).toFixed(2)}</span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>${amount.toFixed(2)}</span>
              </div>
            </div>
            
            <Button
              className="w-full py-6 text-lg relative overflow-hidden group mt-6"
              onClick={handlePayment}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5 mr-2" />
                  Pay ${amount.toFixed(2)}
                </>
              )}
            </Button>
          </motion.div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col items-center text-center px-6 pt-0 pb-4">
        <div className="flex items-center justify-center gap-2 mt-4">
          <Lock className="w-4 h-4 text-muted-foreground" />
          <ShieldCheck className="w-4 h-4 text-muted-foreground" />
          <Fingerprint className="w-4 h-4 text-muted-foreground" />
        </div>
        <div className="text-xs text-muted-foreground mt-2">
          Your payment information is encrypted and secure.
          <br />We use industry-standard security measures to protect your data.
        </div>
      </CardFooter>
    </Card>
  );
}