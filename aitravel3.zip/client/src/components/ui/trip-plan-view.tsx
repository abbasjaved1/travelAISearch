import React from 'react';
import { TripPlan, DayPlan, Activity, EmotionalWeather } from '@/shared/schema';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MapPin, Calendar, Clock, Sun, Cloud, CloudRain, CloudLightning, Banknote, Info } from 'lucide-react';
import { formatCurrency } from "@/lib/utils";
import { EmotionalWeatherView } from '@/components/ui/emotional-weather';

interface TripPlanViewProps {
  plan: TripPlan;
  onBookActivity?: (activity: Activity) => void;
  onExportPlan?: () => void;
}

export function TripPlanView({ plan, onBookActivity, onExportPlan }: TripPlanViewProps) {
  const { destination, startDate, endDate, days, totalEstimatedCost, notes, currencyCode } = plan;
  
  // Format dates for display
  const formattedStartDate = new Date(startDate).toLocaleDateString('en-US', { 
    weekday: 'short', 
    month: 'short', 
    day: 'numeric' 
  });
  
  const formattedEndDate = new Date(endDate).toLocaleDateString('en-US', { 
    weekday: 'short', 
    month: 'short', 
    day: 'numeric' 
  });

  // Helper to get appropriate weather icon
  const getWeatherIcon = (condition: string) => {
    const conditionLower = condition.toLowerCase();
    if (conditionLower.includes('sunny') || conditionLower.includes('clear')) return <Sun className="h-5 w-5 text-amber-500" />;
    if (conditionLower.includes('cloud')) return <Cloud className="h-5 w-5 text-slate-400" />;
    if (conditionLower.includes('rain')) return <CloudRain className="h-5 w-5 text-blue-400" />;
    if (conditionLower.includes('storm')) return <CloudLightning className="h-5 w-5 text-purple-500" />;
    return <Sun className="h-5 w-5 text-amber-500" />;
  };

  // Helper to get background class based on time of day
  const getTimeBasedClass = (startTime: string) => {
    const hour = parseInt(startTime.split(':')[0]);
    if (startTime.includes('PM') && hour >= 6) return 'bg-sky-950/10';
    if (startTime.includes('AM') && hour < 12) return 'bg-amber-50/20';
    return 'bg-blue-50/10';
  };

  // Helper to format time ranges
  const formatTimeRange = (startTime: string, endTime: string) => {
    return `${startTime} – ${endTime}`;
  };
  
  // Function to share trip plan on WhatsApp
  const shareOnWhatsApp = (destination: string, startDate: string, endDate: string) => {
    const text = `Check out my trip plan to ${destination} from ${startDate} to ${endDate}! I created it with AI Trip Planner.`;
    const encodedText = encodeURIComponent(text);
    const whatsappUrl = `https://wa.me/?text=${encodedText}`;
    window.open(whatsappUrl, '_blank');
  };

  // Helper to get activity type badge styling
  const getActivityTypeStyle = (type: string) => {
    const typeLower = type.toLowerCase();
    if (typeLower.includes('food')) return 'bg-orange-100 text-orange-800';
    if (typeLower.includes('attraction')) return 'bg-purple-100 text-purple-800';
    if (typeLower.includes('tour')) return 'bg-blue-100 text-blue-800';
    if (typeLower.includes('relax')) return 'bg-green-100 text-green-800';
    if (typeLower.includes('outdoor')) return 'bg-emerald-100 text-emerald-800';
    if (typeLower.includes('transport')) return 'bg-gray-100 text-gray-800';
    return 'bg-sky-100 text-sky-800';
  };

  return (
    <Card className="w-full overflow-hidden border-t-4 border-t-primary">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-2xl font-bold">Trip to {destination}</CardTitle>
            <CardDescription className="flex items-center mt-1">
              <Calendar className="h-4 w-4 mr-1" /> 
              {formattedStartDate} to {formattedEndDate} ({days?.length || 0} days)
            </CardDescription>
          </div>
          {totalEstimatedCost && (
            <div className="flex items-center text-muted-foreground">
              <Banknote className="h-4 w-4 mr-1" /> 
              <span>Estimated: {formatCurrency(totalEstimatedCost, currencyCode || 'USD')}</span>
            </div>
          )}
        </div>
      </CardHeader>

      <Separator />

      <ScrollArea className="h-[500px]">
        <CardContent className="pt-4">
          {days?.map((day: DayPlan, dayIndex: number) => (
            <div key={day.date} className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold text-lg">
                  Day {dayIndex + 1} · {new Date(day.date).toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </h3>
                
                {day.weatherForecast && (
                  <div className="flex items-center gap-1 text-sm">
                    {getWeatherIcon(day.weatherForecast.condition)}
                    <span className="font-medium">{day.weatherForecast.temperature}°</span>
                    {day.weatherForecast.chanceOfRain > 0 && (
                      <span className="text-blue-500 text-xs">({day.weatherForecast.chanceOfRain}% rain)</span>
                    )}
                  </div>
                )}
              </div>
              
              {day.emotionalWeather && (
                <div className="mb-4">
                  <EmotionalWeatherView data={day.emotionalWeather} className="mb-3" />
                </div>
              )}
              
              <div className="space-y-3">
                {day.activities.map((activity: Activity) => (
                  <Card key={activity.id} className={`border-l-4 border-l-primary/60 ${getTimeBasedClass(activity.startTime)}`}>
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-base">{activity.title}</h4>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <Clock className="h-3.5 w-3.5 mr-1" />
                            <span className="mr-3">{formatTimeRange(activity.startTime, activity.endTime)}</span>
                            <MapPin className="h-3.5 w-3.5 mr-1" />
                            <span>{activity.location}</span>
                          </div>
                        </div>
                        <Badge className={`${getActivityTypeStyle(activity.type)}`}>
                          {activity.type}
                        </Badge>
                      </div>
                      
                      {activity.description && (
                        <p className="text-sm mt-2">{activity.description}</p>
                      )}
                      
                      <div className="flex justify-between items-center mt-3">
                        {activity.cost !== undefined && (
                          <div className="text-sm text-muted-foreground">
                            <Banknote className="h-3.5 w-3.5 inline mr-1" />
                            {typeof activity.cost === 'number' ? 
                              formatCurrency(activity.cost, currencyCode || 'USD') : 
                              activity.cost
                            }
                          </div>
                        )}
                        
                        {onBookActivity && (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => onBookActivity(activity)}
                            className="text-xs h-8"
                          >
                            Book Now
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
          
          {notes && notes.length > 0 && (
            <div className="mt-6 mb-4">
              <h3 className="font-semibold text-lg mb-2 flex items-center">
                <Info className="h-4 w-4 mr-2" /> Trip Notes
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground list-disc pl-5">
                {notes.map((note: string, index: number) => (
                  <li key={index}>{note}</li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </ScrollArea>
      
      {onExportPlan && (
        <CardFooter className="bg-muted/20 pt-2">
          <div className="flex gap-2 w-full">
            <Button 
              onClick={onExportPlan} 
              variant="outline" 
              className="flex-1"
            >
              Export Itinerary
            </Button>
            <Button 
              onClick={() => shareOnWhatsApp(destination, formattedStartDate, formattedEndDate)}
              variant="outline"
              className="flex items-center justify-center bg-green-500 hover:bg-green-600 text-white border-none"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 mr-1" fill="currentColor">
                <path d="M17.498 14.382c-.301-.15-1.767-.867-2.04-.966-.273-.101-.473-.15-.673.15-.197.295-.771.964-.944 1.162-.175.195-.349.21-.646.075-.3-.15-1.263-.465-2.403-1.485-.888-.795-1.484-1.77-1.66-2.07-.174-.3-.019-.465.13-.615.136-.135.301-.345.451-.523.146-.181.194-.301.297-.496.1-.21.049-.375-.025-.524-.075-.15-.672-1.62-.922-2.206-.24-.584-.487-.51-.672-.51-.172-.015-.371-.015-.571-.015-.2 0-.523.074-.797.359-.273.3-1.045 1.02-1.045 2.475s1.07 2.865 1.219 3.075c.149.195 2.105 3.195 5.1 4.485.714.3 1.27.48 1.704.629.714.227 1.365.195 1.88.121.574-.091 1.767-.721 2.016-1.426.255-.705.255-1.29.18-1.425-.074-.135-.27-.21-.57-.345m-5.446 7.443h-.016c-1.77 0-3.524-.48-5.055-1.38l-.36-.214-3.75.975 1.005-3.645-.239-.375c-.99-1.576-1.516-3.391-1.516-5.26 0-5.445 4.455-9.885 9.942-9.885 2.654 0 5.145 1.035 7.021 2.91 1.875 1.859 2.909 4.35 2.909 6.99-.004 5.444-4.46 9.885-9.935 9.885M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .104 5.334.101 11.893c0 2.096.549 4.14 1.595 5.945L0 24l6.335-1.652c1.746.943 3.71 1.444 5.71 1.447h.006c6.585 0 11.946-5.336 11.949-11.896 0-3.176-1.24-6.165-3.495-8.411" />
              </svg>
              Share on WhatsApp
            </Button>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}