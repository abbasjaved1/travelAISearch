import { useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { MapPin } from 'lucide-react';
import usePlacesAutocomplete, {
  getGeocode,
  getLatLng,
} from "use-places-autocomplete";

interface Location {
  lat: number;
  lng: number;
  address: string;
}

interface FareEstimate {
  baseFare: number;
  distanceCharge: number;
  timeCharge: number;
  total: number;
  currency: string;
  distance: string;
  duration: string;
}

const defaultCenter = {
  lat: 37.7749, // San Francisco coordinates
  lng: -122.4194
};

const mapStyles = {
  width: '100%',
  height: '400px'
};

const BASE_FARE = 5; // Base fare in USD
const PER_MILE_RATE = 2; // Rate per mile in USD
const PER_MINUTE_RATE = 0.5; // Rate per minute in USD
const SURGE_MULTIPLIER = 1.5; // Surge pricing multiplier for peak hours

export function RideBooking() {
  const [pickup, setPickup] = useState<Location | null>(null);
  const [dropoff, setDropoff] = useState<Location | null>(null);
  const [fareEstimate, setFareEstimate] = useState<FareEstimate | null>(null);
  const { toast } = useToast();

  // Setup Places Autocomplete for pickup
  const {
    ready: pickupReady,
    value: pickupValue,
    suggestions: { status: pickupStatus, data: pickupSuggestions },
    setValue: setPickupValue,
    clearSuggestions: clearPickupSuggestions
  } = usePlacesAutocomplete({
    callbackName: "initPickupMap",
    requestOptions: { componentRestrictions: { country: 'us' } }
  });

  // Setup Places Autocomplete for dropoff
  const {
    ready: dropoffReady,
    value: dropoffValue,
    suggestions: { status: dropoffStatus, data: dropoffSuggestions },
    setValue: setDropoffValue,
    clearSuggestions: clearDropoffSuggestions
  } = usePlacesAutocomplete({
    callbackName: "initDropoffMap",
    requestOptions: { componentRestrictions: { country: 'us' } }
  });

  const calculateFare = async (pickup: Location, dropoff: Location) => {
    try {
      // Create a DirectionsService object
      const directionsService = new google.maps.DirectionsService();

      const result = await directionsService.route({
        origin: { lat: pickup.lat, lng: pickup.lng },
        destination: { lat: dropoff.lat, lng: dropoff.lng },
        travelMode: google.maps.TravelMode.DRIVING,
      });

      if (result.routes.length > 0) {
        const route = result.routes[0].legs[0];
        const distanceInMiles = route.distance?.value ? route.distance.value / 1609.34 : 0; // Convert meters to miles
        const durationInMinutes = route.duration?.value ? route.duration.value / 60 : 0; // Convert seconds to minutes

        // Check if it's peak hours (7-9 AM or 4-7 PM)
        const hour = new Date().getHours();
        const isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 19);
        const multiplier = isPeakHour ? SURGE_MULTIPLIER : 1;

        const distanceCharge = distanceInMiles * PER_MILE_RATE;
        const timeCharge = durationInMinutes * PER_MINUTE_RATE;
        const subtotal = BASE_FARE + distanceCharge + timeCharge;
        const total = subtotal * multiplier;

        setFareEstimate({
          baseFare: BASE_FARE,
          distanceCharge,
          timeCharge,
          total,
          currency: 'USD',
          distance: route.distance?.text || '0 mi',
          duration: route.duration?.text || '0 mins'
        });

        toast({
          title: "Fare Estimate Updated",
          description: `Estimated fare: $${total.toFixed(2)}`
        });
      }
    } catch (error) {
      console.error('Error calculating fare:', error);
      toast({
        title: "Error",
        description: "Failed to calculate fare estimate",
        variant: "destructive"
      });
    }
  };

  const handlePickupSelect = async (suggestion: any) => {
    setPickupValue(suggestion.description, false);
    clearPickupSuggestions();

    try {
      const results = await getGeocode({ address: suggestion.description });
      const { lat, lng } = await getLatLng(results[0]);
      const newPickup = { lat, lng, address: suggestion.description };
      setPickup(newPickup);

      if (dropoff) {
        calculateFare(newPickup, dropoff);
      }

      toast({
        title: "Pickup Location Set",
        description: suggestion.description
      });
    } catch (error) {
      console.error("Error selecting pickup location:", error);
      toast({
        title: "Error",
        description: "Failed to get location coordinates",
        variant: "destructive"
      });
    }
  };

  const handleDropoffSelect = async (suggestion: any) => {
    setDropoffValue(suggestion.description, false);
    clearDropoffSuggestions();

    try {
      const results = await getGeocode({ address: suggestion.description });
      const { lat, lng } = await getLatLng(results[0]);
      const newDropoff = { lat, lng, address: suggestion.description };
      setDropoff(newDropoff);

      if (pickup) {
        calculateFare(pickup, newDropoff);
      }

      toast({
        title: "Drop-off Location Set",
        description: suggestion.description
      });
    } catch (error) {
      console.error("Error selecting dropoff location:", error);
      toast({
        title: "Error",
        description: "Failed to get location coordinates",
        variant: "destructive"
      });
    }
  };

  const handleMapClick = async (e: google.maps.MapMouseEvent) => {
    if (!e.latLng) return;

    const lat = e.latLng.lat();
    const lng = e.latLng.lng();

    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`
      );
      const data = await response.json();

      if (data.results && data.results[0]) {
        const location = {
          lat,
          lng,
          address: data.results[0].formatted_address
        };

        if (!pickup) {
          setPickup(location);
          setPickupValue(location.address, false);
          toast({
            title: "Pickup Location Set",
            description: location.address
          });
        } else if (!dropoff) {
          setDropoff(location);
          setDropoffValue(location.address, false);
          calculateFare(pickup, location);
          toast({
            title: "Drop-off Location Set",
            description: location.address
          });
        }
      }
    } catch (error) {
      console.error("Error getting address:", error);
      toast({
        title: "Error",
        description: "Failed to get location details",
        variant: "destructive"
      });
    }
  };

  const handleBookRide = () => {
    if (!pickup || !dropoff) {
      toast({
        title: "Missing Locations",
        description: "Please select both pickup and drop-off locations",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Success",
      description: "Your ride has been booked!"
    });
  };

  const handleClearLocations = () => {
    setPickup(null);
    setDropoff(null);
    setPickupValue('', false);
    setDropoffValue('', false);
    setFareEstimate(null);
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Book a Ride</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Pickup Location</label>
              <div className="relative">
                <Input 
                  value={pickupValue}
                  onChange={(e) => setPickupValue(e.target.value)}
                  placeholder="Search or click on map for pickup location"
                  disabled={!pickupReady}
                />
                {pickupStatus === "OK" && (
                  <ul className="absolute z-50 w-full bg-white border rounded-md shadow-lg mt-1 max-h-48 overflow-auto">
                    {pickupSuggestions.map((suggestion) => (
                      <li
                        key={suggestion.place_id}
                        className="p-2 hover:bg-gray-100 cursor-pointer"
                        onClick={() => handlePickupSelect(suggestion)}
                      >
                        {suggestion.description}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Drop-off Location</label>
              <div className="relative">
                <Input 
                  value={dropoffValue}
                  onChange={(e) => setDropoffValue(e.target.value)}
                  placeholder="Search or click on map for drop-off location"
                  disabled={!dropoffReady}
                />
                {dropoffStatus === "OK" && (
                  <ul className="absolute z-50 w-full bg-white border rounded-md shadow-lg mt-1 max-h-48 overflow-auto">
                    {dropoffSuggestions.map((suggestion) => (
                      <li
                        key={suggestion.place_id}
                        className="p-2 hover:bg-gray-100 cursor-pointer"
                        onClick={() => handleDropoffSelect(suggestion)}
                      >
                        {suggestion.description}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          {fareEstimate && (
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <h3 className="font-medium">Fare Estimate</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>Distance:</div>
                <div>{fareEstimate.distance}</div>
                <div>Duration:</div>
                <div>{fareEstimate.duration}</div>
                <div>Base Fare:</div>
                <div>${fareEstimate.baseFare.toFixed(2)}</div>
                <div>Distance Charge:</div>
                <div>${fareEstimate.distanceCharge.toFixed(2)}</div>
                <div>Time Charge:</div>
                <div>${fareEstimate.timeCharge.toFixed(2)}</div>
                <div className="font-medium">Total Estimate:</div>
                <div className="font-medium">${fareEstimate.total.toFixed(2)}</div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                * Prices may vary based on traffic, weather, and demand
              </p>
            </div>
          )}

          <div className="rounded-lg overflow-hidden border">
            <LoadScript 
              googleMapsApiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY}
              libraries={["places"]}
            >
              <GoogleMap
                mapContainerStyle={mapStyles}
                center={pickup || defaultCenter}
                zoom={13}
                onClick={handleMapClick}
              >
                {pickup && (
                  <Marker
                    position={pickup}
                    icon={{
                      url: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
                    }}
                  />
                )}
                {dropoff && (
                  <Marker
                    position={dropoff}
                    icon={{
                      url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
                    }}
                  />
                )}
              </GoogleMap>
            </LoadScript>
          </div>

          <div className="flex gap-4">
            <Button 
              className="flex-1"
              onClick={handleBookRide}
              disabled={!pickup || !dropoff}
            >
              <MapPin className="w-4 h-4 mr-2" />
              Book Ride
            </Button>
            <Button 
              variant="outline"
              onClick={handleClearLocations}
            >
              Clear
            </Button>
          </div>

          <div className="text-sm text-muted-foreground">
            Search for a location or click on the map to set pickup and drop-off points
          </div>
        </div>
      </CardContent>
    </Card>
  );
}