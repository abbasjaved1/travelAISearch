import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface PresenceIndicatorProps {
  status: 'online' | 'away' | 'offline';
  size?: 'sm' | 'md' | 'lg';
  pulseColor?: string;
  className?: string;
}

export function PresenceIndicator({
  status,
  size = 'md',
  pulseColor,
  className
}: PresenceIndicatorProps) {
  const sizeClasses = {
    sm: 'w-2 h-2',
    md: 'w-3 h-3',
    lg: 'w-4 h-4'
  };

  const statusColors = {
    online: 'bg-green-500',
    away: 'bg-yellow-500',
    offline: 'bg-gray-400'
  };

  const pulseAnimation = {
    online: {
      scale: [1, 1.2, 1],
      opacity: [0.8, 0.4, 0.8],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    },
    away: {
      scale: [1, 1.1, 1],
      opacity: [0.6, 0.3, 0.6],
      transition: {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut"
      }
    },
    offline: {
      scale: 1,
      opacity: 0.5
    }
  };

  return (
    <div className={cn("relative", className)}>
      <motion.div
        className={cn(
          "rounded-full",
          sizeClasses[size],
          statusColors[status]
        )}
        animate={pulseAnimation[status]}
      />
      {status === 'online' && (
        <motion.div
          className={cn(
            "absolute inset-0 rounded-full",
            pulseColor || "bg-green-500"
          )}
          initial={{ scale: 1, opacity: 0.3 }}
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.3, 0, 0.3]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}
    </div>
  );
}
