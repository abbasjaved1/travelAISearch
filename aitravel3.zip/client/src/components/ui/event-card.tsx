import { useState } from "react";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { Calendar, MapPin, Ticket, Info } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "./dialog";
import { motion } from "framer-motion";

export interface EventData {
  id: string;
  name: string;
  type: 'sport' | 'cultural' | 'entertainment';
  date: string;
  venue: string;
  description: string;
  ticketPrice?: number;
  category: string;
  image?: string;
}

interface EventCardProps {
  event: EventData;
  index: number;
  compact?: boolean;
}

export function EventCard({ event, index, compact = false }: EventCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(false);
  
  // Format the date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    }).format(date);
  };
  
  // Different background colors based on event type
  const getTypeColor = () => {
    switch (event.type) {
      case 'sport':
        return 'bg-blue-50 text-blue-700';
      case 'cultural':
        return 'bg-purple-50 text-purple-700';
      case 'entertainment':
        return 'bg-amber-50 text-amber-700';
      default:
        return 'bg-gray-50 text-gray-700';
    }
  };
  
  // Sample event images based on category
  const getEventImage = () => {
    if (event.image) return event.image;
    
    const defaultImages = {
      sport: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      cultural: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      entertainment: "https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      concert: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      festival: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      food: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      art: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      museum: "https://images.unsplash.com/photo-1565060169551-820443c5842f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      theater: "https://images.unsplash.com/photo-1503095396549-807759245b35?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
      sports: "https://images.unsplash.com/photo-1471295253337-3ceaaedca402?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    };
    
    // Try to match by category first
    if (event.category && (event.category.toLowerCase() in defaultImages)) {
      return defaultImages[event.category.toLowerCase() as keyof typeof defaultImages];
    }
    
    // Fall back to event type
    return defaultImages[event.type];
  };
  
  // Animation settings
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.5,
        ease: "easeOut"
      }
    })
  };

  return (
    <motion.div
      custom={index}
      initial="hidden"
      animate="visible"
      variants={cardVariants}
    >
      <Card className="overflow-hidden h-full group hover:shadow-md transition-all duration-200">
        <div className="relative">
          <img 
            src={getEventImage()} 
            alt={event.name}
            className="h-40 w-full object-cover"
          />
          <div className={`absolute top-3 right-3 px-2 py-1 rounded-md text-xs font-medium ${getTypeColor()}`}>
            {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
          </div>
        </div>
        
        <CardContent className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-base line-clamp-1">{event.name}</h3>
            <div className="flex items-center text-gray-500 text-sm mt-1">
              <Calendar className="w-3.5 h-3.5 mr-1.5" />
              <span>{formatDate(event.date)}</span>
            </div>
            <div className="flex items-center text-gray-500 text-sm mt-1">
              <MapPin className="w-3.5 h-3.5 mr-1.5" />
              <span className="truncate">{event.venue}</span>
            </div>
          </div>
          
          {!compact && (
            <p className="text-sm text-gray-600 line-clamp-2">{event.description}</p>
          )}
          
          <div className="flex items-center justify-between">
            <div>
              {event.ticketPrice !== undefined ? (
                <div className="flex items-center text-green-600 font-medium">
                  <Ticket className="w-4 h-4 mr-1" />
                  ${Number(event.ticketPrice).toFixed(2)}
                </div>
              ) : (
                <span className="text-sm text-gray-500">Price not available</span>
              )}
            </div>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Info className="w-3.5 h-3.5 mr-1.5" />
                  Details
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>{event.name}</DialogTitle>
                  <DialogDescription className="flex flex-col gap-2 mt-2">
                    <div className="flex items-center text-gray-700">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>{formatDate(event.date)}</span>
                    </div>
                    <div className="flex items-center text-gray-700">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{event.venue}</span>
                    </div>
                    {event.ticketPrice !== undefined && (
                      <div className="flex items-center text-green-600">
                        <Ticket className="w-4 h-4 mr-2" />
                        <span>${Number(event.ticketPrice).toFixed(2)}</span>
                      </div>
                    )}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="mt-4">
                  <img 
                    src={getEventImage()} 
                    alt={event.name}
                    className="w-full h-48 object-cover rounded-md mb-4"
                  />
                  <p className="text-sm text-gray-600">{event.description}</p>
                </div>
                
                <DialogFooter className="mt-6">
                  <DialogClose asChild>
                    <Button variant="outline" className="mr-2">
                      Cancel
                    </Button>
                  </DialogClose>
                  <Button>
                    Book Tickets
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}