import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaTwitter, FaFacebookF, FaLinkedinIn } from 'react-icons/fa';
import { Share2 } from 'lucide-react';
import { Button } from './button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './dropdown-menu';
import { toast } from '@/hooks/use-toast';

interface SocialShareProps {
  title: string;
  description: string;
  url?: string;
  image?: string;
}

export function SocialShare({ title, description, url = window.location.href, image }: SocialShareProps) {
  const [isOpen, setIsOpen] = useState(false);

  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);

  const shareLinks = {
    twitter: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`
  };

  const handleShare = async (platform: keyof typeof shareLinks) => {
    try {
      const shareUrl = shareLinks[platform];
      window.open(shareUrl, '_blank', 'width=600,height=400');
      toast({
        title: 'Shared Successfully',
        description: `Your memory has been shared on ${platform}!`,
      });
    } catch (error) {
      console.error('Share error:', error);
      toast({
        title: 'Share Failed',
        description: 'Failed to share your memory. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="rounded-full hover:bg-primary hover:text-primary-foreground transition-colors"
        >
          <motion.div
            animate={{ rotate: isOpen ? 90 : 0 }}
            transition={{ duration: 0.2 }}
          >
            <Share2 className="h-4 w-4" />
          </motion.div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <DropdownMenuItem
              className="flex items-center cursor-pointer hover:bg-muted transition-colors"
              onClick={() => handleShare('twitter')}
            >
              <FaTwitter className="mr-2 h-4 w-4 text-[#1DA1F2]" />
              Share on Twitter
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center cursor-pointer hover:bg-muted transition-colors"
              onClick={() => handleShare('facebook')}
            >
              <FaFacebookF className="mr-2 h-4 w-4 text-[#4267B2]" />
              Share on Facebook
            </DropdownMenuItem>
            <DropdownMenuItem
              className="flex items-center cursor-pointer hover:bg-muted transition-colors"
              onClick={() => handleShare('linkedin')}
            >
              <FaLinkedinIn className="mr-2 h-4 w-4 text-[#0077B5]" />
              Share on LinkedIn
            </DropdownMenuItem>
          </motion.div>
        </AnimatePresence>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}