import { motion } from "framer-motion";
import { Plane, Globe, Compass } from "lucide-react";

export function LoadingScreen() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-50"
    >
      <div className="relative flex items-center justify-center">
        {/* Rotating globe */}
        <motion.div
          animate={{
            rotate: 360,
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "linear",
          }}
          className="text-primary"
        >
          <Globe className="w-16 h-16" />
        </motion.div>

        {/* Flying plane */}
        <motion.div
          animate={{
            x: [-50, 50],
            y: [-20, 20],
            scale: [1, 1.2, 1],
            rotate: [0, 10, -10, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: "reverse",
            ease: "easeInOut",
          }}
          className="absolute text-primary"
        >
          <Plane className="w-8 h-8" />
        </motion.div>

        {/* Pulsing compass */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [-30, 30],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: "reverse",
            ease: "easeInOut",
          }}
          className="absolute -bottom-12 text-primary"
        >
          <Compass className="w-10 h-10" />
        </motion.div>

        {/* Loading text */}
        <motion.p
          animate={{
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute -top-12 text-lg font-medium text-primary"
        >
          Preparing your journey...
        </motion.p>
      </div>
    </motion.div>
  );
}
