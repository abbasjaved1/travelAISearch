import { useState, useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle } from "./card";
import { Input } from "./input";
import { Button } from "./button";
import { ScrollArea } from "./scroll-area";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Send, UserCheck, Loader2, Check, Clock, MessageCircle, RefreshCw, User, Palette, ArrowLeft } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./dropdown-menu";
import { ChatRecommendations } from "./chat-recommendations";
import { socket, isConnected } from '@/lib/socket';
import { GmailContactsNotice } from "./gmail-contacts-notice";

interface Message {
  id?: string;
  type: 'message' | 'status' | 'typing';
  senderId: number;
  senderName: string;
  content?: string;
  timestamp: string;
  colorScheme?: string;
  roomId?: string;
  status?: string;
}

interface OnlineUser {
  id: number;
  username: string;
  isTyping: boolean;
  lastActive?: string;
  colorScheme?: string;
  currentRoom?: string;
}

interface Room {
  id: string;
  name: string;
  participants: {
    id: number;
    username: string;
    isTyping: boolean;
  }[];
}

const colorSchemes = {
  default: {
    bg: 'bg-primary',
    text: 'text-primary-foreground'
  },
  blue: {
    bg: 'bg-blue-500',
    text: 'text-white'
  },
  green: {
    bg: 'bg-green-500',
    text: 'text-white'
  },
  purple: {
    bg: 'bg-purple-500',
    text: 'text-white'
  },
  pink: {
    bg: 'bg-pink-500',
    text: 'text-white'
  },
  orange: {
    bg: 'bg-orange-500',
    text: 'text-white'
  }
};

type ColorSchemeKey = keyof typeof colorSchemes;

const MessageStatus = ({ status }: { status?: string }) => {
  switch (status) {
    case 'sent':
      return <Check className="h-3 w-3 text-gray-400" />;
    case 'delivered':
      return (
        <div className="relative flex">
          <Check className="h-3 w-3 text-blue-500" />
          <Check className="h-3 w-3 text-blue-500 absolute -right-1 top-0" />
        </div>
      );
    default:
      return <Clock className="h-3 w-3 text-gray-400" />;
  }
};

const OnlineUsersList = ({ users }: { users: OnlineUser[] }) => {
  return (
    <div className="border-t p-4">
      <h3 className="text-sm font-medium mb-2 flex items-center gap-2">
        <User className="h-4 w-4" />
        Online Users ({users.length})
      </h3>
      <ScrollArea className="h-32">
        <div className="space-y-2">
          {users.map((user) => (
            <div key={user.id} className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <span>{user.username}</span>
              {user.isTyping && (
                <span className="text-xs text-muted-foreground italic">typing...</span>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export function ChatRoom() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [connectionState, setConnectionState] = useState<'connecting' | 'connected' | 'reconnecting' | 'failed'>('connecting');
  const [selectedColorScheme, setSelectedColorScheme] = useState<ColorSchemeKey>('default');
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
  const messageEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          toast({
            title: "Location Error",
            description: "Unable to get your location. Some features may be limited.",
            variant: "destructive"
          });
        }
      );
    }
  }, [toast]);

  useEffect(() => {
    if (!user) {
      setConnectionState('connecting');
      setMessages([]);
      setOnlineUsers([]);
      return;
    }

    // Check socket connection
    if (!isConnected()) {
      socket.connect();
    }

    setConnectionState(isConnected() ? 'connected' : 'connecting');

    // Set up event listeners
    const handleConnect = () => {
      console.log('Socket.IO connected');
      setConnectionState('connected');

      socket.emit('auth', {
        id: user.id,
        username: user.username,
        colorScheme: selectedColorScheme
      });

      toast({
        title: "Connected",
        description: "Chat connection established"
      });
    };

    const handleChatMessage = (message: Message) => {
      console.log('Received message:', message);
      setMessages(prev => [...prev, message]);
      messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    const handleUserList = (users: OnlineUser[]) => {
      console.log('Received user list:', users);
      setOnlineUsers(users);
    };

    const handleTypingStatus = (typingUsers: string[]) => {
      setOnlineUsers(prev =>
        prev.map(u => ({
          ...u,
          isTyping: typingUsers.includes(u.username)
        }))
      );
    };

    const handleDisconnect = () => {
      console.log('Socket.IO disconnected');
      setConnectionState('reconnecting');
    };

    const handleConnectError = (error: Error) => {
      console.error('Connection error:', error);
      setConnectionState('failed');
      toast({
        title: "Connection Error",
        description: "Failed to connect to chat server",
        variant: "destructive"
      });
    };

    const handleRoomInfo = (room: Room) => {
      console.log('Received room info:', room);
      setCurrentRoom(room);
    };

    // Add event listeners
    socket.on('connect', handleConnect);
    socket.on('chat_message', handleChatMessage);
    socket.on('user_list', handleUserList);
    socket.on('typing_status', handleTypingStatus);
    socket.on('disconnect', handleDisconnect);
    socket.on('connect_error', handleConnectError);
    socket.on('room_info', handleRoomInfo);

    // Emit auth event if already connected
    if (isConnected()) {
      socket.emit('auth', {
        id: user.id,
        username: user.username,
        colorScheme: selectedColorScheme
      });
    }

    // Cleanup function
    return () => {
      socket.off('connect', handleConnect);
      socket.off('chat_message', handleChatMessage);
      socket.off('user_list', handleUserList);
      socket.off('typing_status', handleTypingStatus);
      socket.off('disconnect', handleDisconnect);
      socket.off('connect_error', handleConnectError);
      socket.off('room_info', handleRoomInfo);
    };
  }, [user, toast, selectedColorScheme]);

  // Handle sending a message
  const handleSend = (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
    }

    if (!message.trim() || !user) {
      return;
    }

    try {
      const chatMessage: Message = {
        type: 'message',
        senderId: user.id,
        senderName: user.username,
        content: message.trim(),
        timestamp: new Date().toISOString(),
        colorScheme: selectedColorScheme
      };
      
      // Add room ID if in a room
      if (currentRoom) {
        chatMessage.roomId = currentRoom.id;
      }

      console.log('Sending message:', chatMessage);
      
      // Emit the appropriate event based on whether we're in a room
      if (currentRoom) {
        socket.emit('room_message', chatMessage);
      } else {
        socket.emit('chat_message', chatMessage);
      }
      
      setMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  };

  // Handle reconnection
  const handleReconnect = () => {
    socket.connect();
  };

  // Handle leaving a room
  const handleLeaveRoom = () => {
    if (currentRoom) {
      socket.emit('leave_room', { roomId: currentRoom.id });
      setCurrentRoom(null);
      setMessages([]);
    }
  };

  if (!user) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="md:col-span-2 flex flex-col gap-2">
        {/* Gmail Contacts Notice */}
        <GmailContactsNotice />
        
        <Card className="h-[600px] flex flex-col">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                {currentRoom ? (
                  <div className="flex items-center">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="mr-2" 
                      onClick={handleLeaveRoom}
                    >
                      <ArrowLeft className="h-4 w-4 mr-1" />
                    </Button>
                    <CardTitle>{currentRoom.name}</CardTitle>
                    <span className="ml-2 text-xs text-muted-foreground">
                      ({currentRoom.participants.length} participants)
                    </span>
                  </div>
                ) : (
                  <CardTitle>Chat Room</CardTitle>
                )}
              </div>
              <div className="flex items-center gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Palette className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {(Object.keys(colorSchemes) as ColorSchemeKey[]).map((name) => (
                      <DropdownMenuItem
                        key={name}
                        onClick={() => setSelectedColorScheme(name)}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded ${colorSchemes[name].bg}`} />
                          <span className="capitalize">{name}</span>
                          {selectedColorScheme === name && (
                            <Check className="h-4 w-4 ml-auto" />
                          )}
                        </div>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                <div className="text-sm text-muted-foreground">
                  <UserCheck className="h-4 w-4 inline-block mr-1" />
                  {onlineUsers.length} online
                </div>
                {connectionState === 'failed' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleReconnect}
                    className="h-8"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>

          <div className="flex-1 overflow-hidden">
            {connectionState !== 'connected' ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    {connectionState === 'connecting' ? 'Connecting to chat...' :
                      connectionState === 'reconnecting' ? 'Reconnecting...' :
                        'Connection failed'}
                  </p>
                  {connectionState === 'failed' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleReconnect}
                      className="mt-4"
                    >
                      Try Again
                    </Button>
                  )}
                </div>
              </div>
            ) : (
              <ScrollArea className="h-full p-4">
                <div className="space-y-4">
                  {messages.map((msg, index) => (
                    <div
                      key={msg.id || index}
                      className={`flex ${msg.senderId === user.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg px-4 py-2 ${
                          msg.senderId === user.id
                            ? `${colorSchemes[msg.colorScheme as ColorSchemeKey || 'default'].bg} ${colorSchemes[msg.colorScheme as ColorSchemeKey || 'default'].text}`
                            : 'bg-muted'
                        }`}
                      >
                        {msg.senderId !== user.id && (
                          <p className="text-xs font-medium mb-1">{msg.senderName}</p>
                        )}
                        <p className="break-words">{msg.content}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-xs opacity-70">
                            {new Date(msg.timestamp).toLocaleTimeString()}
                          </span>
                          {msg.senderId === user.id && (
                            <MessageStatus status={msg.status} />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messageEndRef} />
                </div>
              </ScrollArea>
            )}
          </div>

          {connectionState === 'connected' && (
            currentRoom ? (
              <div className="border-t p-4">
                <h3 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Room Participants ({currentRoom.participants.length})
                </h3>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {currentRoom.participants.map((participant) => (
                      <div key={participant.id} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 rounded-full bg-green-500" />
                        <span>{participant.username}</span>
                        {participant.isTyping && (
                          <span className="text-xs text-muted-foreground italic">typing...</span>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            ) : (
              <OnlineUsersList users={onlineUsers} />
            )
          )}

          <div className="border-t p-4">
            <form
              onSubmit={handleSend}
              className="flex gap-2"
            >
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={currentRoom ? `Message ${currentRoom.name}...` : "Type a message..."}
                disabled={connectionState !== 'connected'}
              />
              <Button
                type="submit"
                disabled={!message.trim() || connectionState !== 'connected'}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </Card>
      </div>
      <div className="hidden md:block">
        {location && <ChatRecommendations />}
      </div>
    </div>
  );
}