import { useEffect, useState } from 'react';
import { useToast } from "@/hooks/use-toast";

interface RobofyChatProps {
  onReady?: () => void;
  onError?: () => void;
}

export function RobofyChat({ onReady, onError }: RobofyChatProps) {
  const { toast } = useToast();
  const [loadAttempts, setLoadAttempts] = useState(0);
  const maxAttempts = 3;

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const initRobofy = () => {
      try {
        // Create and append Robofy script
        const script = document.createElement('script');
        script.id = 'chatbotscript';
        script.dataset.accountid = 'leVNirk+14D14BQBWgpEjw==';
        script.dataset.websiteid = 'OykjZCzimvsf07vJoEgVoA==';
        script.src = 'https://app.robofy.ai/bot/js/common.js?v=' + new Date().getTime();

        // Handle script load success
        script.onload = () => {
          if (onReady) {
            onReady();
          }
          console.log('Robofy chat loaded successfully');
        };

        // Handle script load error
        script.onerror = () => {
          console.error('Failed to load Robofy chat');
          if (loadAttempts < maxAttempts) {
            // Retry after a delay with exponential backoff
            timeoutId = setTimeout(() => {
              setLoadAttempts(prev => prev + 1);
              initRobofy();
            }, 2000 * Math.pow(2, loadAttempts));
          } else {
            if (onError) {
              onError();
            }
            toast({
              title: "Chat Loading Error",
              description: "Failed to initialize chat. Please try again later.",
              variant: "destructive"
            });
          }
        };

        // Remove any existing Robofy script
        const existingScript = document.getElementById('chatbotscript');
        if (existingScript) {
          existingScript.remove();
        }

        document.head.appendChild(script);
      } catch (error) {
        console.error('Error initializing Robofy:', error);
        if (onError) {
          onError();
        }
      }
    };

    initRobofy();

    // Cleanup on unmount
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      const scriptToRemove = document.getElementById('chatbotscript');
      if (scriptToRemove) {
        scriptToRemove.remove();
      }
      // Clean up any Robofy-related elements
      const robofyElements = document.querySelectorAll('[id^="robofy"]');
      robofyElements.forEach(element => element.remove());
    };
  }, [onReady, onError, loadAttempts, toast]);

  return null; // Robofy injects its own UI
}