import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Info, X } from "lucide-react";

interface VideoPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoData: {
    title: string;
    source?: string;
    index: number;
    // These are optional properties that might come from the parent component
    src?: string;
    isPlaying?: boolean;
  } | null;
}

export function VideoPlayerModal({ isOpen, onClose, videoData }: VideoPlayerModalProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [fallbackAttempt, setFallbackAttempt] = useState(0);

  // Direct MP4 videos instead of YouTube embeds which may be blocked in Replit
  const getVideoUrl = (index: number) => {
    // Using multiple reliable CDN sources to maximize compatibility
    // These are free stock videos from trusted CDNs
    const videoGroups = [
      // Group 0: Great Barrier Reef options - primary and fallbacks
      [
        "https://cdn.coverr.co/videos/coverr-underwater-coral-reef-with-fish-5773/1080p/coverr-underwater-coral-reef-with-fish-5773-1080p.mp4",
        "https://static.videezy.com/system/resources/previews/000/043/312/original/Coral_Reef12.mp4",
        "https://assets.mixkit.co/videos/preview/mixkit-blue-underwater-life-of-a-fish-in-an-aquarium-22994-large.mp4"
      ],
      
      // Group 1: Sydney Harbor options - primary and fallbacks  
      [
        "https://cdn.coverr.co/videos/coverr-aerial-footage-of-sydney-harbour-377/1080p/coverr-aerial-footage-of-sydney-harbour-377-1080p.mp4",
        "https://static.videezy.com/system/resources/previews/000/040/495/original/Sydney_Opera_House_5.mp4",
        "https://assets.mixkit.co/videos/preview/mixkit-aerial-long-shot-view-of-sydney-opera-house-5086-large.mp4"
      ],
      
      // Group 2: Australian Outback/wildlife - primary and fallbacks
      [
        "https://cdn.coverr.co/videos/coverr-a-valley-in-australia-7342/1080p/coverr-a-valley-in-australia-7342-1080p.mp4",
        "https://static.videezy.com/system/resources/previews/000/001/836/original/Desert_Kangaroos.mp4",
        "https://assets.mixkit.co/videos/preview/mixkit-kangaroo-jumping-in-slow-motion-9669-large.mp4"
      ]
    ];
    
    // Ensure index is valid
    let groupIndex = 0;
    if (typeof index === 'number' && index >= 0 && index < videoGroups.length) {
      groupIndex = index;
    }
    
    // Get the current group
    const currentGroup = videoGroups[groupIndex];
    
    // Choose a video from the group based on fallback attempt
    const videoIndex = Math.min(fallbackAttempt, currentGroup.length - 1);
    
    console.log(`Using video from group ${groupIndex}, attempt ${fallbackAttempt}, index ${videoIndex}`);
    return currentGroup[videoIndex];
  };

  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  const handleIframeError = () => {
    // Try a fallback video source if available
    if (fallbackAttempt < 2) {
      console.log("Video failed to load, trying fallback...");
      setFallbackAttempt(prev => prev + 1);
      setIsLoading(true);  // Reset loading state for the fallback attempt
      setHasError(false);
    } else {
      // After trying fallbacks, show the error
      console.error("All video sources failed to load");
      setIsLoading(false);
      setHasError(true);
    }
  };

  // Reset state when dialog opens
  const handleOpenChange = (open: boolean) => {
    if (!open && videoData) {
      onClose();
    }
    
    if (open) {
      setIsLoading(true);
      setHasError(false);
      setFallbackAttempt(0); // Reset fallback counter for new video
      
      // Add a fallback in case loading never completes
      setTimeout(() => {
        setIsLoading(false);
      }, 8000);
    }
  };
  
  // Provide a direct fallback in case video fails
  useEffect(() => {
    if (isOpen && videoData) {
      // Ensure loading state is cleared after a timeout
      const safetyTimeout = setTimeout(() => {
        if (isLoading) {
          console.log("Safety timeout triggered - ensuring loading indicator is removed");
          setIsLoading(false);
        }
      }, 10000);
      
      return () => clearTimeout(safetyTimeout);
    }
  }, [isOpen, videoData, isLoading]);

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[800px] p-0 overflow-hidden bg-black text-white">
        <DialogHeader className="p-4 bg-gradient-to-b from-black/80 to-transparent absolute top-0 left-0 right-0 z-10">
          <DialogTitle className="flex items-center gap-2">
            <>
              <img src="/logos/aitraveglobe-logo.svg" alt="AITraveGlobe" className="w-5 h-5" />
              <span>{videoData?.title || "Travel Video"}</span>
            </>
          </DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 text-white hover:bg-white/20 rounded-full"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="relative w-full h-[450px]">
          {videoData && (
            <>
              {/* Loading indicator */}
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-black z-10">
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
                    <p className="text-white/80 text-sm animate-pulse">Loading amazing video...</p>
                  </div>
                </div>
              )}
              
              {/* Error state */}
              {hasError && (
                <div className="absolute inset-0 flex items-center justify-center bg-black z-10">
                  <div className="text-center p-6">
                    <div className="bg-red-500/20 p-3 rounded-full inline-flex mb-4">
                      <X className="h-8 w-8 text-red-500" />
                    </div>
                    <h3 className="text-xl font-medium mb-2">Video Unavailable</h3>
                    <p className="text-white/70 mb-4">
                      Sorry, we couldn't load this video. Please try another video or check your connection.
                    </p>
                    <Button
                      variant="outline"
                      className="bg-white/10 hover:bg-white/20 border-0"
                      onClick={onClose}
                    >
                      Close
                    </Button>
                  </div>
                </div>
              )}
              
              {/* Direct video player with MP4 source */}
              <video
                src={getVideoUrl(videoData.index)}
                className="w-full h-full object-contain bg-black"
                controls
                autoPlay
                playsInline
                onLoadedData={handleIframeLoad}
                onError={handleIframeError}
                ref={(videoElement) => {
                  if (videoElement) {
                    // Add a timeout to detect if video fails to load properly
                    const timeout = setTimeout(() => {
                      if (isLoading) {
                        // Try a fallback if possible
                        if (fallbackAttempt < 2) {
                          console.log("Video loading timeout, trying fallback...");
                          setFallbackAttempt(prev => prev + 1);
                          setIsLoading(true);  // Keep loading state for fallback
                        } else {
                          setIsLoading(false);
                          setHasError(true);
                          console.error("Video loading timeout - all sources failed");
                        }
                      }
                    }, 7000);
                    
                    // Set up handlers
                    videoElement.onloadeddata = () => {
                      clearTimeout(timeout);
                      setIsLoading(false);
                      console.log("Video loaded successfully");
                      
                      // Start playing automatically
                      videoElement.play()
                        .catch(err => {
                          console.error("Failed to autoplay video:", err);
                          // Still show the video player with controls even if autoplay fails
                        });
                    };
                    
                    videoElement.onerror = () => {
                      clearTimeout(timeout);
                      
                      // Try a fallback if possible
                      if (fallbackAttempt < 2) {
                        console.log("Video element encountered an error, trying fallback...");
                        setFallbackAttempt(prev => prev + 1);
                        // Keep loading state active for the fallback attempt
                        setIsLoading(true);
                      } else {
                        setIsLoading(false);
                        setHasError(true);
                        console.error("All video sources failed to load");
                      }
                    };
                    
                    return () => clearTimeout(timeout);
                  }
                }}
              />
            </>
          )}
        </div>

        <DialogFooter className="p-4 bg-gradient-to-t from-black/80 to-transparent absolute bottom-0 left-0 right-0">
          <div className="w-full flex justify-between items-center">
            <div className="flex items-center text-sm">
              <Info className="h-4 w-4 mr-2" />
              Source: <span className="ml-1">{videoData?.source || "Travel Guide"}</span>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              className="bg-white/10 border-0 text-white hover:bg-white/20"
              onClick={onClose}
            >
              Close
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}