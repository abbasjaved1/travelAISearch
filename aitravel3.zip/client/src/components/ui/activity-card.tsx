import { useState } from "react";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { Badge } from "./badge";
import { MapPin, Clock, Star, ArrowRight, Heart } from "lucide-react";
import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "./dialog";

export interface ActivityData {
  id: string;
  name: string;
  location: string;
  description: string;
  rating: number;
  reviewCount?: number;
  image: string;
  duration: string;
  category: string;
  price?: number | null;
  tags?: string[];
  openingHours?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

interface ActivityCardProps {
  activity: ActivityData;
  index: number;
  compact?: boolean;
}

export function ActivityCard({ activity, index, compact = false }: ActivityCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(false);
  
  const getCategoryColor = () => {
    const categories: Record<string, string> = {
      "historic": "bg-amber-100 text-amber-800",
      "museum": "bg-blue-100 text-blue-800",
      "outdoors": "bg-green-100 text-green-800",
      "entertainment": "bg-purple-100 text-purple-800",
      "tour": "bg-indigo-100 text-indigo-800",
      "food": "bg-orange-100 text-orange-800",
      "shopping": "bg-pink-100 text-pink-800",
      "nightlife": "bg-violet-100 text-violet-800",
      "park": "bg-emerald-100 text-emerald-800",
      "beach": "bg-cyan-100 text-cyan-800",
      "adventure": "bg-red-100 text-red-800",
      "wellness": "bg-lime-100 text-lime-800",
    };
    
    const lowerCategory = activity.category.toLowerCase();
    
    // Check if category exists in our mapping
    for (const [key, value] of Object.entries(categories)) {
      if (lowerCategory.includes(key)) {
        return value;
      }
    }
    
    // Default color
    return "bg-gray-100 text-gray-800";
  };
  
  // Format rating to display as stars
  const formatRating = (rating: number) => {
    // Convert to number first in case it comes as a string from the API
    return Number(rating).toFixed(1);
  };
  
  // Animation settings
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.5,
        ease: "easeOut"
      }
    })
  };
  
  // Generate rating stars
  const renderStars = (rating: number, max: number = 5) => {
    // Convert to number to handle if rating comes as a string
    const numRating = Number(rating);
    
    return (
      <div className="flex items-center">
        {[...Array(max)].map((_, i) => (
          <Star
            key={i}
            size={16}
            className={`${
              i < Math.floor(numRating)
                ? "text-yellow-400 fill-yellow-400"
                : i < numRating
                ? "text-yellow-400 fill-yellow-400 opacity-50"
                : "text-gray-300"
            }`}
          />
        ))}
        <span className="ml-1 text-sm font-medium">{formatRating(rating)}</span>
        {activity.reviewCount && (
          <span className="text-xs text-gray-500 ml-1">({activity.reviewCount})</span>
        )}
      </div>
    );
  };

  return (
    <motion.div
      custom={index}
      initial="hidden"
      animate="visible"
      variants={cardVariants}
    >
      <Card className="overflow-hidden h-full group hover:shadow-md transition-all duration-200">
        <div className="relative">
          <img 
            src={activity.image} 
            alt={activity.name}
            className="h-40 w-full object-cover"
          />
          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className="absolute top-3 right-3 bg-white/80 p-1.5 rounded-full hover:bg-white transition-colors"
          >
            <Heart 
              className={`w-4 h-4 ${isBookmarked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} 
            />
          </button>
          <Badge className={`absolute top-3 left-3 ${getCategoryColor()}`}>
            {activity.category}
          </Badge>
        </div>
        
        <CardContent className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-base line-clamp-1">{activity.name}</h3>
            <div className="flex items-center text-gray-500 text-sm mt-1">
              <MapPin className="w-3.5 h-3.5 mr-1.5" />
              <span className="truncate">{activity.location}</span>
            </div>
            <div className="flex items-center mt-1">
              {renderStars(activity.rating)}
            </div>
          </div>
          
          {!compact && (
            <p className="text-sm text-gray-600 line-clamp-2">{activity.description}</p>
          )}
          
          <div className="flex items-center justify-between">
            <div className="flex items-center text-gray-600 text-sm">
              <Clock className="w-3.5 h-3.5 mr-1.5" />
              <span>{activity.duration}</span>
            </div>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <ArrowRight className="w-3.5 h-3.5 mr-1.5" />
                  Details
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>{activity.name}</DialogTitle>
                  <DialogDescription className="flex flex-col gap-2 mt-2">
                    <div className="flex items-center text-gray-700">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{activity.location}</span>
                    </div>
                    <div className="flex items-center text-gray-700">
                      <Clock className="w-4 h-4 mr-2" />
                      <span>{activity.duration}</span>
                      {activity.openingHours && (
                        <span className="ml-2 text-sm text-gray-500">({activity.openingHours})</span>
                      )}
                    </div>
                    <div>
                      {renderStars(activity.rating)}
                    </div>
                  </DialogDescription>
                </DialogHeader>
                
                <div className="mt-4">
                  <img 
                    src={activity.image} 
                    alt={activity.name}
                    className="w-full h-48 object-cover rounded-md mb-4"
                  />
                  <p className="text-sm text-gray-600">{activity.description}</p>
                  
                  {activity.tags && activity.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {activity.tags.map((tag, i) => (
                        <Badge key={i} variant="outline" className="bg-gray-50">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
                
                <DialogFooter className="mt-6">
                  <DialogClose asChild>
                    <Button variant="outline" className="mr-2">
                      Cancel
                    </Button>
                  </DialogClose>
                  <Button>
                    Book Now
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}