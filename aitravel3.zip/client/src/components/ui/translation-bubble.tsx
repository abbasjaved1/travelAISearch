import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select';
import { Card } from './card';
import { Globe2, X, Languages } from 'lucide-react';
import { Button } from './button';
import { aiService } from '@/lib/ai-service';

interface Position {
  x: number;
  y: number;
}

const languages = [
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'it', name: 'Italian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'zh', name: 'Chinese' },
];

export function TranslationBubble() {
  const [isVisible, setIsVisible] = useState(false);
  const [position, setPosition] = useState<Position>({ x: 0, y: 0 });
  const [selectedText, setSelectedText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [targetLanguage, setTargetLanguage] = useState('es');
  const [isLoading, setIsLoading] = useState(false);

  const handleTextSelection = useCallback(() => {
    const selection = window.getSelection();
    const text = selection?.toString().trim();

    if (text && text.length > 0) {
      const range = selection?.getRangeAt(0);
      const rect = range?.getBoundingClientRect();

      if (rect) {
        setSelectedText(text);
        setPosition({
          x: rect.left + window.scrollX + (rect.width / 2),
          y: rect.bottom + window.scrollY
        });
        setIsVisible(true);
      }
    } else {
      setIsVisible(false);
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mouseup', handleTextSelection);
    return () => {
      document.removeEventListener('mouseup', handleTextSelection);
    };
  }, [handleTextSelection]);

  const handleTranslate = async () => {
    if (!selectedText) return;

    setIsLoading(true);
    try {
      const translation = await aiService.translateText(selectedText, targetLanguage);
      setTranslatedText(translation);
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: -10 }}
          className="fixed z-50"
          style={{
            left: `${position.x}px`,
            top: `${position.y + 10}px`,
            transform: 'translate(-50%, 0)'
          }}
        >
          <Card className="p-4 shadow-lg min-w-[300px]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-primary" />
                <span className="font-medium">Translate to:</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => setIsVisible(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <Select
              value={targetLanguage}
              onValueChange={setTargetLanguage}
            >
              <SelectTrigger className="w-full mb-4">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="text-sm mb-2">
              <div className="text-muted-foreground mb-2">Selected text:</div>
              <div className="p-2 bg-muted rounded-md">{selectedText}</div>
            </div>

            {translatedText && (
              <div className="text-sm mt-4">
                <div className="text-muted-foreground mb-2">Translation:</div>
                <div className="p-2 bg-primary/10 rounded-md">{translatedText}</div>
              </div>
            )}

            <Button
              className="w-full mt-4"
              onClick={handleTranslate}
              disabled={isLoading}
            >
              {isLoading ? (
                <Languages className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Languages className="w-4 h-4 mr-2" />
              )}
              Translate
            </Button>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}