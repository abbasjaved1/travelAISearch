import { useState } from "react";
import { motion } from "framer-motion";
import { Plane, Hotel, Car, UtensilsCrossed, Sun, Map, Briefcase, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";
import { useLocation } from "wouter";

export function LoginSplash({ onDismiss }: { onDismiss: () => void }) {
  const [, setLocation] = useLocation();
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-gradient-to-br from-[#003580] via-[#004d99] to-[#006CE4] flex flex-col items-center justify-center z-50"
    >
      <div className="absolute top-8 left-8">
        <Logo size="lg" className="text-white" />
      </div>
      
      <div className="text-center space-y-12 max-w-4xl px-4">
        <motion.div 
          className="flex items-center justify-center gap-8 flex-wrap"
          variants={{
            show: {
              transition: {
                staggerChildren: 0.1
              }
            }
          }}
          initial="hidden"
          animate="show"
        >
          {[
            { icon: Plane, name: "Flights", rotate: -45, gradient: "from-[#FF6B6B] via-[#4ECDC4] to-[#FF6B6B]", image: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&q=80&w=200" },
            { icon: Hotel, name: "Hotels", rotate: 0, gradient: "from-[#A8E6CF] via-[#DCEDC1] to-[#A8E6CF]", image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=200" },
            { icon: Car, name: "Rides", rotate: 0, gradient: "from-[#FFD93D] via-[#FF6B6B] to-[#FFD93D]", image: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&q=80&w=200" },
            { icon: UtensilsCrossed, name: "Dining", rotate: 0, gradient: "from-[#6C5B7B] via-[#C06C84] to-[#6C5B7B]", image: "https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&q=80&w=200" },
          ].map((Item, index) => (
            <motion.div
              key={index}
              className="relative group"
              variants={{
                hidden: { y: 50, opacity: 0 },
                show: { y: 0, opacity: 1 }
              }}
              transition={{ duration: 0.5 }}
            >
              <motion.div 
                className={`absolute -inset-1 bg-gradient-to-r ${Item.gradient} rounded-full blur opacity-75`}
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5],
                  rotate: [0, 180, 360]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: index * 0.2
                }}
              />
              <motion.div 
                className="relative rounded-lg overflow-hidden group-hover:scale-105 transition-transform duration-300"
                whileHover={{ scale: 1.1 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <div className="relative w-24 h-24 md:w-32 md:h-32">
                  <img
                    src={Item.image}
                    alt={Item.name}
                    className="absolute inset-0 w-full h-full object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col items-center justify-end p-2">
                    <Item.icon className="w-8 h-8 text-white mb-1" />
                    <span className="text-white text-sm font-medium">{Item.name}</span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-6"
        >
          <motion.h1 
            className="text-3xl md:text-5xl font-bold text-white px-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            Welcome to TravelAI
          </motion.h1>
          <motion.p 
            className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto leading-relaxed px-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
          >
            Experience the future of travel with AI-powered personalization
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mt-8 px-6"
          >
            <Button 
              size="lg"
              onClick={() => {
                onDismiss();
                setLocation("/auth");
              }}
              className="bg-white text-[#003580] hover:bg-white/90 text-lg font-semibold px-8 py-6 h-auto shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02]"
            >
              Sign In / Register
            </Button>
            <Button 
              size="lg"
              variant="outline"
              onClick={() => {
                onDismiss();
                setLocation("/destinations/explore");
              }}
              className="border-2 border-white text-white hover:bg-white/20 text-lg font-semibold px-8 py-6 h-auto shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02]"
            >
              Explore as Guest
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}