import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "./button";
import {
  MessageSquare,
  X,
  Globe,
  Map,
  Send,
  Loader2,
  Bot
} from "lucide-react";
import { Card } from "./card";
import { ScrollArea } from "./scroll-area";
import { Input } from "./input";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { apiRequest } from '@/lib/api';
import { VoiceAssistant } from './voice-assistant';
import { ErrorBoundary } from "./error-boundary";

type Message = {
  role: "user" | "assistant";
  content: string;
  type?: "general" | "cultural" | "recommendation" | "translation";
  culturalContext?: {
    significance?: string;
    customs?: string[];
    etiquette?: string[];
    localTips?: string[];
  };
};

export function FloatingChat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<Message[]>([]);
  const [currentLocation, setCurrentLocation] = useState<string>("");
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const speak = useCallback((text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  }, []);

  const { isPending: isSending, mutate: sendMessage } = useMutation({
    mutationFn: async (content: string) => {
      if (!user) {
        throw new Error("Please log in to use the chat feature");
      }

      if (!content.trim()) {
        throw new Error("Message cannot be empty");
      }

      const response = await apiRequest('POST', '/api/chatbot', {
        message: content,
        currentLocation,
        chatHistory: chatHistory.map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      });

      if (!response.ok) {
        throw new Error('Failed to get response from chatbot');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setChatHistory(prev => [
        ...prev,
        {
          role: "assistant",
          content: data.message,
          type: data.type,
          culturalContext: data.culturalContext
        }
      ]);
      speak(data.message);
    },
    onError: (error: Error) => {
      console.error('Chat error:', error);
      toast({
        title: "Chat Error",
        description: error.message,
        variant: "destructive"
      });
      setChatHistory(prev => [
        ...prev,
        {
          role: "assistant",
          content: "I apologize, but I encountered an error. Please try again.",
          type: "general"
        }
      ]);
    }
  });

  const handleSend = () => {
    if (!message.trim()) return;

    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to use the chat feature",
        variant: "destructive"
      });
      return;
    }

    setChatHistory(prev => [...prev, { role: "user", content: message }]);
    sendMessage(message);
    setMessage("");
  };

  const handleVoiceMessage = (message: string) => {
    if (message.trim()) {
      setChatHistory(prev => [...prev, { role: "user", content: message }]);
      sendMessage(message);
    }
  };

  return (
    <ErrorBoundary>
      <div className="fixed bottom-4 right-4 z-50">
        <AnimatePresence>
          {isOpen ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="w-[95vw] h-[80vh] sm:w-[400px] sm:h-[600px]"
            >
              <Card className="w-full h-full flex flex-col">
                <div className="flex items-center justify-between p-3 sm:p-4 border-b">
                  <div className="flex items-center gap-2">
                    <Bot className="w-4 h-4" />
                    <span className="font-medium">AI Travel Assistant</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsOpen(false)}
                    className="touch-manipulation"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                <div className="p-3 sm:p-4 border-b">
                  <VoiceAssistant
                    onMessage={handleVoiceMessage}
                    isProcessing={isSending}
                    isSpeaking={isSpeaking}
                  />
                  <div className="flex items-center gap-2 mt-4">
                    <Map className="w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Set your current location (optional)"
                      value={currentLocation}
                      onChange={(e) => setCurrentLocation(e.target.value)}
                      className="flex-1 text-base sm:text-sm"
                    />
                  </div>
                </div>

                <ScrollArea className="flex-1 p-3 sm:p-4" ref={chatContainerRef}>
                  <div className="space-y-4">
                    {chatHistory.map((msg, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2 }}
                        className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`rounded-lg px-4 py-3 max-w-[85%] touch-manipulation ${
                            msg.role === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          }`}
                        >
                          <div className="text-base sm:text-sm whitespace-pre-wrap">{msg.content}</div>
                          {msg.culturalContext && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="mt-3 text-sm bg-background/10 rounded-lg p-3"
                            >
                              <div className="flex items-center gap-2 mb-2">
                                <Globe className="w-4 h-4" />
                                <span className="font-medium">Cultural Insights</span>
                              </div>
                              {msg.culturalContext.significance && (
                                <p className="mb-2 text-base sm:text-sm">{msg.culturalContext.significance}</p>
                              )}
                              {msg.culturalContext.customs && msg.culturalContext.customs.length > 0 && (
                                <ul className="list-disc list-inside space-y-1 text-base sm:text-sm">
                                  {msg.culturalContext.customs.map((custom, idx) => (
                                    <li key={idx}>{custom}</li>
                                  ))}
                                </ul>
                              )}
                            </motion.div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </ScrollArea>

                <div className="p-3 sm:p-4 border-t">
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSend();
                    }}
                    className="flex gap-2"
                  >
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Ask anything about your destination..."
                      className="flex-1 text-base sm:text-sm"
                    />
                    <Button
                      type="submit"
                      size="icon"
                      disabled={isSending}
                      className="touch-manipulation h-12 w-12 sm:h-10 sm:w-10"
                    >
                      {isSending ? (
                        <Loader2 className="h-5 w-5 sm:h-4 sm:w-4 animate-spin" />
                      ) : (
                        <Send className="h-5 w-5 sm:h-4 sm:w-4" />
                      )}
                    </Button>
                  </form>
                </div>
              </Card>
            </motion.div>
          ) : (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
            >
              <Button
                size="lg"
                className="h-14 w-14 sm:h-12 sm:w-12 rounded-full shadow-lg touch-manipulation"
                onClick={() => setIsOpen(true)}
              >
                <MessageSquare className="h-7 w-7 sm:h-6 sm:w-6" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </ErrorBoundary>
  );
}