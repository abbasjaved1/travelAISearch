import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { ForgotPassword } from "@/components/ui/forgot-password";

export function AuthForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isGuestLoading, setIsGuestLoading] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/login", {
        username,
        password,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to login");
      }

      toast({
        title: "Success",
        description: "Logged in successfully",
      });
      setLocation("/");
    } catch (error: any) {
      console.error('Login error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to login",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestLogin = async () => {
    if (isGuestLoading) return;
    setIsGuestLoading(true);
    let currentError: Error | null = null;

    try {
      console.log('Attempting guest login...');
      const response = await apiRequest("POST", "/api/guest-login");
      console.log('Guest login response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to login as guest");
      }

      const data = await response.json();
      console.log('Guest login successful:', data);

      if (!data.isGuest) {
        throw new Error("Failed to create guest session");
      }

      // Double check the session is established
      const sessionCheck = await apiRequest("GET", "/api/session");
      const sessionData = await sessionCheck.json();

      if (sessionData.authenticated) {
        toast({
          title: "Welcome!",
          description: "You're now logged in as a guest user",
        });
        setLocation("/");
      } else {
        // If session check fails, retry guest login
        if (retryCount < 2) {
          setRetryCount(prev => prev + 1);
          currentError = new Error("Session validation failed, retrying...");
          throw currentError;
        } else {
          throw new Error("Unable to establish guest session after multiple attempts");
        }
      }
    } catch (error: any) {
      console.error('Guest login error:', error);
      currentError = error;

      if (error.message.includes("retrying")) {
        // Wait briefly and retry
        await new Promise(resolve => setTimeout(resolve, 1000));
        handleGuestLogin();
        return;
      }

      toast({
        title: "Error",
        description: error.message || "Failed to login as guest",
        variant: "destructive",
      });
    } finally {
      if (!currentError?.message?.includes("retrying")) {
        setIsGuestLoading(false);
        setRetryCount(0);
      }
    }
  };

  const handleForgotPasswordClick = () => {
    setShowForgotPassword(true);
  };

  const handleCancelForgotPassword = () => {
    setShowForgotPassword(false);
  };

  const handlePasswordResetComplete = () => {
    setShowForgotPassword(false);
    toast({
      title: "Success",
      description: "Your password has been reset successfully. You can now log in with your new password.",
    });
  };

  useEffect(() => {
    // Reset retry count when component mounts
    setRetryCount(0);
  }, []);

  if (showForgotPassword) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Reset Password</CardTitle>
        </CardHeader>
        <CardContent>
          <ForgotPassword 
            onCancel={handleCancelForgotPassword} 
            onComplete={handlePasswordResetComplete}
          />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Login</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
            />
          </div>
          <div className="space-y-4">
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : "Login"}
            </Button>
            
            <div className="flex justify-center w-full">
              <Button 
                variant="link"
                className="text-blue-600 hover:text-blue-800 hover:underline font-medium"
                onClick={handleForgotPasswordClick}
                type="button"
              >
                Forgot your password?
              </Button>
            </div>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  Or
                </span>
              </div>
            </div>
            
            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={handleGuestLogin}
              disabled={isGuestLoading}
            >
              {isGuestLoading ? "Creating guest session..." : "Continue as Guest"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}