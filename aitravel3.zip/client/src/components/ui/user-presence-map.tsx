import { useState, useEffect, useCallback, useRef } from 'react';
import { Card } from "./card";
import { MapPin, Users, Globe, AlertCircle, RefreshCw, MapPinOff } from 'lucide-react';
import type { OnlineUser } from '@shared/schema';
import { getLocationName as fetchLocationName } from '@/services/locationService';
import { Button } from './button';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from './skeleton';
import { socket, updateLocation } from '@/lib/socket';

interface UserPresenceMapProps {
  onlineUsers: OnlineUser[];
}

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return Math.round(R * c);
};

export function UserPresenceMap({ onlineUsers }: UserPresenceMapProps) {
  const [selectedUser, setSelectedUser] = useState<OnlineUser | null>(null);
  const [locationNames, setLocationNames] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [locationLoadAttempted, setLocationLoadAttempted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shareLocation, setShareLocation] = useState(false);
  const locationWatchId = useRef<number | null>(null);
  const initialLoadRef = useRef<boolean>(true);
  const { toast } = useToast();
  
  // Filter only users with location data
  const usersWithLocation = onlineUsers.filter(user => user.location);
  
  // Set initial loading state on first render
  useEffect(() => {
    if (initialLoadRef.current && usersWithLocation.length > 0) {
      setIsLoading(true);
      initialLoadRef.current = false;
    }
  }, [usersWithLocation]);
  
  // Handle starting/stopping location sharing
  const toggleLocationSharing = useCallback(() => {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      toast({
        title: "Not logged in",
        description: "You need to be logged in to share your location",
        variant: "destructive"
      });
      return;
    }
    
    if (shareLocation) {
      // Stop sharing location
      if (locationWatchId.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(locationWatchId.current);
        locationWatchId.current = null;
      }
      setShareLocation(false);
      toast({
        title: "Location sharing stopped",
        description: "Your location is no longer being shared with other travelers"
      });
    } else {
      // Start sharing location
      if (navigator.geolocation) {
        try {
          locationWatchId.current = navigator.geolocation.watchPosition(
            (position) => {
              const location = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
              };
              
              // Send location update via socket
              const parsedUserId = parseInt(userId, 10);
              updateLocation(parsedUserId, location);
              
              setShareLocation(true);
            },
            (error) => {
              console.error('Geolocation error:', error);
              setError(`Location error: ${error.message}`);
              setShareLocation(false);
            },
            { 
              enableHighAccuracy: true, 
              timeout: 10000,
              maximumAge: 60000 // 1 minute
            }
          );
          
          toast({
            title: "Location sharing started",
            description: "Your location is now visible to other travelers"
          });
        } catch (err) {
          console.error('Error starting location watch:', err);
          setError('Failed to access location services');
        }
      } else {
        setError('Geolocation is not supported by your browser');
      }
    }
  }, [shareLocation, toast]);

  // Cleanup location watch when component unmounts
  useEffect(() => {
    return () => {
      if (locationWatchId.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(locationWatchId.current);
        console.log('Cleaned up location watch on unmount');
      }
    };
  }, []);
  
  // Fetch location names for each user more efficiently
  useEffect(() => {
    async function fetchLocationNames() {
      if (usersWithLocation.length === 0) {
        setLocationLoadAttempted(true);
        return;
      }
      
      setIsLoading(true);
      setError(null);
      
      // First - show what we already have in cache immediately
      const newLocationNames: Record<string, string> = {};
      const pendingUsers: { user: OnlineUser, key: string }[] = [];
      
      // Identify which locations need fetching
      usersWithLocation.forEach(user => {
        if (!user.location) return;
        
        const key = `${user.location.lat},${user.location.lng}`;
        if (locationNames[key]) return; // Skip if we already have this location name
        
        // Add placeholder while loading
        newLocationNames[key] = 'Loading...';
        pendingUsers.push({ user, key });
      });
      
      // Update immediately with placeholders to show users faster
      if (Object.keys(newLocationNames).length > 0) {
        setLocationNames(prev => ({ ...prev, ...newLocationNames }));
      }
      
      // If no pending users, we're done
      if (pendingUsers.length === 0) {
        setLocationLoadAttempted(true);
        setIsLoading(false);
        return;
      }
      
      // Process in small batches to avoid overwhelming the APIs
      const batchSize = 3;
      const batches = [];
      
      for (let i = 0; i < pendingUsers.length; i += batchSize) {
        batches.push(pendingUsers.slice(i, i + batchSize));
      }
      
      try {
        // Process each batch sequentially
        for (const batch of batches) {
          const batchPromises = batch.map(async ({ user, key }) => {
            if (!user.location) return;
            
            try {
              const name = await fetchLocationName(user.location.lat, user.location.lng);
              // Update immediately as each location resolves
              setLocationNames(prev => ({
                ...prev,
                [key]: name
              }));
              return { key, name };
            } catch (err) {
              console.error('Error fetching location name:', err);
              setLocationNames(prev => ({
                ...prev,
                [key]: 'Unknown Location'
              }));
              return { key, name: 'Unknown Location' };
            }
          });
          
          await Promise.all(batchPromises);
        }
      } catch (err) {
        console.error('Error in location names batch:', err);
        // Don't set error as we'll have placeholders at least
      } finally {
        setLocationLoadAttempted(true);
        setIsLoading(false);
      }
    }
    
    fetchLocationNames();
  }, [usersWithLocation]);
  
  // Get location name helper function
  const getLocationName = (lat: number, lng: number): string => {
    const key = `${lat},${lng}`;
    return locationNames[key] || 'Loading location...';
  };

  const handleRefresh = () => {
    // This doesn't really refresh server data but can be used to retry location name fetching
    setLocationLoadAttempted(false);
    setLocationNames({});
    
    toast({
      title: "Refreshing traveler data",
      description: "Attempting to get the latest traveler information...",
    });
  };

  // Display message when loading is done but no users were found
  const showEmptyState = locationLoadAttempted && usersWithLocation.length === 0;

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Globe className="w-5 h-5" />
          Travelers Map
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {usersWithLocation.length} travelers online
          </span>
          <Button 
            variant={shareLocation ? "destructive" : "outline"}
            size="sm"
            className="h-7 text-xs"
            onClick={toggleLocationSharing}
          >
            {shareLocation ? (
              <>
                <MapPinOff className="w-3 h-3 mr-1" />
                Stop sharing
              </>
            ) : (
              <>
                <MapPin className="w-3 h-3 mr-1" />
                Share location
              </>
            )}
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1 h-7 w-7" 
            onClick={handleRefresh} 
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-50 rounded-md mb-4 flex items-center gap-2 text-red-600">
          <AlertCircle className="w-4 h-4" />
          <span className="text-sm">{error}</span>
        </div>
      )}

      {isLoading && !locationLoadAttempted && (
        <div className="space-y-3 mb-4">
          <Skeleton className="h-20 w-full rounded-md" />
          <Skeleton className="h-20 w-full rounded-md" />
          <div className="flex justify-center items-center mt-4">
            <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full"></div>
            <span className="ml-2 text-sm text-muted-foreground">Loading traveler locations...</span>
          </div>
        </div>
      )}

      {showEmptyState ? (
        <div className="text-center py-8 text-muted-foreground">
          <Globe className="w-10 h-10 mx-auto mb-2 opacity-20" />
          <p>No travelers with location data currently online.</p>
          <div className="mt-4">
            <Button 
              onClick={toggleLocationSharing} 
              variant="outline" 
              size="sm" 
              className={shareLocation ? "bg-red-50" : ""}
            >
              {shareLocation ? (
                <>
                  <MapPinOff className="w-4 h-4 mr-2" />
                  Stop sharing your location
                </>
              ) : (
                <>
                  <MapPin className="w-4 h-4 mr-2" />
                  Share your location
                </>
              )}
            </Button>
            <p className="text-sm mt-3">
              {shareLocation 
                ? "You're sharing your location. Others can see you on the map!" 
                : "Be the first traveler on the map! Share your location to connect with others."}
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          {usersWithLocation.map((user) => (
            <Card
              key={user.id}
              className={`p-4 cursor-pointer transition-colors hover:shadow-md ${
                selectedUser?.id === user.id ? 'bg-primary/5 border-primary/30' : ''
              }`}
              onClick={() => setSelectedUser(prev => prev?.id === user.id ? null : user)}
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
                  {user.username[0].toUpperCase()}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <h4 className="font-medium">{user.username}</h4>
                    <div className="flex items-center gap-1 text-xs bg-green-100 px-2 py-0.5 rounded-full text-green-800">
                      <span className="w-2 h-2 rounded-full bg-green-500"></span>
                      <span>Online</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                    <MapPin className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">
                      {user.location ? getLocationName(user.location.lat, user.location.lng) : 'Location unknown'}
                    </span>
                  </p>
                  {selectedUser?.id === user.id && user.location && (
                    <div className="mt-3 p-2 bg-slate-50 rounded-md text-sm">
                      <p className="font-medium mb-1 text-slate-700">Distance to other travelers:</p>
                      {(() => {
                        // Get other users with location info
                        const othersWithLocation = usersWithLocation.filter(
                          (other) => other.id !== user.id && other.location
                        );
                        
                        if (othersWithLocation.length === 0) {
                          return (
                            <p className="text-muted-foreground text-xs italic">
                              No other travelers to compare distance
                            </p>
                          );
                        }
                        
                        // Calculate distances only once
                        const distanceData = othersWithLocation.map(other => ({
                          user: other,
                          distance: calculateDistance(
                            user.location!.lat,
                            user.location!.lng,
                            other.location!.lat,
                            other.location!.lng
                          )
                        }))
                        // Sort by distance (closest first)
                        .sort((a, b) => a.distance - b.distance);
                        
                        return (
                          <div className="space-y-1 max-h-28 overflow-y-auto">
                            {distanceData.map(({ user: other, distance }) => (
                              <p key={other.id} className="text-muted-foreground text-xs flex justify-between">
                                <span className="font-medium">{other.username}:</span>
                                <span>{distance} km</span>
                              </p>
                            ))}
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {isLoading && locationLoadAttempted && (
        <div className="flex justify-center items-center my-2">
          <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full"></div>
          <span className="ml-2 text-sm text-muted-foreground">Loading additional location data...</span>
        </div>
      )}
    </div>
  );
}