import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./card";
import { ScrollArea } from "./scroll-area";
import { Badge } from "./badge";
import { Button } from "./button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./tabs";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Legend, 
  Tooltip, 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid 
} from "recharts";
import { 
  Wallet, 
  Ticket, 
  Bus, 
  Hotel, 
  Coffee, 
  Info, 
  Utensils, 
  Plane, 
  ShoppingBag,
  CreditCard,
  Clock,
  CalendarDays,
  MapPin,
  TrendingDown,
  TrendingUp,
  Download,
  Share2,
  AlertTriangle,
  Car,
  ExternalLink,
  Receipt
} from "lucide-react";
import { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";
import { useQuery } from "@tanstack/react-query";
import { getUserExpenses, getExpensesByTimeframe, getExpenseAnalytics } from "@/lib/expense-service";
import { Expense } from "@shared/schema";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface Activity {
  title: string;
  cost: number;
  ticketing: {
    price: number;
    ticketTypes?: Array<{
      name: string;
      price: number;
    }>;
    location?: string;
    gateNumber?: string;
    timeRequired?: number; // in minutes
  };
  transportation: {
    cost: number;
    type: string;
    departureGate?: string;
    arrivalGate?: string;
  };
  timeDetails?: {
    startTime: string;
    endTime: string;
    duration: number; // in minutes
  };
}

interface DayPlan {
  day: number;
  date: string;
  activities: Activity[];
  summary: {
    totalCost: number;
  };
}

interface TripPlan {
  id?: string;
  destination?: string;
  startDate?: string;
  endDate?: string;
  schedule: DayPlan[];
  expenses?: Expense[];
  budget: {
    total: number;
    remaining?: number;
    spent?: number;
    breakdown: {
      accommodation: number;
      activities: number;
      transportation: number;
      food: number;
      other: number;
    };
  };
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];
const CATEGORY_ICONS = {
  accommodation: <Hotel className="h-4 w-4" />,
  transportation: <Plane className="h-4 w-4" />,
  food: <Utensils className="h-4 w-4" />,
  activities: <Ticket className="h-4 w-4" />,
  other: <ShoppingBag className="h-4 w-4" />
};

export function TripFinancialReport({ plan }: { plan: TripPlan }) {
  const [timeframe, setTimeframe] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [expenseView, setExpenseView] = useState<'all' | 'recent' | 'byCategory'>('all');
  
  // Fetch user expenses and analytics from enhanced endpoint
  const { data: expenseData, isLoading: expensesLoading } = useQuery({
    queryKey: ['/api/expenses/analytics', timeframe],
    queryFn: async () => {
      return await getExpenseAnalytics(undefined, undefined, timeframe);
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Show loading state while fetching expenses
  if (expensesLoading) {
    return (
      <Card>
        <CardContent className="p-6 flex flex-col items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
          <p>Loading expense data...</p>
        </CardContent>
      </Card>
    );
  }
  
  if (!plan || !plan.schedule) {
    return (
      <Card>
        <CardContent className="p-4">
          <p>No financial data available</p>
        </CardContent>
      </Card>
    );
  }

  // Get expenses and analytics data
  const bookingExpenses = expenseData?.expenses || [];
  const analytics = expenseData?.analytics;
  
  // Combine booking expenses, trip plan expenses, and activities
  const allExpenses: Expense[] = [...bookingExpenses];
  
  // Add existing expenses from the plan
  if (plan.expenses && plan.expenses.length > 0) {
    // Filter out any duplicates by id
    const existingIds = new Set(allExpenses.map(e => e.id));
    plan.expenses.forEach(expense => {
      if (!existingIds.has(expense.id)) {
        allExpenses.push(expense);
        existingIds.add(expense.id);
      }
    });
  }
  
  // Add activities as expenses for complete reporting
  plan.schedule.forEach(day => {
    day.activities.forEach(activity => {
      if (!allExpenses.some(e => e.title === activity.title)) {
        allExpenses.push({
          id: `activity-${Math.random().toString(36).substring(2, 9)}`,
          title: activity.title,
          category: 'activities',
          amount: activity.cost,
          date: day.date,
          location: activity.ticketing.location || 'Unknown',
          paymentMethod: 'Credit Card',
          status: 'completed'
        });
      }
    });
  });

  const pieData = [
    { name: 'Accommodation', value: plan.budget.breakdown.accommodation },
    { name: 'Activities', value: plan.budget.breakdown.activities },
    { name: 'Transportation', value: plan.budget.breakdown.transportation },
    { name: 'Food', value: plan.budget.breakdown.food },
    { name: 'Other', value: plan.budget.breakdown.other }
  ];

  const totalSpent = plan.budget.spent || allExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const remainingBudget = plan.budget.total - totalSpent;
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  // Use server provided analytics data if available, or generate it locally
  const getExpensesOverTime = () => {
    // If analytics data is available from the server, use it
    if (analytics?.timeframeSummary && analytics.timeframeSummary.length > 0) {
      return analytics.timeframeSummary;
    }
    
    // Otherwise, calculate locally
    const sortedExpenses = [...allExpenses].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    if (timeframe === 'daily') {
      // Group by day
      const dailyData: {[key: string]: number} = {};
      sortedExpenses.forEach(expense => {
        const date = new Date(expense.date).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + expense.amount;
      });
      
      return Object.entries(dailyData).map(([date, value]) => ({ date, amount: value }));
    } else if (timeframe === 'weekly') {
      // Group by week
      const weeklyData: {[key: string]: number} = {};
      sortedExpenses.forEach(expense => {
        const date = new Date(expense.date);
        const weekNumber = getWeekNumber(date);
        const weekLabel = `Week ${weekNumber}`;
        weeklyData[weekLabel] = (weeklyData[weekLabel] || 0) + expense.amount;
      });
      
      return Object.entries(weeklyData).map(([week, value]) => ({ date: week, amount: value }));
    } else {
      // Group by month
      const monthlyData: {[key: string]: number} = {};
      sortedExpenses.forEach(expense => {
        const date = new Date(expense.date);
        const monthLabel = date.toLocaleString('default', { month: 'short' });
        monthlyData[monthLabel] = (monthlyData[monthLabel] || 0) + expense.amount;
      });
      
      return Object.entries(monthlyData).map(([month, value]) => ({ date: month, amount: value }));
    }
  };

  // Get week number from date
  const getWeekNumber = (d: Date) => {
    const date = new Date(d.getTime());
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
    const week1 = new Date(date.getFullYear(), 0, 4);
    return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
  };

  // Group expenses by category - use server data if available
  const getExpensesByCategory = () => {
    // If category summary is available from the server, use it
    if (analytics?.categorySummary) {
      return Object.entries(analytics.categorySummary).map(([category, amount]) => ({
        category: category.charAt(0).toUpperCase() + category.slice(1),
        amount
      }));
    }
    
    // Otherwise, calculate locally
    const categories: {[key: string]: number} = {
      accommodation: 0,
      transportation: 0,
      food: 0,
      activities: 0,
      other: 0
    };
    
    allExpenses.forEach(expense => {
      categories[expense.category] += expense.amount;
    });
    
    return Object.entries(categories).map(([category, amount]) => ({
      category: category.charAt(0).toUpperCase() + category.slice(1),
      amount
    }));
  };

  // Calculate average daily spending
  const averageDailySpend = () => {
    if (plan.startDate && plan.endDate) {
      const start = new Date(plan.startDate);
      const end = new Date(plan.endDate);
      const tripDays = Math.max(1, (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
      return totalSpent / tripDays;
    }
    
    // Fallback to using schedule length
    return totalSpent / Math.max(1, plan.schedule.length);
  };

  // Get list of expense categories with their totals
  const getCategorySummary = () => {
    const categories = {
      accommodation: 0,
      transportation: 0,
      food: 0,
      activities: 0,
      other: 0
    };
    
    allExpenses.forEach(expense => {
      categories[expense.category] += expense.amount;
    });
    
    return Object.entries(categories).map(([category, total]) => ({ 
      category,
      categoryName: category.charAt(0).toUpperCase() + category.slice(1),
      total,
      icon: CATEGORY_ICONS[category as keyof typeof CATEGORY_ICONS]
    }));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="h-5 w-5" />
                Travel Expense Report
              </CardTitle>
              {plan.destination && (
                <CardDescription className="flex items-center mt-1">
                  <MapPin className="h-3 w-3 mr-1" />
                  {plan.destination}
                  {plan.startDate && plan.endDate && (
                    <span className="ml-2 flex items-center">
                      <CalendarDays className="h-3 w-3 mr-1" />
                      {new Date(plan.startDate).toLocaleDateString()} - {new Date(plan.endDate).toLocaleDateString()}
                    </span>
                  )}
                </CardDescription>
              )}
            </div>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => {
                  // PDF export - create detailed expense report
                  const doc = new jsPDF();
                  
                  // Add title and basic info
                  doc.setFontSize(20);
                  doc.text('Travel Expense Report', 14, 20);
                  
                  doc.setFontSize(12);
                  if (plan.destination) {
                    doc.text(`Destination: ${plan.destination}`, 14, 30);
                  }
                  
                  if (plan.startDate && plan.endDate) {
                    doc.text(`Date: ${new Date(plan.startDate).toLocaleDateString()} - ${new Date(plan.endDate).toLocaleDateString()}`, 14, 36);
                  }
                  
                  // Add budget summary
                  doc.setFontSize(14);
                  doc.text('Budget Summary', 14, 46);
                  doc.setFontSize(10);
                  doc.text(`Total Budget: ${formatCurrency(plan.budget.total)}`, 14, 54);
                  doc.text(`Total Spent: ${formatCurrency(totalSpent)}`, 14, 60);
                  doc.text(`Remaining Budget: ${formatCurrency(remainingBudget)}`, 14, 66);
                  doc.text(`Budget Status: ${remainingBudget >= 0 ? 'Under Budget' : 'Over Budget'}`, 14, 72);
                  
                  // Add expense breakdown by category
                  doc.setFontSize(14);
                  doc.text('Expense Breakdown by Category', 14, 82);
                  
                  const categoryData = getCategorySummary().map(cat => [
                    cat.categoryName,
                    formatCurrency(cat.total),
                    Math.round((cat.total / totalSpent) * 100) + '%'
                  ]);
                  
                  autoTable(doc, {
                    head: [['Category', 'Amount', 'Percentage']],
                    body: categoryData,
                    startY: 86,
                    theme: 'grid',
                    headStyles: { fillColor: [41, 128, 185] }
                  });
                  
                  // Add expense list
                  doc.addPage();
                  doc.setFontSize(16);
                  doc.text('Detailed Expense List', 14, 20);
                  
                  const expenseData = allExpenses.map(expense => [
                    new Date(expense.date).toLocaleDateString(),
                    expense.title,
                    expense.category.charAt(0).toUpperCase() + expense.category.slice(1),
                    formatCurrency(expense.amount),
                    expense.location || '-',
                    expense.paymentMethod || '-'
                  ]);
                  
                  autoTable(doc, {
                    head: [['Date', 'Description', 'Category', 'Amount', 'Location', 'Payment Method']],
                    body: expenseData,
                    startY: 25,
                    theme: 'striped',
                    headStyles: { fillColor: [41, 128, 185] },
                    columnStyles: {
                      3: { halign: 'right' }
                    },
                    didDrawPage: (data) => {
                      // Add footer with page numbers
                      const pageCount = doc.getNumberOfPages();
                      doc.setFontSize(8);
                      for (let i = 1; i <= pageCount; i++) {
                        doc.setPage(i);
                        doc.text(
                          `Page ${i} of ${pageCount} - Generated on ${new Date().toLocaleDateString()}`,
                          data.settings.margin.left,
                          doc.internal.pageSize.height - 10
                        );
                      }
                    }
                  });
                  
                  // Save PDF
                  doc.save(`Travel_Expense_Report_${plan.destination || 'Trip'}_${new Date().toISOString().split('T')[0]}.pdf`);
                  
                  // Also create CSV for data portability
                  const headers = ["Date", "Title", "Category", "Amount", "Payment Method", "Status", "Location"];
                  const csvRows = [headers];
                  
                  // Add expense data
                  allExpenses.forEach(expense => {
                    csvRows.push([
                      new Date(expense.date).toLocaleDateString(),
                      expense.title,
                      expense.category,
                      expense.amount.toString(),
                      expense.paymentMethod,
                      expense.status,
                      expense.location
                    ]);
                  });
                  
                  // Convert to CSV string
                  const csvContent = csvRows.map(row => row.join(",")).join("\n");
                  
                  // Create blob and download link for CSV
                  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement("a");
                  link.setAttribute("href", url);
                  link.setAttribute("download", `trip_expenses_${new Date().toISOString().split('T')[0]}.csv`);
                  link.style.visibility = "hidden";
                  document.body.appendChild(link);
                  // Uncomment to also download CSV
                  // link.click();
                  document.body.removeChild(link);
                }}
              >
                <Download className="h-4 w-4 mr-1" />
                Export
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => {
                  // Generate a PDF report for sharing
                  const doc = new jsPDF();
                  
                  // Create a branded header for the shared report
                  doc.setFillColor(41, 128, 185);
                  doc.rect(0, 0, doc.internal.pageSize.width, 40, 'F');
                  
                  doc.setTextColor(255, 255, 255);
                  doc.setFontSize(18);
                  doc.text('TRIP EXPENSE SUMMARY', 14, 20);
                  
                  doc.setTextColor(255, 255, 255);
                  doc.setFontSize(10);
                  doc.text('Shared via TravelBuddy Finance', 14, 30);
                  
                  // Reset text color
                  doc.setTextColor(0, 0, 0);
                  
                  // Add report details
                  doc.setFontSize(12);
                  if (plan.destination) {
                    doc.text(`Destination: ${plan.destination}`, 14, 50);
                  }
                  
                  if (plan.startDate && plan.endDate) {
                    doc.text(`Trip Dates: ${new Date(plan.startDate).toLocaleDateString()} - ${new Date(plan.endDate).toLocaleDateString()}`, 14, 60);
                  }
                  
                  // Add summary box
                  doc.setDrawColor(200, 200, 200);
                  doc.setFillColor(245, 245, 245);
                  // Use standard rect instead of roundedRect which might not be supported in all jsPDF versions
                  doc.rect(14, 70, 180, 40, 'FD');
                  
                  doc.setFontSize(11);
                  doc.text(`Total Budget: ${formatCurrency(plan.budget.total)}`, 20, 82);
                  doc.text(`Total Spent: ${formatCurrency(totalSpent)}`, 20, 90);
                  doc.text(`Remaining: ${formatCurrency(remainingBudget)}`, 20, 98);
                  
                  const status = remainingBudget >= 0 ? 'Under Budget' : 'Over Budget';
                  doc.setTextColor(remainingBudget >= 0 ? 0 : 255, remainingBudget >= 0 ? 128 : 0, 0);
                  doc.text(`Status: ${status}`, 120, 90);
                  doc.setTextColor(0, 0, 0);
                  
                  // Add expense breakdown by category
                  doc.setFontSize(12);
                  doc.text('Expense Breakdown', 14, 120);
                  
                  // Create a pie chart-like visual in the PDF (simple representation)
                  const categoryData = getCategorySummary();
                  
                  // Add a table of categories
                  const tableData = categoryData.map(cat => [
                    cat.categoryName,
                    formatCurrency(cat.total),
                    `${Math.round((cat.total / totalSpent) * 100)}%`
                  ]);
                  
                  if (autoTable) {
                    autoTable(doc, {
                      head: [['Category', 'Amount', 'Percentage']],
                      body: tableData,
                      startY: 125,
                      theme: 'striped',
                      headStyles: { fillColor: [41, 128, 185] }
                    });
                  }
                  
                  // Add a footer
                  const pageCount = doc.getNumberOfPages();
                  doc.setFontSize(8);
                  doc.text(
                    `This report was generated on ${new Date().toLocaleDateString()} and is for informational purposes only.`,
                    14,
                    doc.internal.pageSize.height - 10
                  );
                  
                  // Generate a summary without the PDF data URL to keep clipboard content manageable
                  const shareMessage = `Check out my travel expenses for ${plan.destination || 'my trip'}!\n\n` +
                    `Total Budget: ${formatCurrency(plan.budget.total)}\n` +
                    `Total Spent: ${formatCurrency(totalSpent)}\n` +
                    `Status: ${remainingBudget >= 0 ? 'Under Budget 🎉' : 'Over Budget 😬'}`;
                  
                  // Copy to clipboard
                  try {
                    navigator.clipboard.writeText(shareMessage);
                    alert("Financial report summary copied to clipboard! You can now paste and share it.");
                  } catch (error) {
                    console.error("Failed to copy report: ", error);
                    alert("Failed to copy report. Please try again.");
                  }
                }}
              >
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Budget Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className={`border-l-4 ${remainingBudget >= 0 ? 'border-l-green-500' : 'border-l-red-500'}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Budget</p>
                      <p className="text-2xl font-bold">{formatCurrency(plan.budget.total)}</p>
                    </div>
                    <span className="bg-primary/10 p-2 rounded-full">
                      <Wallet className="h-5 w-5 text-primary" />
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Spent</p>
                      <p className="text-2xl font-bold">{formatCurrency(totalSpent)}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {Math.round((totalSpent / plan.budget.total) * 100)}% of budget
                      </p>
                    </div>
                    <span className="bg-blue-100 p-2 rounded-full">
                      <CreditCard className="h-5 w-5 text-blue-600" />
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className={`border-l-4 ${remainingBudget >= 0 ? 'border-l-green-500' : 'border-l-red-500'}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Remaining Budget</p>
                      <p className="text-2xl font-bold">{formatCurrency(remainingBudget)}</p>
                      <div className="flex items-center mt-1">
                        {remainingBudget >= 0 ? (
                          <TrendingDown className="h-4 w-4 text-green-500 mr-1" />
                        ) : (
                          <TrendingUp className="h-4 w-4 text-red-500 mr-1" />
                        )}
                        <p className={`text-sm ${remainingBudget >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                          {remainingBudget >= 0 ? 'Under budget' : 'Over budget'}
                        </p>
                      </div>
                    </div>
                    <span className={`p-2 rounded-full ${remainingBudget >= 0 ? 'bg-green-100' : 'bg-red-100'}`}>
                      {remainingBudget >= 0 ? (
                        <TrendingDown className={`h-5 w-5 text-green-600`} />
                      ) : (
                        <AlertTriangle className={`h-5 w-5 text-red-600`} />
                      )}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tabs for different views */}
            <Tabs defaultValue="overview">
              <TabsList className="mb-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                <TabsTrigger value="timeline">Timeline</TabsTrigger>
                <TabsTrigger value="transactions">Transactions</TabsTrigger>
              </TabsList>
              
              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Category Summary */}
                  <div className="col-span-1">
                    <h3 className="text-lg font-semibold mb-3">Expense Categories</h3>
                    <div className="space-y-3">
                      {getCategorySummary().map(cat => (
                        <div key={cat.category} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                              {cat.icon}
                            </div>
                            <span>{cat.categoryName}</span>
                          </div>
                          <span className="font-medium">{formatCurrency(cat.total)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Pie Chart */}
                  <div className="col-span-2">
                    <h3 className="text-lg font-semibold mb-3">Spending Distribution</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, value, percent }) => 
                              `${name}: ${formatCurrency(value)} (${(percent * 100).toFixed(0)}%)`
                            }
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
                
                {/* Daily Average and Per-Person Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-5 w-5 text-primary" />
                        <h3 className="font-semibold">Average Daily Spend</h3>
                      </div>
                      <p className="text-2xl font-bold text-primary">
                        {formatCurrency(averageDailySpend())}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Based on {plan.schedule.length} days of travel
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-4 space-y-2">
                      <div className="flex items-center gap-2">
                        <Info className="h-5 w-5 text-primary" />
                        <h3 className="font-semibold">Budget Tips</h3>
                      </div>
                      <ul className="space-y-1 text-sm text-muted-foreground">
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span>Book tickets online in advance for better rates</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span>Consider purchasing multi-day transport passes</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span>Look for combination tickets for multiple attractions</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span>Track expenses daily to stay within budget</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              {/* Breakdown Tab */}
              <TabsContent value="breakdown" className="space-y-6">
                <div className="flex justify-between mb-4">
                  <h3 className="text-lg font-semibold">Category Breakdown</h3>
                </div>
                
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={getExpensesByCategory()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="category" />
                      <YAxis tickFormatter={(value) => `$${value}`} />
                      <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                      <Bar dataKey="amount" fill="#0088FE" name="Amount" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.keys(CATEGORY_ICONS).map(category => {
                    const categoryExpenses = allExpenses.filter(e => e.category === category);
                    const total = categoryExpenses.reduce((sum, exp) => sum + exp.amount, 0);
                    
                    return (
                      <Card key={category}>
                        <CardHeader className="pb-2">
                          <CardTitle className="flex items-center gap-2 text-base">
                            {CATEGORY_ICONS[category as keyof typeof CATEGORY_ICONS]}
                            {category.charAt(0).toUpperCase() + category.slice(1)}
                            <Badge variant="outline" className="ml-auto">
                              {formatCurrency(total)}
                            </Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {categoryExpenses.length > 0 ? (
                            <ScrollArea className="h-[180px]">
                              <div className="space-y-2">
                                {categoryExpenses.slice(0, 5).map(expense => (
                                  <div key={expense.id} className="flex justify-between items-center p-2 bg-muted/30 rounded-md">
                                    <div>
                                      <p className="font-medium text-sm">{expense.title}</p>
                                      <p className="text-xs text-muted-foreground">
                                        {new Date(expense.date).toLocaleDateString()}
                                      </p>
                                    </div>
                                    <span className="font-medium">{formatCurrency(expense.amount)}</span>
                                  </div>
                                ))}
                                {categoryExpenses.length > 5 && (
                                  <p className="text-sm text-center text-muted-foreground pt-2">
                                    +{categoryExpenses.length - 5} more items
                                  </p>
                                )}
                              </div>
                            </ScrollArea>
                          ) : (
                            <p className="text-sm text-muted-foreground py-4 text-center">
                              No expenses in this category
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>
              
              {/* Timeline Tab */}
              <TabsContent value="timeline" className="space-y-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Spending Timeline</h3>
                  <Select 
                    value={timeframe} 
                    onValueChange={(value) => {
                      // Set timeframe will trigger a new API request due to the dependency in useQuery
                      setTimeframe(value as 'daily' | 'weekly' | 'monthly');
                    }}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Time period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={getExpensesOverTime()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis tickFormatter={(value) => `$${value}`} />
                      <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                      <Line 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="#8884d8" 
                        strokeWidth={2}
                        name="Spending"
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                
                <ScrollArea className="h-[300px]">
                  <div className="space-y-4">
                    {plan.schedule.map((day) => (
                      <Card key={day.day} className="border-l-4 border-l-primary">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base flex justify-between">
                            <span>Day {day.day} - {new Date(day.date).toLocaleDateString()}</span>
                            <Badge variant="outline">{formatCurrency(day.summary.totalCost)}</Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {day.activities.map((activity, index) => (
                            <div key={index} className="border-b last:border-0 pb-2 last:pb-0">
                              <div className="flex justify-between items-start mb-1">
                                <div>
                                  <h4 className="font-medium">{activity.title}</h4>
                                  {activity.timeDetails && (
                                    <div className="flex items-center text-xs text-muted-foreground">
                                      <Clock className="h-3 w-3 mr-1" />
                                      {activity.timeDetails.startTime} - {activity.timeDetails.endTime} 
                                      ({Math.floor(activity.timeDetails.duration / 60)}h {activity.timeDetails.duration % 60}m)
                                    </div>
                                  )}
                                </div>
                                <Badge variant="outline">{formatCurrency(activity.cost)}</Badge>
                              </div>
                              <div className="text-xs text-muted-foreground space-y-1">
                                {activity.ticketing.price > 0 && (
                                  <div className="flex items-center gap-2">
                                    <Ticket className="h-3 w-3" />
                                    <span>
                                      Tickets: {formatCurrency(activity.ticketing.price)}
                                      {activity.ticketing.gateNumber && (
                                        <span className="ml-2">Gate: {activity.ticketing.gateNumber}</span>
                                      )}
                                      {activity.ticketing.timeRequired && (
                                        <span className="ml-2">Time needed: {activity.ticketing.timeRequired}min</span>
                                      )}
                                    </span>
                                  </div>
                                )}
                                {activity.transportation.cost > 0 && (
                                  <div className="flex items-center gap-2">
                                    <Bus className="h-3 w-3" />
                                    <span>
                                      {activity.transportation.type}: {formatCurrency(activity.transportation.cost)}
                                      {activity.transportation.departureGate && (
                                        <span className="ml-2">Departure: {activity.transportation.departureGate}</span>
                                      )}
                                      {activity.transportation.arrivalGate && (
                                        <span className="ml-2">Arrival: {activity.transportation.arrivalGate}</span>
                                      )}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              {/* Transactions Tab */}
              <TabsContent value="transactions" className="space-y-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Transaction History</h3>
                  <div className="flex gap-2">
                    <Select value={expenseView} onValueChange={(value) => setExpenseView(value as any)}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="View" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="recent">Recent</SelectItem>
                        <SelectItem value="byCategory">By Category</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {allExpenses
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .slice(0, expenseView === 'recent' ? 10 : undefined)
                      .map(expense => (
                      <div key={expense.id} className="flex justify-between items-center p-3 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            {/* Use booking-specific icons if available */}
                            {expense.bookingType === 'flight' ? (
                              <Plane className="h-5 w-5" />
                            ) : expense.bookingType === 'hotel' ? (
                              <Hotel className="h-5 w-5" />
                            ) : expense.bookingType === 'ride' ? (
                              <Car className="h-5 w-5" />
                            ) : expense.bookingType === 'dining' ? (
                              <Utensils className="h-5 w-5" />
                            ) : (
                              CATEGORY_ICONS[expense.category]
                            )}
                          </div>
                          <div>
                            <p className="font-medium">
                              {expense.title}
                              {expense.bookingType && (
                                <Badge variant="outline" className="ml-2 text-xs font-normal">
                                  {expense.bookingType}
                                </Badge>
                              )}
                            </p>
                            <div className="flex items-center flex-wrap text-xs text-muted-foreground gap-x-3">
                              <span className="flex items-center">
                                <CalendarDays className="h-3 w-3 mr-1" />
                                {new Date(expense.date).toLocaleDateString()}
                              </span>
                              {expense.location && (
                                <span className="flex items-center">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  {expense.location}
                                </span>
                              )}
                              {expense.status && (
                                <span className={`flex items-center ${
                                  expense.status === 'completed' ? 'text-green-500' : 
                                  expense.status === 'pending' ? 'text-amber-500' : 
                                  'text-red-500'
                                }`}>
                                  •&nbsp;{expense.status}
                                </span>
                              )}
                              {expense.tags && expense.tags.length > 0 && (
                                <span className="flex items-center gap-1 mt-1">
                                  {expense.tags.map(tag => (
                                    <Badge key={tag} variant="secondary" className="text-xs px-1 py-0">
                                      {tag}
                                    </Badge>
                                  ))}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(expense.amount)}</p>
                          <div className="flex items-center justify-end text-xs text-muted-foreground">
                            <CreditCard className="h-3 w-3 mr-1" />
                            {expense.paymentMethod}
                            {expense.receiptUrl && (
                              <Button variant="link" size="sm" className="h-5 px-1 text-xs" asChild>
                                <a href={expense.receiptUrl} target="_blank" rel="noopener noreferrer">
                                  <Receipt className="h-3 w-3 ml-1" />
                                </a>
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {allExpenses.length === 0 && (
                      <div className="p-8 text-center">
                        <div className="mx-auto w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                          <CreditCard className="h-6 w-6 text-muted-foreground" />
                        </div>
                        <h3 className="text-lg font-medium mb-1">No transactions yet</h3>
                        <p className="text-sm text-muted-foreground">
                          Transactions from bookings will appear here
                        </p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
