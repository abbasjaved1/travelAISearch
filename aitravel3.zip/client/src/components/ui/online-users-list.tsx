import { motion, AnimatePresence } from "framer-motion";
import { PresenceIndicator } from "./presence-indicator";
import { Avatar, AvatarFallback } from "./avatar";
import { Card } from "./card";

interface OnlineUser {
  id: string;
  username: string;
  status: 'online' | 'away' | 'offline';
}

interface OnlineUsersListProps {
  users: OnlineUser[];
}

export function OnlineUsersList({ users }: OnlineUsersListProps) {
  return (
    <Card className="p-4 space-y-2">
      <h3 className="font-semibold text-sm mb-4">Online Users</h3>
      <AnimatePresence mode="popLayout">
        {users.map((user) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.2 }}
            className="flex items-center space-x-3 py-2"
          >
            <div className="relative">
              <Avatar className="h-8 w-8">
                <AvatarFallback>
                  {user.username.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <PresenceIndicator
                status={user.status}
                size="sm"
                className="absolute bottom-0 right-0 transform translate-x-1/4"
              />
            </div>
            <span className="text-sm font-medium">{user.username}</span>
          </motion.div>
        ))}
      </AnimatePresence>
      {users.length === 0 && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          className="text-sm text-muted-foreground text-center py-2"
        >
          No users online
        </motion.p>
      )}
    </Card>
  );
}
