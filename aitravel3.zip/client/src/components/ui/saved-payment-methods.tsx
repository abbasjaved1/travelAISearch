import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "./card";
import { Button } from "./button";
import { Input } from "./input";
import { Label } from "./label";
import { ScrollArea } from "./scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { Switch } from "./switch";
import { Skeleton } from "./skeleton";
import { 
  CreditCard, 
  Wallet, 
  PlusCircle, 
  Trash2, 
  Check, 
  AlertCircle,
  Edit,
  CreditCardIcon
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "./dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "./alert-dialog";

// Define types
interface PaymentMethod {
  id: string;
  type: 'card' | 'bank_account';
  brand?: string;
  last4: string;
  expiryMonth?: number;
  expiryYear?: number;
  isDefault: boolean;
  holderName?: string;
}

export function SavedPaymentMethods() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    number: '',
    name: '',
    expMonth: '',
    expYear: '',
    cvc: ''
  });
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Fetch saved payment methods
  const { data: paymentMethods, isLoading } = useQuery<PaymentMethod[]>({
    queryKey: ['/api/payment/methods'] as const,
    retry: 0
  });

  // Add new payment method
  const addCardMutation = useMutation({
    mutationFn: async (data: typeof cardDetails) => {
      return await apiRequest('POST', '/api/payment/methods', data);
    },
    onSuccess: () => {
      toast({
        title: "Payment method added",
        description: "Your card has been saved successfully",
      });
      resetCardForm();
      queryClient.invalidateQueries({ queryKey: ['/api/payment/methods'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add payment method",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Set default payment method
  const setDefaultMutation = useMutation({
    mutationFn: async (paymentMethodId: string) => {
      setProcessingId(paymentMethodId);
      return await apiRequest('POST', '/api/payment/methods/default', { paymentMethodId });
    },
    onSuccess: () => {
      toast({
        title: "Default payment method updated",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/payment/methods'] });
      setProcessingId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update default payment method",
        description: error.message,
        variant: "destructive"
      });
      setProcessingId(null);
    }
  });

  // Delete payment method
  const deleteMethodMutation = useMutation({
    mutationFn: async (paymentMethodId: string) => {
      setProcessingId(paymentMethodId);
      return await apiRequest('DELETE', `/api/payment/methods/${paymentMethodId}`);
    },
    onSuccess: () => {
      toast({
        title: "Payment method deleted",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/payment/methods'] });
      setProcessingId(null);
      setDeletingId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete payment method",
        description: error.message,
        variant: "destructive"
      });
      setProcessingId(null);
      setDeletingId(null);
    }
  });

  // Reset card form
  const resetCardForm = () => {
    setCardDetails({
      number: '',
      name: '',
      expMonth: '',
      expYear: '',
      cvc: ''
    });
    setIsAddingCard(false);
  };

  // Format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  // Handle card form changes
  const handleCardChange = (field: keyof typeof cardDetails) => (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    
    if (field === 'number') {
      value = formatCardNumber(value);
    } else if (field === 'expMonth' || field === 'expYear') {
      value = value.replace(/[^0-9]/g, '');
    } else if (field === 'cvc') {
      value = value.replace(/[^0-9]/g, '').substring(0, 4);
    }
    
    setCardDetails(prev => ({ ...prev, [field]: value }));
  };

  // Validate form before submission
  const validateCardForm = () => {
    if (cardDetails.number.replace(/\s/g, '').length < 16) {
      toast({
        title: "Invalid card number",
        description: "Please enter a valid card number",
        variant: "destructive"
      });
      return false;
    }
    
    if (!cardDetails.name.trim()) {
      toast({
        title: "Missing cardholder name",
        description: "Please enter the cardholder name",
        variant: "destructive"
      });
      return false;
    }
    
    const month = parseInt(cardDetails.expMonth);
    if (isNaN(month) || month < 1 || month > 12) {
      toast({
        title: "Invalid expiration month",
        description: "Please enter a valid month (1-12)",
        variant: "destructive"
      });
      return false;
    }
    
    const year = parseInt(cardDetails.expYear);
    const currentYear = new Date().getFullYear() % 100;
    if (isNaN(year) || year < currentYear) {
      toast({
        title: "Invalid expiration year",
        description: "Expiration year cannot be in the past",
        variant: "destructive"
      });
      return false;
    }
    
    if (cardDetails.cvc.length < 3) {
      toast({
        title: "Invalid security code",
        description: "Please enter a valid security code",
        variant: "destructive"
      });
      return false;
    }
    
    return true;
  };

  // Handle add card submission
  const handleAddCard = () => {
    if (!validateCardForm()) return;
    
    addCardMutation.mutate(cardDetails);
  };

  // Handle set default payment method
  const handleSetDefault = (id: string) => {
    if (processingId) return; // Prevent multiple operations
    setDefaultMutation.mutate(id);
  };

  // Handle payment method deletion
  const handleDeletePaymentMethod = () => {
    if (!deletingId || processingId) return;
    deleteMethodMutation.mutate(deletingId);
  };

  // Get card brand icon/name
  const getCardBrandInfo = (brand?: string) => {
    if (!brand) return { name: 'Card', icon: <CreditCard className="h-4 w-4" /> };
    
    const brandLower = brand.toLowerCase();
    
    switch (brandLower) {
      case 'visa':
        return { 
          name: 'Visa', 
          icon: <CreditCard className="h-4 w-4 text-blue-600" /> 
        };
      case 'mastercard':
        return { 
          name: 'Mastercard', 
          icon: <CreditCard className="h-4 w-4 text-red-600" /> 
        };
      case 'amex':
      case 'american express':
        return { 
          name: 'American Express', 
          icon: <CreditCard className="h-4 w-4 text-blue-800" /> 
        };
      case 'discover':
        return { 
          name: 'Discover', 
          icon: <CreditCard className="h-4 w-4 text-orange-600" /> 
        };
      default:
        return { 
          name: brand.charAt(0).toUpperCase() + brand.slice(1), 
          icon: <CreditCard className="h-4 w-4" /> 
        };
    }
  };

  // Using paymentMethods directly from the query

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5" />
              Payment Methods
            </CardTitle>
            <CardDescription>
              Manage your saved payment methods for faster checkout
            </CardDescription>
          </div>
          <Dialog open={isAddingCard} onOpenChange={setIsAddingCard}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <PlusCircle className="h-4 w-4" />
                Add Payment Method
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Payment Method</DialogTitle>
                <DialogDescription>
                  Enter your card details to save for future payments
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input 
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={cardDetails.number}
                      onChange={handleCardChange('number')}
                      maxLength={19}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="cardHolderName">Cardholder Name</Label>
                    <Input 
                      id="cardHolderName"
                      placeholder="John Smith"
                      value={cardDetails.name}
                      onChange={handleCardChange('name')}
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="expMonth">Month</Label>
                      <Input 
                        id="expMonth"
                        placeholder="MM"
                        value={cardDetails.expMonth}
                        onChange={handleCardChange('expMonth')}
                        maxLength={2}
                      />
                    </div>
                    <div>
                      <Label htmlFor="expYear">Year</Label>
                      <Input 
                        id="expYear"
                        placeholder="YY"
                        value={cardDetails.expYear}
                        onChange={handleCardChange('expYear')}
                        maxLength={2}
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvc">CVC</Label>
                      <Input 
                        id="cvc"
                        placeholder="123"
                        value={cardDetails.cvc}
                        onChange={handleCardChange('cvc')}
                        maxLength={4}
                        type="password"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={resetCardForm}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleAddCard}
                  disabled={addCardMutation.isPending}
                >
                  {addCardMutation.isPending ? 'Adding...' : 'Add Card'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>

        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2].map(i => (
                <Card key={i}>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div>
                        <Skeleton className="h-5 w-32 mb-1" />
                        <Skeleton className="h-4 w-24" />
                      </div>
                    </div>
                    <Skeleton className="h-8 w-24" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !paymentMethods || paymentMethods.length === 0 ? (
            <div className="text-center py-8">
              <CreditCardIcon className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <h3 className="text-lg font-semibold mb-1">No payment methods</h3>
              <p className="text-muted-foreground mb-4">
                You haven't added any payment methods yet
              </p>
              <Button onClick={() => setIsAddingCard(true)}>
                <PlusCircle className="h-4 w-4 mr-2" />
                Add Your First Card
              </Button>
            </div>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {paymentMethods.map((method: PaymentMethod) => {
                  const { name: brandName, icon: brandIcon } = getCardBrandInfo(method.brand);
                  const isProcessing = processingId === method.id;
                  
                  return (
                    <Card key={method.id} className={method.isDefault ? 'border-primary' : ''}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <div className={`h-10 w-10 rounded-full flex items-center justify-center ${method.isDefault ? 'bg-primary/10' : 'bg-muted'}`}>
                              {brandIcon}
                            </div>
                            <div>
                              <p className="font-medium flex items-center">
                                {brandName} •••• {method.last4}
                                {method.isDefault && (
                                  <span className="ml-2 text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                                    Default
                                  </span>
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {method.expiryMonth && method.expiryYear ? 
                                  `Expires ${method.expiryMonth}/${method.expiryYear}` : 
                                  'No expiration data'
                                }
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {!method.isDefault && (
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleSetDefault(method.id)}
                                disabled={isProcessing}
                              >
                                {isProcessing ? (
                                  <div className="flex items-center">
                                    <Skeleton className="h-4 w-4 mr-2 rounded-full animate-spin" />
                                    Processing...
                                  </div>
                                ) : (
                                  <>
                                    <Check className="h-4 w-4 mr-1" />
                                    Set as default
                                  </>
                                )}
                              </Button>
                            )}
                            
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="icon"
                                  onClick={() => setDeletingId(method.id)}
                                  disabled={isProcessing}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Payment Method</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete this payment method? This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel onClick={() => setDeletingId(null)}>
                                    Cancel
                                  </AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={handleDeletePaymentMethod}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    {deleteMethodMutation.isPending && deletingId === method.id ? (
                                      <>
                                        <Skeleton className="h-4 w-4 mr-2 rounded-full animate-spin" />
                                        Deleting...
                                      </>
                                    ) : (
                                      'Delete'
                                    )}
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </ScrollArea>
          )}
        </CardContent>
        
        <CardFooter className="border-t px-6 py-4 bg-muted/20">
          <div className="flex items-start gap-2 text-sm text-muted-foreground">
            <AlertCircle className="h-4 w-4 mt-0.5" />
            <p>
              Your payment information is stored securely. We use industry-standard encryption to protect your sensitive data.
            </p>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}