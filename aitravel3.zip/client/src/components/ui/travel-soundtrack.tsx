import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Play, Pause, SkipForward, SkipBack, Music, Heart, Share2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

interface Mood {
  name: string;
  description: string;
  intensity: 'calm' | 'moderate' | 'energetic';
  emotionalTone: 'happy' | 'melancholic' | 'excited' | 'relaxed' | 'adventurous';
}

interface Track {
  title: string;
  artist: string;
  genre: string;
  mood: string;
  intensity: number;
  url?: string;
  imageUrl?: string;
  previewUrl?: string;
  duration?: string;
}

interface Soundtrack {
  id: string;
  name: string;
  description: string;
  destination: string;
  mood: Mood;
  tracks: Track[];
  coverImageUrl?: string;
  duration?: string;
  createdAt: string;
}

interface SoundtrackGeneratorProps {
  destinationName?: string;
  isEmbedded?: boolean;
  onSoundtrackCreated?: (soundtrack: Soundtrack) => void;
}

export function TravelSoundtrack({ 
  destinationName, 
  isEmbedded = false,
  onSoundtrackCreated
}: SoundtrackGeneratorProps) {
  const [destination, setDestination] = useState(destinationName || '');
  const [selectedMood, setSelectedMood] = useState<string>('');
  const [intensity, setIntensity] = useState<number>(5);
  const [currentSoundtrack, setCurrentSoundtrack] = useState<Soundtrack | null>(null);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const { toast } = useToast();

  // Define form validation
  const isFormValid = destination.trim() !== '';

  // Fetch available moods
  const { data: moodsData, isLoading: moodsLoading } = useQuery({
    queryKey: ['/api/soundtrack/moods'],
    enabled: true
  });

  // Create mutation for generating soundtrack
  const { mutate: generateSoundtrack, isPending } = useMutation({
    mutationFn: async (data: { destination: string; mood?: string; intensity?: number }) => {
      const response = await fetch('/api/soundtrack/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate soundtrack');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentSoundtrack(data.soundtrack);
      setCurrentTrackIndex(0);
      toast({
        title: "Soundtrack Generated!",
        description: `Your "${data.soundtrack.name}" soundtrack is now ready to play.`,
      });
      
      if (onSoundtrackCreated) {
        onSoundtrackCreated(data.soundtrack);
      }
    },
    onError: (error) => {
      toast({
        title: "Error Generating Soundtrack",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    }
  });

  // Handle form submission
  const handleGenerateSoundtrack = () => {
    if (!isFormValid) {
      toast({
        title: "Validation Error",
        description: "Please enter a destination",
        variant: "destructive",
      });
      return;
    }
    
    generateSoundtrack({
      destination,
      mood: selectedMood || undefined,
      intensity: intensity || undefined
    });
  };

  // Play controls
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    // In a real implementation, this would control the actual audio playback
  };

  const handlePreviousTrack = () => {
    if (currentTrackIndex > 0) {
      setCurrentTrackIndex(currentTrackIndex - 1);
    }
  };

  const handleNextTrack = () => {
    if (currentSoundtrack && currentTrackIndex < currentSoundtrack.tracks.length - 1) {
      setCurrentTrackIndex(currentTrackIndex + 1);
    }
  };

  // Set destination if provided via props
  useEffect(() => {
    if (destinationName) {
      setDestination(destinationName);
    }
  }, [destinationName]);

  // Render loading state
  if (moodsLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-full" />
        </CardFooter>
      </Card>
    );
  }

  const moods = moodsData?.moods || [];

  return (
    <Card className={`w-full ${isEmbedded ? 'shadow-none border-0' : 'shadow-md'}`}>
      <CardHeader>
        <CardTitle>Travel Soundtrack Generator</CardTitle>
        <CardDescription>
          Create a personalized music playlist for your journey based on your destination and mood
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue={currentSoundtrack ? "player" : "generator"} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="generator">Create</TabsTrigger>
            <TabsTrigger value="player" disabled={!currentSoundtrack}>Player</TabsTrigger>
          </TabsList>
          
          <TabsContent value="generator" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="destination">Destination</Label>
                <Input 
                  id="destination" 
                  placeholder="Where are you traveling to?" 
                  value={destination} 
                  onChange={e => setDestination(e.target.value)} 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mood">Mood</Label>
                <Select value={selectedMood} onValueChange={setSelectedMood}>
                  <SelectTrigger id="mood">
                    <SelectValue placeholder="Select mood (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {moods.map((mood: Mood) => (
                      <SelectItem key={mood.name} value={mood.name}>
                        {mood.name} - {mood.description}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="intensity">Intensity</Label>
                  <span className="text-sm text-muted-foreground">{intensity}/10</span>
                </div>
                <Slider
                  id="intensity"
                  min={1}
                  max={10}
                  step={1}
                  value={[intensity]}
                  onValueChange={(values) => setIntensity(values[0])}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Calm</span>
                  <span>Moderate</span>
                  <span>Energetic</span>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="player" className="space-y-4 mt-4">
            {currentSoundtrack ? (
              <div className="space-y-6">
                <div className="flex flex-col items-center space-y-4">
                  <div className="w-48 h-48 rounded-lg overflow-hidden relative group">
                    <img 
                      src={currentSoundtrack.coverImageUrl || 'https://source.unsplash.com/featured/?music'} 
                      alt={currentSoundtrack.name}
                      className="w-full h-full object-cover transition-transform group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Heart className="w-10 h-10 text-white cursor-pointer" />
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h3 className="font-semibold text-lg">{currentSoundtrack.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {currentSoundtrack.tracks.length} tracks • {currentSoundtrack.duration || '45 min'}
                    </p>
                    <div className="flex items-center justify-center gap-1 mt-1">
                      <Badge variant="outline">{currentSoundtrack.mood.intensity}</Badge>
                      <Badge variant="outline">{currentSoundtrack.mood.emotionalTone}</Badge>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center gap-4 w-full mt-2">
                    <Button variant="ghost" size="icon" onClick={handlePreviousTrack} disabled={currentTrackIndex === 0}>
                      <SkipBack className="h-6 w-6" />
                    </Button>
                    <Button 
                      variant="default" 
                      size="icon" 
                      className="h-12 w-12 rounded-full" 
                      onClick={handlePlayPause}
                    >
                      {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={handleNextTrack} 
                      disabled={currentTrackIndex === currentSoundtrack.tracks.length - 1}
                    >
                      <SkipForward className="h-6 w-6" />
                    </Button>
                  </div>
                </div>
                
                <ScrollArea className="h-[180px]">
                  <div className="space-y-1">
                    {currentSoundtrack.tracks.map((track, index) => (
                      <div 
                        key={index}
                        className={`flex items-center gap-3 p-2 rounded-md hover:bg-accent cursor-pointer ${
                          index === currentTrackIndex ? 'bg-accent' : ''
                        }`}
                        onClick={() => setCurrentTrackIndex(index)}
                      >
                        <div className="shrink-0">
                          {index === currentTrackIndex && isPlaying ? (
                            <div className="w-6 h-6 flex items-center justify-center">
                              <div className="animate-pulse">
                                <Music className="h-4 w-4" />
                              </div>
                            </div>
                          ) : (
                            <div className="w-6 h-6 flex items-center justify-center">
                              <span className="text-sm">{index + 1}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`truncate font-medium ${index === currentTrackIndex ? 'text-primary' : ''}`}>
                            {track.title}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">{track.artist}</p>
                        </div>
                        <div className="text-xs text-muted-foreground">{track.duration}</div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <Music className="h-16 w-16 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Generate a soundtrack to start listening</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        {!currentSoundtrack ? (
          <Button 
            className="w-full" 
            onClick={handleGenerateSoundtrack} 
            disabled={!isFormValid || isPending}
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              'Generate Soundtrack'
            )}
          </Button>
        ) : (
          <div className="flex w-full gap-2">
            <Button variant="outline" className="flex-1" onClick={handleGenerateSoundtrack}>
              Create New
            </Button>
            <Button variant="outline" size="icon">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}