import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Heart, Plane, Hotel, Utensils, Map, Bus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Import user preferences schema
import { userPreferencesSchema } from "@shared/schema";

// Define form schema
const profileFormSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  dateOfBirth: z.string().min(1, "Date of birth is required"),
  nationality: z.string().min(2, "Nationality must be at least 2 characters"),
  passportNumber: z.string().min(6, "Passport number must be at least 6 characters"),
  preferences: userPreferencesSchema
});

export type ProfileFormData = z.infer<typeof profileFormSchema>;

interface PassengerProfileFormProps {
  onSubmit: (data: ProfileFormData) => void;
  defaultValues?: Partial<ProfileFormData>;
}

const travelClasses = ["economy", "premium_economy", "business", "first"];
const seatTypes = ["window", "aisle", "middle"];
const cuisineTypes = ["Italian", "Japanese", "Indian", "Mediterranean", "Mexican", "Thai", "American", "French"];
const accommodationTypes = ["Hotel", "Resort", "Apartment", "Villa", "Hostel", "Boutique"];
const transportTypes = ["Flight", "Train", "Bus", "Rental Car", "Rideshare"];
const activityTypes = ["Sightseeing", "Adventure", "Cultural", "Relaxation", "Shopping", "Nature", "Food Tours"];

export function PassengerProfileForm({ onSubmit, defaultValues }: PassengerProfileFormProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("basic");

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: defaultValues || {
      firstName: "",
      lastName: "",
      dateOfBirth: "",
      nationality: "",
      passportNumber: "",
      preferences: {
        preferredClass: "economy",
        seatPreference: "window",
        cuisinePreferences: [],
        accommodationPreferences: [],
        transportPreferences: [],
        activityPreferences: []
      }
    }
  });

  const handleSubmit = (data: ProfileFormData) => {
    onSubmit(data);
  };

  return (
    <Card className="p-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-6 gap-4 mb-6">
              <TabsTrigger value="basic" className="flex items-center gap-2">
                <Heart className="w-4 h-4" />
                Basic Info
              </TabsTrigger>
              <TabsTrigger value="flight" className="flex items-center gap-2">
                <Plane className="w-4 h-4" />
                Flight
              </TabsTrigger>
              <TabsTrigger value="accommodation" className="flex items-center gap-2">
                <Hotel className="w-4 h-4" />
                Accommodation
              </TabsTrigger>
              <TabsTrigger value="dining" className="flex items-center gap-2">
                <Utensils className="w-4 h-4" />
                Dining
              </TabsTrigger>
              <TabsTrigger value="activities" className="flex items-center gap-2">
                <Map className="w-4 h-4" />
                Activities
              </TabsTrigger>
              <TabsTrigger value="transport" className="flex items-center gap-2">
                <Bus className="w-4 h-4" />
                Transport
              </TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your first name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your last name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dateOfBirth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date of Birth</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="nationality"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nationality</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your nationality" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="passportNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Passport Number</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your passport number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>

            <TabsContent value="flight" className="space-y-4">
              <FormField
                control={form.control}
                name="preferences.preferredClass"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Travel Class</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select preferred class" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {travelClasses.map((travelClass) => (
                          <SelectItem key={travelClass} value={travelClass}>
                            {travelClass.replace('_', ' ').charAt(0).toUpperCase() + travelClass.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="preferences.seatPreference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Seat Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select seat preference" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {seatTypes.map((seatType) => (
                          <SelectItem key={seatType} value={seatType}>
                            {seatType.charAt(0).toUpperCase() + seatType.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>

            <TabsContent value="dining" className="space-y-4">
              <FormField
                control={form.control}
                name="preferences.cuisinePreferences"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cuisine Preferences</FormLabel>
                    <FormDescription>
                      Select your favorite types of cuisine
                    </FormDescription>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {cuisineTypes.map((cuisine) => (
                        <label key={cuisine} className="flex items-center space-x-2">
                          <Checkbox
                            checked={field.value?.includes(cuisine)}
                            onCheckedChange={(checked) => {
                              const newValue = checked
                                ? [...(field.value || []), cuisine]
                                : (field.value || []).filter((value) => value !== cuisine);
                              field.onChange(newValue);
                            }}
                          />
                          <span>{cuisine}</span>
                        </label>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>
            <TabsContent value="accommodation" className="space-y-4">
              <FormField
                control={form.control}
                name="preferences.accommodationPreferences"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Accommodation Preferences</FormLabel>
                    <FormDescription>
                      Select your preferred accommodation types
                    </FormDescription>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {accommodationTypes.map((type) => (
                        <label key={type} className="flex items-center space-x-2">
                          <Checkbox
                            checked={field.value?.includes(type)}
                            onCheckedChange={(checked) => {
                              const newValue = checked
                                ? [...(field.value || []), type]
                                : (field.value || []).filter((value) => value !== type);
                              field.onChange(newValue);
                            }}
                          />
                          <span>{type}</span>
                        </label>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>
            <TabsContent value="activities" className="space-y-4">
              <FormField
                control={form.control}
                name="preferences.activityPreferences"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Activity Preferences</FormLabel>
                    <FormDescription>
                      Select your preferred activity types
                    </FormDescription>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {activityTypes.map((type) => (
                        <label key={type} className="flex items-center space-x-2">
                          <Checkbox
                            checked={field.value?.includes(type)}
                            onCheckedChange={(checked) => {
                              const newValue = checked
                                ? [...(field.value || []), type]
                                : (field.value || []).filter((value) => value !== type);
                              field.onChange(newValue);
                            }}
                          />
                          <span>{type}</span>
                        </label>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>
            <TabsContent value="transport" className="space-y-4">
              <FormField
                control={form.control}
                name="preferences.transportPreferences"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transport Preferences</FormLabel>
                    <FormDescription>
                      Select your preferred transport types
                    </FormDescription>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {transportTypes.map((type) => (
                        <label key={type} className="flex items-center space-x-2">
                          <Checkbox
                            checked={field.value?.includes(type)}
                            onCheckedChange={(checked) => {
                              const newValue = checked
                                ? [...(field.value || []), type]
                                : (field.value || []).filter((value) => value !== type);
                              field.onChange(newValue);
                            }}
                          />
                          <span>{type}</span>
                        </label>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-4">
            <Button type="submit">
              Create Profile
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}