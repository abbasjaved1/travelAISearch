import { useState, useEffect } from "react";
import { 
  PaymentElement, 
  useStripe, 
  useElements,
  AddressElement
} from "@stripe/react-stripe-js";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import type { PaymentFormProps } from "@shared/schema";

export function PaymentForm({ amount, onSuccess, onCancel, details, bookingType = 'flight' }: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<string>("card");
  const [upiId, setUpiId] = useState<string>("");
  const [upiDetails, setUpiDetails] = useState<any>(null);
  const [paymentOptions, setPaymentOptions] = useState<Record<string, any>>({
    layout: {
      type: 'accordion',
      defaultCollapsed: false
    },
    fields: {
      billingDetails: 'auto'
    },
    paymentMethodOrder: ['card']
  });
  const { toast } = useToast();
  
  // Update payment element options when payment method tab changes
  useEffect(() => {
    const methodMap: Record<string, string[]> = {
      card: ['card'],
      upi: ['upi'],
      netbanking: ['netbanking'],
      wallet: ['wallet', 'google_pay', 'apple_pay', 'link']
    };
    
    setPaymentOptions({
      layout: {
        type: 'accordion',
        defaultCollapsed: false
      },
      fields: {
        billingDetails: 'auto'
      },
      paymentMethodOrder: methodMap[paymentMethod] || ['card']
    });
  }, [paymentMethod]);

  // Handle UPI Payment creation
  const handleUpiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!upiId) {
      toast({
        title: "Missing UPI ID",
        description: "Please enter your UPI ID to proceed with the payment",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      console.log(`Processing UPI payment for ${bookingType}, amount: $${amount}`);
      
      // Prepare metadata
      const metadata = {
        ...details,
        bookingType,
        amount,
        date: new Date().toISOString(),
      };
      
      // Call our UPI payment API endpoint
      const response = await fetch("/api/payment/create-upi-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          amount,
          bookingType,
          metadata,
          upiId 
        }),
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`UPI payment request failed: ${response.statusText}`);
      }
      
      const upiPaymentDetails = await response.json();
      
      console.log("UPI payment request created:", upiPaymentDetails);
      setUpiDetails(upiPaymentDetails);
      
      toast({
        title: "UPI Payment Ready",
        description: "Scan the QR code with any UPI app to complete your payment",
      });
      
    } catch (error: any) {
      console.error("UPI payment request failed:", error);
      
      toast({
        title: "UPI Payment Error",
        description: error.message || "Failed to create UPI payment request. Please try again or use a different payment method.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Handle UPI Payment verification
  const handleVerifyUpiPayment = async () => {
    if (!upiDetails?.referenceId) {
      toast({
        title: "Verification Error",
        description: "No payment reference found to verify",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      console.log("Verifying UPI payment:", upiDetails.referenceId);
      
      // Call our UPI payment verification API
      const response = await fetch("/api/payment/verify-upi", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          referenceId: upiDetails.referenceId 
        }),
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`UPI payment verification failed: ${response.statusText}`);
      }
      
      const verificationResult = await response.json();
      
      if (verificationResult.status === 'success') {
        toast({
          title: "Payment Successful!",
          description: `Your ${bookingType} booking has been confirmed.`,
        });
        
        // Call onSuccess to complete the booking
        onSuccess();
      } else {
        toast({
          title: "Payment Not Complete",
          description: "We couldn't verify your payment. If you have already paid, please contact support with your reference ID.",
          variant: "destructive",
        });
      }
      
    } catch (error: any) {
      console.error("UPI payment verification failed:", error);
      
      toast({
        title: "Verification Error",
        description: error.message || "Failed to verify your payment. If you have completed the payment, please contact support with your reference ID.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      console.error("Payment submission attempted with missing Stripe or Elements:", {
        stripeAvailable: !!stripe,
        elementsAvailable: !!elements,
        paymentMethod
      });
      
      toast({
        title: "Payment System Error",
        description: "Payment system is not ready. This may be due to connection issues or missing configuration. Please try again later or contact support if the issue persists.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Log booking details for debugging
      console.log(`Processing ${bookingType} payment for $${amount}:`, details);
      
      // Prepare customer name for billing details
      let customerName = 'Guest Customer';
      
      // Extract customer name based on booking type and details
      if (details.passengers) {
        if (Array.isArray(details.passengers)) {
          // Handle PassengerDetails[] case
          if (details.passengers.length > 0 && 'firstName' in details.passengers[0]) {
            customerName = `${details.passengers[0].firstName} ${details.passengers[0].lastName}`;
          }
        } else {
          // Handle number case (just keeps the default "Guest Customer")
        }
      }
      
      // Attempt to confirm the payment with Stripe
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          // Return to the current page after payment
          return_url: window.location.href,
          // Include booking details in payment metadata
          payment_method_data: {
            billing_details: {
              name: customerName
            }
          },
        },
        redirect: "if_required",
      });

      if (error) {
        console.error("Payment confirmation error:", error);
        // Handle specific error types with more specific messages
        if (error.type === 'card_error') {
          if (error.code === 'card_declined') {
            toast({
              title: "Card Declined",
              description: "Your card was declined. Please check your card details or try a different payment method.",
              variant: "destructive",
            });
          } else if (error.code === 'expired_card') {
            toast({
              title: "Expired Card",
              description: "Your card has expired. Please use a valid card with a future expiration date.",
              variant: "destructive",
            });
          } else if (error.code === 'incorrect_cvc') {
            toast({
              title: "Incorrect Security Code",
              description: "The security code (CVC) you entered is incorrect. Please check your card details.",
              variant: "destructive",
            });
          } else if (error.code === 'processing_error') {
            toast({
              title: "Processing Error",
              description: "An error occurred while processing your card. Please try again or use a different payment method.",
              variant: "destructive",
            });
          } else if (error.code === 'insufficient_funds') {
            toast({
              title: "Insufficient Funds",
              description: "Your card has insufficient funds. Please use a different card or payment method.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Payment Failed",
              description: error.message || "There was an issue with your card. Please try a different payment method.",
              variant: "destructive",
            });
          }
        } else if (error.type === 'validation_error') {
          toast({
            title: "Validation Error",
            description: error.message || "Please check your payment details and try again.",
            variant: "destructive",
          });
        } else if (error.type === 'invalid_request_error') {
          toast({
            title: "Invalid Request",
            description: "There was an issue with the payment request. Please refresh the page and try again.",
            variant: "destructive",
          });
        } else if (error.type === 'api_error' || error.type === 'api_connection_error') {
          toast({
            title: "Service Unavailable",
            description: "We're experiencing issues connecting to our payment service. Please try again in a few moments.",
            variant: "destructive",
          });
        } else if (error.type === 'authentication_error') {
          toast({
            title: "Authentication Error",
            description: "There's an issue with our payment system. Please contact support.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Payment Failed",
            description: error.message || "Something went wrong with your payment. Please try again or use a different method.",
            variant: "destructive",
          });
        }
      } else if (paymentIntent && paymentIntent.status === "succeeded") {
        // Payment succeeded, now confirm the booking on our backend
        try {
          const confirmResponse = await fetch(`/api/payment/confirm/${paymentIntent.id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              bookingDetails: {
                ...details,
                bookingType,
                amount,
                date: new Date().toISOString(),
              }
            }),
            credentials: 'include'
          });
          
          if (confirmResponse.ok) {
            toast({
              title: `${bookingType.charAt(0).toUpperCase() + bookingType.slice(1)} Booking Confirmed!`,
              description: "Your payment was successful and booking has been confirmed.",
            });
            onSuccess();
          } else {
            // Payment successful but booking confirmation failed
            toast({
              title: "Payment Processed",
              description: "Payment successful, but there was an issue confirming your booking. Please contact support.",
              variant: "destructive",
            });
            // Still consider this a success since the payment went through
            onSuccess();
          }
        } catch (confirmError) {
          console.error("Booking confirmation error:", confirmError);
          toast({
            title: "Payment Processed",
            description: "Payment was successful, but we couldn't confirm your booking. Please contact support.",
            variant: "destructive",
          });
          // Still consider this a success since the payment went through
          onSuccess();
        }
      } else if (paymentIntent) {
        // Handle other payment states
        toast({
          title: "Payment Processing",
          description: `Your payment is ${paymentIntent.status}. We'll update you when it completes.`,
        });
      }
    } catch (error: any) {
      console.error("Payment processing error:", error);
      
      // Capture additional error information for debugging
      const errorDetails = {
        message: error.message || 'Unknown error',
        code: error.code,
        type: error.type,
        stack: error.stack,
        timestamp: new Date().toISOString()
      };
      console.error("Detailed payment error:", errorDetails);
      
      // Provide more specific messages based on error properties if available
      if (error.name === 'AbortError') {
        toast({
          title: "Payment Cancelled",
          description: "The payment process was cancelled or timed out. Please try again.",
          variant: "destructive",
        });
      } else if (error.message && error.message.includes('network')) {
        toast({
          title: "Network Error",
          description: "We couldn't connect to the payment service. Please check your internet connection and try again.",
          variant: "destructive",
        });
      } else if (error.message && (error.message.includes('Stripe') || error.message.includes('stripe'))) {
        toast({
          title: "Payment Provider Error",
          description: error.message || "There was an issue with our payment provider. Please try again later.",
          variant: "destructive",
        });
      } else {
        // Generic fallback message
        toast({
          title: "Payment System Error",
          description: "We encountered an unexpected error. Please try again or use a different payment method.",
          variant: "destructive",
        });
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="p-6">
      <h2 className="text-2xl font-bold mb-4">Complete Payment</h2>
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-2">Booking Summary</h3>
        {bookingType === 'flight' && details.flight && (
          <div className="mb-2 p-3 bg-slate-50 rounded-md">
            <p className="font-medium text-primary">Flight: {details.flight.airline}</p>
            <p>From: <span className="font-medium">{details.flight.from}</span> To: <span className="font-medium">{details.flight.to}</span></p>
            <p>Departure: {new Date(details.flight.departure).toLocaleString()}</p>
            <p>Class: <span className="capitalize">{details.flight.class}</span></p>
            {details.seat && <p>Seat: {details.seat.row}{details.seat.column}</p>}
          </div>
        )}
        
        {bookingType === 'hotel' && details.hotel && (
          <div className="mb-2 p-3 bg-slate-50 rounded-md">
            <p className="font-medium text-primary">Hotel: {details.hotel.name}</p>
            <p>Location: {details.hotel.location}</p>
            <p>Check-in: {new Date(details.hotel.checkIn).toLocaleDateString()}</p>
            <p>Check-out: {new Date(details.hotel.checkOut).toLocaleDateString()}</p>
            <p>Rating: {details.hotel.rating} ⭐</p>
          </div>
        )}
        
        {bookingType === 'dining' && details.dining && (
          <div className="mb-2 p-3 bg-slate-50 rounded-md">
            <p className="font-medium text-primary">Restaurant: {details.dining.restaurant}</p>
            <p>Cuisine: <span className="capitalize">{details.dining.cuisine}</span></p>
            <p>Date: {new Date(details.dining.date).toLocaleDateString()}</p>
            <p>Time: {details.dining.time}</p>
            <p>Guests: {details.dining.guests}</p>
            {details.dining.location && <p>Location: {details.dining.location}</p>}
          </div>
        )}
        
        {bookingType === 'ride' && details.ride && (
          <div className="mb-2 p-3 bg-slate-50 rounded-md">
            <p className="font-medium text-primary">Ride: {details.ride.type}</p>
            <p>From: <span className="font-medium">{details.ride.from}</span></p>
            <p>To: <span className="font-medium">{details.ride.to}</span></p>
            <p>Pickup Time: {details.ride.pickupTime}</p>
          </div>
        )}
        
        <div className="flex justify-between items-center mt-4 p-2 border-t border-b">
          <p className="text-lg">Total Amount:</p>
          <p className="text-lg font-bold">${amount.toFixed(2)}</p>
        </div>
      </div>
      <div className="my-4">
        <h3 className="text-lg font-semibold mb-2">Select Payment Method</h3>
        <div className="mb-4">
          <p className="text-sm font-medium mb-2">Recommended Payment Methods</p>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="flex items-center gap-1 cursor-pointer hover:bg-secondary" onClick={() => setPaymentMethod("wallet")}>
              <img src="/logos/paytm-logo.svg" alt="Paytm" className="h-4" />
              Paytm
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1 cursor-pointer hover:bg-secondary" onClick={() => setPaymentMethod("card")}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="16" height="16">
                <path fill="#1565C0" d="M45,35c0,2.209-1.791,4-4,4H7c-2.209,0-4-1.791-4-4V13c0-2.209,1.791-4,4-4h34c2.209,0,4,1.791,4,4V35z"/>
                <path fill="#FFF" d="M15.186 19l-2.626 7.832c0 0-.667-3.313-.733-3.729-1.495-3.411-3.701-3.221-3.701-3.221L10.726 30v-.002h3.161L18.258 19H15.186zM17.689 30L20.56 30 22.296 19 19.389 19zM38.008 19h-3.021l-4.71 11h2.852l.588-1.571h3.596L37.619 30h2.613L38.008 19zM34.513 26.328l1.563-4.157.881 4.157H34.513zM26.369 22.206c0-.606.498-1.057 1.926-1.057.928 0 1.991.177 1.991.177l.466-2.242c0 0-1.358-.515-2.691-.515-3.019 0-4.576 1.444-4.576 3.272 0 3.306 3.979 2.853 3.979 4.551 0 .291-.231.964-1.888.964-1.662 0-2.759-.609-2.759-.609l-.495 2.268c0 0 1.063.466 3.117.466 2.059 0 4.915-1.090 4.915-3.752C30.354 23.586 26.369 23.394 26.369 22.206z"/>
              </svg>
              Visa
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1 cursor-pointer hover:bg-secondary" onClick={() => setPaymentMethod("upi")}>
              <img src="/logos/upi-logo.svg" alt="UPI" className="h-4" />
              UPI
            </Badge>
          </div>
        </div>
        
        <Tabs defaultValue="card" value={paymentMethod} onValueChange={setPaymentMethod} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="card">
              <div className="flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-1">
                  <rect width="20" height="14" x="2" y="5" rx="2" />
                  <line x1="2" x2="22" y1="10" y2="10" />
                </svg>
                <span className="text-xs">Card</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="upi">
              <div className="flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-1">
                  <path d="M15 11h.01" />
                  <path d="M11 15h.01" />
                  <path d="M16 16h.01" />
                  <path d="m2 16 20 6-6-20a12 12 0 0 0-8.5 15.5" />
                </svg>
                <span className="text-xs">UPI</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="netbanking">
              <div className="flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-1">
                  <path d="M5 3v4" />
                  <path d="M19 3v4" />
                  <path d="M5 7h14" />
                  <path d="M5 21h14" />
                  <path d="M12 7v4" />
                  <path d="M12 15v2" />
                  <path d="M4 14a1 1 0 0 0 2 0V8a1 1 0 0 0-2 0v6Z" />
                  <path d="M20 11v6a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2Z" />
                </svg>
                <span className="text-xs">Banking</span>
              </div>
            </TabsTrigger>
            <TabsTrigger value="wallet">
              <div className="flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-1">
                  <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" />
                  <path d="M4 6v12c0 1.1.9 2 2 2h14v-4" />
                  <path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4Z" />
                </svg>
                <span className="text-xs">Wallet</span>
              </div>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="card" className="mt-4">
            <Badge className="mb-3">Credit & Debit Cards</Badge>
            <form onSubmit={handleSubmit} className="space-y-4">
              <PaymentElement options={paymentOptions} />
              <div className="flex justify-between gap-4 mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isProcessing}
                >
                  Back
                </Button>
                <Button type="submit" disabled={isProcessing}>
                  {isProcessing ? "Processing..." : `Pay $${amount}`}
                </Button>
              </div>
            </form>
          </TabsContent>
          
          <TabsContent value="upi" className="mt-4">
            <Badge className="mb-3">UPI Payment</Badge>
            <form onSubmit={handleUpiSubmit} className="space-y-4">
              <div className="space-y-4">
                <div className="mb-4">
                  <label htmlFor="upiId" className="block text-sm font-medium mb-1">UPI ID / VPA</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      id="upiId" 
                      value={upiId} 
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="yourname@upi" 
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
                      required 
                    />
                  </div>
                </div>
                
                {/* Show QR code and payment instructions when a UPI ID is entered */}
                {upiDetails && (
                  <div className="border rounded-md p-4 space-y-4">
                    <h4 className="font-medium">UPI Payment Instructions</h4>
                    <div className="flex flex-col items-center justify-center">
                      {upiDetails.qrCode && (
                        <div className="mb-4">
                          <img 
                            src={upiDetails.qrCode} 
                            alt="UPI Payment QR Code" 
                            className="w-48 h-48 border rounded-md"
                          />
                        </div>
                      )}
                      <p className="text-center text-sm mb-2">Scan with any UPI app to pay</p>
                      <div className="flex gap-2 justify-center mt-2">
                        <img src="/logos/upi-logo.svg" alt="UPI" className="h-6" />
                        <img src="/logos/gpay-logo.svg" alt="Google Pay" className="h-6" />
                        <img src="/logos/phonepe-logo.svg" alt="PhonePe" className="h-6" />
                        <img src="/logos/paytm-logo.svg" alt="Paytm" className="h-6" />
                      </div>
                    </div>
                    <div className="mt-4 border-t pt-4">
                      <p className="text-sm mb-2"><span className="font-medium">Amount:</span> ₹{amount}</p>
                      <p className="text-sm mb-2"><span className="font-medium">Reference ID:</span> {upiDetails.referenceId}</p>
                      <p className="text-sm text-muted-foreground">After completing payment in your UPI app, click "Verify Payment" below</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex justify-between gap-4 mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isProcessing}
                >
                  Back
                </Button>
                {!upiDetails ? (
                  <Button type="submit" disabled={isProcessing || !upiId}>
                    {isProcessing ? "Processing..." : "Generate Payment"}
                  </Button>
                ) : (
                  <Button 
                    type="button" 
                    onClick={handleVerifyUpiPayment} 
                    disabled={isProcessing}
                  >
                    {isProcessing ? "Verifying..." : "Verify Payment"}
                  </Button>
                )}
              </div>
            </form>
          </TabsContent>
          
          <TabsContent value="netbanking" className="mt-4">
            <Badge className="mb-3">Net Banking</Badge>
            <form onSubmit={handleSubmit} className="space-y-4">
              <PaymentElement options={paymentOptions} />
              <div className="flex justify-between gap-4 mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isProcessing}
                >
                  Back
                </Button>
                <Button type="submit" disabled={isProcessing}>
                  {isProcessing ? "Processing..." : `Pay $${amount}`}
                </Button>
              </div>
            </form>
          </TabsContent>
          
          <TabsContent value="wallet" className="mt-4">
            <Badge className="mb-3">Digital Wallets</Badge>
            <form onSubmit={handleSubmit} className="space-y-4">
              <PaymentElement options={paymentOptions} />
              <div className="flex justify-between gap-4 mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isProcessing}
                >
                  Back
                </Button>
                <Button type="submit" disabled={isProcessing}>
                  {isProcessing ? "Processing..." : `Pay $${amount}`}
                </Button>
              </div>
            </form>
          </TabsContent>
        </Tabs>
      </div>
    </Card>
  );
}