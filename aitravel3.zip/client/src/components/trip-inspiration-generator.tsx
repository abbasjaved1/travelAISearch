import { useState } from 'react';
import axios from 'axios';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Sparkles } from "lucide-react";

interface TripInspiration {
  destination: string;
  description: string;
  activities: string[];
  budget: {
    currency: string;
    range: {
      min: number;
      max: number;
    };
    perDay: number;
  };
  bestTimeToVisit: string[];
  transportationOptions: string[];
  accommodationSuggestions: string[];
  localCuisine: string[];
  culturalTips: string[];
  imageUrl: string;
}

type CategoryType = 'beach' | 'mountain' | 'city' | 'culture' | 'adventure' | 'food' | 'wellness' | 'nature' | 'history' | 'luxury';

const TripInspirationGenerator = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [inspiration, setInspiration] = useState<TripInspiration | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | null>(null);
  const { toast } = useToast();

  const categories: { value: CategoryType, label: string, emoji: string }[] = [
    { value: 'beach', label: 'Beach', emoji: '🏖️' },
    { value: 'mountain', label: 'Mountain', emoji: '⛰️' },
    { value: 'city', label: 'City', emoji: '🏙️' },
    { value: 'culture', label: 'Culture', emoji: '🏛️' },
    { value: 'adventure', label: 'Adventure', emoji: '🧗' },
    { value: 'food', label: 'Food', emoji: '🍲' },
    { value: 'wellness', label: 'Wellness', emoji: '🧘' },
    { value: 'nature', label: 'Nature', emoji: '🌳' },
    { value: 'history', label: 'History', emoji: '🏺' },
    { value: 'luxury', label: 'Luxury', emoji: '✨' }
  ];

  const generateRandomTrip = async (category?: CategoryType) => {
    setIsLoading(true);
    setInspiration(null);
    
    try {
      const params = category ? { category } : {};
      const response = await axios.get<TripInspiration>('/api/trip-inspiration/random', { params });
      setInspiration(response.data);
      
      // Log analytics event
      console.log('Trip inspiration generated:', response.data.destination);
    } catch (error) {
      console.error('Error generating trip inspiration:', error);
      toast({
        title: "Error",
        description: "Failed to generate trip inspiration. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold mb-2 flex items-center justify-center">
          <Sparkles className="h-6 w-6 mr-2 text-yellow-500" />
          One-Click Trip Inspiration
          <Sparkles className="h-6 w-6 ml-2 text-yellow-500" />
        </h2>
        <p className="text-muted-foreground">
          Discover your next adventure with a single click or refine by category
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-2 mb-6">
        {categories.map((category) => (
          <Button
            key={category.value}
            variant={selectedCategory === category.value ? "default" : "outline"}
            className="flex items-center gap-1"
            onClick={() => {
              setSelectedCategory(category.value);
              generateRandomTrip(category.value);
            }}
          >
            <span>{category.emoji}</span>
            <span>{category.label}</span>
          </Button>
        ))}
      </div>

      <div className="flex justify-center mb-8">
        <Button 
          size="lg" 
          onClick={() => {
            setSelectedCategory(null);
            generateRandomTrip();
          }}
          disabled={isLoading}
          className="relative overflow-hidden group"
        >
          <span className="relative z-10">
            {isLoading ? "Generating Inspiration..." : "Surprise Me!"}
          </span>
          <span className="absolute inset-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-0 group-hover:opacity-100 transition-opacity"></span>
        </Button>
      </div>

      {isLoading ? (
        <Card className="w-full">
          <CardHeader>
            <Skeleton className="h-8 w-[250px] mb-2" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[200px] w-full mb-4" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Skeleton className="h-6 w-[100px] mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </div>
              <div>
                <Skeleton className="h-6 w-[100px] mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </div>
          </CardContent>
        </Card>
      ) : inspiration ? (
        <Card className="w-full">
          <div className="relative h-[250px] overflow-hidden rounded-t-lg">
            <img 
              src={inspiration.imageUrl} 
              alt={inspiration.destination} 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <h3 className="text-2xl font-bold text-white">{inspiration.destination}</h3>
            </div>
          </div>
          <CardHeader>
            <CardDescription className="text-lg">{inspiration.description}</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-lg mb-2">Activities</h4>
              <ul className="space-y-1">
                {inspiration.activities.map((activity, index) => (
                  <li key={index} className="flex items-center">
                    <span className="mr-2">•</span> {activity}
                  </li>
                ))}
              </ul>

              <h4 className="font-semibold text-lg mt-4 mb-2">Budget</h4>
              <div className="space-y-1">
                <p>
                  <span className="font-medium">Range:</span> {inspiration.budget.currency} {inspiration.budget.range.min.toLocaleString()} - {inspiration.budget.range.max.toLocaleString()}
                </p>
                <p>
                  <span className="font-medium">Per Day:</span> ~{inspiration.budget.currency} {inspiration.budget.perDay.toLocaleString()}
                </p>
              </div>

              <h4 className="font-semibold text-lg mt-4 mb-2">Best Time to Visit</h4>
              <div className="flex flex-wrap gap-2">
                {inspiration.bestTimeToVisit.map((time, index) => (
                  <Badge key={index} variant="outline">{time}</Badge>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-lg mb-2">Accommodations</h4>
              <ul className="space-y-1">
                {inspiration.accommodationSuggestions.map((accommodation, index) => (
                  <li key={index} className="flex items-center">
                    <span className="mr-2">•</span> {accommodation}
                  </li>
                ))}
              </ul>

              <h4 className="font-semibold text-lg mt-4 mb-2">Local Cuisine</h4>
              <ul className="space-y-1">
                {inspiration.localCuisine.map((cuisine, index) => (
                  <li key={index} className="flex items-center">
                    <span className="mr-2">•</span> {cuisine}
                  </li>
                ))}
              </ul>

              <h4 className="font-semibold text-lg mt-4 mb-2">Cultural Tips</h4>
              <ul className="space-y-1">
                {inspiration.culturalTips.map((tip, index) => (
                  <li key={index} className="flex items-center">
                    <span className="mr-2">•</span> {tip}
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
          <Separator />
          <CardFooter className="justify-between pt-6">
            <Button 
              variant="outline" 
              onClick={() => setInspiration(null)}
            >
              Clear
            </Button>
            <Button 
              onClick={() => {
                setSelectedCategory(null);
                generateRandomTrip();
              }}
              disabled={isLoading}
            >
              Generate Another
            </Button>
          </CardFooter>
        </Card>
      ) : null}
    </div>
  );
};

export default TripInspirationGenerator;