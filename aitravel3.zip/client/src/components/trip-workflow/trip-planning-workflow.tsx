import React, { useState } from 'react';
import axios from 'axios';
import { useQuery, useMutation } from '@tanstack/react-query';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { LocationSearch } from '@/components/ui/location-search';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TripPlanView } from '@/components/ui/trip-plan-view';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon, CheckCircle, Loader2, MapPin, Plane, Calendar as CalendarIcon2, Clock, Briefcase, User, Users, Heart } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, addDays, isAfter, isBefore, isEqual } from 'date-fns';
import { TripPlan, Activity } from '@/shared/schema';

interface TripPlanFormData {
  destination: string;
  dates: {
    start: Date | undefined;
    end: Date | undefined;
  };
  preferences: {
    pace: 'relaxed' | 'moderate' | 'intensive';
    type: 'leisure' | 'business' | 'family' | 'adventure';
    interests: string[];
  };
  meetingDetails?: {
    time: string;
    duration: number;
    attendees: number;
  };
}

export function TripPlanningWorkflow() {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [formData, setFormData] = useState<TripPlanFormData>({
    destination: '',
    dates: {
      start: undefined,
      end: undefined,
    },
    preferences: {
      pace: 'moderate',
      type: 'leisure',
      interests: [],
    },
  });
  const [tripPlan, setTripPlan] = useState<TripPlan | null>(null);
  
  // Function to handle destination selection
  const handleDestinationSelect = (destination: string) => {
    setFormData({
      ...formData,
      destination
    });
  };
  
  // Function to handle date selection
  const handleDateSelect = (date: Date | undefined, type: 'start' | 'end') => {
    setFormData({
      ...formData,
      dates: {
        ...formData.dates,
        [type]: date
      }
    });
  };
  
  // Function to handle pace selection
  const handlePaceChange = (pace: 'relaxed' | 'moderate' | 'intensive') => {
    setFormData({
      ...formData,
      preferences: {
        ...formData.preferences,
        pace
      }
    });
  };
  
  // Function to handle trip type selection
  const handleTripTypeChange = (type: 'leisure' | 'business' | 'family' | 'adventure') => {
    setFormData({
      ...formData,
      preferences: {
        ...formData.preferences,
        type
      }
    });
    
    // If business trip is selected, initialize meeting details
    if (type === 'business' && !formData.meetingDetails) {
      setFormData({
        ...formData,
        preferences: {
          ...formData.preferences,
          type
        },
        meetingDetails: {
          time: '09:00',
          duration: 60,
          attendees: 2
        }
      });
    }
  };
  
  // Function to handle interests selection
  const handleInterestToggle = (interest: string) => {
    const currentInterests = [...formData.preferences.interests];
    
    if (currentInterests.includes(interest)) {
      // Remove interest if already selected
      setFormData({
        ...formData,
        preferences: {
          ...formData.preferences,
          interests: currentInterests.filter(i => i !== interest)
        }
      });
    } else {
      // Add interest if not already selected
      setFormData({
        ...formData,
        preferences: {
          ...formData.preferences,
          interests: [...currentInterests, interest]
        }
      });
    }
  };
  
  // Function to handle meeting details changes
  const handleMeetingDetailsChange = (field: 'time' | 'duration' | 'attendees', value: string | number) => {
    if (!formData.meetingDetails) return;
    
    setFormData({
      ...formData,
      meetingDetails: {
        ...formData.meetingDetails,
        [field]: value
      }
    });
  };
  
  // Interest options
  const interests = [
    { id: 'food', label: 'Food & Dining', icon: '🍴' },
    { id: 'culture', label: 'Culture & Arts', icon: '🎭' },
    { id: 'history', label: 'History', icon: '🏛️' },
    { id: 'nature', label: 'Nature', icon: '🌿' },
    { id: 'adventure', label: 'Adventure', icon: '🧗‍♂️' },
    { id: 'nightlife', label: 'Nightlife', icon: '🌃' },
    { id: 'shopping', label: 'Shopping', icon: '🛍️' },
    { id: 'wellness', label: 'Wellness & Spa', icon: '💆‍♀️' },
    { id: 'sports', label: 'Sports', icon: '🏅' },
    { id: 'local', label: 'Local Experiences', icon: '👨‍👩‍👧‍👦' },
  ];

  // Generate Trip Plan mutation
  const generatePlanMutation = useMutation({
    mutationFn: async () => {
      // Validate form data
      if (!formData.destination) {
        throw new Error('Please select a destination');
      }
      if (!formData.dates.start || !formData.dates.end) {
        throw new Error('Please select both start and end dates');
      }
      
      // Format dates for API
      const requestData = {
        destination: formData.destination,
        dates: {
          start: format(formData.dates.start, 'yyyy-MM-dd'),
          end: format(formData.dates.end, 'yyyy-MM-dd')
        },
        preferences: formData.preferences,
        meetingDetails: formData.meetingDetails
      };
      
      const response = await axios.post('/api/ai/trip-plan', requestData);
      return response.data;
    },
    onSuccess: (data) => {
      setTripPlan(data.plan);
      setCurrentStep(3);
      toast({
        title: 'Trip plan generated',
        description: `Your personalized trip to ${formData.destination} is ready!`,
        variant: 'default',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error generating trip plan',
        description: error instanceof Error ? error.message : 'An unexpected error occurred',
        variant: 'destructive',
      });
    },
  });

  // Function to handle activity booking
  const handleBookActivity = (activity: Activity) => {
    // In a real app, this would redirect to a booking page or open a booking modal
    toast({
      title: 'Booking initiated',
      description: `You're about to book "${activity.title}" - This feature is coming soon!`,
      variant: 'default',
    });
  };
  
  // Function to handle exporting the plan
  const handleExportPlan = () => {
    toast({
      title: 'Export trip plan',
      description: 'Exporting feature is coming soon!',
      variant: 'default',
    });
  };
  
  // Function to go to next step
  const goToNextStep = () => {
    // Validate current step
    if (currentStep === 1) {
      if (!formData.destination) {
        toast({
          title: 'Destination required',
          description: 'Please select a destination for your trip',
          variant: 'destructive',
        });
        return;
      }
      if (!formData.dates.start || !formData.dates.end) {
        toast({
          title: 'Dates required',
          description: 'Please select both start and end dates for your trip',
          variant: 'destructive',
        });
        return;
      }
      if (isAfter(formData.dates.start, formData.dates.end)) {
        toast({
          title: 'Invalid dates',
          description: 'End date must be after start date',
          variant: 'destructive',
        });
        return;
      }
    }
    
    if (currentStep < 2) {
      setCurrentStep(currentStep + 1);
    } else if (currentStep === 2) {
      generatePlanMutation.mutate();
    }
  };
  
  // Function to go to previous step
  const goToPreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Progress Indicator */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className={`flex items-center justify-center h-8 w-8 rounded-full ${currentStep >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
              <MapPin className="h-4 w-4" />
            </div>
            <div className={`h-1 w-12 ${currentStep >= 2 ? 'bg-primary' : 'bg-muted'} mx-2`}></div>
            <div className={`flex items-center justify-center h-8 w-8 rounded-full ${currentStep >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
              <Heart className="h-4 w-4" />
            </div>
            <div className={`h-1 w-12 ${currentStep >= 3 ? 'bg-primary' : 'bg-muted'} mx-2`}></div>
            <div className={`flex items-center justify-center h-8 w-8 rounded-full ${currentStep >= 3 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
              <CheckCircle className="h-4 w-4" />
            </div>
          </div>
          <div className="text-sm text-muted-foreground">
            Step {currentStep} of 3
          </div>
        </div>
        <div className="flex items-center justify-between mt-2 px-1">
          <span className={`text-xs ${currentStep >= 1 ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
            Destination
          </span>
          <span className={`text-xs ${currentStep >= 2 ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
            Preferences
          </span>
          <span className={`text-xs ${currentStep >= 3 ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
            Your Plan
          </span>
        </div>
      </div>
      
      {/* Step 1: Destination and Dates */}
      {currentStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Where do you want to go?</CardTitle>
            <CardDescription>Select your destination and travel dates</CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="destination">Destination</Label>
              <LocationSearch
                onLocationSelect={handleDestinationSelect}
                initialValue={formData.destination}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.dates.start && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.dates.start ? format(formData.dates.start, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.dates.start}
                      onSelect={(date) => handleDateSelect(date, 'start')}
                      initialFocus
                      disabled={(date) => {
                        return isBefore(date, new Date());
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endDate">End Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.dates.end && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.dates.end ? format(formData.dates.end, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.dates.end}
                      onSelect={(date) => handleDateSelect(date, 'end')}
                      initialFocus
                      disabled={(date) => {
                        return isBefore(date, new Date()) || 
                               (formData.dates.start && isBefore(date, formData.dates.start));
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-end">
            <Button onClick={goToNextStep}>
              Continue
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {/* Step 2: Trip Preferences */}
      {currentStep === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Customize your trip</CardTitle>
            <CardDescription>Tell us about your preferences so we can create a personalized plan</CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Trip Type</Label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Button
                  type="button"
                  variant={formData.preferences.type === 'leisure' ? 'default' : 'outline'}
                  className="flex flex-col items-center justify-center h-20 gap-1"
                  onClick={() => handleTripTypeChange('leisure')}
                >
                  <Heart className="h-5 w-5" />
                  <span>Leisure</span>
                </Button>
                <Button
                  type="button"
                  variant={formData.preferences.type === 'business' ? 'default' : 'outline'}
                  className="flex flex-col items-center justify-center h-20 gap-1"
                  onClick={() => handleTripTypeChange('business')}
                >
                  <Briefcase className="h-5 w-5" />
                  <span>Business</span>
                </Button>
                <Button
                  type="button"
                  variant={formData.preferences.type === 'family' ? 'default' : 'outline'}
                  className="flex flex-col items-center justify-center h-20 gap-1"
                  onClick={() => handleTripTypeChange('family')}
                >
                  <Users className="h-5 w-5" />
                  <span>Family</span>
                </Button>
                <Button
                  type="button"
                  variant={formData.preferences.type === 'adventure' ? 'default' : 'outline'}
                  className="flex flex-col items-center justify-center h-20 gap-1"
                  onClick={() => handleTripTypeChange('adventure')}
                >
                  <Plane className="h-5 w-5" />
                  <span>Adventure</span>
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Trip Pace</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  type="button"
                  variant={formData.preferences.pace === 'relaxed' ? 'default' : 'outline'}
                  onClick={() => handlePaceChange('relaxed')}
                >
                  Relaxed
                </Button>
                <Button
                  type="button"
                  variant={formData.preferences.pace === 'moderate' ? 'default' : 'outline'}
                  onClick={() => handlePaceChange('moderate')}
                >
                  Moderate
                </Button>
                <Button
                  type="button"
                  variant={formData.preferences.pace === 'intensive' ? 'default' : 'outline'}
                  onClick={() => handlePaceChange('intensive')}
                >
                  Intensive
                </Button>
              </div>
            </div>
            
            {formData.preferences.type === 'business' && formData.meetingDetails && (
              <div className="space-y-3 border rounded-md p-3 bg-muted/20">
                <Label className="font-medium">Meeting Details</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label htmlFor="meetingTime" className="text-xs">Meeting Time</Label>
                    <Input
                      type="time"
                      id="meetingTime"
                      value={formData.meetingDetails.time}
                      onChange={(e) => handleMeetingDetailsChange('time', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="duration" className="text-xs">Duration (min)</Label>
                    <Select
                      value={formData.meetingDetails.duration.toString()}
                      onValueChange={(val) => handleMeetingDetailsChange('duration', parseInt(val))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">60 minutes</SelectItem>
                        <SelectItem value="90">90 minutes</SelectItem>
                        <SelectItem value="120">2 hours</SelectItem>
                        <SelectItem value="180">3 hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="attendees" className="text-xs">Number of Attendees</Label>
                    <Input
                      type="number"
                      id="attendees"
                      min={1}
                      max={50}
                      value={formData.meetingDetails.attendees}
                      onChange={(e) => handleMeetingDetailsChange('attendees', parseInt(e.target.value))}
                    />
                  </div>
                </div>
              </div>
            )}
            
            <div className="space-y-3">
              <Label>Interests (Select all that apply)</Label>
              <div className="grid grid-cols-2 gap-2">
                {interests.map((interest) => (
                  <div
                    key={interest.id}
                    className={`flex items-center border rounded-md p-2 cursor-pointer transition-colors ${
                      formData.preferences.interests.includes(interest.id)
                        ? 'border-primary bg-primary/10'
                        : 'border-input hover:bg-muted/50'
                    }`}
                    onClick={() => handleInterestToggle(interest.id)}
                  >
                    <Checkbox
                      id={`interest-${interest.id}`}
                      checked={formData.preferences.interests.includes(interest.id)}
                      className="mr-2"
                    />
                    <Label
                      htmlFor={`interest-${interest.id}`}
                      className="flex-1 cursor-pointer text-sm"
                    >
                      <span className="mr-1">{interest.icon}</span> {interest.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={goToPreviousStep}>
              Back
            </Button>
            <Button 
              onClick={goToNextStep} 
              disabled={generatePlanMutation.isPending}
            >
              {generatePlanMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                'Generate Trip Plan'
              )}
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {/* Step 3: Generated Trip Plan */}
      {currentStep === 3 && tripPlan && (
        <div className="space-y-4">
          <Card className="bg-muted/30">
            <CardHeader className="pb-2">
              <CardTitle>Your Trip Plan is Ready!</CardTitle>
              <CardDescription>
                We've created a personalized itinerary for your trip to {formData.destination}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-sm flex items-center">
                  <CalendarIcon2 className="h-3.5 w-3.5 mr-1" />
                  {format(new Date(tripPlan.startDate), 'MMM d')} - {format(new Date(tripPlan.endDate), 'MMM d, yyyy')}
                </div>
                <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-sm flex items-center">
                  <Clock className="h-3.5 w-3.5 mr-1" />
                  {formData.preferences.pace} pace
                </div>
                <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-sm flex items-center">
                  <User className="h-3.5 w-3.5 mr-1" />
                  {formData.preferences.type} trip
                </div>
                {formData.preferences.interests.length > 0 && (
                  <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-sm flex items-center truncate max-w-[200px]">
                    <Heart className="h-3.5 w-3.5 mr-1 shrink-0" />
                    <span className="truncate">
                      {formData.preferences.interests.map(id => 
                        interests.find(i => i.id === id)?.label
                      ).join(', ')}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          <TripPlanView 
            plan={tripPlan} 
            onBookActivity={handleBookActivity}
            onExportPlan={handleExportPlan}
          />
          
          <div className="flex justify-between">
            <Button variant="outline" onClick={goToPreviousStep}>
              Adjust Preferences
            </Button>
            <Button variant="default" onClick={() => setCurrentStep(1)}>
              Plan New Trip
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}