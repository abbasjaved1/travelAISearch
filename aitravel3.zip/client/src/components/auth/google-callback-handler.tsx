import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import { Button } from '@/components/ui/button';

export default function GoogleCallbackHandler() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [attempts, setAttempts] = useState(0);
  
  useEffect(() => {
    console.log('Google callback handler mounted');
    
    // Check if the URL contains an error parameter
    const urlParams = new URLSearchParams(window.location.search);
    const errorParam = urlParams.get('error');
    
    if (errorParam) {
      console.error('Google auth error parameter:', errorParam);
      setError('Google authentication failed. Please try again.');
      setLoading(false);
      return;
    }
    
    // Check if user is already authenticated
    if (user) {
      console.log('User already authenticated, redirecting to dashboard');
      // User is already authenticated, redirect to dashboard
      setLocation('/');
      return;
    }
    
    // The Google auth will automatically create the session
    // Poll for authentication status
    const checkAuthStatus = async () => {
      try {
        console.log('Checking auth status, attempt:', attempts + 1);
        const response = await fetch('/api/user');
        if (response.ok) {
          console.log('User authenticated successfully');
          // User is now authenticated, redirect to dashboard
          setLocation('/');
        } else {
          // Still not authenticated, wait and try again
          setAttempts(prev => prev + 1);
          if (attempts < 10) {
            setTimeout(checkAuthStatus, 1000);
          } else {
            setError('Authentication timed out. Please try again.');
            setLoading(false);
          }
        }
      } catch (err) {
        console.error('Error checking auth status:', err);
        setError('Error checking authentication status. Please try again.');
        setLoading(false);
      }
    };
    
    // Start polling
    checkAuthStatus();
    
  }, [user, setLocation, attempts]);
  
  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-gray-50">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="bg-blue-50">
          <CardTitle className="text-center text-blue-700">Google Authentication</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 p-6">
          {loading ? (
            <div className="flex flex-col items-center space-y-4 py-6">
              <Spinner size="lg" />
              <p className="text-center text-muted-foreground">
                Processing your Google sign-in...
              </p>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mt-4">
                <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${Math.min(attempts * 10, 100)}%` }}></div>
              </div>
            </div>
          ) : error ? (
            <div className="space-y-4">
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
              <div className="flex justify-center mt-4">
                <Button 
                  onClick={() => window.location.href = '/auth'} 
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Return to Login
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}