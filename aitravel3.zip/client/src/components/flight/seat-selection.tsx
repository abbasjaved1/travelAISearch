import React, { useState, useEffect } from 'react';
import { Seat } from '@/shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ArrowRight, Info } from 'lucide-react';

interface SeatSelectionProps {
  flightId: string;
  onComplete: (selectedSeats: Seat[]) => void;
  onBack: () => void;
  numPassengers: number;
}

export function SeatSelection({ flightId, onComplete, onBack, numPassengers }: SeatSelectionProps) {
  const [availableSeats, setAvailableSeats] = useState<Seat[]>([]);
  const [selectedSeats, setSelectedSeats] = useState<Seat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real application, we would fetch available seats from the API
    // For demonstration, we'll generate a sample seat map
    const generateSeatMap = () => {
      const seatMap: Seat[] = [];
      const rows = 30;
      const cols = ['A', 'B', 'C', 'D', 'E', 'F'];
      const randomlyOccupy = () => Math.random() > 0.7; // 30% chance a seat is occupied

      for (let row = 1; row <= rows; row++) {
        for (let colIndex = 0; colIndex < cols.length; colIndex++) {
          const col = cols[colIndex];
          
          // Create aisle seat types
          let type: "window" | "middle" | "aisle" = "middle";
          if (col === 'A' || col === 'F') type = "window";
          if (col === 'C' || col === 'D') type = "aisle";
          
          // Determine if seat is occupied
          const status = randomlyOccupy() ? "occupied" : "available";
          
          // Add higher prices for window and aisle seats, emergency exit rows
          let price = 0;
          if (row <= 5) price = 75; // First class
          else if (row >= 14 && row <= 16) price = 45; // Emergency exit rows
          else if (type === "window") price = 30;
          else if (type === "aisle") price = 25;
          else price = 15; // Middle seats
          
          seatMap.push({
            id: `${row}${col}`,
            row,
            column: col,
            type,
            status: status,
            price
          });
        }
      }
      
      return seatMap;
    };

    // Simulate API delay
    setTimeout(() => {
      setAvailableSeats(generateSeatMap());
      setLoading(false);
    }, 800);
  }, [flightId]);

  // Handle seat selection
  const handleSeatClick = (seat: Seat) => {
    if (seat.status === "occupied") return;
    
    const seatIndex = selectedSeats.findIndex(s => s.id === seat.id);
    
    if (seatIndex > -1) {
      // Unselect the seat
      const updatedSelectedSeats = [...selectedSeats];
      updatedSelectedSeats.splice(seatIndex, 1);
      setSelectedSeats(updatedSelectedSeats);
    } else {
      // Check if we've reached the maximum number of seats
      if (selectedSeats.length >= numPassengers) {
        // Replace the first selected seat
        const updatedSelectedSeats = [...selectedSeats.slice(1), seat];
        setSelectedSeats(updatedSelectedSeats);
      } else {
        // Select the seat
        setSelectedSeats([...selectedSeats, seat]);
      }
    }
  };

  // Get seat color based on status and type
  const getSeatColor = (seat: Seat) => {
    // If seat is selected
    if (selectedSeats.some(s => s.id === seat.id)) {
      return "bg-blue-600 text-white hover:bg-blue-700";
    }
    
    // If seat is occupied
    if (seat.status === "occupied") {
      return "bg-gray-300 text-gray-500 cursor-not-allowed";
    }
    
    // Available seats by type
    switch (seat.type) {
      case "window":
        return "bg-green-100 hover:bg-green-200 text-green-800";
      case "aisle":
        return "bg-purple-100 hover:bg-purple-200 text-purple-800";
      default:
        return "bg-gray-100 hover:bg-gray-200 text-gray-800";
    }
  };

  // Calculate total price for selected seats
  const calculateTotalPrice = () => {
    return selectedSeats.reduce((total, seat) => total + (seat.price || 0), 0);
  };

  // Check if selection is complete
  const isSelectionComplete = selectedSeats.length === numPassengers;

  // Handle completion
  const handleComplete = () => {
    onComplete(selectedSeats);
  };

  // Group seats by row for display
  const seatsByRow = availableSeats.reduce((acc, seat) => {
    if (!acc[seat.row]) acc[seat.row] = [];
    acc[seat.row].push(seat);
    return acc;
  }, {} as Record<number, Seat[]>);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl">Select Your Seats</CardTitle>
        <CardDescription>
          {isSelectionComplete 
            ? `${numPassengers} seats selected - Total: $${calculateTotalPrice()}`
            : `Please select ${numPassengers} seats (${selectedSeats.length} selected)`
          }
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center h-60">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="flex justify-between items-center px-4">
              <span className="text-sm">Front of aircraft</span>
              <div className="flex gap-2">
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                  Window
                </Badge>
                <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
                  Aisle
                </Badge>
                <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
                  Middle
                </Badge>
              </div>
            </div>
            
            <div className="relative overflow-auto max-h-[400px] p-2 border rounded-md">
              <div className="w-full">
                {Object.keys(seatsByRow).map(rowNum => (
                  <div key={rowNum} className="flex justify-between mb-1 relative">
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 -ml-2 w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-xs font-semibold">
                      {rowNum}
                    </div>
                    {seatsByRow[Number(rowNum)].map((seat: Seat, index: number) => (
                      <React.Fragment key={seat.id}>
                        <button
                          className={`w-10 h-10 rounded text-xs font-medium flex items-center justify-center ${getSeatColor(seat)}`}
                          onClick={() => handleSeatClick(seat)}
                          disabled={seat.status === "occupied"}
                        >
                          {seat.column}
                          {selectedSeats.findIndex(s => s.id === seat.id) > -1 && (
                            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-blue-700 text-white text-[9px] flex items-center justify-center">
                              {selectedSeats.findIndex(s => s.id === seat.id) + 1}
                            </span>
                          )}
                        </button>
                        {/* Add gap for aisle */}
                        {(index === 2) && <div className="w-5"></div>}
                      </React.Fragment>
                    ))}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-2 p-3 border rounded-md bg-blue-50">
              <div className="flex items-start gap-2">
                <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium">Seat Selection Tips</h3>
                  <p className="text-xs text-gray-600">
                    Window seats offer views, while aisle seats provide easy access to lavatories. 
                    Emergency exit rows (14-16) have extra legroom but require ability to assist in emergencies.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mt-2">
                {selectedSeats.map((seat, index) => (
                  <div key={seat.id} className="text-xs bg-white p-2 rounded border">
                    <span className="font-medium">Passenger {index + 1}:</span> Seat {seat.row}{seat.column} 
                    <span className="text-green-600 ml-1">(${seat.price})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={onBack}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        
        <Button 
          onClick={handleComplete}
          disabled={!isSelectionComplete}
          className="flex items-center gap-2"
        >
          Confirm Seats
          <ArrowRight className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}