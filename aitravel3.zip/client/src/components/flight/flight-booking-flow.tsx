import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { FlightBooking, PassengerDetails, Seat } from '@/shared/schema';
import { PaymentForm } from '@/components/payment/payment-form';
import { PassengerForm } from './passenger-form';
import { SeatSelection } from './seat-selection';
import { FlightBookingSummary } from './flight-booking-summary';
import { X, Check } from 'lucide-react';

interface FlightBookingFlowProps {
  flight: FlightBooking;
  onCancel: () => void;
  onSuccess: () => void;
}

type BookingStep = 'passengers' | 'seats' | 'summary' | 'payment' | 'confirmation';

export function FlightBookingFlow({ flight, onCancel, onSuccess }: FlightBookingFlowProps) {
  const [currentStep, setCurrentStep] = useState<BookingStep>('passengers');
  const [passengerCount, setPassengerCount] = useState<number>(1);
  const [passengers, setPassengers] = useState<PassengerDetails[]>([]);
  const [selectedSeats, setSelectedSeats] = useState<Seat[]>([]);
  const [bookingReference, setBookingReference] = useState<string>('');
  const { toast } = useToast();

  // Initialize with the passenger count from flight search
  useState(() => {
    // This would normally come from the flight search params
    setPassengerCount(1);
  });

  // Handle passenger form completion
  const handlePassengerFormComplete = (passengerData: PassengerDetails[]) => {
    setPassengers(passengerData);
    setCurrentStep('seats');
  };

  // Handle seat selection completion
  const handleSeatSelectionComplete = (seats: Seat[]) => {
    setSelectedSeats(seats);
    setCurrentStep('summary');
  };

  // Handle proceed to payment
  const handleProceedToPayment = () => {
    setCurrentStep('payment');
  };

  // Handle payment success
  const handlePaymentSuccess = () => {
    // Generate a booking reference
    const referenceNumber = 'FL' + Math.random().toString(36).substring(2, 8).toUpperCase();
    setBookingReference(referenceNumber);
    setCurrentStep('confirmation');
    
    // Notify of successful booking
    toast({
      title: "Booking Successful",
      description: `Your booking reference is ${referenceNumber}`,
    });
  };

  // Handle back button
  const handleBack = () => {
    switch(currentStep) {
      case 'seats':
        setCurrentStep('passengers');
        break;
      case 'summary':
        setCurrentStep('seats');
        break;
      case 'payment':
        setCurrentStep('summary');
        break;
      default:
        onCancel();
    }
  };

  // Calculate the total amount for payment
  const calculateTotalAmount = () => {
    const flightBasePrice = flight.price * passengers.length;
    const seatUpgradeTotal = selectedSeats.reduce((total, seat) => total + (seat.price || 0), 0);
    return flightBasePrice + seatUpgradeTotal;
  };

  // Render confirmation screen
  const renderConfirmation = () => (
    <div className="bg-white rounded-lg shadow-lg p-8 max-w-3xl mx-auto text-center">
      <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
        <Check className="h-10 w-10 text-green-600" />
      </div>
      
      <h2 className="text-2xl font-bold mb-2">Booking Confirmed!</h2>
      <p className="text-gray-600 mb-6">Your flight has been successfully booked.</p>
      
      <div className="bg-blue-50 rounded-lg p-4 mb-6">
        <p className="text-sm text-gray-700 mb-2">Booking Reference</p>
        <p className="text-xl font-bold text-blue-700">{bookingReference}</p>
      </div>
      
      <div className="space-y-4 mb-8">
        <div className="flex justify-between px-4">
          <span className="font-medium">Flight</span>
          <span>{flight.id}</span>
        </div>
        
        <div className="flex justify-between px-4">
          <span className="font-medium">From</span>
          <span>{flight.from}</span>
        </div>
        
        <div className="flex justify-between px-4">
          <span className="font-medium">To</span>
          <span>{flight.to}</span>
        </div>
        
        <div className="flex justify-between px-4">
          <span className="font-medium">Date</span>
          <span>{new Date(flight.departure).toLocaleDateString()}</span>
        </div>
        
        <div className="flex justify-between px-4">
          <span className="font-medium">Passengers</span>
          <span>{passengers.length}</span>
        </div>
      </div>
      
      <div className="flex justify-center">
        <Button onClick={onSuccess} className="px-8">
          Done
        </Button>
      </div>
    </div>
  );

  return (
    <div className="relative bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Header with steps */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white relative">
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-2 top-2 text-white hover:bg-white/20"
          onClick={onCancel}
        >
          <X className="h-5 w-5" />
        </Button>
        
        <h2 className="text-xl font-bold mb-4">Book Your Flight</h2>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'passengers' || currentStep === 'seats' || currentStep === 'summary' || currentStep === 'payment' || currentStep === 'confirmation' ? 'bg-white text-blue-600' : 'bg-blue-400'}`}>
              1
            </div>
            <span className="text-sm hidden sm:inline">Passengers</span>
          </div>
          
          <div className="h-0.5 flex-1 bg-blue-400"></div>
          
          <div className="flex items-center gap-2 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'seats' || currentStep === 'summary' || currentStep === 'payment' || currentStep === 'confirmation' ? 'bg-white text-blue-600' : 'bg-blue-400'}`}>
              2
            </div>
            <span className="text-sm hidden sm:inline">Seats</span>
          </div>
          
          <div className="h-0.5 flex-1 bg-blue-400"></div>
          
          <div className="flex items-center gap-2 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'summary' || currentStep === 'payment' || currentStep === 'confirmation' ? 'bg-white text-blue-600' : 'bg-blue-400'}`}>
              3
            </div>
            <span className="text-sm hidden sm:inline">Summary</span>
          </div>
          
          <div className="h-0.5 flex-1 bg-blue-400"></div>
          
          <div className="flex items-center gap-2 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 'payment' || currentStep === 'confirmation' ? 'bg-white text-blue-600' : 'bg-blue-400'}`}>
              4
            </div>
            <span className="text-sm hidden sm:inline">Payment</span>
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-6">
        {currentStep === 'passengers' && (
          <PassengerForm
            numPassengers={passengerCount}
            onComplete={handlePassengerFormComplete}
            onBack={onCancel}
          />
        )}
        
        {currentStep === 'seats' && (
          <SeatSelection
            flightId={flight.id}
            numPassengers={passengerCount}
            onComplete={handleSeatSelectionComplete}
            onBack={handleBack}
          />
        )}
        
        {currentStep === 'summary' && (
          <FlightBookingSummary
            flight={flight}
            passengers={passengers}
            selectedSeats={selectedSeats}
            onProceedToPayment={handleProceedToPayment}
            onBack={handleBack}
          />
        )}
        
        {currentStep === 'payment' && (
          <PaymentForm
            amount={calculateTotalAmount()}
            onSuccess={handlePaymentSuccess}
            onCancel={handleBack}
            bookingType="flight"
            details={{
              flight,
              passengers,
              seat: selectedSeats[0] || null
            }}
          />
        )}
        
        {currentStep === 'confirmation' && renderConfirmation()}
      </div>
    </div>
  );
}