import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PassengerDetails } from '@/shared/schema';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, ArrowRight, User, Calendar, Flag, CreditCard } from 'lucide-react';

// Define the passenger form schema
const passengerSchema = z.object({
  firstName: z.string().min(2, { message: 'First name must be at least 2 characters' }),
  lastName: z.string().min(2, { message: 'Last name must be at least 2 characters' }),
  dateOfBirth: z.string().min(10, { message: 'Date of birth is required' }),
  nationality: z.string().min(2, { message: 'Nationality is required' }),
  passportNumber: z.string().optional(),
  specialRequirements: z.string().optional(),
});

// Define the form type
type PassengerFormValues = z.infer<typeof passengerSchema>;

// Nationality options
const nationalities = [
  "United States", "India", "United Kingdom", "Canada", "Australia",
  "Germany", "France", "Italy", "Spain", "Japan", "China", "Russia",
  "Brazil", "Mexico", "South Africa", "Nigeria", "Egypt", "Saudi Arabia",
  "United Arab Emirates", "Singapore", "Thailand", "Malaysia", "Indonesia",
  "Philippines", "New Zealand", "Argentina", "Chile", "Colombia", "Peru",
];

interface PassengerFormProps {
  numPassengers: number;
  onComplete: (passengers: PassengerDetails[]) => void;
  onBack: () => void;
}

export function PassengerForm({ numPassengers, onComplete, onBack }: PassengerFormProps) {
  const [currentPassenger, setCurrentPassenger] = useState(0);
  const [passengers, setPassengers] = useState<PassengerDetails[]>([]);
  const [sameAsFirst, setSameAsFirst] = useState(false);

  // Initialize form
  const form = useForm<PassengerFormValues>({
    resolver: zodResolver(passengerSchema),
    defaultValues: {
      firstName: passengers[currentPassenger]?.firstName || '',
      lastName: passengers[currentPassenger]?.lastName || '',
      dateOfBirth: passengers[currentPassenger]?.dateOfBirth || '',
      nationality: passengers[currentPassenger]?.nationality || '',
      passportNumber: passengers[currentPassenger]?.passportNumber || '',
      specialRequirements: passengers[currentPassenger]?.specialRequirements || '',
    },
  });

  // Handle form submission
  const onSubmit = (data: PassengerFormValues) => {
    const updatedPassengers = [...passengers];
    
    // Add current passenger data
    updatedPassengers[currentPassenger] = data;
    setPassengers(updatedPassengers);
    
    // If it's the last passenger, complete the process
    if (currentPassenger === numPassengers - 1) {
      onComplete(updatedPassengers);
    } else {
      // Move to next passenger
      setCurrentPassenger(currentPassenger + 1);
      
      // If "same as first passenger" is checked, pre-fill with data from first passenger
      if (currentPassenger === 0 || (currentPassenger > 0 && sameAsFirst)) {
        form.reset({
          ...updatedPassengers[0],
          specialRequirements: '',
        });
      } else {
        form.reset();
      }
    }
  };

  // Handle back button
  const handleBack = () => {
    if (currentPassenger === 0) {
      onBack();
    } else {
      setCurrentPassenger(currentPassenger - 1);
      form.reset(passengers[currentPassenger - 1]);
    }
  };

  // Handle same as first passenger checkbox
  const handleSameAsFirst = (checked: boolean) => {
    setSameAsFirst(checked);
    if (checked && passengers[0]) {
      form.reset({
        ...passengers[0],
        specialRequirements: form.getValues().specialRequirements,
      });
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl">Passenger Information</CardTitle>
        <CardDescription>
          {`Passenger ${currentPassenger + 1} of ${numPassengers}`}
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {currentPassenger > 0 && (
              <div className="flex items-center space-x-2 py-2 border-b mb-4">
                <Checkbox 
                  checked={sameAsFirst} 
                  onCheckedChange={(checked) => handleSameAsFirst(!!checked)} 
                  id="sameAsFirst" 
                />
                <label
                  htmlFor="sameAsFirst"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Same as first passenger
                </label>
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input placeholder="John" {...field} className="pl-10" />
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input placeholder="Doe" {...field} className="pl-10" />
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="dateOfBirth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date of Birth</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          type="date" 
                          placeholder="YYYY-MM-DD" 
                          {...field} 
                          className="pl-10"
                        />
                        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </FormControl>
                    <FormDescription>
                      Used for identity verification
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="nationality"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nationality</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <div className="relative">
                          <SelectTrigger className="pl-10">
                            <SelectValue placeholder="Select nationality" />
                          </SelectTrigger>
                          <Flag className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        </div>
                      </FormControl>
                      <SelectContent>
                        {nationalities.map((nationality) => (
                          <SelectItem key={nationality} value={nationality}>
                            {nationality}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="passportNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Passport Number (Optional)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input 
                        placeholder="Enter passport number" 
                        {...field} 
                        className="pl-10"
                      />
                      <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    </div>
                  </FormControl>
                  <FormDescription>
                    For international flights
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="specialRequirements"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Requirements (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Dietary restrictions, wheelchair assistance, etc." 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-between mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={handleBack}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              
              <Button 
                type="submit" 
                className="flex items-center gap-2"
              >
                {currentPassenger === numPassengers - 1 ? 'Complete' : 'Next Passenger'}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}