import { FlightBooking, PassengerDetails, Seat } from '@/shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { format, parseISO } from 'date-fns';
import { Plane, Calendar, Clock, Users, CreditCard, ArrowLeft, ArrowRight, Map } from 'lucide-react';

interface FlightBookingSummaryProps {
  flight: FlightBooking;
  passengers: PassengerDetails[];
  selectedSeats: Seat[];
  onProceedToPayment: () => void;
  onBack: () => void;
}

export function FlightBookingSummary({ 
  flight, 
  passengers, 
  selectedSeats, 
  onProceedToPayment, 
  onBack 
}: FlightBookingSummaryProps) {
  // Format date and time
  const formatDate = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      return format(date, 'EEE, MMM d, yyyy');
    } catch (error) {
      return dateString; // If parsing fails, return the original string
    }
  };

  const formatTime = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      return format(date, 'h:mm a');
    } catch (error) {
      return dateString; // If parsing fails, return the original string
    }
  };

  // Calculate duration in hours and minutes
  const calculateDuration = () => {
    if (!flight.departure || !flight.arrival) return 'N/A';
    
    try {
      const departureTime = parseISO(flight.departure);
      const arrivalTime = parseISO(flight.arrival);
      
      // Calculate duration in minutes
      const durationInMinutes = (arrivalTime.getTime() - departureTime.getTime()) / (1000 * 60);
      
      // Convert to hours and minutes
      const hours = Math.floor(durationInMinutes / 60);
      const minutes = Math.floor(durationInMinutes % 60);
      
      return `${hours}h ${minutes}m`;
    } catch (error) {
      return flight.duration || 'N/A';
    }
  };

  // Calculate subtotal for flight
  const flightSubtotal = flight.price * passengers.length;
  
  // Calculate seat upgrade total
  const seatUpgradeTotal = selectedSeats.reduce((total, seat) => total + (seat.price || 0), 0);
  
  // Calculate total price
  const totalPrice = flightSubtotal + seatUpgradeTotal;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl">Booking Summary</CardTitle>
        <CardDescription>
          Review your flight details before payment
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Flight Details */}
        <div className="rounded-lg border overflow-hidden">
          <div className="bg-blue-50 p-4 border-b">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Plane className="h-5 w-5 text-blue-600" />
                <h3 className="font-medium">Flight Details</h3>
              </div>
              <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                {flight.class || 'Economy'}
              </Badge>
            </div>
          </div>
          
          <div className="p-4 space-y-4">
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div className="space-y-1">
                <div className="text-sm text-gray-500">Airline</div>
                <div className="font-medium">{flight.airline}</div>
              </div>
              
              <div className="space-y-1">
                <div className="text-sm text-gray-500">Flight</div>
                <div className="font-medium">{flight.id}</div>
              </div>
              
              <div className="space-y-1">
                <div className="text-sm text-gray-500">Duration</div>
                <div className="font-medium">{flight.duration || calculateDuration()}</div>
              </div>
              
              <div className="space-y-1">
                <div className="text-sm text-gray-500">Stops</div>
                <div className="font-medium">
                  {flight.stops ? `${flight.stops} ${flight.stops === 1 ? 'stop' : 'stops'}` : 'Direct'}
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Map className="h-4 w-4 text-gray-400" />
                  <span className="text-sm font-medium">Departure</span>
                </div>
                <div className="ml-6 space-y-1">
                  <div className="text-lg font-bold">{flight.from}</div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <span className="text-sm">{formatDate(flight.departure)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gray-400" />
                    <span className="text-sm">{formatTime(flight.departure)}</span>
                  </div>
                </div>
              </div>
              
              <div className="hidden md:flex items-center justify-center">
                <div className="w-24 h-0.5 bg-gray-300 relative">
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-blue-600"></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Map className="h-4 w-4 text-gray-400" />
                  <span className="text-sm font-medium">Arrival</span>
                </div>
                <div className="ml-6 space-y-1">
                  <div className="text-lg font-bold">{flight.to}</div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <span className="text-sm">{formatDate(flight.arrival)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gray-400" />
                    <span className="text-sm">{formatTime(flight.arrival)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Passenger Details */}
        <div className="rounded-lg border overflow-hidden">
          <div className="bg-blue-50 p-4 border-b">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-600" />
              <h3 className="font-medium">Passenger Details</h3>
            </div>
          </div>
          
          <div className="p-4">
            <div className="space-y-4">
              {passengers.map((passenger, index) => (
                <div key={index} className="flex flex-col md:flex-row justify-between border-b pb-3 last:border-0 last:pb-0">
                  <div className="space-y-1">
                    <div className="text-sm text-gray-500">Passenger {index + 1}</div>
                    <div className="font-medium">{passenger.firstName} {passenger.lastName}</div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-sm text-gray-500">Nationality</div>
                    <div className="font-medium">{passenger.nationality}</div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-sm text-gray-500">Seat</div>
                    <div className="font-medium">
                      {selectedSeats[index] ? `${selectedSeats[index].row}${selectedSeats[index].column}` : 'Not assigned'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Price Breakdown */}
        <div className="rounded-lg border overflow-hidden">
          <div className="bg-blue-50 p-4 border-b">
            <div className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-blue-600" />
              <h3 className="font-medium">Price Details</h3>
            </div>
          </div>
          
          <div className="p-4">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Base fare ({passengers.length} {passengers.length === 1 ? 'passenger' : 'passengers'})</span>
                <span>${flightSubtotal.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Seat selection</span>
                <span>${seatUpgradeTotal.toFixed(2)}</span>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span className="text-blue-700">${totalPrice.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={onBack}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        
        <Button 
          onClick={onProceedToPayment}
          className="flex items-center gap-2"
        >
          Proceed to Payment
          <ArrowRight className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}