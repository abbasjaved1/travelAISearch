import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CreditCard, Calendar, Check, Shield, Loader2 } from 'lucide-react';

interface BookingDetails {
  flight?: any;
  hotel?: any;
  dining?: any;
  ride?: any;
  seat?: any;
  passengers?: any;
}

interface PaymentFormProps {
  amount: number;
  bookingType: 'flight' | 'hotel' | 'dining' | 'ride';
  details: BookingDetails;
  onSuccess: () => void;
  onCancel: () => void;
}

export function PaymentForm({ amount, bookingType, details, onSuccess, onCancel }: PaymentFormProps) {
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'netbanking' | 'wallet'>('card');
  const [isLoading, setIsLoading] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    number: '',
    name: '',
    expiry: '',
    cvc: '',
  });
  const [upiId, setUpiId] = useState('');
  const [bankSelected, setBankSelected] = useState('');
  const [walletSelected, setWalletSelected] = useState('');
  
  const banks = [
    { id: 'hdfc', name: 'HDFC Bank' },
    { id: 'icici', name: 'ICICI Bank' },
    { id: 'sbi', name: 'State Bank of India' },
    { id: 'axis', name: 'Axis Bank' },
    { id: 'yes', name: 'Yes Bank' },
  ];
  
  const wallets = [
    { id: 'paytm', name: 'Paytm' },
    { id: 'phonepe', name: 'PhonePe' },
    { id: 'amazonpay', name: 'Amazon Pay' },
    { id: 'gpay', name: 'Google Pay' },
  ];
  
  const handleCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCardDetails({ ...cardDetails, [name]: value });
  };
  
  const validateForm = () => {
    if (paymentMethod === 'card') {
      if (!cardDetails.number || !cardDetails.name || !cardDetails.expiry || !cardDetails.cvc) {
        toast({
          title: 'Incomplete details',
          description: 'Please fill in all card details',
          variant: 'destructive',
        });
        return false;
      }
      
      // Simple validation for card number (16 digits)
      if (cardDetails.number.replace(/\s/g, '').length !== 16) {
        toast({
          title: 'Invalid card number',
          description: 'Please enter a valid 16-digit card number',
          variant: 'destructive',
        });
        return false;
      }
    } else if (paymentMethod === 'upi') {
      if (!upiId || !upiId.includes('@')) {
        toast({
          title: 'Invalid UPI ID',
          description: 'Please enter a valid UPI ID (e.g., username@upi)',
          variant: 'destructive',
        });
        return false;
      }
    } else if (paymentMethod === 'netbanking') {
      if (!bankSelected) {
        toast({
          title: 'Bank not selected',
          description: 'Please select a bank for net banking',
          variant: 'destructive',
        });
        return false;
      }
    } else if (paymentMethod === 'wallet') {
      if (!walletSelected) {
        toast({
          title: 'Wallet not selected',
          description: 'Please select a digital wallet',
          variant: 'destructive',
        });
        return false;
      }
    }
    
    return true;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate API call for payment processing
      await new Promise((resolve) => setTimeout(resolve, 2000));
      
      // Success case
      toast({
        title: 'Payment successful',
        description: `Your ${bookingType} has been booked successfully`,
      });
      
      onSuccess();
    } catch (error) {
      console.error('Payment error:', error);
      toast({
        title: 'Payment failed',
        description: 'There was an error processing your payment. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const getPaymentMethodLabel = () => {
    switch (paymentMethod) {
      case 'card': return 'Credit/Debit Card';
      case 'upi': return 'UPI Payment';
      case 'netbanking': return 'Net Banking';
      case 'wallet': return 'Digital Wallet';
      default: return 'Payment';
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium">{bookingType.charAt(0).toUpperCase() + bookingType.slice(1)} Booking</h3>
            {details[bookingType] && (
              <p className="text-sm text-muted-foreground">
                {bookingType === 'flight' && details.flight && `${details.flight.airline} - ${details.flight.from} to ${details.flight.to}`}
                {bookingType === 'hotel' && details.hotel && `${details.hotel.name}, ${details.hotel.location}`}
                {bookingType === 'dining' && details.dining && `${details.dining.restaurant}, ${details.dining.cuisine}`}
                {bookingType === 'ride' && details.ride && `${details.ride.type} - ${details.ride.from} to ${details.ride.to}`}
              </p>
            )}
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold">${amount.toFixed(2)}</span>
            <p className="text-xs text-muted-foreground">Total amount</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="card" onValueChange={(value) => setPaymentMethod(value as any)}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="card">Card</TabsTrigger>
          <TabsTrigger value="upi">UPI</TabsTrigger>
          <TabsTrigger value="netbanking">NetBanking</TabsTrigger>
          <TabsTrigger value="wallet">Wallet</TabsTrigger>
        </TabsList>
        
        <TabsContent value="card" className="space-y-4 py-4">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label htmlFor="number">Card Number</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  id="number" 
                  name="number" 
                  placeholder="1234 5678 9012 3456" 
                  className="pl-10"
                  value={cardDetails.number}
                  onChange={handleCardChange}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="name">Cardholder Name</Label>
              <Input 
                id="name" 
                name="name" 
                placeholder="John Doe" 
                value={cardDetails.name}
                onChange={handleCardChange}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiry">Expiry Date</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="expiry" 
                    name="expiry" 
                    placeholder="MM/YY"
                    className="pl-10"
                    value={cardDetails.expiry}
                    onChange={handleCardChange}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cvc">CVC</Label>
                <Input 
                  id="cvc" 
                  name="cvc" 
                  placeholder="123"
                  value={cardDetails.cvc}
                  onChange={handleCardChange}
                />
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="upi" className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="upi-id">UPI ID</Label>
            <Input 
              id="upi-id" 
              placeholder="username@upi" 
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
            />
            <p className="text-sm text-muted-foreground">Enter your UPI ID and you'll receive a payment request.</p>
          </div>
          
          <div className="flex items-center p-3 border rounded-md bg-muted/50">
            <div className="mr-3 bg-primary/10 p-2 rounded-full">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <div className="text-sm">
              <p className="font-medium">Secure UPI Payment</p>
              <p className="text-muted-foreground">Your payment is protected with end-to-end encryption</p>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="netbanking" className="space-y-4 py-4">
          <RadioGroup value={bankSelected} onValueChange={setBankSelected}>
            {banks.map((bank) => (
              <div key={bank.id} className="flex items-center space-x-2 py-2">
                <RadioGroupItem value={bank.id} id={`bank-${bank.id}`} />
                <Label htmlFor={`bank-${bank.id}`} className="flex-1 cursor-pointer">
                  {bank.name}
                </Label>
              </div>
            ))}
          </RadioGroup>
          
          <p className="text-sm text-muted-foreground">You will be redirected to your bank's website to complete the payment.</p>
        </TabsContent>
        
        <TabsContent value="wallet" className="space-y-4 py-4">
          <RadioGroup value={walletSelected} onValueChange={setWalletSelected}>
            {wallets.map((wallet) => (
              <div key={wallet.id} className="flex items-center space-x-2 py-2">
                <RadioGroupItem value={wallet.id} id={`wallet-${wallet.id}`} />
                <Label htmlFor={`wallet-${wallet.id}`} className="flex-1 cursor-pointer">
                  {wallet.name}
                </Label>
              </div>
            ))}
          </RadioGroup>
          
          <p className="text-sm text-muted-foreground">You'll be redirected to complete the payment with your selected wallet.</p>
        </TabsContent>
      </Tabs>
      
      <Separator />
      
      <div className="pt-2 flex justify-between gap-4">
        <Button 
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={isLoading}
        >
          Cancel
        </Button>
        
        <Button 
          type="submit"
          disabled={isLoading}
          className="flex-1"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              Pay ${amount.toFixed(2)} with {getPaymentMethodLabel()}
            </>
          )}
        </Button>
      </div>
    </form>
  );
}