import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  Plane,
  Building2,
  Car,
  UtensilsCrossed,
  User,
  LogOut,
  Book,
  Bot,
  Home,
  Route,
  Music,
  Menu,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { FloatingChat } from "@/components/ui/floating-chat";
import { useIsMobile } from "@/hooks/use-mobile";
import { useMobileOptimization } from "@/hooks/use-mobile-optimization";
import { useState } from "react";
import { MobileNavigation, MobileNavigationItem } from "./mobile-container";

export default function DashboardNav() {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const isMobile = useIsMobile();
  const deviceInfo = useMobileOptimization();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", icon: Home, label: "Dashboard" },
    { href: "/flights", icon: Plane, label: "Flights" },
    { href: "/hotels", icon: Building2, label: "Hotels" },
    { href: "/rides", icon: Car, label: "Rides" },
    { href: "/dining", icon: UtensilsCrossed, label: "Dining" },
    { href: "/trip-planner", icon: Route, label: "AI Trip Planner" },
    { href: "/soundtrack", icon: Music, label: "Travel Soundtrack" },
    { href: "/memories", icon: Book, label: "Memories" },
    { href: "/chatbot", icon: Bot, label: "Travel Assistant" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  // Mobile navigation items (limited to 5 for bottom bar)
  const mobileNavItems = [
    { href: "/", icon: <Home className="w-5 h-5" />, label: "Home" },
    { href: "/flights", icon: <Plane className="w-5 h-5" />, label: "Flights" },
    { href: "/trip-planner", icon: <Route className="w-5 h-5" />, label: "Plan" },
    { href: "/soundtrack", icon: <Music className="w-5 h-5" />, label: "Music" },
    { href: "/profile", icon: <User className="w-5 h-5" />, label: "Profile" },
  ];

  // If we're on mobile, render mobile navigation
  if (isMobile) {
    return (
      <>
        {/* Mobile slide-in menu */}
        <div 
          className={`
            fixed inset-0 bg-background/80 backdrop-blur-sm z-50 
            transition-all duration-300 ease-in-out
            ${mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}
          `}
          onClick={() => setMobileMenuOpen(false)}
        >
          <div 
            className={`
              absolute top-0 left-0 h-full w-3/4 max-w-xs bg-background shadow-lg
              transform transition-transform duration-300 ease-in-out
              pt-safe-top pb-safe-bottom
              ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
            `}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b">
              <div className="text-xl font-bold text-primary">AITravelGlobe</div>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setMobileMenuOpen(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            
            <div className="p-4 space-y-4">
              {navItems.map(({ href, icon: Icon, label }) => (
                <Link key={href} href={href}>
                  <a 
                    className={`flex items-center space-x-3 p-3 rounded-md transition-colors
                      ${location === href 
                        ? "bg-primary text-primary-foreground" 
                        : "hover:bg-primary/10"
                      }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{label}</span>
                  </a>
                </Link>
              ))}
              
              <div className="pt-4 border-t mt-4">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => logoutMutation.mutate()}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Top mobile header with menu button */}
        <div className={`
          fixed top-0 left-0 right-0 h-[60px] 
          bg-background shadow-sm z-40 
          flex items-center justify-between px-4
          ${deviceInfo.isIOS ? 'pt-[var(--safe-area-inset-top)]' : 'pt-0'}
        `}>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div className="text-lg font-bold text-primary">AITravelGlobe</div>
          <div className="w-9"></div> {/* Spacer for symmetry */}
        </div>
        
        {/* Bottom mobile navigation */}
        <MobileNavigation>
          {mobileNavItems.map(({ href, icon, label }) => (
            <MobileNavigationItem
              key={href}
              icon={icon}
              label={label}
              isActive={location === href}
              onClick={() => window.location.href = href}
            />
          ))}
        </MobileNavigation>
        
        <FloatingChat />
      </>
    );
  }

  // Desktop navigation
  return (
    <>
      <nav className="flex flex-col h-full p-4 space-y-2">
        <div className="text-xl font-bold mb-8 text-primary">AITravelGlobe</div>

        <div className="flex flex-col space-y-2">
          {navItems.map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}>
              <a 
                className={`flex items-center space-x-2 p-2 rounded-lg transition-colors
                  ${location === href 
                    ? "bg-primary text-primary-foreground" 
                    : "hover:bg-primary/10"
                  }`}
              >
                <Icon className="w-5 h-5" />
                <span>{label}</span>
              </a>
            </Link>
          ))}
        </div>

        <div className="mt-auto">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </nav>
      <FloatingChat />
    </>
  );
}