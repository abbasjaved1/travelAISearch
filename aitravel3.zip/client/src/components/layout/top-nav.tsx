import { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { Logo } from '@/components/ui/logo';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Plane,
  Hotel,
  Car,
  Utensils,
  Map,
  Headphones,
  Bell,
  Menu,
  User,
  LogOut,
  Settings,
  BookMarked,
  Sparkles,
  MessageSquare,
  LucideIcon,
} from 'lucide-react';

interface NavItem {
  icon: LucideIcon;
  label: string;
  href: string;
  isNew?: boolean;
}

export function TopNav() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: NavItem[] = [
    { icon: Plane, label: 'Flights', href: '/flights' },
    { icon: Hotel, label: 'Hotels', href: '/hotels' },
    { icon: Car, label: 'Rides', href: '/rides' },
    { icon: Utensils, label: 'Dining', href: '/dining' },
    { icon: Map, label: 'Destination Guide', href: '/destinations/explore', isNew: true },
    { icon: BookMarked, label: 'Trip Planner', href: '/trip-planner/complete' },
    { icon: Sparkles, label: 'Inspiration', href: '/inspiration' },
    { icon: Headphones, label: 'Soundtrack', href: '/soundtrack' },
    { icon: MessageSquare, label: 'Chat', href: '/chatbot' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="flex items-center mr-4">
          <Link href="/">
            <a className="flex items-center">
              <Logo className="h-8 w-auto" />
            </a>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-4 lg:space-x-6 flex-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a className={`flex items-center text-sm font-medium transition-colors ${
                location === item.href 
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-primary'
              }`}>
                <item.icon className="h-4 w-4 mr-1" />
                {item.label}
                {item.isNew && (
                  <Badge variant="outline" className="ml-1 bg-primary/10 text-[9px] py-0 h-4">NEW</Badge>
                )}
              </a>
            </Link>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Profile and Notifications */}
        <div className="ml-auto flex items-center space-x-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <div className="flex flex-col">
                  <span className="font-medium">New deals available</span>
                  <span className="text-xs text-muted-foreground">Check our latest offers</span>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <div className="flex flex-col">
                  <span className="font-medium">Trip reminder</span>
                  <span className="text-xs text-muted-foreground">Your trip to Paris is in 3 days</span>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.avatar} alt={user?.display_name || 'User'} />
                  <AvatarFallback>{user?.display_name?.[0] || 'U'}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                <Link href="/profile">
                  <a>Profile</a>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <Link href="/profile/preferences">
                  <a>Settings</a>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t py-2 px-4 space-y-2">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a
                className={`flex items-center p-2 rounded-md ${
                  location === item.href
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                <item.icon className="h-5 w-5 mr-3" />
                {item.label}
                {item.isNew && (
                  <Badge variant="outline" className="ml-2 bg-primary/10 text-[9px] py-0 h-4">NEW</Badge>
                )}
              </a>
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}

export default TopNav;