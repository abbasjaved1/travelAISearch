
import React, { useEffect } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useMobileOptimization } from "@/hooks/use-mobile-optimization";

interface MobileContainerProps {
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
  noPadding?: boolean;
  useBottomNav?: boolean;
  safeAreaTop?: boolean;
  safeAreaBottom?: boolean;
  preventScroll?: boolean;
  style?: React.CSSProperties;
}

export function MobileContainer({ 
  children, 
  className = "", 
  fullWidth = false,
  noPadding = false,
  useBottomNav = false,
  safeAreaTop = false,
  safeAreaBottom = false,
  preventScroll = false,
  style = {}
}: MobileContainerProps) {
  const isMobile = useIsMobile();
  const deviceInfo = useMobileOptimization();
  
  // Determine device-specific classes
  const deviceClasses = [];
  
  if (isMobile) {
    deviceClasses.push('mobile-container');
    
    if (useBottomNav) {
      deviceClasses.push('has-bottom-nav');
    }
    
    if (preventScroll) {
      deviceClasses.push('overflow-hidden');
    }
  }
  
  // Add safe area classes for modern iOS devices
  const safeAreaClasses = [];
  if (safeAreaTop && deviceInfo.isIOS) {
    safeAreaClasses.push('pt-[var(--safe-area-inset-top)]');
  }
  
  if (safeAreaBottom && deviceInfo.isIOS) {
    safeAreaClasses.push('pb-[var(--safe-area-inset-bottom)]');
  }
  
  return (
    <div 
      className={`
        ${isMobile ? 'max-w-full' : (fullWidth ? 'max-w-full' : 'max-w-7xl')} 
        ${!noPadding ? (isMobile ? 'px-4' : 'px-6 lg:px-8') : ''}
        mx-auto w-full
        ${deviceClasses.join(' ')}
        ${safeAreaClasses.join(' ')}
        ${className}
      `}
      style={{
        ...style,
        ...(isMobile && {
          minHeight: deviceInfo.isIOS ? 'calc(100 * var(--vh))' : '100vh'
        })
      }}
    >
      {children}
    </div>
  );
}

/**
 * Mobile page container that automatically handles safe areas and device-specific styling
 */
export function MobilePage({ 
  children, 
  className = "",
  fullWidth = false,
  hasBottomNav = true
}: {
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
  hasBottomNav?: boolean;
}) {
  const deviceInfo = useMobileOptimization();
  
  return (
    <MobileContainer 
      className={`mobile-page ${className}`}
      fullWidth={fullWidth}
      useBottomNav={hasBottomNav}
      safeAreaTop
      safeAreaBottom
    >
      {children}
    </MobileContainer>
  );
}

/**
 * Mobile bottom navigation component that respects safe areas on iOS devices
 */
export function MobileNavigation({ children }: { children: React.ReactNode }) {
  const deviceInfo = useMobileOptimization();
  
  return (
    <div className={`
      mobile-menu
      ${deviceInfo.isIOS ? 'ios-fixed-fix' : ''}
    `}>
      {children}
    </div>
  );
}

/**
 * Mobile navigation item component
 */
export function MobileNavigationItem({ 
  icon, 
  label, 
  isActive, 
  onClick 
}: { 
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}) {
  const deviceInfo = useMobileOptimization();
  
  return (
    <div 
      className={`
        mobile-menu-item 
        ${isActive ? 'active' : ''}
        ${deviceInfo.isAndroid ? 'android-ripple' : ''}
      `}
      onClick={onClick}
    >
      <div className="mobile-menu-item-icon">{icon}</div>
      <div>{label}</div>
    </div>
  );
}

/**
 * Mobile-optimized bottom sheet component
 */
export function MobileBottomSheet({ 
  children, 
  isOpen, 
  onClose 
}: { 
  children: React.ReactNode;
  isOpen: boolean;
  onClose: () => void;
}) {
  const deviceInfo = useMobileOptimization();
  
  // Prevent body scroll when sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);
  
  if (!isOpen) return null;
  
  return (
    <>
      <div 
        className="fixed inset-0 bg-black/50 z-50 animate-in fade-in" 
        onClick={onClose}
      />
      <div className={`
        mobile-bottom-sheet 
        ${isOpen ? 'open' : ''}
      `}>
        <div className="mobile-bottom-sheet-handle" />
        {children}
      </div>
    </>
  );
}
