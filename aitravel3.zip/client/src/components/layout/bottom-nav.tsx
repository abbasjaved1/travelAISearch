import React from 'react';
import { useLocation, Link } from 'wouter';
import { Badge } from '@/components/ui/badge';
import {
  Plane,
  Hotel,
  Utensils,
  Map,
  MessageSquare,
  Home,
  BookMarked,
  User,
  Sparkles,
  LucideIcon
} from 'lucide-react';

interface NavItem {
  icon: LucideIcon;
  label: string;
  href: string;
  isNew?: boolean;
}

export function BottomNav() {
  const [location] = useLocation();

  const navItems: NavItem[] = [
    { icon: Home, label: 'Home', href: '/' },
    { icon: Plane, label: 'Flights', href: '/flights' },
    { icon: Hotel, label: 'Hotels', href: '/hotels' },
    { icon: Utensils, label: 'Dining', href: '/dining' },
    { icon: BookMarked, label: 'Plan', href: '/trip-planner/complete' },
    { icon: Map, label: 'Explore', href: '/destinations/explore', isNew: true },
    { icon: Sparkles, label: 'Inspire', href: '/inspiration' },
    { icon: MessageSquare, label: 'Chat', href: '/chatbot' },
    { icon: User, label: 'Profile', href: '/profile' }
  ];

  // Show only the most important items on mobile
  const mobileNavItems = navItems.slice(0, 5);

  return (
    <nav className="md:hidden fixed bottom-0 left-0 z-40 w-full h-16 bg-background border-t">
      <div className="grid grid-cols-5 h-full">
        {mobileNavItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <a className="flex flex-col items-center justify-center h-full">
              <div className="relative">
                <item.icon
                  className={`h-5 w-5 ${
                    location === item.href
                      ? 'text-primary'
                      : 'text-muted-foreground'
                  }`}
                />
                {item.isNew && (
                  <span className="absolute -top-1 -right-1 h-2 w-2 bg-primary rounded-full" />
                )}
              </div>
              <span
                className={`text-[10px] mt-1 ${
                  location === item.href
                    ? 'font-medium text-primary'
                    : 'text-muted-foreground'
                }`}
              >
                {item.label}
              </span>
            </a>
          </Link>
        ))}
      </div>
    </nav>
  );
}

export default BottomNav;