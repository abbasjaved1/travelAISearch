import React from 'react';
import { AppShell } from './app-shell';
import { BottomNav } from './bottom-nav';
import { TopNav } from './top-nav';

interface PageLayoutProps {
  children: React.ReactNode;
  hideNavigation?: boolean;
}

export function PageLayout({ children, hideNavigation = false }: PageLayoutProps) {
  return (
    <AppShell>
      {!hideNavigation && <TopNav />}
      <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
        {children}
      </main>
      {!hideNavigation && <BottomNav />}
    </AppShell>
  );
}

export default PageLayout;