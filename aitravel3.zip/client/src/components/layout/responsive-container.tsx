
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useMobileOptimization } from "@/hooks/use-mobile-optimization";

interface ResponsiveContainerProps {
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
  noPadding?: boolean;
  noTopPadding?: boolean;
  noBottomPadding?: boolean;
}

export function ResponsiveContainer({ 
  children, 
  className = "",
  fullWidth = false,
  noPadding = false,
  noTopPadding = false,
  noBottomPadding = false
}: ResponsiveContainerProps) {
  const isMobile = useIsMobile();
  const deviceInfo = useMobileOptimization();
  
  // Determine mobile-specific classes and padding
  const mobileClasses = [];
  if (isMobile) {
    // Add top padding for mobile header if needed
    if (!noTopPadding) {
      mobileClasses.push('pt-[60px]'); // Match the height of the mobile header
      
      // Add iOS safe area inset for notched devices
      if (deviceInfo.isIOS) {
        mobileClasses.push('pt-[calc(60px+var(--safe-area-inset-top))]');
      }
    }
    
    // Add bottom padding for mobile navigation bar if needed
    if (!noBottomPadding) {
      mobileClasses.push('pb-[64px]'); // Match the height of the mobile navigation
      
      // Add iOS safe area inset for devices with home indicators
      if (deviceInfo.isIOS) {
        mobileClasses.push('pb-[calc(64px+var(--safe-area-inset-bottom))]');
      }
    }
  }
  
  return (
    <div 
      className={`
        w-full 
        ${!noPadding ? (isMobile ? 'px-4' : 'px-6 lg:px-8') : ''} 
        mx-auto 
        ${fullWidth ? 'max-w-full' : (isMobile ? 'max-w-full' : 'max-w-7xl')} 
        ${isMobile ? mobileClasses.join(' ') : ''}
        ${className}
      `}
    >
      {children}
    </div>
  );
}

/**
 * A responsive page container that automatically adjusts for mobile header and footer spacing
 */
export function ResponsivePage({ 
  children, 
  className = "",
  fullWidth = false
}: {
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
}) {
  return (
    <ResponsiveContainer 
      className={`mobile-optimized-page ${className}`}
      fullWidth={fullWidth}
    >
      {children}
    </ResponsiveContainer>
  );
}
