import { useState, useEffect, ReactNode } from "react";
import { loadStripe, Stripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import { Badge } from "@/components/ui/badge";

// Get the Stripe publishable key from environment variables
const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || 
                              import.meta.env.STRIPE_PUBLISHABLE_KEY;

// Validate key format - Stripe publishable keys start with 'pk_'
const isValidStripeKey = STRIPE_PUBLISHABLE_KEY && 
                        typeof STRIPE_PUBLISHABLE_KEY === 'string' && 
                        (STRIPE_PUBLISHABLE_KEY.startsWith('pk_test_') || 
                         STRIPE_PUBLISHABLE_KEY.startsWith('pk_live_'));

// Log the key's presence for debugging (without exposing the actual key)
console.log('Stripe publishable key available:', STRIPE_PUBLISHABLE_KEY ? 'Yes' : 'No');
console.log('Stripe publishable key is valid format:', isValidStripeKey);
console.log('Key format check:', STRIPE_PUBLISHABLE_KEY ? 
            `Key starts with: ${STRIPE_PUBLISHABLE_KEY.substring(0, 3)}... (should be pk_)` : 
            'No key to check');

// Only initialize Stripe with a valid key
let stripePromise = null;
try {
  if (isValidStripeKey) {
    stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);
  }
} catch (error) {
  console.error('Failed to initialize Stripe:', error);
}

interface StripeProviderProps {
  children: ReactNode;
  amount: number;
  bookingDetails?: any;
  bookingType?: 'flight' | 'hotel' | 'dining' | 'ride';
}

export function StripeProvider({ children, amount, bookingDetails, bookingType = 'dining' }: StripeProviderProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // Always define these states, regardless of condition
  const [demoStep, setDemoStep] = useState<'initial' | 'processing' | 'payment-method' | 'confirmation' | 'receipt'>('initial');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'wallet'>('card');
  const [cardDetails, setCardDetails] = useState({
    number: '•••• •••• •••• ••••',
    expiry: 'MM/YY',
    name: ''
  });
  const [transactionDetails, setTransactionDetails] = useState<any>(null);

  useEffect(() => {
    // Only fetch payment intent if we have a valid Stripe instance
    if (stripePromise) {
      // Fetch a real payment intent from the backend
      const fetchPaymentIntent = async () => {
        try {
          setLoading(true);
          setError(null);
          
          console.log('Creating payment intent with:', { amount, bookingType, details: bookingDetails });
          
          if (!amount || amount <= 0) {
            setError('Invalid amount. Please specify a valid payment amount.');
            setLoading(false);
            return;
          }
          
          // First check if user is authenticated - otherwise payment will fail
          const userResponse = await fetch('/api/user', {
            credentials: 'include'
          });
          
          if (!userResponse.ok) {
            setError('You need to be logged in to make a payment. Please log in and try again.');
            setLoading(false);
            return;
          }
          
          // Proceed with payment intent creation
          const response = await fetch('/api/payment/create-intent', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              amount,
              bookingType: bookingType || 'dining', // Ensure we always send a booking type
              metadata: bookingDetails || {}
            }),
            credentials: 'include'
          });
          
          let errorMessage = 'Failed to create payment intent';
          
          if (!response.ok) {
            if (response.status === 401) {
              errorMessage = 'You need to be logged in to make a payment';
            } else if (response.status === 500) {
              errorMessage = 'Server error creating payment. Please try again later.';
            } else if (response.status === 400) {
              errorMessage = 'Invalid payment details. Please check the information and try again.';
            }
            
            try {
              const errorData = await response.json();
              console.error('Error response from server:', errorData);
              if (errorData && errorData.message) {
                errorMessage = errorData.message;
                if (errorData.details) {
                  errorMessage += `: ${errorData.details}`;
                }
              }
            } catch (parseError) {
              console.error('Failed to parse error response:', parseError);
              // Could not parse JSON response, use default error message
            }
            
            setError(errorMessage);
            setLoading(false);
            return;
          }
          
          // Successfully got a response
          let data;
          try {
            data = await response.json();
            console.log('Payment intent created successfully:', data);
          } catch (jsonError) {
            console.error('Failed to parse payment intent response:', jsonError);
            setError('Invalid response from payment service - could not parse JSON');
            setLoading(false);
            return;
          }
          
          if (!data || !data.clientSecret) {
            console.error('Missing client secret in response:', data);
            setError('Invalid response from payment service - missing client secret');
            setLoading(false);
            return;
          }
          
          setClientSecret(data.clientSecret);
          setLoading(false);
        } catch (error) {
          console.error("Error fetching payment intent:", error);
          setError(error instanceof Error 
            ? `Payment setup failed: ${error.message}` 
            : 'Payment setup failed. Please try again.');
          setLoading(false);
        }
      };

      fetchPaymentIntent();
    }
  }, [amount, bookingDetails, bookingType]);

  if (error) {
    return (
      <div className="p-6 flex flex-col items-center">
        <div className="text-red-500 mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <p className="text-center mt-2">Payment setup failed</p>
        </div>
        <p>{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
        >
          Try Again
        </button>
      </div>
    );
  }

  // Check if we have a valid Stripe instance
  if (!stripePromise) {
    // Use demo mode with states already defined above
    
    // Format amount
    const formattedAmount = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
    
    // Handle demo payment
    const handleDemoPayment = async () => {
      try {
        setDemoStep('processing');
        
        console.log('Processing demo payment for:', { amount, bookingType, details: bookingDetails });
        
        // Create a mock booking record via a special endpoint
        const response = await fetch('/api/payment/demo-payment', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            amount,
            bookingType: bookingType || 'dining',
            metadata: bookingDetails || {},
            paymentMethod
          }),
          credentials: 'include'
        });
        
        if (!response.ok) {
          throw new Error('Failed to process demo payment');
        }
        
        // Get transaction details from response
        const result = await response.json();
        setTransactionDetails(result);
        
        // Show confirmation
        setDemoStep('confirmation');
        
        // Automatically proceed to receipt after 2 seconds
        setTimeout(() => {
          setDemoStep('receipt');
        }, 2000);
        
      } catch (error) {
        console.error("Error with demo payment:", error);
        setError('Demo payment failed. Please try again.');
        setDemoStep('initial');
      }
    };
    
    // Handle card input changes
    const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length > 16) value = value.slice(0, 16);
      
      // Format with spaces
      const formatted = value.replace(/(\d{4})(?=\d)/g, '$1 ');
      
      setCardDetails(prev => ({
        ...prev,
        number: formatted || '•••• •••• •••• ••••'
      }));
    };
    
    const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length > 4) value = value.slice(0, 4);
      
      // Format as MM/YY
      if (value.length > 2) {
        value = value.slice(0, 2) + '/' + value.slice(2);
      }
      
      setCardDetails(prev => ({
        ...prev,
        expiry: value || 'MM/YY'
      }));
    };
    
    // Proceed to payment method selection
    const startPayment = () => {
      setDemoStep('payment-method');
    };
    
    // Return home after successful booking
    const returnHome = () => {
      window.location.href = `/${bookingType}s?success=true&demo=true`;
    };
    
    // Initial demo mode screen
    if (demoStep === 'initial') {
      return (
        <div className="p-6 flex flex-col items-center">
          <div className="text-amber-500 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-center mt-2 font-medium">Demonstration Mode</p>
          </div>
          <p className="text-center mb-2">We're currently in demonstration mode. Actual payments can't be processed.</p>
          <p className="text-sm text-gray-600 mt-1 text-center mb-3">Your booking details can be saved with a simulated payment for demonstration purposes.</p>
          
          <div className="w-full max-w-sm bg-slate-50 rounded-lg p-4 my-3">
            <h3 className="text-sm font-medium text-slate-700 mb-2">Booking Summary</h3>
            <div className="text-sm space-y-1">
              {bookingType === 'dining' && bookingDetails?.restaurant && (
                <>
                  <p><span className="font-medium">Restaurant:</span> {bookingDetails.restaurant}</p>
                  <p><span className="font-medium">Date:</span> {new Date(bookingDetails.date).toLocaleDateString()}</p>
                  <p><span className="font-medium">Time:</span> {bookingDetails.time}</p>
                  <p><span className="font-medium">Guests:</span> {bookingDetails.guests}</p>
                </>
              )}
              {bookingType === 'hotel' && bookingDetails?.hotel && (
                <>
                  <p><span className="font-medium">Hotel:</span> {bookingDetails.hotel.name}</p>
                  <p><span className="font-medium">Check-in:</span> {new Date(bookingDetails.hotel.checkIn).toLocaleDateString()}</p>
                  <p><span className="font-medium">Check-out:</span> {new Date(bookingDetails.hotel.checkOut).toLocaleDateString()}</p>
                  <p><span className="font-medium">Guests:</span> {bookingDetails.passengers || 1}</p>
                </>
              )}
              <p className="pt-1 border-t mt-2"><span className="font-medium">Total:</span> {formattedAmount}</p>
            </div>
          </div>
          
          <div className="mt-4 flex flex-col items-center space-y-2">
            <button 
              onClick={startPayment}
              className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 w-full max-w-xs"
            >
              Proceed to Payment
            </button>
            <button 
              onClick={() => window.history.back()}
              className="px-6 py-2 bg-transparent border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 w-full max-w-xs"
            >
              Go Back
            </button>
          </div>
        </div>
      );
    }
    
    // Payment method selection
    if (demoStep === 'payment-method') {
      return (
        <div className="p-6 flex flex-col items-center">
          <div className="text-center mb-4">
            <h3 className="text-lg font-semibold">Select Payment Method</h3>
            <p className="text-sm text-gray-500">Demo mode - no actual payment will be processed</p>
          </div>
          
          <div className="w-full max-w-sm">
            <div className="mb-4">
              <p className="text-sm font-medium mb-2">Recommended Payment Methods</p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className={`flex items-center gap-1 cursor-pointer hover:bg-secondary ${paymentMethod === 'wallet' ? 'bg-secondary' : ''}`} onClick={() => setPaymentMethod("wallet")}>
                  <img src="/logos/paytm-logo.svg" alt="Paytm" className="h-4" />
                  Paytm
                </Badge>
                <Badge variant="outline" className={`flex items-center gap-1 cursor-pointer hover:bg-secondary ${paymentMethod === 'card' ? 'bg-secondary' : ''}`} onClick={() => setPaymentMethod("card")}>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="16" height="16">
                    <path fill="#1565C0" d="M45,35c0,2.209-1.791,4-4,4H7c-2.209,0-4-1.791-4-4V13c0-2.209,1.791-4,4-4h34c2.209,0,4,1.791,4,4V35z"/>
                    <path fill="#FFF" d="M15.186 19l-2.626 7.832c0 0-.667-3.313-.733-3.729-1.495-3.411-3.701-3.221-3.701-3.221L10.726 30v-.002h3.161L18.258 19H15.186zM17.689 30L20.56 30 22.296 19 19.389 19zM38.008 19h-3.021l-4.71 11h2.852l.588-1.571h3.596L37.619 30h2.613L38.008 19zM34.513 26.328l1.563-4.157.881 4.157H34.513zM26.369 22.206c0-.606.498-1.057 1.926-1.057.928 0 1.991.177 1.991.177l.466-2.242c0 0-1.358-.515-2.691-.515-3.019 0-4.576 1.444-4.576 3.272 0 3.306 3.979 2.853 3.979 4.551 0 .291-.231.964-1.888.964-1.662 0-2.759-.609-2.759-.609l-.495 2.268c0 0 1.063.466 3.117.466 2.059 0 4.915-1.090 4.915-3.752C30.354 23.586 26.369 23.394 26.369 22.206z"/>
                  </svg>
                  Visa
                </Badge>
                <Badge variant="outline" className={`flex items-center gap-1 cursor-pointer hover:bg-secondary ${paymentMethod === 'upi' ? 'bg-secondary' : ''}`} onClick={() => setPaymentMethod("upi")}>
                  <img src="/logos/upi-logo.svg" alt="UPI" className="h-4" />
                  UPI
                </Badge>
              </div>
            </div>
            
            {paymentMethod === 'card' && (
              <div className="space-y-3 mt-6">
                <div className="bg-white rounded-md border p-3 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 to-purple-500"></div>
                  <div className="pt-3">
                    <div className="space-y-4">
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Card Number</label>
                        <input 
                          type="text" 
                          className="w-full border-none text-base p-0 focus:ring-0" 
                          placeholder="1234 5678 9012 3456"
                          value={cardDetails.number !== '•••• •••• •••• ••••' ? cardDetails.number : ''}
                          onChange={handleCardNumberChange}
                        />
                      </div>
                      <div className="flex gap-3">
                        <div className="flex-1">
                          <label className="text-xs text-gray-500 mb-1 block">Expiry Date</label>
                          <input 
                            type="text" 
                            className="w-full border-none text-base p-0 focus:ring-0" 
                            placeholder="MM/YY"
                            value={cardDetails.expiry !== 'MM/YY' ? cardDetails.expiry : ''}
                            onChange={handleExpiryChange}
                          />
                        </div>
                        <div className="flex-1">
                          <label className="text-xs text-gray-500 mb-1 block">CVC</label>
                          <input 
                            type="text" 
                            className="w-full border-none text-base p-0 focus:ring-0" 
                            placeholder="123"
                            maxLength={3}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Name on Card</label>
                        <input 
                          type="text" 
                          className="w-full border-none text-base p-0 focus:ring-0" 
                          placeholder="John Doe"
                          value={cardDetails.name}
                          onChange={(e) => setCardDetails(prev => ({...prev, name: e.target.value}))}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end items-center gap-2">
                  <img src="/logos/visa.svg" alt="Visa" className="h-6" />
                  <img src="/logos/mastercard.svg" alt="Mastercard" className="h-6" />
                  <img src="/logos/amex.svg" alt="American Express" className="h-6" />
                </div>
              </div>
            )}
            
            {paymentMethod === 'upi' && (
              <div className="space-y-3 mt-6">
                <div className="bg-white rounded-md border p-4">
                  <label className="block text-sm font-medium mb-1">UPI ID / VPA</label>
                  <input 
                    type="text" 
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-0 disabled:cursor-not-allowed disabled:opacity-50" 
                    placeholder="yourname@upi"
                  />
                  <div className="mt-3">
                    <p className="text-xs text-gray-500 mb-2">Select UPI App</p>
                    <div className="flex gap-3 flex-wrap">
                      <div className="w-16 h-16 flex flex-col items-center justify-center border rounded-md cursor-pointer hover:bg-slate-50">
                        <img src="/logos/gpay-logo.svg" alt="Google Pay" className="h-8 w-8" />
                        <span className="text-xs mt-1">GPay</span>
                      </div>
                      <div className="w-16 h-16 flex flex-col items-center justify-center border rounded-md cursor-pointer hover:bg-slate-50">
                        <img src="/logos/phonepe-logo.svg" alt="PhonePe" className="h-8 w-8" />
                        <span className="text-xs mt-1">PhonePe</span>
                      </div>
                      <div className="w-16 h-16 flex flex-col items-center justify-center border rounded-md cursor-pointer hover:bg-slate-50">
                        <img src="/logos/paytm-logo.svg" alt="Paytm" className="h-8 w-8" />
                        <span className="text-xs mt-1">Paytm</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {paymentMethod === 'wallet' && (
              <div className="space-y-3 mt-6">
                <div className="bg-white rounded-md border p-4">
                  <p className="text-sm font-medium mb-3">Select Digital Wallet</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 border rounded-md cursor-pointer hover:bg-slate-50">
                      <div className="flex items-center gap-2">
                        <img src="/logos/paytm-logo.svg" alt="Paytm" className="h-6 w-6" />
                        <span>Paytm</span>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="9 18 15 12 9 6"></polyline>
                      </svg>
                    </div>
                    <div className="flex items-center justify-between p-2 border rounded-md cursor-pointer hover:bg-slate-50">
                      <div className="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#4285F4">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" opacity="0.3" />
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="#4285F4" />
                          <path d="M13 7h-2v5.41l3.29 3.29 1.41-1.41-2.7-2.7z" fill="#4285F4" />
                        </svg>
                        <span>Google Pay</span>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="9 18 15 12 9 6"></polyline>
                      </svg>
                    </div>
                    <div className="flex items-center justify-between p-2 border rounded-md cursor-pointer hover:bg-slate-50">
                      <div className="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                          <rect width="24" height="24" fill="#0F0F0F" rx="4" />
                          <path d="M12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm3 7h-2v2h-2v-2H9v-2h2V9h2v2h2v2z" fill="white" />
                        </svg>
                        <span>PhonePe</span>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="9 18 15 12 9 6"></polyline>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="mt-6 flex flex-col items-center space-y-2">
              <button 
                onClick={handleDemoPayment}
                className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 w-full"
              >
                Pay {formattedAmount}
              </button>
              <button 
                onClick={() => setDemoStep('initial')}
                className="px-6 py-2 bg-transparent border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 w-full"
              >
                Back
              </button>
            </div>
          </div>
        </div>
      );
    }
    
    // Processing screen
    if (demoStep === 'processing') {
      return (
        <div className="p-6 flex flex-col items-center justify-center min-h-[300px]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
          <p className="text-lg font-medium">Processing Payment</p>
          <p className="text-sm text-gray-500 mt-1">Please wait while we process your payment...</p>
          <p className="text-xs text-gray-400 mt-4">Demo Mode - No actual payment is being processed</p>
        </div>
      );
    }
    
    // Confirmation screen
    if (demoStep === 'confirmation') {
      return (
        <div className="p-6 flex flex-col items-center justify-center min-h-[300px]">
          <div className="bg-green-100 text-green-600 p-3 rounded-full mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <p className="text-lg font-medium text-green-600">Payment Successful!</p>
          <p className="text-sm text-gray-500 mt-1">Your booking has been confirmed.</p>
          <p className="text-xs text-gray-400 mt-4">Demo Mode - This is a simulated transaction</p>
        </div>
      );
    }
    
    // Receipt screen
    if (demoStep === 'receipt') {
      const today = new Date().toLocaleDateString();
      const time = new Date().toLocaleTimeString();
      const transactionId = transactionDetails?.transactionId || `demo_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      
      return (
        <div className="p-6 flex flex-col items-center">
          <div className="max-w-md w-full bg-white border rounded-lg overflow-hidden">
            <div className="bg-primary text-white p-4 text-center">
              <h3 className="text-lg font-bold">Payment Receipt</h3>
              <p className="text-sm opacity-90">Demo Transaction</p>
            </div>
            
            <div className="p-5 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Date & Time</span>
                <span className="text-sm font-medium">{today}, {time}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Transaction ID</span>
                <span className="text-sm font-medium">{transactionId}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Payment Method</span>
                <span className="text-sm font-medium capitalize">{paymentMethod}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Status</span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Successful
                </span>
              </div>
              
              <div className="border-t pt-3 mt-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500">Subtotal</span>
                  <span className="text-sm font-medium">{formattedAmount}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500">Tax</span>
                  <span className="text-sm font-medium">$0.00</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t">
                  <span className="text-base font-semibold">Total</span>
                  <span className="text-base font-bold">{formattedAmount}</span>
                </div>
              </div>
              
              <div className="flex justify-center mt-4">
                <button 
                  onClick={returnHome}
                  className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
                >
                  Return to {bookingType === 'dining' ? 'Dining' : bookingType === 'hotel' ? 'Hotels' : 'Home'}
                </button>
              </div>
            </div>
            
            <div className="bg-gray-50 p-3 text-center">
              <p className="text-xs text-gray-500">This is a demo receipt. No actual payment was processed.</p>
            </div>
          </div>
        </div>
      );
    }
    
    // Fallback (should never reach here)
    return (
      <div className="p-6 flex flex-col items-center">
        <div className="text-amber-500 mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-center mt-2 font-medium">Demonstration Mode</p>
        </div>
        <p className="text-center mb-2">We're currently in demonstration mode. Actual payments can't be processed.</p>
        <button 
          onClick={() => setDemoStep('initial')}
          className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 mt-4"
        >
          Go Back
        </button>
      </div>
    );
  }

  if (loading || !clientSecret) {
    return (
      <div className="p-6 flex flex-col items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
        <p>Preparing payment form...</p>
      </div>
    );
  }

  return (
    <Elements
      stripe={stripePromise}
      options={{
        clientSecret,
        appearance: {
          theme: 'stripe',
          variables: {
            colorPrimary: '#003580',
          },
        },
        // Configure locale to match user's region (Auto-detect)
        locale: 'auto',
      }}
    >
      {children}
    </Elements>
  );
}