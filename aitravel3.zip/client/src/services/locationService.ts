
import { useState, useEffect, useCallback } from 'react';

// Options for geolocation API
const geoOptions = {
  enableHighAccuracy: true,
  timeout: 15000, // Increased timeout to 15 seconds
  maximumAge: 60000 // Allow 1 minute old cached positions
};

export class LocationError extends Error {
  code?: number;
  
  constructor(message: string, code?: number) {
    super(message);
    this.name = 'LocationError';
    this.code = code;
  }
}

export async function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new LocationError('Geolocation is not supported by this browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => resolve(position),
      (error) => {
        let errorMessage: string;
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'User denied the request for geolocation';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information is unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'The request to get user location timed out';
            break;
          default:
            errorMessage = 'An unknown error occurred while retrieving location';
        }
        
        console.warn(`Geolocation error (${error.code}): ${errorMessage}`);
        reject(new LocationError(errorMessage, error.code));
      },
      geoOptions
    );
  });
}

// Cache for location names to reduce API calls - using localStorage for persistent caching
const CACHE_KEY = 'location_name_cache';
const CACHE_EXPIRY = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
const BATCH_SIZE = 5; // Maximum concurrent requests

// Load existing cache from localStorage
let locationNameCache: Record<string, {name: string, timestamp: number}> = {};
try {
  const storedCache = localStorage.getItem(CACHE_KEY);
  if (storedCache) {
    locationNameCache = JSON.parse(storedCache);
    console.log(`Loaded ${Object.keys(locationNameCache).length} cached locations`);
  }
} catch (e) {
  console.warn('Failed to load location cache from localStorage:', e);
}

// Save cache to localStorage
function saveCache() {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(locationNameCache));
  } catch (e) {
    console.warn('Failed to save location cache to localStorage:', e);
  }
}

// Use a request queue to prevent too many concurrent API calls
const pendingRequests: Record<string, Promise<string>> = {};

export async function getLocationName(lat: number, lng: number): Promise<string> {
  try {
    // Round coordinates to 4 decimal places for better cache hits (approx 11m precision)
    const roundedLat = Math.round(lat * 10000) / 10000;
    const roundedLng = Math.round(lng * 10000) / 10000;
    const cacheKey = `${roundedLat},${roundedLng}`;
    
    // If this request is already in progress, return the existing promise
    if (pendingRequests[cacheKey]) {
      return pendingRequests[cacheKey];
    }
    
    // Check cache first
    const now = Date.now();
    const cachedLocation = locationNameCache[cacheKey];
    if (cachedLocation && (now - cachedLocation.timestamp) < CACHE_EXPIRY) {
      return cachedLocation.name;
    }
    
    // Create a new request and add it to the pending queue
    const requestPromise = fetchLocationName(roundedLat, roundedLng, cacheKey, now);
    pendingRequests[cacheKey] = requestPromise;
    
    // Remove from pending after completion
    requestPromise.finally(() => {
      delete pendingRequests[cacheKey];
    });
    
    return requestPromise;
  } catch (error) {
    console.error('Error getting location name:', error);
    return 'Unknown location';
  }
}

// Fetch location name with faster timeouts
async function fetchLocationName(lat: number, lng: number, cacheKey: string, now: number): Promise<string> {
  try {
    // First try the client-side BigDataCloud API (no API key required)
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500); // Reduced timeout to 2.5 seconds
      
      const response = await fetch(
        `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=en`,
        { signal: controller.signal }
      );
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      const locationName = data.city || data.locality || data.principalSubdivision || 'Unknown location';
      
      // Cache the result
      locationNameCache[cacheKey] = {
        name: locationName,
        timestamp: now
      };
      
      // Save to localStorage periodically (every 10 cache updates)
      if (Object.keys(locationNameCache).length % 10 === 0) {
        saveCache();
      }
      
      return locationName;
    } catch (firstApiError) {
      // Fallback to Nominatim OpenStreetMap API
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500); // Reduced timeout to 2.5 seconds
      
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10`,
          {
            headers: {
              'Accept-Language': 'en-US,en;q=0.9',
              'User-Agent': 'TravelApplication/1.0'
            },
            signal: controller.signal
          }
        );
        
        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`Failed to fetch location name: ${response.statusText}`);
        }

        const data = await response.json();
        
        // Extract city, state and country from address
        const address = data.address || {};
        const city = address.city || address.town || address.village || address.hamlet;
        const state = address.state || address.county;
        const country = address.country;

        let locationName;
        if (city && country) {
          locationName = `${city}, ${country}`;
        } else if (state && country) {
          locationName = `${state}, ${country}`;
        } else if (country) {
          locationName = country;
        } else {
          locationName = 'Unknown location';
        }
        
        // Cache the result
        locationNameCache[cacheKey] = {
          name: locationName,
          timestamp: now
        };
        
        // Save to localStorage periodically
        if (Object.keys(locationNameCache).length % 10 === 0) {
          saveCache();
        }
        
        return locationName;
      } catch (fallbackError) {
        clearTimeout(timeoutId);
        
        // If all APIs fail, return a simplified error message
        const fallbackName = 'Location information unavailable';
        
        // Still cache this result but with shorter expiry
        locationNameCache[cacheKey] = {
          name: fallbackName,
          timestamp: now - CACHE_EXPIRY + (5 * 60 * 1000) // Only cache for 5 minutes
        };
        
        return fallbackName;
      }
    }
  } catch (error) {
    console.error('Error fetching location name:', error);
    return 'Unknown location';
  }
}

export function useUserLocation() {
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationName, setLocationName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const detectLocation = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const position = await getCurrentPosition();
      const { latitude, longitude } = position.coords;
      
      setLocation({ lat: latitude, lng: longitude });
      console.log("Location detected:", latitude, longitude);
      
      try {
        const name = await getLocationName(latitude, longitude);
        setLocationName(name);
        console.log("Location name determined:", name);
      } catch (nameError) {
        console.warn('Could not get location name, but coordinates were obtained');
        // We don't set an error here since we at least have coordinates
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown location error';
      setError(message);
      console.error('Location detection error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // Optional: Auto-detect on component mount
    // detectLocation();
  }, [detectLocation]);

  return {
    location,
    locationName,
    error,
    isLoading,
    detectLocation
  };
}
