import { PackingAssistant } from "@/components/ui/packing-assistant";

export default function PackingPage() {
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
        Smart Travel Packing Assistant
      </h1>
      <PackingAssistant />
    </div>
  );
}
