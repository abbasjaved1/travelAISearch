import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, addDays, isBefore } from 'date-fns';
import { 
  Search, 
  Plane, 
  Calendar, 
  Users, 
  ArrowUpDown, 
  ArrowRightLeft, 
  Filter, 
  X, 
  Loader2, 
  AlertCircle,
  Luggage,
  ArrowRight,
  Coffee,
  Wifi,
  ChevronDown,
  ChevronUp,
  Monitor,
  Heart,
  Clock,
  MapPin,
  Info,
  CreditCard,
  Building,
  Home,
  Train,
  Bus,
  Car,
  User
} from 'lucide-react';

// UI Components
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";


// Airport data for search
import { airports } from '@/lib/airport-data';

// Define the search form schema
const searchFormSchema = z.object({
  from: z.string().min(3, "Origin airport is required"),
  to: z.string().min(3, "Destination airport is required"),
  departureDate: z.date({
    required_error: "Departure date is required",
  }),
  returnDate: z.date().optional(),
  passengers: z.preprocess(
    (val) => (val === "" ? 1 : Number(val)),
    z.number().min(1).max(10)
  ),
  cabinClass: z.string().default("economy"),
  tripType: z.enum(["one-way", "round-trip"]),
});

export default function NewFlightsPage() {
  // State for keeping track of current search
  const [selectedFilters, setSelectedFilters] = useState({
    price: { min: 0, max: 10000 },
    stops: { direct: true, oneStop: true, multiStop: true },
    airlines: new Set(),
    departureTime: { morning: true, afternoon: true, evening: true, night: true },
    arrivalTime: { morning: true, afternoon: true, evening: true, night: true },
    duration: { max: 24 },
    amenities: { wifi: false, food: false, entertainment: false, powerOutlets: false }
  });
  
  const [showFilters, setShowFilters] = useState(false);
  const [fromSuggestions, setFromSuggestions] = useState<any[]>([]);
  const [toSuggestions, setToSuggestions] = useState<any[]>([]);
  const [fromFocused, setFromFocused] = useState(false);
  const [toFocused, setToFocused] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [favoriteFlights, setFavoriteFlights] = useState(new Set());
  
  const fromRef = useRef<HTMLInputElement>(null);
  const toRef = useRef<HTMLInputElement>(null);
  const [, setLocation] = useLocation();
  
  // Initialize form with react-hook-form
  const form = useForm<z.infer<typeof searchFormSchema>>({
    resolver: zodResolver(searchFormSchema),
    defaultValues: {
      from: "",
      to: "",
      departureDate: new Date(),
      passengers: 1,
      cabinClass: "economy",
      tripType: "round-trip",
    },
  });
  
  // Watch form values for conditional rendering
  const tripType = form.watch("tripType");
  const fromValue = form.watch("from");
  const toValue = form.watch("to");
  const departureDate = form.watch("departureDate");
  const returnDate = form.watch("returnDate");
  
  // Set return date automatically when departure date changes for round trips
  useEffect(() => {
    if (tripType === "round-trip" && departureDate && (!returnDate || isBefore(returnDate, departureDate))) {
      form.setValue("returnDate", addDays(departureDate, 7));
    }
  }, [departureDate, tripType, form, returnDate]);
  
  // Filter airports when user types in origin/destination fields
  useEffect(() => {
    if (fromValue.length >= 2) {
      const results = airports.filter(airport =>
        airport.name.toLowerCase().includes(fromValue.toLowerCase()) ||
        airport.city.toLowerCase().includes(fromValue.toLowerCase()) ||
        airport.code.toLowerCase().includes(fromValue.toLowerCase())
      ).slice(0, 5);
      setFromSuggestions(results);
    } else {
      setFromSuggestions([]);
    }
  }, [fromValue]);
  
  useEffect(() => {
    if (toValue.length >= 2) {
      const results = airports.filter(airport =>
        airport.name.toLowerCase().includes(toValue.toLowerCase()) ||
        airport.city.toLowerCase().includes(toValue.toLowerCase()) ||
        airport.code.toLowerCase().includes(toValue.toLowerCase())
      ).slice(0, 5);
      setToSuggestions(results);
    } else {
      setToSuggestions([]);
    }
  }, [toValue]);
  
  // Handle selection of airports from suggestions
  const selectFromAirport = (airport: any) => {
    form.setValue("from", airport.code);
    setFromSuggestions([]);
    setFromFocused(false);
    
    // Focus on the destination field if empty
    if (!toValue && toRef.current) {
      toRef.current.focus();
    }
  };
  
  const selectToAirport = (airport: any) => {
    form.setValue("to", airport.code);
    setToSuggestions([]);
    setToFocused(false);
  };
  
  // Format date for display
  const formatDate = (date: Date | undefined): string => {
    if (!date) return "";
    return format(date, "MMM dd, yyyy");
  };
  
  // Format time for display
  const formatTime = (dateString: string): string => {
    try {
      const date = new Date(dateString);
      return format(date, "h:mm a");
    } catch (e) {
      return "Invalid time";
    }
  };
  
  // Calculate flight duration
  const calculateDuration = (departure: string, arrival: string): string => {
    try {
      const departureDate = new Date(departure);
      const arrivalDate = new Date(arrival);
      
      const diffInMinutes = Math.round((arrivalDate.getTime() - departureDate.getTime()) / (1000 * 60));
      const hours = Math.floor(diffInMinutes / 60);
      const minutes = diffInMinutes % 60;
      
      return `${hours}h ${minutes}m`;
    } catch (e) {
      return "Duration unavailable";
    }
  };
  
  // Submit handler for search form
  const onSubmit = (values: z.infer<typeof searchFormSchema>) => {
    setIsSearching(true);
    
    // Perform search, refetch data with new parameters
    refetch();
  };
  
  // Query for flight search results
  const {
    data: searchResults,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery({
    queryKey: ['flightSearch'],
    queryFn: async () => {
      // Get form values
      const values = form.getValues();
      
      // Format dates for API
      const formattedDepartureDate = format(values.departureDate, "yyyy-MM-dd");
      const formattedReturnDate = values.returnDate 
        ? format(values.returnDate, "yyyy-MM-dd") 
        : undefined;
      
      // Build query parameters
      const params = new URLSearchParams({
        from: values.from,
        to: values.to,
        date: formattedDepartureDate, // The backend expects 'date' not 'departure_date'
        passengers: values.passengers.toString(),
        cabin_class: values.cabinClass,
        trip_type: values.tripType,
      });
      
      // Add optional return date if it's a round trip
      if (values.tripType === "round-trip" && formattedReturnDate) {
        params.append("return_date", formattedReturnDate);
      }
      
      console.log("Search parameters:", params.toString());
      
      // Make API request
      const response = await fetch(`/api/flights/search?${params.toString()}`);
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.message || "Failed to search flights");
      }
      
      setIsSearching(false);
      return data;
    },
    enabled: false, // Don't run on component mount
    retry: 1,
  });
  
  // Apply filters to flight results
  const getFilteredFlights = () => {
    if (!searchResults || !searchResults.flights) return [];
    
    return searchResults.flights.filter((flight: any) => {
      // Filter by price
      const price = parseFloat(String(flight.price).replace(/[^0-9.]/g, ''));
      if (price < selectedFilters.price.min || price > selectedFilters.price.max) {
        return false;
      }
      
      // Filter by stops
      if (flight.stops === 0 && !selectedFilters.stops.direct) return false;
      if (flight.stops === 1 && !selectedFilters.stops.oneStop) return false;
      if (flight.stops > 1 && !selectedFilters.stops.multiStop) return false;
      
      // Filter by airline
      if (selectedFilters.airlines.size > 0 && !selectedFilters.airlines.has(flight.airline)) {
        return false;
      }
      
      return true;
    });
  };
  
  // Get list of airlines from search results
  const getAirlines = (): string[] => {
    if (!searchResults || !searchResults.flights) return [];
    
    const airlines = new Set<string>();
    searchResults.flights.forEach((flight: any) => {
      if (flight.airline) {
        airlines.add(flight.airline);
      }
    });
    
    return Array.from(airlines).sort();
  };
  
  // Toggle favorite status for a flight
  const toggleFavorite = (flightId: string) => {
    setFavoriteFlights(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(flightId)) {
        newFavorites.delete(flightId);
      } else {
        newFavorites.add(flightId);
      }
      return newFavorites;
    });
  };
  
  // Navigate to flight details page
  const viewFlightDetails = (flightId: string) => {
    setLocation(`/flights/details/${flightId}`);
  };
  
  const filteredFlights = searchResults ? getFilteredFlights() : [];
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation Bar */}
      <div className="bg-blue-600 text-white">
        <div className="container mx-auto py-4">
          <div className="flex justify-between items-center">
            <div className="flex space-x-6">
              <div className="flex items-center font-medium cursor-pointer border-b-2 border-white pb-1">
                <Plane className="h-4 w-4 mr-2" />
                <span>Flights</span>
              </div>
              <div className="flex items-center font-medium cursor-pointer opacity-75 hover:opacity-100">
                <Building className="h-4 w-4 mr-2" />
                <span>Hotels</span>
              </div>
              <div className="flex items-center font-medium cursor-pointer opacity-75 hover:opacity-100">
                <Home className="h-4 w-4 mr-2" />
                <span>Homestays</span>
              </div>
              <div className="flex items-center font-medium cursor-pointer opacity-75 hover:opacity-100">
                <Train className="h-4 w-4 mr-2" />
                <span>Trains</span>
              </div>
              <div className="flex items-center font-medium cursor-pointer opacity-75 hover:opacity-100">
                <Bus className="h-4 w-4 mr-2" />
                <span>Buses</span>
              </div>
              <div className="flex items-center font-medium cursor-pointer opacity-75 hover:opacity-100">
                <Car className="h-4 w-4 mr-2" />
                <span>Cabs</span>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center cursor-pointer">
                <CreditCard className="h-4 w-4 mr-1" />
                <span className="text-sm">My Trips</span>
              </div>
              <div className="flex items-center cursor-pointer">
                <User className="h-4 w-4 mr-1" />
                <span className="text-sm">Login</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Search Area */}
      <div className="bg-blue-600 pb-20">
        <div className="container mx-auto pt-2 pb-8 px-4">
          {/* Trip Type Selection Card */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-6">
            <div className="flex items-center bg-white border-b p-4">
              <div className="flex space-x-4 w-full overflow-x-auto">
                <FormField
                  control={form.control}
                  name="tripType"
                  render={({ field }) => (
                    <div className="flex space-x-6">
                      <label 
                        className={`flex items-center cursor-pointer ${field.value === 'one-way' ? 'text-blue-600' : 'text-gray-500'}`}
                      >
                        <input 
                          type="radio" 
                          name="tripType"
                          value="one-way"
                          className="h-4 w-4 mr-2 text-blue-600 border-gray-300"
                          checked={field.value === 'one-way'} 
                          onChange={() => field.onChange('one-way')}
                        />
                        <span>One Way</span>
                      </label>
                      
                      <label 
                        className={`flex items-center cursor-pointer ${field.value === 'round-trip' ? 'text-blue-600' : 'text-gray-500'}`}
                      >
                        <input 
                          type="radio"
                          name="tripType" 
                          value="round-trip"
                          className="h-4 w-4 mr-2 text-blue-600 border-gray-300"
                          checked={field.value === 'round-trip'} 
                          onChange={() => field.onChange('round-trip')}
                        />
                        <span>Round Trip</span>
                      </label>
                      
                      <label 
                        className="flex items-center cursor-not-allowed text-gray-400"
                      >
                        <input 
                          type="radio" 
                          name="tripType"
                          className="h-4 w-4 mr-2 text-gray-300 border-gray-300"
                          disabled
                        />
                        <span>Multi City</span>
                      </label>
                    </div>
                  )}
                />
                
                <div className="ml-auto">
                  <FormField
                    control={form.control}
                    name="cabinClass"
                    render={({ field }) => (
                      <Select 
                        value={field.value} 
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger className="w-[180px] h-9">
                          <SelectValue placeholder="Select Class" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="economy">Economy</SelectItem>
                          <SelectItem value="premium_economy">Premium Economy</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                          <SelectItem value="first">First Class</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>
              </div>
            </div>
            
            {/* Search Form Inputs */}
            <div className="p-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Origin and Destination */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="from"
                        render={({ field }) => (
                          <FormItem className="relative">
                            <FormLabel>From</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input
                                  {...field}
                                  ref={fromRef}
                                  placeholder="City or airport code"
                                  className="pl-9"
                                  onFocus={() => setFromFocused(true)}
                                  onBlur={() => setTimeout(() => setFromFocused(false), 200)}
                                />
                                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                {field.value && (
                                  <button
                                    type="button"
                                    onClick={() => form.setValue("from", "")}
                                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                )}
                              </div>
                            </FormControl>
                            {fromSuggestions.length > 0 && fromFocused && (
                              <div className="absolute z-10 mt-1 w-full bg-white rounded-md shadow-lg max-h-60 overflow-auto">
                                <ul className="py-1">
                                  {fromSuggestions.map((airport) => (
                                    <li
                                      key={airport.code}
                                      className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                                      onClick={() => selectFromAirport(airport)}
                                    >
                                      <div className="font-medium">{airport.code} - {airport.name}</div>
                                      <div className="text-sm text-gray-500">{airport.city}, {airport.country}</div>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="to"
                        render={({ field }) => (
                          <FormItem className="relative">
                            <FormLabel>To</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input
                                  {...field}
                                  ref={toRef}
                                  placeholder="City or airport code"
                                  className="pl-9"
                                  onFocus={() => setToFocused(true)}
                                  onBlur={() => setTimeout(() => setToFocused(false), 200)}
                                />
                                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                {field.value && (
                                  <button
                                    type="button"
                                    onClick={() => form.setValue("to", "")}
                                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                )}
                              </div>
                            </FormControl>
                            {toSuggestions.length > 0 && toFocused && (
                              <div className="absolute z-10 mt-1 w-full bg-white rounded-md shadow-lg max-h-60 overflow-auto">
                                <ul className="py-1">
                                  {toSuggestions.map((airport) => (
                                    <li
                                      key={airport.code}
                                      className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                                      onClick={() => selectToAirport(airport)}
                                    >
                                      <div className="font-medium">{airport.code} - {airport.name}</div>
                                      <div className="text-sm text-gray-500">{airport.city}, {airport.country}</div>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    {/* Dates and Passengers */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="departureDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Departure Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={`w-full pl-9 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                                  >
                                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    {field.value ? (
                                      formatDate(field.value)
                                    ) : (
                                      <span>Select date</span>
                                    )}
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <CalendarComponent
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date < new Date()}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {tripType === "round-trip" && (
                        <FormField
                          control={form.control}
                          name="returnDate"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>Return Date</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className={`w-full pl-9 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                                    >
                                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                      {field.value ? (
                                        formatDate(field.value)
                                      ) : (
                                        <span>Select date</span>
                                      )}
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <CalendarComponent
                                    mode="single"
                                    selected={field.value || undefined}
                                    onSelect={field.onChange}
                                    disabled={(date) => 
                                      date < new Date() || 
                                      (departureDate && date < departureDate)
                                    }
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  </div>
                  
                  {/* Passengers and Search Button */}
                  <div className="flex flex-col md:flex-row justify-between gap-4 items-end">
                    <FormField
                      control={form.control}
                      name="passengers"
                      render={({ field }) => (
                        <FormItem className="w-full md:w-auto">
                          <FormLabel>Passengers</FormLabel>
                          <div className="flex items-center">
                            <FormControl>
                              <div className="flex border rounded-md overflow-hidden">
                                <button
                                  type="button"
                                  onClick={() => field.onChange(Math.max(1, Number(field.value) - 1))}
                                  className="px-3 py-2 bg-gray-100 hover:bg-gray-200"
                                >
                                  -
                                </button>
                                <Input
                                  type="number"
                                  className="flex-1 text-center border-0 w-16"
                                  min={1}
                                  max={10}
                                  {...field}
                                />
                                <button
                                  type="button"
                                  onClick={() => field.onChange(Math.min(10, Number(field.value) + 1))}
                                  className="px-3 py-2 bg-gray-100 hover:bg-gray-200"
                                >
                                  +
                                </button>
                              </div>
                            </FormControl>
                            <div className="ml-2 text-sm text-muted-foreground">
                              <Users className="h-4 w-4 inline mr-1" />
                              {field.value} {Number(field.value) === 1 ? 'Passenger' : 'Passengers'}
                            </div>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white"
                      size="lg"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Searching...
                        </>
                      ) : (
                        <>
                          <Search className="mr-2 h-4 w-4" />
                          Search Flights
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          </div>
          
          {/* Search Results */}
          {isSearching && (
            <div className="flex justify-center my-12">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          )}
          
          {isError && (
            <Alert variant="destructive" className="my-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error instanceof Error ? error.message : "Failed to search flights"}
              </AlertDescription>
            </Alert>
          )}
          
          {!isSearching && searchResults && (
            <div className="mt-6">
              {/* Filters */}
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800">
                  {filteredFlights.length} {filteredFlights.length === 1 ? 'Flight' : 'Flights'} Found
                </h2>
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center"
                >
                  <Filter className="mr-2 h-4 w-4" />
                  Filters
                  {showFilters ? (
                    <ChevronUp className="ml-2 h-4 w-4" />
                  ) : (
                    <ChevronDown className="ml-2 h-4 w-4" />
                  )}
                </Button>
              </div>
              
              {/* Filter Panel */}
              {showFilters && (
                <div className="bg-white p-4 rounded-lg shadow-md mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Price Filter */}
                    <div>
                      <h3 className="font-medium mb-2 text-gray-700">Price Range</h3>
                      <div className="flex items-center">
                        <Input 
                          type="number"
                          value={selectedFilters.price.min}
                          onChange={(e) => setSelectedFilters({
                            ...selectedFilters,
                            price: { ...selectedFilters.price, min: Number(e.target.value) }
                          })}
                          className="w-24"
                          min={0}
                        />
                        <Separator className="w-8 mx-2" />
                        <Input 
                          type="number"
                          value={selectedFilters.price.max}
                          onChange={(e) => setSelectedFilters({
                            ...selectedFilters,
                            price: { ...selectedFilters.price, max: Number(e.target.value) }
                          })}
                          className="w-24"
                          min={0}
                        />
                      </div>
                    </div>
                    
                    {/* Stops Filter */}
                    <div>
                      <h3 className="font-medium mb-2 text-gray-700">Stops</h3>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <Checkbox 
                            id="direct"
                            checked={selectedFilters.stops.direct}
                            onCheckedChange={(checked) => setSelectedFilters({
                              ...selectedFilters,
                              stops: { ...selectedFilters.stops, direct: !!checked }
                            })}
                          />
                          <label htmlFor="direct" className="ml-2 cursor-pointer text-sm">
                            Direct
                          </label>
                        </div>
                        <div className="flex items-center">
                          <Checkbox 
                            id="oneStop"
                            checked={selectedFilters.stops.oneStop}
                            onCheckedChange={(checked) => setSelectedFilters({
                              ...selectedFilters,
                              stops: { ...selectedFilters.stops, oneStop: !!checked }
                            })}
                          />
                          <label htmlFor="oneStop" className="ml-2 cursor-pointer text-sm">
                            1 Stop
                          </label>
                        </div>
                        <div className="flex items-center">
                          <Checkbox 
                            id="multiStop"
                            checked={selectedFilters.stops.multiStop}
                            onCheckedChange={(checked) => setSelectedFilters({
                              ...selectedFilters,
                              stops: { ...selectedFilters.stops, multiStop: !!checked }
                            })}
                          />
                          <label htmlFor="multiStop" className="ml-2 cursor-pointer text-sm">
                            2+ Stops
                          </label>
                        </div>
                      </div>
                    </div>
                    
                    {/* Airlines Filter */}
                    <div>
                      <h3 className="font-medium mb-2 text-gray-700">Airlines</h3>
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {getAirlines().map((airline) => (
                          <div key={airline} className="flex items-center">
                            <Checkbox 
                              id={`airline-${airline}`}
                              checked={selectedFilters.airlines.size === 0 || selectedFilters.airlines.has(airline)}
                              onCheckedChange={(checked) => {
                                const newAirlines = new Set(selectedFilters.airlines);
                                if (checked) {
                                  newAirlines.add(airline);
                                } else {
                                  newAirlines.delete(airline);
                                }
                                setSelectedFilters({
                                  ...selectedFilters,
                                  airlines: newAirlines
                                });
                              }}
                            />
                            <label htmlFor={`airline-${airline}`} className="ml-2 cursor-pointer text-sm">
                              {airline}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Flight List */}
              <div className="space-y-4">
                {filteredFlights.length === 0 ? (
                  <div className="bg-white p-8 rounded-lg shadow text-center">
                    <AlertCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No flights found</h3>
                    <p className="text-gray-500">
                      Try adjusting your search criteria or changing your travel dates.
                    </p>
                  </div>
                ) : (
                  filteredFlights.map((flight: any) => (
                    <Card key={flight.id} className="overflow-hidden">
                      <div className="border-l-4 border-blue-500">
                        <CardContent className="p-0">
                          <div className="flex flex-col md:flex-row">
                            {/* Airline Info */}
                            <div className="py-4 px-6 w-full md:w-48 border-r bg-gray-50 flex flex-row md:flex-col justify-between items-center">
                              <div className="flex items-center space-x-2">
                                <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                                  <Plane className="h-5 w-5 text-blue-500" />
                                </div>
                                <div>
                                  <p className="font-medium">{flight.airline}</p>
                                  <p className="text-xs text-gray-500">{flight.flight_number || 'Flight'}</p>
                                </div>
                              </div>
                              
                              <Badge className={flight.stops === 0 ? 'bg-green-500' : flight.stops === 1 ? 'bg-yellow-500' : 'bg-red-500'}>
                                {flight.stops === 0 
                                  ? 'Direct' 
                                  : `${flight.stops} stop${flight.stops > 1 ? 's' : ''}`}
                              </Badge>
                            </div>
                            
                            {/* Flight Details */}
                            <div className="flex-1 p-4 flex flex-col md:flex-row items-center">
                              {/* Departure & Arrival */}
                              <div className="flex-1 w-full flex items-center justify-between px-2 md:px-6">
                                <div className="text-center">
                                  <div className="text-xl font-bold">{formatTime(flight.departure)}</div>
                                  <div className="text-sm font-medium">{flight.from}</div>
                                </div>
                                
                                <div className="flex-1 mx-4 flex flex-col items-center">
                                  <div className="text-xs text-gray-500">
                                    {flight.duration || calculateDuration(flight.departure, flight.arrival)}
                                  </div>
                                  <div className="relative w-full flex items-center">
                                    <div className="h-0.5 bg-gray-300 w-full"></div>
                                    <div className="absolute -top-1.5 left-0 w-3 h-3 rounded-full bg-blue-500"></div>
                                    {flight.stops > 0 && (
                                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 rounded-full bg-indigo-400"></div>
                                    )}
                                    <div className="absolute -top-1.5 right-0 w-3 h-3 rounded-full bg-blue-500"></div>
                                  </div>
                                  <div className="text-xs text-gray-500 mt-1">
                                    {flight.stops === 0 
                                      ? 'Direct Flight' 
                                      : `${flight.stops} stop${flight.stops > 1 ? 's' : ''}`}
                                  </div>
                                </div>
                                
                                <div className="text-center">
                                  <div className="text-xl font-bold">{formatTime(flight.arrival)}</div>
                                  <div className="text-sm font-medium">{flight.to}</div>
                                </div>
                              </div>
                              
                              {/* Price & CTAs */}
                              <div className="mt-4 md:mt-0 w-full md:w-auto md:border-l md:pl-6 flex flex-col items-center justify-center py-2 px-4">
                                <div className="mb-3 text-center">
                                  <div className="text-2xl font-bold text-blue-600">${flight.price}</div>
                                  <div className="text-sm text-muted-foreground">per passenger</div>
                                </div>
                                
                                <div className="flex flex-col w-full space-y-2">
                                  <Button 
                                    onClick={() => viewFlightDetails(flight.id)}
                                    className="bg-blue-600 hover:bg-blue-700 w-full"
                                  >
                                    Select
                                  </Button>
                                  
                                  <Button
                                    variant="outline"
                                    className="w-full"
                                    onClick={() => toggleFavorite(flight.id)}
                                  >
                                    {favoriteFlights.has(flight.id) ? (
                                      <Heart className="h-4 w-4 mr-2 fill-red-500 text-red-500" />
                                    ) : (
                                      <Heart className="h-4 w-4 mr-2" />
                                    )}
                                    {favoriteFlights.has(flight.id) ? 'Saved' : 'Save'}
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Amenities & Additional Info */}
                          <Accordion type="single" collapsible className="border-t">
                            <AccordionItem value="details">
                              <AccordionTrigger className="px-6 py-2 text-sm">
                                Flight Details & Amenities
                              </AccordionTrigger>
                              <AccordionContent className="px-6 pb-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div>
                                    <h4 className="font-medium text-sm mb-2">Flight Information</h4>
                                    <ul className="space-y-1 text-sm">
                                      <li className="flex items-start">
                                        <Plane className="h-4 w-4 mr-2 mt-0.5 text-gray-500" />
                                        <span className="text-gray-600">
                                          {flight.airline} - {flight.flight_number || 'Flight Number N/A'}
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <Luggage className="h-4 w-4 mr-2 mt-0.5 text-gray-500" />
                                        <span className="text-gray-600">
                                          {flight.baggage_allowance || 'Standard baggage allowance applies'}
                                        </span>
                                      </li>
                                      <li className="flex items-start">
                                        <Clock className="h-4 w-4 mr-2 mt-0.5 text-gray-500" />
                                        <span className="text-gray-600">
                                          {flight.duration || calculateDuration(flight.departure, flight.arrival)}
                                        </span>
                                      </li>
                                    </ul>
                                  </div>
                                  
                                  <div>
                                    <h4 className="font-medium text-sm mb-2">Amenities</h4>
                                    <div className="flex flex-wrap gap-2">
                                      {(flight.amenities || []).map((amenity: string, index: number) => (
                                        <Badge key={index} variant="outline" className="flex items-center space-x-1">
                                          {amenity.includes('Wi-Fi') && <Wifi className="h-3 w-3" />}
                                          {amenity.includes('Meals') && <Coffee className="h-3 w-3" />}
                                          {amenity.includes('Entertainment') && <Monitor className="h-3 w-3" />}
                                          <span>{amenity}</span>
                                        </Badge>
                                      ))}
                                      
                                      {(!flight.amenities || flight.amenities.length === 0) && (
                                        <span className="text-gray-500 text-sm">
                                          No amenity information available
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                                
                                <div className="mt-4">
                                  <h4 className="font-medium text-sm mb-2">Stops</h4>
                                  <p className="text-sm text-gray-600">
                                    {flight.stops === 0 
                                      ? 'This is a direct flight with no stops.' 
                                      : `${flight.stops} stop${flight.stops > 1 ? 's' : ''}`}
                                  </p>
                                </div>
                              </AccordionContent>
                            </AccordionItem>
                          </Accordion>
                        </CardContent>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}