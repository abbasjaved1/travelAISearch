import { PassengerProfileForm } from "@/components/passenger-profile-form";
import TopNav from "@/components/layout/top-nav";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import type { ProfileFormData } from "@/components/passenger-profile-form";

export default function ProfileCreationPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleProfileSubmit = async (data: ProfileFormData) => {
    try {
      const response = await apiRequest("POST", "/api/profile", data);

      if (!response.ok) {
        throw new Error("Failed to create profile");
      }

      toast({
        title: "Profile Created",
        description: "Your travel profile has been created successfully!",
      });

      // Redirect to the dashboard or profile view
      setLocation("/profile");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TopNav />

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Create Your Travel Profile</h1>
          <p className="text-muted-foreground mt-2">
            Tell us about your travel preferences to help us personalize your experience
          </p>
        </div>

        <PassengerProfileForm onSubmit={handleProfileSubmit} />
      </div>
    </div>
  );
}