import { useState } from "react";
import { useLocation } from "wouter";
import { ForgotPassword } from "@/components/ui/forgot-password";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Logo } from "@/components/ui/logo";
import { useToast } from "@/hooks/use-toast";

export default function ForgotPasswordPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleCancel = () => {
    setLocation("/");
  };

  const handleComplete = () => {
    toast({
      title: "Success",
      description: "Your password has been reset successfully. You can now log in with your new password.",
    });
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-[#003580]">
      {/* Top Logo Bar */}
      <div className="container mx-auto px-6 py-8">
        <Logo size="lg" className="text-white" />
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 pb-16 flex justify-center">
        <div className="w-full max-w-md">
          <Card className="backdrop-blur-xl bg-white/95 border-0 shadow-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-2xl font-bold text-center">Reset Your Password</CardTitle>
            </CardHeader>
            <CardContent>
              <ForgotPassword
                onCancel={handleCancel}
                onComplete={handleComplete}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}