import { useEffect } from 'react';
import { useLocation } from 'wouter';
import TripInspirationGenerator from '@/components/trip-inspiration-generator';
import { useAuth } from '@/hooks/use-auth';
import PageLayout from '@/components/layout/page-layout';

const TripInspirationPage = () => {
  const [_, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation('/auth');
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <PageLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container mx-auto py-8">
        <TripInspirationGenerator />
      </div>
    </PageLayout>
  );
};

export default TripInspirationPage;