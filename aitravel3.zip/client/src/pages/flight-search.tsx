import { useState, FormEvent } from 'react';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";

// Icons
import { 
  Plane, 
  Calendar, 
  Users, 
  ArrowRight, 
  Clock, 
  Luggage, 
  DollarSign,
  Filter,
  Star,
  AlertCircle
} from 'lucide-react';

// Flight type definition
type Flight = {
  id: string;
  airline: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  price: number;
  class: string;
  stops?: number;
};

export default function FlightSearchPage() {
  // Search form state
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [date, setDate] = useState("");
  const [passengers, setPassengers] = useState("1");
  
  // Search results state
  const [hasSearched, setHasSearched] = useState(false);
  const [searchParams, setSearchParams] = useState<any>(null);

  // Handle form submission
  const handleSearch = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setHasSearched(true);
    setSearchParams({
      origin,
      destination,
      date,
      passengers: parseInt(passengers)
    });
  };

  // Fetch flights data when search is performed
  const { data: flights, isLoading, isError, error } = useQuery({
    queryKey: ['flights', searchParams],
    queryFn: async () => {
      if (!searchParams) return null;
      
      console.log('Searching flights with params:', searchParams);
      
      try {
        // Make API call to backend
        const response = await axios.get('/api/flights/search', {
          params: searchParams
        });
        
        console.log('Flight search response:', response.data);
        return response.data;
      } catch (err) {
        console.error('Flight search error:', err);
        throw err;
      }
    },
    enabled: !!searchParams,
  });

  return (
    <div className="min-h-screen bg-blue-50">
      {/* Header */}
      <div className="bg-blue-600 text-white">
        <div className="container mx-auto py-4 px-4">
          <div className="flex items-center gap-2">
            <Plane className="h-6 w-6" />
            <h1 className="text-xl font-bold">Flight Search</h1>
          </div>
        </div>
      </div>
      
      {/* Search Form */}
      <div className="container mx-auto py-8 px-4">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Search for Flights</CardTitle>
            <CardDescription>Enter your travel details to find the best flights</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-6">
              {/* Trip Type */}
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="oneWay" 
                    name="tripType" 
                    value="oneWay" 
                    defaultChecked 
                    className="h-4 w-4 text-blue-600"
                  />
                  <Label htmlFor="oneWay">One Way</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="roundTrip" 
                    name="tripType" 
                    value="roundTrip" 
                    className="h-4 w-4 text-blue-600"
                  />
                  <Label htmlFor="roundTrip">Round Trip</Label>
                </div>
              </div>
              
              {/* Flight Search Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="origin">From</Label>
                  <div className="relative">
                    <Input
                      id="origin"
                      type="text"
                      placeholder="Origin city or airport"
                      value={origin}
                      onChange={(e) => setOrigin(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 rotate-45 h-4 w-4 text-gray-400" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="destination">To</Label>
                  <div className="relative">
                    <Input
                      id="destination"
                      type="text"
                      placeholder="Destination city or airport"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 -rotate-45 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="date">Departure Date</Label>
                  <div className="relative">
                    <Input
                      id="date"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="passengers">Passengers</Label>
                  <div className="relative">
                    <Input
                      id="passengers"
                      type="number"
                      min="1"
                      max="10"
                      value={passengers}
                      onChange={(e) => setPassengers(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Search Flights
              </Button>
            </form>
          </CardContent>
        </Card>
        
        {/* Search Results */}
        {hasSearched && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold">Flight Results</h2>
              
              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <span>Filter</span>
              </Button>
            </div>
            
            {isLoading && (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardContent className="p-0">
                      <div className="p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <Skeleton className="h-6 w-32" />
                          <Skeleton className="h-6 w-24" />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <Skeleton className="h-12 w-full" />
                          <Skeleton className="h-12 w-full" />
                          <Skeleton className="h-12 w-full" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
            
            {isError && (
              <Card className="bg-red-50 border-red-200">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 text-red-600">
                    <AlertCircle className="h-5 w-5" />
                    <div>
                      <h3 className="font-medium">Error loading flights</h3>
                      <p className="text-sm">There was a problem fetching flight results. Please try again later.</p>
                      {error && <p className="text-xs mt-2 text-red-500">Error details: {(error as any)?.message}</p>}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {flights && flights.length === 0 && (
              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="p-6">
                  <p className="text-center text-gray-500">No flights found for your search criteria. Try different dates or destinations.</p>
                </CardContent>
              </Card>
            )}
            
            {flights && flights.length > 0 && (
              <div className="space-y-4">
                {flights.map((flight: Flight) => (
                  <Card key={flight.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-0">
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                            <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                              <Plane className="h-5 w-5" />
                            </div>
                            <div>
                              <h3 className="font-medium">{flight.airline}</h3>
                              <p className="text-sm text-gray-500">Flight #{flight.id}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold">${flight.price}</p>
                            <p className="text-sm text-gray-500">{flight.class}</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {/* Departure */}
                          <div className="flex flex-col">
                            <p className="text-sm text-gray-500">Departure</p>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-gray-400" />
                              <p className="font-medium">{new Date(flight.departure).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                            </div>
                            <p className="text-sm">{flight.from}</p>
                          </div>
                          
                          {/* Flight Info */}
                          <div className="flex flex-col items-center justify-center">
                            <div className="flex items-center w-full">
                              <div className="h-px bg-gray-300 flex-1"></div>
                              <ArrowRight className="h-4 w-4 text-gray-400 mx-2" />
                              <div className="h-px bg-gray-300 flex-1"></div>
                            </div>
                            <p className="text-sm text-gray-500 mt-1">
                              {flight.stops 
                                ? `${flight.stops} ${flight.stops === 1 ? 'stop' : 'stops'}`
                                : 'Direct flight'
                              }
                            </p>
                          </div>
                          
                          {/* Arrival */}
                          <div className="flex flex-col">
                            <p className="text-sm text-gray-500">Arrival</p>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-gray-400" />
                              <p className="font-medium">{new Date(flight.arrival).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                            </div>
                            <p className="text-sm">{flight.to}</p>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="p-4 bg-gray-50 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center text-yellow-500">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className="h-4 w-4"
                                fill={i < 4 ? "currentColor" : "none"}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-500">4.0 (250+ reviews)</span>
                        </div>
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                          Book Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
        
        {/* Featured Destinations - Only show if no search performed */}
        {!hasSearched && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Popular Destinations</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {['New Delhi', 'Mumbai', 'Bangalore', 'Goa', 'Kolkata', 'Chennai'].map((city) => (
                <Card 
                  key={city} 
                  className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden"
                >
                  <div className="h-40 bg-gradient-to-r from-blue-400 to-blue-600 relative">
                    <div className="absolute inset-0 flex items-end">
                      <div className="p-4 text-white">
                        <h3 className="font-bold text-xl">{city}</h3>
                        <p className="text-blue-100">Explore flights</p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}