import { useQuery } from "@tanstack/react-query";
import { DiningBooking } from "@shared/schema";
import { StripeProvider } from "@/components/StripeProvider";
import DashboardNav from "@/components/layout/dashboard-nav";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Clock, UtensilsCrossed, Star, Search, Users, Filter } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { PaymentForm } from "@/components/PaymentForm";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import { generateDining } from "@shared/mockData";

const cuisineTypes = [
  { name: "Italian", icon: "🍝" },
  { name: "Japanese", icon: "🍱" },
  { name: "Chinese", icon: "🥡" },
  { name: "Indian", icon: "🍛" },
  { name: "Mexican", icon: "🌮" },
  { name: "Thai", icon: "🍜" },
  { name: "French", icon: "🥖" },
  { name: "American", icon: "🍔" },
  { name: "Mediterranean", icon: "🫒" },
  { name: "Seafood", icon: "🦐" },
  { name: "BBQ", icon: "🍖" },
  { name: "Vegetarian", icon: "🥗" },
];

export default function DiningPage() {
  const [showPayment, setShowPayment] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<DiningBooking | null>(null);
  const [searchParams, setSearchParams] = useState({
    location: "",
    date: "",
    guests: "2",
    cuisine: "", // Add cuisine field for filtering
    priceRange: "", // Add price range field for filtering
    mealType: "", // Add meal type field for filtering
    features: [] as string[] // Add features field for filtering
  });
  const [isSearching, setIsSearching] = useState(false);

  const { data: dining, isLoading, refetch } = useQuery<DiningBooking[]>({
    queryKey: ["/api/dining", searchParams],
    queryFn: async () => {
      try {
        const params = new URLSearchParams({
          location: searchParams.location,
          // Pass cuisine type if a selection is made
          ...(searchParams.cuisine && { cuisine: searchParams.cuisine }),
          // Format date and time for the API
          ...(searchParams.date && { date: searchParams.date }),
          // Price range filter
          ...(searchParams.priceRange && { priceRange: searchParams.priceRange }),
          // Meal type filter
          ...(searchParams.mealType && { mealType: searchParams.mealType }),
          // Guest count
          guests: searchParams.guests
        });
        
        // Add features as multiple parameters if any are selected
        if (searchParams.features.length > 0) {
          searchParams.features.forEach(feature => {
            params.append('features', feature);
          });
        }
        
        const response = await fetch(`/api/dining?${params}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch restaurant data');
        }
        
        const data = await response.json();
        console.log('Fetched restaurant data:', data);
        
        // Transform the data to match our DiningBooking interface if needed
        return data.map((restaurant: any) => ({
          id: restaurant.id || `restaurant-${Math.random().toString(36).substring(2, 9)}`,
          restaurant: restaurant.restaurant || restaurant.name,
          cuisine: restaurant.cuisine || 'International',
          date: restaurant.date || new Date().toISOString(),
          time: restaurant.time || '7:00 PM',
          guests: restaurant.guests || parseInt(searchParams.guests) || 2,
          price: restaurant.price || Math.floor(Math.random() * 100) + 50,
          rating: restaurant.rating || (Math.floor(Math.random() * 15) + 35) / 10, // 3.5 to 5.0
          location: restaurant.location,
          image: restaurant.image || `https://images.unsplash.com/photo-${
            ['1517248135467-4c7edcad34c4', '1414235077428-338989a2e8c0', '1559925393-0761761e60c4'][
              Math.floor(Math.random() * 3)
            ]
          }?auto=format&fit=crop&q=80`,
          reservationTime: restaurant.reservationTime || restaurant.date || new Date().toISOString()
        }));
      } catch (error) {
        console.error('Error fetching restaurants:', error);
        throw error;
      }
    },
    enabled: true, // Enable the query to fetch real-time data
    initialData: generateDining(12), // Still provide initial data but will be replaced with real data
  });

  const { toast } = useToast();

  const handleSearch = async () => {
    if (!searchParams.location.trim()) {
      toast({
        title: "Please enter a location",
        description: "Location is required to search for restaurants",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    try {
      await refetch();
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <aside className="w-64 border-r bg-white shadow-sm fixed h-full">
        <DashboardNav />
      </aside>
      <main className="ml-64">
        {/* Hero Search Section */}
        <div className="bg-[#003580] text-white p-8">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-3xl font-bold mb-4">
              Find and book the best restaurants
            </h1>
            <p className="text-lg mb-8 text-white/90">
              Discover amazing dining experiences at top-rated restaurants
            </p>

            <Card className="bg-white shadow-lg border-0">
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-4">
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <Input 
                        placeholder="Search for city or restaurant"
                        className="pl-10 h-12 text-lg bg-white border-2 border-gray-200 hover:border-[#003580] focus:border-[#003580]"
                        value={searchParams.location}
                        onChange={(e) => setSearchParams(prev => ({ ...prev, location: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="md:col-span-3">
                    <div className="relative">
                      <Clock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <Input 
                        type="datetime-local"
                        className="pl-10 h-12 text-lg bg-white border-2 border-gray-200 hover:border-[#003580] focus:border-[#003580]"
                        value={searchParams.date}
                        onChange={(e) => setSearchParams(prev => ({ ...prev, date: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="md:col-span-3">
                    <div className="relative">
                      <Users className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <Select
                        value={searchParams.guests}
                        onValueChange={(value) => setSearchParams(prev => ({ ...prev, guests: value }))}
                      >
                        <SelectTrigger className="h-12 pl-10 bg-white border-2 border-gray-200 hover:border-[#003580] focus:border-[#003580]">
                          <SelectValue placeholder="2 people" />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6].map((num) => (
                            <SelectItem key={num} value={num.toString()}>
                              {num} {num === 1 ? "person" : "people"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="md:col-span-2">
                    <Button 
                      className="w-full h-12 bg-[#006CE4] hover:bg-[#003580] text-white text-lg font-semibold"
                      size="lg"
                      onClick={handleSearch}
                      disabled={isSearching}
                    >
                      {isSearching ? (
                        <span className="flex items-center">
                          <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                          Searching...
                        </span>
                      ) : (
                        <>
                          <Search className="w-5 h-5 mr-2" />
                          Search
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Cuisine Types Scroller */}
        <div className="bg-white border-b">
          <div className="max-w-6xl mx-auto py-6 px-8">
            <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-hide">
              {cuisineTypes.map((cuisine) => (
                <Button
                  key={cuisine.name}
                  variant={searchParams.cuisine === cuisine.name ? "default" : "outline"}
                  className={`flex items-center space-x-2 min-w-max px-6 ${
                    searchParams.cuisine === cuisine.name 
                      ? "bg-[#003580] hover:bg-[#00224f]" 
                      : ""
                  }`}
                  onClick={() => {
                    // Toggle cuisine selection
                    setSearchParams(prev => ({
                      ...prev,
                      cuisine: prev.cuisine === cuisine.name ? "" : cuisine.name
                    }));
                  }}
                >
                  <span className="text-xl">{cuisine.icon}</span>
                  <span>{cuisine.name}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-8">
          <div className="grid grid-cols-12 gap-8">
            {/* Filters Sidebar */}
            <div className="col-span-3">
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Filter className="w-5 h-5" /> Filters
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Price Range */}
                    <div>
                      <h3 className="font-medium mb-3">Price Range</h3>
                      <div className="space-y-2">
                        {['$', '$$', '$$$', '$$$$'].map((price, index) => (
                          <label key={price} className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              className="rounded border-gray-300"
                              checked={searchParams.priceRange === `${index + 1}`}
                              onChange={(e) => {
                                setSearchParams(prev => ({
                                  ...prev,
                                  priceRange: e.target.checked ? `${index + 1}` : ""
                                }));
                                // Trigger search when a filter is selected
                                if (searchParams.location) {
                                  handleSearch();
                                }
                              }}
                            />
                            <span>{price}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Meals */}
                    <div>
                      <h3 className="font-medium mb-3">Meals</h3>
                      <div className="space-y-2">
                        {[
                          'Breakfast',
                          'Lunch',
                          'Dinner',
                          'Cafe',
                          'Brunch',
                        ].map((meal) => (
                          <label key={meal} className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              className="rounded border-gray-300"
                              checked={searchParams.mealType === meal}
                              onChange={(e) => {
                                setSearchParams(prev => ({
                                  ...prev,
                                  mealType: e.target.checked ? meal : ""
                                }));
                                // Trigger search when a filter is selected
                                if (searchParams.location) {
                                  handleSearch();
                                }
                              }}
                            />
                            <span>{meal}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Features */}
                    <div>
                      <h3 className="font-medium mb-3">Features</h3>
                      <div className="space-y-2">
                        {[
                          'Outdoor seating',
                          'Live music',
                          'Great views',
                          'Family friendly',
                          'Romantic',
                          'Business meetings',
                        ].map((feature) => (
                          <label key={feature} className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              className="rounded border-gray-300"
                              checked={searchParams.features.includes(feature)}
                              onChange={(e) => {
                                setSearchParams(prev => {
                                  let newFeatures;
                                  if (e.target.checked) {
                                    // Add feature if checked
                                    newFeatures = [...prev.features, feature];
                                  } else {
                                    // Remove feature if unchecked
                                    newFeatures = prev.features.filter(f => f !== feature);
                                  }
                                  return {
                                    ...prev,
                                    features: newFeatures
                                  };
                                });
                                // Trigger search when a filter is selected
                                if (searchParams.location) {
                                  handleSearch();
                                }
                              }}
                            />
                            <span>{feature}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Restaurant Listings */}
            <div className="col-span-9">
              <div className="mb-6 flex items-center justify-between">
                <div className="text-lg font-semibold">
                  {dining?.length || 0} restaurants available
                </div>
                <Select defaultValue="recommended">
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="rating">Rating</SelectItem>
                    <SelectItem value="price-low">Price (low to high)</SelectItem>
                    <SelectItem value="price-high">Price (high to low)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {isLoading ? (
                  Array(3).fill(0).map((_, i) => (
                    <Card key={i}>
                      <CardContent className="p-6">
                        <Skeleton className="h-24" />
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  dining?.map((booking) => (
                    <Card
                      key={booking.id}
                      className="overflow-hidden group hover:shadow-xl transition-all duration-300"
                    >
                      <CardContent className="p-0">
                        <div className="flex">
                          <div 
                            className="relative h-48 w-64 bg-cover bg-center"
                            style={{ backgroundImage: `url(${booking.image || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80'})` }}
                          >
                            {booking.price < 50 && (
                              <Badge className="absolute top-4 left-4 bg-green-600">
                                Special Offer
                              </Badge>
                            )}
                          </div>
                          <div className="p-6 flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h3 className="text-xl font-semibold group-hover:text-[#003580] transition-colors">
                                  {booking.restaurant}
                                </h3>
                                <div className="flex items-center gap-2">
                                  <div className="flex items-center space-x-1">
                                    {Array(5)
                                      .fill(0)
                                      .map((_, i) => (
                                        <Star
                                          key={i}
                                          className={`w-4 h-4 ${
                                            i < (booking.rating || 4)
                                              ? "fill-[#003580] text-[#003580]"
                                              : "fill-muted text-muted"
                                          }`}
                                        />
                                      ))}
                                  </div>
                                  <span className="text-sm text-muted-foreground">
                                    {booking.rating || 4}/5
                                  </span>
                                </div>
                              </div>
                              <UtensilsCrossed className="w-6 h-6 text-[#003580]" />
                            </div>

                            <p className="text-muted-foreground mb-4 flex items-center">
                              <MapPin className="w-4 h-4 mr-1" />
                              {booking.location || "City Center"}
                            </p>

                            <div className="flex items-center gap-4 mb-4">
                              <div className="flex items-center text-sm text-muted-foreground">
                                <Clock className="w-4 h-4 mr-1" />
                                {booking.time}
                              </div>
                              <div className="flex items-center text-sm text-muted-foreground">
                                <Users className="w-4 h-4 mr-1" />
                                {booking.guests} guests
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="text-right">
                                <div className="text-2xl font-bold text-[#003580]">
                                  ${booking.price}
                                  <span className="text-sm text-muted-foreground ml-1">
                                    /person
                                  </span>
                                </div>
                              </div>

                              <Dialog
                                open={showPayment && selectedBooking?.id === booking.id}
                                onOpenChange={(open) => {
                                  if (!open) {
                                    setShowPayment(false);
                                    setSelectedBooking(null);
                                  }
                                }}
                              >
                                <DialogTrigger asChild>
                                  <Button
                                    size="lg"
                                    className="bg-[#006CE4] hover:bg-[#003580] text-white"
                                    onClick={() => {
                                      setSelectedBooking(booking);
                                      setShowPayment(true);
                                    }}
                                  >
                                    Reserve Table
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-md">
                                  <StripeProvider 
                                    amount={booking.price * booking.guests}
                                    bookingType="dining"
                                    bookingDetails={{
                                      restaurant: booking.restaurant,
                                      guests: booking.guests,
                                      date: booking.date,
                                      time: booking.time
                                    }}
                                  >
                                    <PaymentForm
                                      amount={booking.price * booking.guests}
                                      bookingType="dining"
                                      details={{
                                        // Include required fields to match the interface
                                        passengers: booking.guests,
                                        flight: null,
                                        hotel: null,
                                        dining: booking,
                                        ride: null,
                                        seat: null
                                      }}
                                      onSuccess={() => {
                                        // Handle success locally instead of in the callback
                                        // to match the expected interface
                                        fetch(`/api/dining/${booking.id}/book`, {
                                          method: "POST",
                                          credentials: "include",
                                        })
                                          .then(res => {
                                            if (!res.ok) throw new Error("Booking failed");
                                            setShowPayment(false);
                                            setSelectedBooking(null);
                                            toast({
                                              title: "Booking Successful",
                                              description: "Your table has been reserved successfully.",
                                            });
                                          })
                                          .catch(error => {
                                            console.error("Booking error:", error);
                                            toast({
                                              title: "Booking Failed",
                                              description: "Failed to reserve the table. Please try again.",
                                              variant: "destructive",
                                            });
                                          });
                                      }}
                                      onCancel={() => {
                                        setShowPayment(false);
                                        setSelectedBooking(null);
                                        toast({
                                          title: "Payment Cancelled",
                                          description: "Reservation has been cancelled.",
                                          variant: "destructive",
                                        });
                                      }}
                                    />
                                  </StripeProvider>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}