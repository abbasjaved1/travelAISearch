import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  MapPin,
  Calendar,
  Sparkles,
  Clock,
  Briefcase,
  Users,
  Share2,
  RefreshCw
} from "lucide-react";
import { format, addDays, parseISO } from "date-fns";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { socket } from '@/lib/socket'; // Import socket instance
import { LocationTracker } from "@/components/ui/location-tracker";

// Helper function to safely format time
const formatTimeSlot = (date: string, time: string) => {
  try {
    if (!time) return '';
    // Ensure time is in HH:mm format
    const [hours, minutes] = time.split(':');
    if (!hours || !minutes) return time;

    const dateTime = new Date(date);
    dateTime.setHours(parseInt(hours, 10));
    dateTime.setMinutes(parseInt(minutes, 10));

    if (isNaN(dateTime.getTime())) {
      return time;
    }

    return format(dateTime, 'h:mm a');
  } catch (error) {
    console.error('Error formatting time:', error);
    return time;
  }
};

// Format message for WhatsApp sharing
const formatWhatsAppMessage = (
  destination: string,
  date: string,
  meetingTime: string,
  duration: string,
  attendees: string,
  plan: any
) => {
  const message = `
🏢 *Business Trip to ${destination}*
📅 Date: ${format(parseISO(date), 'EEEE, MMM d, yyyy')}
🕒 Meeting Time: ${formatTimeSlot(date, meetingTime)}
⏱️ Duration: ${duration} hour${parseInt(duration) > 1 ? 's' : ''}
👥 Attendees: ${attendees}

*Schedule:*
${plan?.plan?.schedule?.map((timeSlot: any, index: number) => `
${index + 1}. ${formatTimeSlot(date, timeSlot.startTime)} - ${formatTimeSlot(date, timeSlot.endTime)}
   📍 ${timeSlot.activity}
   ${timeSlot.location ? `   📌 Location: ${timeSlot.location}` : ''}
   ${timeSlot.notes ? `   ℹ️ Note: ${timeSlot.notes}` : ''}`).join('\n') || ''}

*Travel Tips:*
${plan?.recommendations?.map((tip: string) => `• ${tip}`).join('\n') || ''}
`.trim();

  return encodeURIComponent(message);
};

const ShareButton = ({
  destination,
  date,
  meetingTime,
  duration,
  attendees,
  plan
}: {
  destination: string;
  date: string;
  meetingTime: string;
  duration: string;
  attendees: string;
  plan: any;
}) => {
  const handleShare = () => {
    const message = formatWhatsAppMessage(destination, date, meetingTime, duration, attendees, plan);
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  return (
    <Button
      onClick={handleShare}
      variant="outline"
      className="flex items-center gap-2"
      disabled={!plan}
    >
      <svg
        viewBox="0 0 24 24"
        className="w-5 h-5 fill-current"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
      Share on WhatsApp
    </Button>
  );
};

export default function QuickPlan() {
  const [destination, setDestination] = useState('');
  const [meetingTime, setMeetingTime] = useState('');
  const [meetingDuration, setMeetingDuration] = useState('1');
  const [attendees, setAttendees] = useState('1');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize dates with proper format
  const today = format(new Date(), 'yyyy-MM-dd');
  const tomorrow = format(addDays(new Date(), 1), 'yyyy-MM-dd');
  const [startDate, setStartDate] = useState(today);
  const [endDate, setEndDate] = useState(tomorrow);
  const [isConnected, setIsConnected] = useState(socket.connected);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const { data: plan, isLoading, error } = useQuery({
    queryKey: ['/api/ai/trip-plan', destination, startDate, endDate, meetingTime, meetingDuration, attendees],
    queryFn: async () => {
      if (!destination || !meetingTime) return null;

      try {
        const response = await fetch("/api/ai/trip-plan", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            destination,
            dates: {
              start: startDate,
              end: endDate
            },
            meetingDetails: {
              time: meetingTime,
              duration: parseInt(meetingDuration),
              attendees: parseInt(attendees)
            },
            preferences: {
              type: 'business',
              pace: 'moderate',
              includeImages: true
            }
          }),
          credentials: 'include'
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.message || 'Failed to generate trip plan');
        }

        const data = await response.json();
        if (!data || !data.plan) {
          throw new Error('Invalid response from server');
        }

        return data;
      } catch (error) {
        console.error('Trip plan error:', error);
        throw error;
      }
    },
    enabled: !!(destination && meetingTime),
    retry: 1,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination) {
      toast({
        title: "Error",
        description: "Please enter a destination",
        variant: "destructive",
      });
      return;
    }
    if (!meetingTime) {
      toast({
        title: "Error",
        description: "Please enter meeting time",
        variant: "destructive",
      });
      return;
    }
  };

  useEffect(() => {
    function onConnect() {
      setIsConnected(true);
    }

    function onDisconnect() {
      setIsConnected(false);
    }

    function onPlanUpdate(updatedPlan: any) {
      queryClient.setQueryData(['/api/ai/trip-plan', destination, startDate, endDate, meetingTime, meetingDuration, attendees],
        oldData => ({
          ...oldData,
          plan: updatedPlan
        })
      );
      setLastUpdate(new Date());
    }

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('planUpdate', onPlanUpdate);

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('planUpdate', onPlanUpdate);
    };
  }, [destination, startDate, endDate, meetingTime, meetingDuration, attendees, queryClient]);


  return (
    <div className="container mx-auto py-4 px-4 sm:py-8 sm:px-6">
      <div className="space-y-6">
        <LocationTracker />
        <Card className="w-full max-w-2xl mx-auto">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Quick Business Trip Plan</CardTitle>
                <CardDescription>
                  Get an instant AI-generated itinerary for your business meeting
                </CardDescription>
              </div>
              {isConnected ? (
                <div className="text-xs text-muted-foreground flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  Live
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => socket.connect()}
                  className="h-8 w-8"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-4">
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Meeting location"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="pl-10 w-full"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Meeting Date</label>
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value);
                        setEndDate(format(addDays(new Date(e.target.value), 1), 'yyyy-MM-dd'));
                      }}
                      min={today}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Meeting Time</label>
                    <Input
                      type="time"
                      value={meetingTime}
                      onChange={(e) => setMeetingTime(e.target.value)}
                      className="w-full"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Duration (hours)</label>
                    <Select value={meetingDuration} onValueChange={setMeetingDuration}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 8].map(hours => (
                          <SelectItem key={hours} value={hours.toString()}>
                            {hours} {hours === 1 ? 'hour' : 'hours'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Attendees</label>
                    <Select value={attendees} onValueChange={setAttendees}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, '6+'].map(num => (
                          <SelectItem key={num} value={num.toString()}>
                            {num} {num === 1 ? 'person' : 'people'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Plan...
                  </>
                ) : (
                  <>
                    <Briefcase className="mr-2 h-4 w-4" />
                    Generate Business Trip Plan
                  </>
                )}
              </Button>
            </form>

            {error ? (
              <div className="mt-4 p-4 bg-red-50 text-red-600 rounded-lg">
                {error instanceof Error ? error.message : 'Failed to generate plan'}
              </div>
            ) : plan ? (
              <div className="mt-6 space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <h3 className="text-lg font-semibold">Your Business Trip Plan</h3>
                  <div className="flex items-center gap-2">
                    {lastUpdate && (
                      <p className="text-xs text-muted-foreground">
                        Last updated: {format(lastUpdate, 'HH:mm:ss')}
                      </p>
                    )}
                    <ShareButton
                      destination={destination}
                      date={startDate}
                      meetingTime={meetingTime}
                      duration={meetingDuration}
                      attendees={attendees}
                      plan={plan}
                    />
                  </div>
                </div>

                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Briefcase className="h-4 w-4" />
                        Meeting Details
                      </CardTitle>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4" />
                        {meetingTime}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        {attendees} {parseInt(attendees) === 1 ? 'attendee' : 'attendees'}
                      </div>
                      <div>
                        Duration: {meetingDuration} {parseInt(meetingDuration) === 1 ? 'hour' : 'hours'}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-4">
                  {plan.plan?.schedule?.map((timeSlot: any, index: number) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="text-base">
                          {formatTimeSlot(startDate, timeSlot.startTime)} - {formatTimeSlot(startDate, timeSlot.endTime)}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <p className="font-medium">{timeSlot.activity}</p>
                          {timeSlot.location && (
                            <p className="text-sm text-gray-500">
                              <MapPin className="inline-block h-4 w-4 mr-1" />
                              {timeSlot.location}
                            </p>
                          )}
                          {timeSlot.notes && (
                            <p className="text-sm text-gray-600">{timeSlot.notes}</p>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {plan.recommendations && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Travel Tips</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-4 space-y-1">
                        {plan.recommendations.map((tip: string, index: number) => (
                          <li key={index} className="text-sm">{tip}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}