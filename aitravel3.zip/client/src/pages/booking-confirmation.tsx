import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import { PassengerDetailsForm } from "@/components/PassengerDetailsForm";
import { PaymentForm } from "@/components/PaymentForm";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { PassengerDetails, FlightBooking } from "@shared/schema";

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export default function BookingConfirmation() {
  const [location] = useLocation();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [passengers, setPassengers] = useState<PassengerDetails[]>([]);
  const [showPayment, setShowPayment] = useState(false);
  const [clientSecret, setClientSecret] = useState("");
  const [bookingDetails, setBookingDetails] = useState<{
    flight: FlightBooking | null;
    amount: number;
    passengers: number;
  }>({
    flight: null,
    amount: 0,
    passengers: 1
  });

  useEffect(() => {
    // Parse URL parameters
    const params = new URLSearchParams(window.location.search);
    const flightId = params.get('flightId');
    const price = parseFloat(params.get('price') || '0');
    const seatId = params.get('seatId');
    const seatPrice = parseFloat(params.get('seatPrice') || '0');

    if (flightId && price) {
      setBookingDetails({
        flight: {
          id: flightId,
          price: price + seatPrice, // Include seat price if selected
        } as FlightBooking,
        amount: price + seatPrice,
        passengers: 1
      });
    } else {
      // Redirect back to flights page if no booking details
      setLocation('/flights');
    }
  }, [location, setLocation]);

  const handlePassengerSubmit = async (passengerDetails: PassengerDetails[]) => {
    setPassengers(passengerDetails);

    try {
      // Create payment intent with passenger details
      const response = await apiRequest("POST", "/api/payment/create-intent", {
        amount: bookingDetails.amount,
        bookingType: "flight",
        metadata: {
          flightId: bookingDetails.flight?.id,
        },
        passengers: passengerDetails,
      });

      if (!response.ok) {
        throw new Error("Failed to create payment intent");
      }

      const data = await response.json();
      setClientSecret(data.clientSecret);
      setShowPayment(true);
    } catch (error) {
      console.error("Payment intent creation failed:", error);
      toast({
        title: "Error",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = async () => {
    try {
      // Show success message
      toast({
        title: "Booking Confirmed!",
        description: "Your itinerary has been created successfully.",
      });

      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/itineraries"] });

      // Redirect to itinerary page
      setLocation(`/itineraries`);
    } catch (error) {
      console.error("Payment confirmation failed:", error);
      toast({
        title: "Error",
        description: "Failed to confirm booking. Please contact support.",
        variant: "destructive",
      });
    }
  };

  if (!bookingDetails.flight) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-3xl mx-auto">
        {!showPayment ? (
          <PassengerDetailsForm
            onSubmit={handlePassengerSubmit}
            passengerCount={bookingDetails.passengers}
          />
        ) : (
          clientSecret && (
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <PaymentForm
                amount={bookingDetails.amount}
                onSuccess={handlePaymentSuccess}
                details={{
                  flight: bookingDetails.flight,
                  passengers: bookingDetails.passengers,
                }}
              />
            </Elements>
          )
        )}
      </div>
    </div>
  );
}