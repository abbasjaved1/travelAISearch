import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { HotelBooking } from "@shared/schema";
import { StripeProvider } from "@/components/StripeProvider";
import TopNav from "@/components/layout/top-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { generateHotels } from "@shared/mockData";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Search,
  Calendar,
  Users,
  Wifi,
  Coffee,
  Star,
  Filter,
  MapPin,
} from 'lucide-react';
import { motion } from "framer-motion";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { PaymentForm } from "@/components/ui/payment-form";
import { LocationSearch, type Location } from "@/components/ui/location-search";

const HotelsPage = () => {
  const [filters, setFilters] = useState<{
    rating?: string;
    priceRange?: string;
    amenities?: string[];
  }>({});
  const [showPayment, setShowPayment] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState<HotelBooking | null>(null);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState("2");
  const [searchKey, setSearchKey] = useState(0);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const { toast } = useToast();

  const { data: hotels = [], isLoading } = useQuery<HotelBooking[]>({
    queryKey: ["/api/hotels", searchKey, selectedLocation?.city, checkIn, checkOut, guests, filters],
    queryFn: async () => {
      try {
        // Always attempt to get real hotel data if location is provided
        if (selectedLocation?.city) {
          // Build query parameters for the API request
          const params = new URLSearchParams({
            location: selectedLocation.city,
            checkIn: checkIn || new Date().toISOString().split('T')[0],
            checkOut: checkOut || new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0], // 3 days from now if not specified
            guests: guests,
            ...(filters.rating && { rating: filters.rating }),
            ...(filters.priceRange && { priceRange: filters.priceRange })
          });

          console.log('Fetching hotels with params:', Object.fromEntries(params.entries()));
          
          // Make the API request to get real hotel data
          const response = await fetch(`/api/hotels?${params}`);
          
          if (!response.ok) {
            console.warn(`Hotel search API returned status: ${response.status}`);
            // Fall back to mock data if API fails
            return generateHotels(8);
          }
          
          const data = await response.json();
          console.log('Hotel search results:', data);
          
          // Process the response to ensure it matches the HotelBooking interface
          const processedHotels = Array.isArray(data) ? data : [];
          
          if (processedHotels.length === 0) {
            console.warn('No hotel results returned from API, using fallback data');
            return generateHotels(8);
          }
          
          // Filter the results based on additional criteria
          return processedHotels.filter(hotel => {
            // Apply rating filter if specified
            if (filters.rating && hotel.rating < parseInt(filters.rating)) {
              return false;
            }

            // Apply price range filter if specified
            if (filters.priceRange) {
              const ranges = {
                budget: { min: 0, max: 150 },
                mid: { min: 151, max: 300 },
                luxury: { min: 301, max: Infinity }
              };
              const range = ranges[filters.priceRange as keyof typeof ranges];
              if (hotel.price < range.min || hotel.price > range.max) {
                return false;
              }
            }

            // Apply amenities filter if specified
            if (filters.amenities?.length) {
              if (!hotel.amenities) return false;
              
              // Convert amenities to lowercase for case-insensitive comparison
              const hotelAmenities = hotel.amenities.map(a => 
                typeof a === 'string' ? a.toLowerCase() : a
              );
              
              // Check if all required amenities are present
              if (!filters.amenities.every(amenity => 
                hotelAmenities.some(a => 
                  typeof a === 'string' && a.includes(amenity.toLowerCase())
                )
              )) {
                return false;
              }
            }

            return true;
          });
        } else {
          // Initial state with no location selected
          return generateHotels(8);
        }
      } catch (error) {
        console.error('Error searching hotels:', error);
        // Return mock data on error
        return generateHotels(8);
      }
    },
    enabled: true // Always enable the query to try fetching data when possible
  });

  const handleSearch = () => {
    if (!checkIn || !checkOut) {
      toast({
        title: "Dates Required",
        description: "Please select check-in and check-out dates",
        variant: "destructive",
      });
      return;
    }

    setSearchKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <TopNav />

      {/* Hero Section with Search */}
      <div className="relative bg-[#00224f] text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-[#00224f] to-[#003580] opacity-90" />
        <div className="container mx-auto px-4 py-8 sm:py-16 relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center mb-8 sm:mb-12"
          >
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold mb-4">
              Find Your Perfect Stay
            </h1>
            <p className="text-lg sm:text-xl opacity-90">
              Book hotels, resorts, and unique accommodations worldwide
            </p>
          </motion.div>

          {/* Search Box */}
          <Card className="bg-white shadow-xl border-0">
            <CardContent className="p-4 sm:p-6">
              <div className="grid grid-cols-1 gap-4">
                {/* Location Search */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Where are you going?
                  </label>
                  <LocationSearch
                    onLocationSelect={setSelectedLocation}
                    className="w-full"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Check-in Date */}
                  <div>
                    <label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4" /> Check-in
                    </label>
                    <Input
                      type="date"
                      value={checkIn}
                      onChange={(e) => setCheckIn(e.target.value)}
                      className="w-full border-2 border-gray-200 focus:border-[#003580]"
                      min={format(new Date(), 'yyyy-MM-dd')}
                    />
                  </div>

                  {/* Check-out Date */}
                  <div>
                    <label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4" /> Check-out
                    </label>
                    <Input
                      type="date"
                      value={checkOut}
                      onChange={(e) => setCheckOut(e.target.value)}
                      className="w-full border-2 border-gray-200 focus:border-[#003580]"
                      min={checkIn || format(new Date(), 'yyyy-MM-dd')}
                    />
                  </div>
                </div>

                {/* Guests Field */}
                <div>
                  <label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <Users className="w-4 h-4" /> Guests
                  </label>
                  <Select value={guests} onValueChange={setGuests}>
                    <SelectTrigger className="w-full border-2 border-gray-200 focus:border-[#003580]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num} {num === 1 ? "Guest" : "Guests"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleSearch}
                  className="w-full h-12 text-lg bg-[#003580] hover:bg-[#00224f] text-white"
                  size="lg"
                >
                  <Search className="w-5 h-5 mr-2" /> Search Hotels
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Filters Sidebar - Modal on mobile */}
          <div className="lg:col-span-3">
            <Dialog>
              <DialogTrigger asChild>
                <Button className="w-full mb-4 lg:hidden">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter Properties
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <div className="space-y-6">
                  {/* Star Rating */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Star Rating</h4>
                    <div className="space-y-2">
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <label key={rating} className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            checked={filters.rating === rating.toString()}
                            onChange={() => setFilters({ ...filters, rating: rating.toString() })}
                            className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                          />
                          <span className="ml-2 flex items-center">
                            {Array.from({ length: rating }).map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-[#febb02] text-[#febb02]" />
                            ))}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Price Range */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Your Budget</h4>
                    <div className="space-y-2">
                      {[
                        { label: "$0 - $150", value: "budget" },
                        { label: "$151 - $300", value: "mid" },
                        { label: "$301+", value: "luxury" },
                      ].map(({ label, value }) => (
                        <label key={value} className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            checked={filters.priceRange === value}
                            onChange={() => setFilters({ ...filters, priceRange: value })}
                            className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                          />
                          <span className="ml-2 text-sm">{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Amenities */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Popular Amenities</h4>
                    <div className="space-y-2">
                      {[
                        { icon: Wifi, label: "Free WiFi" },
                        { icon: Coffee, label: "Breakfast Included" },
                      ].map(({ icon: Icon, label }) => (
                        <label key={label} className="flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filters.amenities?.includes(label)}
                            onChange={() => {
                              const newAmenities = filters.amenities?.includes(label)
                                ? filters.amenities.filter((a) => a !== label)
                                : [...(filters.amenities || []), label];
                              setFilters({ ...filters, amenities: newAmenities });
                            }}
                            className="w-4 h-4 border-2 border-gray-300 rounded text-[#003580]"
                          />
                          <Icon className="w-4 h-4 mx-2 text-gray-500" />
                          <span className="text-sm">{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Desktop Filters */}
            <Card className="bg-white sticky top-4 hidden lg:block">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-4 pb-4 border-b">
                  <Filter className="w-4 h-4 text-[#003580]" />
                  <h3 className="font-semibold text-[#003580]">Filter Properties</h3>
                </div>

                <div className="space-y-6">
                  {/* Star Rating */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Star Rating</h4>
                    <div className="space-y-2">
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <label key={rating} className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            checked={filters.rating === rating.toString()}
                            onChange={() => setFilters({ ...filters, rating: rating.toString() })}
                            className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                          />
                          <span className="ml-2 flex items-center">
                            {Array.from({ length: rating }).map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-[#febb02] text-[#febb02]" />
                            ))}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Price Range */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Your Budget</h4>
                    <div className="space-y-2">
                      {[
                        { label: "$0 - $150", value: "budget" },
                        { label: "$151 - $300", value: "mid" },
                        { label: "$301+", value: "luxury" },
                      ].map(({ label, value }) => (
                        <label key={value} className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            checked={filters.priceRange === value}
                            onChange={() => setFilters({ ...filters, priceRange: value })}
                            className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                          />
                          <span className="ml-2 text-sm">{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Amenities */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Popular Amenities</h4>
                    <div className="space-y-2">
                      {[
                        { icon: Wifi, label: "Free WiFi" },
                        { icon: Coffee, label: "Breakfast Included" },
                      ].map(({ icon: Icon, label }) => (
                        <label key={label} className="flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filters.amenities?.includes(label)}
                            onChange={() => {
                              const newAmenities = filters.amenities?.includes(label)
                                ? filters.amenities.filter((a) => a !== label)
                                : [...(filters.amenities || []), label];
                              setFilters({ ...filters, amenities: newAmenities });
                            }}
                            className="w-4 h-4 border-2 border-gray-300 rounded text-[#003580]"
                          />
                          <Icon className="w-4 h-4 mx-2 text-gray-500" />
                          <span className="text-sm">{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Hotel Listings */}
          <div className="lg:col-span-9 space-y-4">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="bg-white p-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
                    <Skeleton className="h-48 w-full sm:h-32 sm:w-48" />
                    <div className="flex-1 w-full">
                      <Skeleton className="h-6 w-48 mb-2" />
                      <Skeleton className="h-4 w-72 mb-4" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              hotels?.map((hotel) => (
                <motion.div
                  key={hotel.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="bg-white hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
                        {/* Hotel Image */}
                        <div
                          className="w-full sm:w-48 h-48 sm:h-32 bg-cover bg-center rounded-lg relative"
                          style={{
                            backgroundImage: `url(${
                              hotel.image ||
                              'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1470'
                            })`
                          }}
                        >
                          {hotel.price < 200 && (
                            <Badge className="absolute top-2 left-2 bg-green-600">
                              Deal
                            </Badge>
                          )}
                        </div>

                        {/* Hotel Details */}
                        <div className="flex-1">
                          <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                            <div>
                              <h3 className="text-xl font-semibold text-[#003580] mb-2">
                                {hotel.name}
                              </h3>
                              <div className="flex items-center gap-2 mb-3">
                                <div className="flex">
                                  {Array.from({ length: hotel.rating }).map((_, i) => (
                                    <Star
                                      key={i}
                                      className="w-4 h-4 fill-[#febb02] text-[#febb02]"
                                    />
                                  ))}
                                </div>
                                <span className="text-sm text-gray-500">
                                  {hotel.rating} Star Hotel
                                </span>
                              </div>
                              <p className="text-sm text-gray-500 flex items-center mb-4">
                                <MapPin className="w-4 h-4 mr-1" />
                                {hotel.location}
                              </p>
                            </div>

                            <div className="w-full sm:w-auto text-center sm:text-right">
                              <div className="text-3xl font-bold text-[#003580] mb-2">
                                ${hotel.price}
                                <span className="text-sm font-normal text-gray-500 ml-1">per night</span>
                              </div>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    className="w-full sm:w-auto bg-[#003580] hover:bg-[#00224f]"
                                    onClick={() => setSelectedHotel(hotel)}
                                  >
                                    See availability
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[800px]">
                                  <StripeProvider 
                                    amount={hotel.price}
                                    bookingType="hotel"
                                    bookingDetails={{
                                      hotel: hotel,
                                      checkIn: hotel.checkIn,
                                      checkOut: hotel.checkOut
                                    }}
                                  >
                                    <PaymentForm
                                    amount={hotel.price}
                                    bookingType="hotel"
                                    details={{
                                      hotel: hotel,
                                      flight: null,
                                      dining: null,
                                      ride: null,
                                      seat: null,
                                      passengers: 1
                                    }}
                                    onSuccess={() => {
                                      setShowPayment(false);
                                      setSelectedHotel(null);
                                      toast({
                                        title: "Booking Successful",
                                        description: "Your hotel has been booked successfully!",
                                      });
                                    }}
                                    onCancel={() => {
                                      setShowPayment(false);
                                      setSelectedHotel(null);
                                      toast({
                                        title: "Payment Cancelled",
                                        description: "Hotel reservation has been cancelled.",
                                        variant: "destructive",
                                      });
                                    }}
                                  />
                                  </StripeProvider>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HotelsPage;