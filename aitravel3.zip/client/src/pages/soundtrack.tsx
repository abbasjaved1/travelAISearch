import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { TravelSoundtrack } from '@/components/ui/travel-soundtrack';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { LocationSearch, Location } from '@/components/ui/location-search';
import { useAuth } from '@/hooks/use-auth';
import { Music, Library } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Soundtrack {
  id: string;
  name: string;
  description: string;
  destination: string;
  mood: {
    name: string;
    description: string;
    intensity: 'calm' | 'moderate' | 'energetic';
    emotionalTone: 'happy' | 'melancholic' | 'excited' | 'relaxed' | 'adventurous';
  };
  tracks: Array<{
    title: string;
    artist: string;
    genre: string;
    mood: string;
    intensity: number;
    duration?: string;
  }>;
  coverImageUrl?: string;
  duration?: string;
  createdAt: string;
}

export default function SoundtrackPage() {
  const { user } = useAuth();
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [savedSoundtracks, setSavedSoundtracks] = useState<Soundtrack[]>([]);

  // Fetch user's saved soundtracks
  const { data: userSoundtracks, isLoading } = useQuery({
    queryKey: ['/api/user/soundtracks'],
    enabled: !!user,
  });

  const handleLocationSelect = (location: Location) => {
    setSelectedLocation(location);
  };

  const handleSoundtrackCreated = (soundtrack: Soundtrack) => {
    setSavedSoundtracks(prev => [soundtrack, ...prev]);
  };

  return (
    <div className="container mx-auto py-6 space-y-8">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Travel Soundtracks</h1>
        <p className="text-muted-foreground">
          Generate custom music playlists based on your travel destination and mood
        </p>
      </div>

      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="create">Create New</TabsTrigger>
          <TabsTrigger value="library">My Library</TabsTrigger>
        </TabsList>
        
        <TabsContent value="create" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Create Your Travel Soundtrack</CardTitle>
                  <CardDescription>
                    Generate a custom soundtrack for your next adventure
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-2">Travel Destination</h3>
                      <LocationSearch 
                        onLocationSelect={handleLocationSelect} 
                        placeholder="Search for a destination"
                      />
                    </div>
                    
                    {selectedLocation ? (
                      <div className="mt-6">
                        <TravelSoundtrack 
                          destinationName={selectedLocation.city} 
                          onSoundtrackCreated={handleSoundtrackCreated}
                        />
                      </div>
                    ) : (
                      <div className="bg-muted/50 rounded-lg p-8 text-center">
                        <Music className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                        <h3 className="font-medium text-lg mb-2">Search for a destination</h3>
                        <p className="text-muted-foreground">
                          Start by searching for your travel destination to create a personalized soundtrack
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>How It Works</CardTitle>
                </CardHeader>
                <CardContent>
                  <ol className="space-y-4">
                    <li className="flex gap-3">
                      <div className="bg-primary/10 text-primary rounded-full h-6 w-6 flex items-center justify-center shrink-0">
                        1
                      </div>
                      <div>
                        <p className="font-medium">Choose a destination</p>
                        <p className="text-sm text-muted-foreground">
                          Enter the location you're traveling to
                        </p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <div className="bg-primary/10 text-primary rounded-full h-6 w-6 flex items-center justify-center shrink-0">
                        2
                      </div>
                      <div>
                        <p className="font-medium">Select your mood</p>
                        <p className="text-sm text-muted-foreground">
                          Pick a mood that matches your travel vibe
                        </p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <div className="bg-primary/10 text-primary rounded-full h-6 w-6 flex items-center justify-center shrink-0">
                        3
                      </div>
                      <div>
                        <p className="font-medium">Adjust intensity</p>
                        <p className="text-sm text-muted-foreground">
                          Fine-tune the energy level of your soundtrack
                        </p>
                      </div>
                    </li>
                    <li className="flex gap-3">
                      <div className="bg-primary/10 text-primary rounded-full h-6 w-6 flex items-center justify-center shrink-0">
                        4
                      </div>
                      <div>
                        <p className="font-medium">Generate and enjoy</p>
                        <p className="text-sm text-muted-foreground">
                          Create your custom soundtrack and enjoy the perfect travel music
                        </p>
                      </div>
                    </li>
                  </ol>
                  
                  <div className="mt-6 pt-6 border-t">
                    <h4 className="font-medium mb-2">Travel Music Benefits</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>• Enhances travel experiences</li>
                      <li>• Reduces travel anxiety</li>
                      <li>• Creates lasting memories</li>
                      <li>• Adapts to your mood and destination</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="library" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {isLoading ? (
              Array(4).fill(0).map((_, i) => (
                <Card key={i} className="flex flex-col">
                  <div className="h-40 bg-muted animate-pulse rounded-t-lg" />
                  <CardContent className="flex-1 p-4">
                    <div className="h-5 w-2/3 bg-muted animate-pulse rounded mb-2" />
                    <div className="h-4 w-full bg-muted animate-pulse rounded opacity-70" />
                  </CardContent>
                </Card>
              ))
            ) : (
              <>
                {savedSoundtracks.length > 0 || (userSoundtracks?.soundtracks?.length > 0) ? (
                  [...savedSoundtracks, ...(userSoundtracks?.soundtracks || [])].map((soundtrack, index) => (
                    <Card key={soundtrack.id || index} className="flex flex-col overflow-hidden">
                      <div className="relative h-48 overflow-hidden">
                        <img 
                          src={soundtrack.coverImageUrl || "https://source.unsplash.com/featured/?music"} 
                          alt={soundtrack.name}
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent text-white">
                          <h3 className="font-medium">{soundtrack.name}</h3>
                        </div>
                      </div>
                      <CardContent className="flex-1 py-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-sm text-muted-foreground">{soundtrack.destination}</p>
                            <p className="text-xs text-muted-foreground">{soundtrack.tracks.length} tracks • {soundtrack.duration || '45 min'}</p>
                          </div>
                        </div>
                        <div className="flex gap-1 mt-2">
                          <Button variant="outline" size="sm" className="w-full text-xs">
                            Play
                          </Button>
                          <Button variant="ghost" size="sm" className="text-xs">
                            Share
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full flex flex-col items-center justify-center p-10 text-center">
                    <Library className="h-16 w-16 text-muted-foreground mb-4" />
                    <h3 className="font-medium text-lg">Your soundtrack library is empty</h3>
                    <p className="text-muted-foreground mt-1 mb-4">
                      Create your first travel soundtrack to see it here
                    </p>
                    <Button onClick={() => document.querySelector('button[value="create"]')?.click()}>
                      Create a Soundtrack
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}