import { useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useLocation } from 'wouter';
import { TripPlanningWorkflow } from '@/components/trip-workflow/trip-planning-workflow';
import PageLayout from '@/components/layout/page-layout';

export default function TripPlanningCompletePage() {
  const { user, isLoading } = useAuth();
  const [_, setLocation] = useLocation();

  // Check if user is authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      setLocation('/auth');
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <PageLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container mx-auto py-8">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold">
            AI-Powered Trip Planning
          </h1>
          <p className="text-muted-foreground mt-2">
            Plan, customize, and book your perfect trip in one seamless experience
          </p>
        </div>
        
        <TripPlanningWorkflow 
          onComplete={(plan) => {
            console.log('Trip plan completed:', plan);
          }} 
        />
      </div>
    </PageLayout>
  );
}