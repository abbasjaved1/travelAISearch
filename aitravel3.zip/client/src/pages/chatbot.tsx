import { useState } from "react";
import { TravelChatbot } from "@/components/ui/travel-chatbot";
import { MessageSquare, ChevronRight, ChevronLeft, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function ChatbotPage() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <>
      <AnimatePresence mode="wait">
        {isOpen && (
          <motion.div
            key="chatbot"
            initial={{ x: 600 }}
            animate={{ x: 0 }}
            exit={{ x: 600 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed inset-y-0 right-0 w-[600px] h-screen flex flex-col bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-2xl border-l"
          >
            <div className="p-6 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                      Travel Assistant
                    </h1>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your AI-powered travel companion
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-destructive/10"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-hidden relative">
              <TravelChatbot />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Button
        variant="outline"
        size="icon"
        className={`fixed top-1/2 -translate-y-1/2 transition-all duration-200 shadow-lg ${
          isOpen ? "right-[600px]" : "right-0"
        }`}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
      </Button>
    </>
  );
}