import { useState } from "react";
import DashboardNav from "@/components/layout/dashboard-nav";
import { TravelScrapbook } from "@/components/ui/travel-scrapbook";
import { generateTravelMemories } from "@shared/mockData";
import { Button } from "@/components/ui/button";
import { Plus, Filter, Calendar, Hash, MapPin, Upload } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { Textarea } from "@/components/ui/textarea";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useRoute } from "wouter";

type CreateMemoryForm = {
  title: string;
  location: string;
  date: string;
  description: string;
  imageUrl: string;
  tags: string[];
};

export default function MemoriesPage() {
  const [, params] = useRoute("/memories/share/:id");
  const sharedMemoryId = params?.id;

  // If we have a shared memory ID, find that specific memory
  const allMemories = generateTravelMemories(12);
  const sharedMemory = sharedMemoryId 
    ? allMemories.find(m => m.id === sharedMemoryId)
    : null;

  const memories = sharedMemory ? [sharedMemory] : allMemories;

  const [selectedFilter, setSelectedFilter] = useState<string>("all");
  const [selectedYear, setSelectedYear] = useState<string>("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CreateMemoryForm>({
    defaultValues: {
      title: "",
      location: "",
      date: new Date().toISOString().split('T')[0],
      description: "",
      imageUrl: "",
      tags: []
    }
  });

  const createMemoryMutation = useMutation({
    mutationFn: async (data: CreateMemoryForm) => {
      const response = await apiRequest("POST", "/api/memories", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/memories"] });
      toast({
        title: "Memory Created",
        description: "Your travel memory has been saved successfully!",
      });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Extract unique years from memories
  const years = Array.from(new Set(memories.map(m => format(new Date(m.date), 'yyyy'))));

  // Extract unique categories from memory tags
  const categories = Array.from(new Set(memories.flatMap(m => m.tags)));

  // Filter memories based on selected criteria
  const filteredMemories = memories.filter(memory => {
    if (sharedMemoryId) return true; // Don't filter if we're showing a shared memory
    const yearMatches = selectedYear === "all" || format(new Date(memory.date), 'yyyy') === selectedYear;
    const categoryMatches = selectedFilter === "all" || memory.tags.includes(selectedFilter);
    return yearMatches && categoryMatches;
  });

  return (
    <div className="flex min-h-screen bg-gradient-to-b from-background to-secondary/10">
      {!sharedMemoryId && (
        <aside className="w-64 border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <DashboardNav />
        </aside>
      )}
      <main className="flex-1 overflow-hidden">
        <div className="h-full flex flex-col">
          {/* Header Section */}
          <div className="bg-primary/5 border-b px-8 py-6">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                    {sharedMemoryId ? "Shared Travel Story" : "Travel Stories"}
                  </h1>
                  <p className="text-lg text-muted-foreground mt-2">
                    {sharedMemoryId 
                      ? "Someone shared this travel memory with you"
                      : "A collection of unforgettable moments and adventures"}
                  </p>
                </div>
                {!sharedMemoryId && (
                  <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="shadow-lg" size="lg">
                        <Plus className="w-5 h-5 mr-2" />
                        Create Memory
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>Create New Memory</DialogTitle>
                      </DialogHeader>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit((data) => createMemoryMutation.mutate(data))} className="space-y-4">
                          <FormField
                            control={form.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Title</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter memory title" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="location"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Location</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter location" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="date"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea placeholder="Share your memory..." {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="imageUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Image URL</FormLabel>
                                <FormControl>
                                  <div className="flex gap-2">
                                    <Input placeholder="Enter image URL" {...field} />
                                    <Button type="button" variant="outline" size="icon">
                                      <Upload className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <Button 
                            type="submit" 
                            className="w-full"
                            disabled={createMemoryMutation.isPending}
                          >
                            {createMemoryMutation.isPending ? "Creating..." : "Create Memory"}
                          </Button>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>

              {/* Filters Section - Only show if not viewing a shared memory */}
              {!sharedMemoryId && (
                <div className="flex flex-col gap-4">
                  {/* Year Filter */}
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span className="font-medium">Year:</span>
                    <div className="flex gap-2">
                      <Button
                        variant={selectedYear === "all" ? "secondary" : "ghost"}
                        size="sm"
                        onClick={() => setSelectedYear("all")}
                      >
                        All
                      </Button>
                      {years.map(year => (
                        <Button
                          key={year}
                          variant={selectedYear === year ? "secondary" : "ghost"}
                          size="sm"
                          onClick={() => setSelectedYear(year)}
                        >
                          {year}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Category Filter */}
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-primary" />
                    <span className="font-medium">Categories:</span>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={selectedFilter === "all" ? "secondary" : "ghost"}
                        size="sm"
                        onClick={() => setSelectedFilter("all")}
                      >
                        All
                      </Button>
                      {categories.map(category => (
                        <Button
                          key={category}
                          variant={selectedFilter === category ? "secondary" : "ghost"}
                          size="sm"
                          onClick={() => setSelectedFilter(category)}
                        >
                          {category}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Content Area */}
          <ScrollArea className="flex-1 px-8 py-6">
            <div className="max-w-7xl mx-auto">
              <TravelScrapbook 
                memories={filteredMemories}
                viewType="grid"
                className="min-h-[calc(100vh-16rem)]"
              />
            </div>
          </ScrollArea>
        </div>
      </main>
    </div>
  );
}