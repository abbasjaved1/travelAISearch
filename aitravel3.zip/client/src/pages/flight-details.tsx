import { useState, useEffect } from 'react';
import { useLocation, useRoute, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { 
  ArrowLeft, 
  Plane, 
  Clock, 
  Calendar, 
  Users, 
  CreditCard, 
  Info, 
  MapPin,
  Wifi,
  Coffee,
  Utensils,
  Monitor,
  Power,
  Headphones,
  Luggage,
  BedSingle
} from 'lucide-react';
import { format } from 'date-fns';

// UI Components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from '@/hooks/use-toast';

// Airport data
import { airports } from '@/lib/airport-data';

export default function FlightDetailsPage() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute('/flights/details/:flightNumber');
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState('details');
  const [passengerCount, setPassengerCount] = useState(1);
  
  const flightNumber = match ? params.flightNumber : null;
  
  // Query flight details
  const { 
    data: flight, 
    isLoading, 
    isError,
    error
  } = useQuery({
    queryKey: [`/api/flights/${flightNumber}`],
    queryFn: async () => {
      if (!flightNumber) return null;
      
      const response = await fetch(`/api/flights/${flightNumber}`);
      const data = await response.json();
      
      if (data.error || !data.flight) {
        throw new Error(data.message || 'Could not retrieve flight details');
      }
      
      return data.flight;
    },
    enabled: !!flightNumber,
    retry: 1,
    refetchOnWindowFocus: false
  });

  // Get airport details from codes
  const getDepartureAirport = () => {
    if (!flight || !flight.from) return null;
    return airports.find(airport => airport.code === flight.from) || null;
  };
  
  const getArrivalAirport = () => {
    if (!flight || !flight.to) return null;
    return airports.find(airport => airport.code === flight.to) || null;
  };

  // Format flight times
  const formatDateTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return {
        date: format(date, 'MMMM dd, yyyy'),
        time: format(date, 'h:mm a'),
        full: format(date, 'MMMM dd, yyyy h:mm a')
      };
    } catch (e) {
      return { date: 'Invalid date', time: 'Invalid time', full: 'Invalid date/time' };
    }
  };

  // Format price
  const formatPrice = (price: number | string) => {
    if (typeof price === 'number') {
      return `$${price.toFixed(2)}`;
    }
    return price;
  };

  // Handle booking
  const handleBookFlight = () => {
    toast({
      title: "Starting booking process",
      description: "This will guide you through the flight booking process for " + flight?.flightNumber
    });
    
    // Navigate to booking page (would be implemented in a real app)
    // setLocation('/booking/flight/...');
  };

  return (
    <div className="container mx-auto p-4 md:p-6">
      <Button 
        variant="outline" 
        className="mb-6" 
        onClick={() => setLocation('/flights')}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Flight Search
      </Button>
      
      {isLoading && (
        <div className="space-y-4">
          <div className="w-full h-12">
            <Skeleton className="h-12 w-3/4" />
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-1/2 mb-2" />
              <Skeleton className="h-4 w-1/3" />
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between">
                <Skeleton className="h-20 w-28" />
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-20 w-28" />
              </div>
              <Skeleton className="h-40 w-full" />
            </CardContent>
          </Card>
        </div>
      )}
      
      {isError && (
        <Alert variant="destructive" className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Error loading flight details</AlertTitle>
          <AlertDescription>
            {error instanceof Error ? error.message : 'Failed to load flight information. Please try again.'}
          </AlertDescription>
        </Alert>
      )}
      
      {!isLoading && !isError && flight && (
        <>
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2">Flight {flight.flightNumber || 'Details'}</h1>
            <p className="text-muted-foreground">
              {getDepartureAirport()?.city || flight.from} to {getArrivalAirport()?.city || flight.to} • {formatDateTime(flight.departure).date}
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Flight Summary Card */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-xl">{flight.airline}</CardTitle>
                      <CardDescription>Flight {flight.flightNumber}</CardDescription>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-2xl text-primary">{formatPrice(flight.price)}</span>
                      <p className="text-sm text-muted-foreground">per passenger</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Flight Route Visualization */}
                  <div className="flex items-center justify-between my-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{formatDateTime(flight.departure).time}</div>
                      <div className="text-sm font-medium">{flight.from}</div>
                      <div className="text-xs text-muted-foreground">
                        {getDepartureAirport()?.city}, {getDepartureAirport()?.country}
                      </div>
                    </div>
                    
                    <div className="flex-1 mx-4 flex flex-col items-center">
                      <div className="text-sm text-muted-foreground mb-1">{flight.duration || 'Flight duration unavailable'}</div>
                      <div className="w-full h-0.5 bg-gray-300 relative">
                        <div className="absolute left-0 -top-1.5 w-3 h-3 rounded-full bg-primary"></div>
                        <div className="absolute right-0 -top-1.5 w-3 h-3 rounded-full bg-primary"></div>
                        <Plane className="absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2 h-5 w-5 text-primary" />
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {flight.stops === 0 ? 'Direct Flight' : `${flight.stops} stop${flight.stops !== 1 ? 's' : ''}`}
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-2xl font-bold">{formatDateTime(flight.arrival).time}</div>
                      <div className="text-sm font-medium">{flight.to}</div>
                      <div className="text-xs text-muted-foreground">
                        {getArrivalAirport()?.city}, {getArrivalAirport()?.country}
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* Flight Details Tabs */}
                  <Tabs defaultValue="details" value={selectedTab} onValueChange={setSelectedTab}>
                    <TabsList className="grid grid-cols-3">
                      <TabsTrigger value="details">Flight Details</TabsTrigger>
                      <TabsTrigger value="amenities">Amenities</TabsTrigger>
                      <TabsTrigger value="airports">Airport Info</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="details" className="space-y-4 mt-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h3 className="font-medium">Departure</h3>
                          <p>{formatDateTime(flight.departure).full}</p>
                          <p>{flight.departureAirport || getDepartureAirport()?.name}</p>
                        </div>
                        <div>
                          <h3 className="font-medium">Arrival</h3>
                          <p>{formatDateTime(flight.arrival).full}</p>
                          <p>{flight.arrivalAirport || getArrivalAirport()?.name}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h3 className="font-medium">Flight Duration</h3>
                          <p>{flight.duration || 'Information unavailable'}</p>
                        </div>
                        <div>
                          <h3 className="font-medium">Flight Status</h3>
                          <Badge variant={flight.status === 'active' || flight.status === 'scheduled' ? 'outline' : 'secondary'}>
                            {flight.status ? (flight.status.charAt(0).toUpperCase() + flight.status.slice(1)) : 'Not Available'}
                          </Badge>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-medium">Cabin Class</h3>
                        <p>{flight.class}</p>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="amenities" className="space-y-4 mt-4">
                      <div className="grid grid-cols-2 gap-4">
                        {(flight.amenities && flight.amenities.length > 0) ? (
                          <div className="col-span-2">
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                              {flight.amenities.includes("Wi-Fi") && (
                                <div className="flex items-center gap-2">
                                  <Wifi className="h-4 w-4" />
                                  <span>Wi-Fi</span>
                                </div>
                              )}
                              {flight.amenities.includes("In-flight Entertainment") && (
                                <div className="flex items-center gap-2">
                                  <Monitor className="h-4 w-4" />
                                  <span>Entertainment</span>
                                </div>
                              )}
                              {flight.amenities.includes("Power Outlets") && (
                                <div className="flex items-center gap-2">
                                  <Power className="h-4 w-4" />
                                  <span>Power Outlets</span>
                                </div>
                              )}
                              {flight.amenities.includes("Meals") && (
                                <div className="flex items-center gap-2">
                                  <Utensils className="h-4 w-4" />
                                  <span>Meals</span>
                                </div>
                              )}
                              {flight.amenities.includes("Beverages") && (
                                <div className="flex items-center gap-2">
                                  <Coffee className="h-4 w-4" />
                                  <span>Beverages</span>
                                </div>
                              )}
                              <div className="flex items-center gap-2">
                                <Luggage className="h-4 w-4" />
                                <span>Checked Baggage</span>
                              </div>
                              {flight.class.toLowerCase().includes('business') && (
                                <div className="flex items-center gap-2">
                                  <BedSingle className="h-4 w-4" />
                                  <span>Lie-flat Seats</span>
                                </div>
                              )}
                            </div>
                          </div>
                        ) : (
                          <p className="col-span-2">Detailed amenity information not available for this flight.</p>
                        )}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="airports" className="space-y-4 mt-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Departure Airport</CardTitle>
                            <CardDescription>{flight.from} - {getDepartureAirport()?.name || flight.departureAirport}</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div className="flex gap-2">
                                <MapPin className="h-4 w-4 text-muted-foreground" />
                                <span>{getDepartureAirport()?.city}, {getDepartureAirport()?.country}</span>
                              </div>
                              {flight.departureTerminal && (
                                <div className="flex gap-2">
                                  <Info className="h-4 w-4 text-muted-foreground" />
                                  <span>Terminal: {flight.departureTerminal}</span>
                                </div>
                              )}
                              {flight.departureGate && (
                                <div className="flex gap-2">
                                  <Info className="h-4 w-4 text-muted-foreground" />
                                  <span>Gate: {flight.departureGate}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Arrival Airport</CardTitle>
                            <CardDescription>{flight.to} - {getArrivalAirport()?.name || flight.arrivalAirport}</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div className="flex gap-2">
                                <MapPin className="h-4 w-4 text-muted-foreground" />
                                <span>{getArrivalAirport()?.city}, {getArrivalAirport()?.country}</span>
                              </div>
                              {flight.arrivalTerminal && (
                                <div className="flex gap-2">
                                  <Info className="h-4 w-4 text-muted-foreground" />
                                  <span>Terminal: {flight.arrivalTerminal}</span>
                                </div>
                              )}
                              {flight.arrivalGate && (
                                <div className="flex gap-2">
                                  <Info className="h-4 w-4 text-muted-foreground" />
                                  <span>Gate: {flight.arrivalGate}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
            
            {/* Booking Card */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Flight</span>
                    <span>{flight.flightNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Date</span>
                    <span>{formatDateTime(flight.departure).date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Class</span>
                    <span>{flight.class}</span>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <label htmlFor="passengers" className="block mb-2 text-sm font-medium">
                      Passengers
                    </label>
                    <select
                      id="passengers"
                      value={passengerCount}
                      onChange={(e) => setPassengerCount(parseInt(e.target.value))}
                      className="w-full p-2 border border-gray-300 rounded-md"
                    >
                      {[1, 2, 3, 4, 5, 6].map(num => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? 'Passenger' : 'Passengers'}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between font-medium">
                    <span>Price per passenger</span>
                    <span>{formatPrice(flight.price)}</span>
                  </div>
                  
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total price</span>
                    <span className="text-primary">
                      {typeof flight.price === 'number' 
                        ? formatPrice(flight.price * passengerCount) 
                        : 'Check at booking'}
                    </span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleBookFlight} className="w-full">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Book Flight
                  </Button>
                </CardFooter>
              </Card>
              
              {/* Baggage Information */}
              <Card className="mt-4">
                <CardHeader>
                  <CardTitle className="text-base">Baggage Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Carry-on Baggage</span>
                    <span>Included</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Checked Baggage</span>
                    <span>
                      {flight.class.toLowerCase().includes('economy') ? '1 x 23kg' : 
                       flight.class.toLowerCase().includes('business') ? '2 x 32kg' : 
                       flight.class.toLowerCase().includes('first') ? '3 x 32kg' : 'Varies'}
                    </span>
                  </div>
                  <Alert className="mt-4 py-2">
                    <Info className="h-4 w-4" />
                    <AlertTitle className="text-xs">Baggage Policy</AlertTitle>
                    <AlertDescription className="text-xs">
                      Additional baggage can be purchased during the booking process.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}