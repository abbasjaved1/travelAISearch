import { useState, FormEvent } from 'react';
import { Plane, Calendar, Users } from 'lucide-react';

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// Simple Flight Search Page
export default function MakeMyTripFlightsPage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [passengers, setPassengers] = useState("1");
  
  // Basic form submission handler
  const handleSearch = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log("Search submitted:", { from, to, date, passengers });
    // In a real app, we would make an API call here
  };
  
  return (
    <div className="min-h-screen bg-blue-50">
      {/* Header */}
      <div className="bg-blue-600 text-white">
        <div className="container mx-auto py-4 px-4">
          <div className="flex items-center space-x-2">
            <Plane className="h-6 w-6" />
            <h1 className="text-xl font-bold">MakeMyTrip Flight Search</h1>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="container mx-auto py-8 px-4">
        <Card className="w-full max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Search for Flights</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-6">
              {/* Trip Type */}
              <div className="flex space-x-4">
                <label className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    name="tripType" 
                    value="oneWay" 
                    defaultChecked 
                    className="text-blue-600"
                  />
                  <span>One Way</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    name="tripType" 
                    value="roundTrip" 
                    className="text-blue-600"
                  />
                  <span>Round Trip</span>
                </label>
              </div>
              
              {/* Flight Search Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">From</label>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Origin city or airport"
                      value={from}
                      onChange={(e) => setFrom(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 rotate-45 h-4 w-4 text-gray-400" />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">To</label>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Destination city or airport"
                      value={to}
                      onChange={(e) => setTo(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 -rotate-45 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Departure Date</label>
                  <div className="relative">
                    <Input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Passengers</label>
                  <div className="relative">
                    <Input
                      type="number"
                      min="1"
                      max="10"
                      value={passengers}
                      onChange={(e) => setPassengers(e.target.value)}
                      required
                      className="pl-10"
                    />
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Search Flights
              </Button>
            </form>
          </CardContent>
        </Card>
        
        {/* Featured Destinations */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Popular Destinations</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {["New Delhi", "Mumbai", "Bangalore", "Goa", "Kolkata", "Chennai"].map((city) => (
              <Card key={city} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-2">{city}</h3>
                  <p className="text-sm text-gray-500">
                    Explore flights to {city}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}