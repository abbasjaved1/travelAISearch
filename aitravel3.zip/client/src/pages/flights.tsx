import { useState, FormEvent, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { format } from 'date-fns';
import { Flight } from '@/shared/schema';
import { FlightBookingFlow } from '@/components/flight/flight-booking-flow';

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

// Icons
import { 
  Plane, 
  Calendar as CalendarIcon, 
  Users, 
  ArrowRight, 
  Clock, 
  Luggage, 
  DollarSign,
  Filter,
  Star,
  AlertCircle,
  X,
  Info,
  ArrowRightLeft,
  ArrowDown,
  ArrowUp,
  Heart,
  Check
} from 'lucide-react';

// Airport data for search
import { airports } from '@/lib/airport-data';

// Flight type definition
type Flight = {
  id: string;
  airline: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  price: number;
  class?: string;
  stops?: number;
  amenities?: string[];
  duration?: string;
  isFavorite?: boolean;
};

export default function FlightsPage() {
  // Search form state
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [departureDate, setDepartureDate] = useState<Date | undefined>(new Date());
  const [returnDate, setReturnDate] = useState<Date | undefined>(undefined);
  const [passengers, setPassengers] = useState("1");
  const [cabinClass, setCabinClass] = useState("economy");
  const [tripType, setTripType] = useState("one-way");
  const [openCalendar, setOpenCalendar] = useState(false);
  const [openReturnCalendar, setOpenReturnCalendar] = useState(false);
  
  // Search filtering state
  const [showFilters, setShowFilters] = useState(false);
  const [sortOption, setSortOption] = useState<string>("price");
  const [filterPriceMin, setFilterPriceMin] = useState(0);
  const [filterPriceMax, setFilterPriceMax] = useState(10000);
  const [filterStops, setFilterStops] = useState<{[key: string]: boolean}>({
    direct: true,
    oneStop: true,
    multiStop: true
  });
  const [filterAirlines, setFilterAirlines] = useState<Set<string>>(new Set());
  const [favoriteFlights, setFavoriteFlights] = useState<Set<string>>(new Set());
  
  // Search results state
  const [hasSearched, setHasSearched] = useState(false);
  const [searchParams, setSearchParams] = useState<any>(null);
  
  // Booking state
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [showBookingFlow, setShowBookingFlow] = useState(false);

  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Get list of airlines from search results
  const getUniqueAirlines = (flights: Flight[]): string[] => {
    if (!flights || flights.length === 0) return [];
    
    const airlines = new Set<string>();
    flights.forEach((flight) => {
      if (flight.airline) airlines.add(flight.airline);
    });
    
    return Array.from(airlines).sort();
  };

  // Toggle favorite status
  const toggleFavorite = (flightId: string) => {
    setFavoriteFlights(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(flightId)) {
        newFavorites.delete(flightId);
      } else {
        newFavorites.add(flightId);
      }
      return newFavorites;
    });
  };

  // Switch origin and destination
  const swapOriginDestination = () => {
    const temp = origin;
    setOrigin(destination);
    setDestination(temp);
  };

  // Handle form submission
  const handleSearch = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!origin || !destination) {
      toast({
        title: "Missing information",
        description: "Please enter both origin and destination airports",
        variant: "destructive"
      });
      return;
    }
    
    if (!departureDate) {
      toast({
        title: "Missing information",
        description: "Please select a departure date",
        variant: "destructive"
      });
      return;
    }
    
    if (tripType === "round-trip" && !returnDate) {
      toast({
        title: "Missing information",
        description: "Please select a return date",
        variant: "destructive"
      });
      return;
    }
    
    setHasSearched(true);
    setSearchParams({
      from: origin,
      to: destination,
      date: format(departureDate, 'yyyy-MM-dd'),
      return_date: returnDate ? format(returnDate, 'yyyy-MM-dd') : undefined,
      passengers: parseInt(passengers),
      cabin_class: cabinClass,
      trip_type: tripType
    });
  };

  // Format price display
  const formatPrice = (price: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  // Calculate flight duration
  const calculateDuration = (departure: string, arrival: string): string => {
    try {
      const departureDate = new Date(departure);
      const arrivalDate = new Date(arrival);
      
      const diffInMinutes = Math.round((arrivalDate.getTime() - departureDate.getTime()) / (1000 * 60));
      const hours = Math.floor(diffInMinutes / 60);
      const minutes = diffInMinutes % 60;
      
      return `${hours}h ${minutes}m`;
    } catch (e) {
      return "Duration unavailable";
    }
  };

  // Navigate to flight details
  const viewFlightDetails = (flightId: string) => {
    setLocation(`/flights/details/${flightId}`);
  };

  // Get filtered flights
  const getFilteredFlights = (flights: Flight[]): Flight[] => {
    if (!flights) return [];
    
    return flights.filter(flight => {
      // Filter by price
      if (flight.price < filterPriceMin || flight.price > filterPriceMax) return false;
      
      // Filter by stops
      if (flight.stops === 0 && !filterStops.direct) return false;
      if (flight.stops === 1 && !filterStops.oneStop) return false;
      if (flight.stops && flight.stops > 1 && !filterStops.multiStop) return false;
      
      // Filter by airline
      if (filterAirlines.size > 0 && !filterAirlines.has(flight.airline)) return false;
      
      return true;
    });
  };

  // Sort flights
  const getSortedFlights = (flights: Flight[]): Flight[] => {
    if (!flights) return [];
    
    return [...flights].sort((a, b) => {
      switch (sortOption) {
        case 'price':
          return a.price - b.price;
        case 'duration':
          const durationA = a.duration ? parseInt(a.duration.split('h')[0]) : 0;
          const durationB = b.duration ? parseInt(b.duration.split('h')[0]) : 0;
          return durationA - durationB;
        case 'departure':
          return new Date(a.departure).getTime() - new Date(b.departure).getTime();
        case 'arrival':
          return new Date(a.arrival).getTime() - new Date(b.arrival).getTime();
        default:
          return a.price - b.price;
      }
    });
  };

  // Fetch flights data when search is performed
  const { data: searchResults, isLoading, isError, error } = useQuery({
    queryKey: ['flights', searchParams],
    queryFn: async () => {
      if (!searchParams) return null;
      
      console.log('Searching flights with params:', searchParams);
      
      try {
        // Make API call to backend
        const response = await axios.get('/api/flights/search', {
          params: searchParams
        });
        
        console.log('Raw flight search response:', response.data);
        
        // Handle different response formats
        let flights = [];
        
        if (response.data && Array.isArray(response.data)) {
          // If the response is directly an array of flights
          flights = response.data;
        } else if (response.data && response.data.flights && Array.isArray(response.data.flights)) {
          // If the response has a flights property that is an array
          flights = response.data.flights;
        } else if (response.data && typeof response.data === 'object') {
          // If the response is an object but not in the expected format
          // Try to extract any array that might contain flight data
          const possibleFlights = Object.values(response.data).find(val => Array.isArray(val));
          if (possibleFlights) {
            flights = possibleFlights;
          } else {
            // If no array found, create an empty array
            flights = [];
          }
        } else {
          // Default to empty array if no valid data found
          flights = [];
        }
        
        // Add duration to each flight
        const flightsWithDuration = flights.map((flight: Flight) => ({
          ...flight,
          duration: calculateDuration(flight.departure, flight.arrival),
          isFavorite: favoriteFlights.has(flight.id)
        }));
        
        console.log('Processed flight data:', flightsWithDuration);
        return { flights: flightsWithDuration };
      } catch (err) {
        console.error('Flight search error:', err);
        throw err;
      }
    },
    enabled: !!searchParams,
  });

  // Make sure searchResults.flights is defined and is an array to avoid the mapping error
  const flightData = searchResults?.flights || [];
  
  // Get airline list for filters
  const airlineList = Array.isArray(flightData) ? getUniqueAirlines(flightData) : [];
  
  // Get filtered flights
  const filteredFlights = Array.isArray(flightData) ? getFilteredFlights(flightData) : [];
  
  // Get sorted flights
  const sortedFlights = getSortedFlights(filteredFlights);

  // Close booking flow
  const handleCloseBooking = () => {
    setShowBookingFlow(false);
    setSelectedFlight(null);
  };

  // Handle booking success
  const handleBookingSuccess = () => {
    setShowBookingFlow(false);
    setSelectedFlight(null);
    toast({
      title: "Booking Complete",
      description: "Your flight has been booked successfully.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Booking Flow */}
      {showBookingFlow && selectedFlight && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="max-w-4xl w-full">
            <FlightBookingFlow 
              flight={selectedFlight} 
              onCancel={handleCloseBooking}
              onSuccess={handleBookingSuccess}
            />
          </div>
        </div>
      )}
      
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md">
        <div className="container mx-auto py-6 px-4">
          <div className="flex items-center gap-3">
            <Plane className="h-8 w-8" />
            <div>
              <h1 className="text-2xl font-bold">Flight Search</h1>
              <p className="text-blue-100">Find the best flights for your journey</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Search Form */}
      <div className="container mx-auto py-8 px-4">
        <Card className="mb-8 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle>Search for Flights</CardTitle>
            <CardDescription>Enter your travel details below</CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-6">
              {/* Trip Type */}
              <div className="flex space-x-6 pb-2 border-b">
                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="oneWay" 
                    name="tripType" 
                    value="one-way" 
                    checked={tripType === "one-way"}
                    onChange={() => setTripType("one-way")}
                    className="h-4 w-4 text-blue-600"
                  />
                  <Label htmlFor="oneWay" className="cursor-pointer">One Way</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input 
                    type="radio" 
                    id="roundTrip" 
                    name="tripType" 
                    value="round-trip" 
                    checked={tripType === "round-trip"}
                    onChange={() => setTripType("round-trip")}
                    className="h-4 w-4 text-blue-600"
                  />
                  <Label htmlFor="roundTrip" className="cursor-pointer">Round Trip</Label>
                </div>
              </div>
              
              {/* Flight Search Fields */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* From - To Fields */}
                <div className="space-y-2 col-span-full md:col-span-1">
                  <Label htmlFor="origin">From</Label>
                  <div className="relative">
                    <Select value={origin} onValueChange={setOrigin}>
                      <SelectTrigger className="pl-10">
                        <SelectValue placeholder="Origin city or airport" />
                      </SelectTrigger>
                      <SelectContent>
                        {airports.map(airport => (
                          <SelectItem key={airport.code} value={airport.code}>
                            {airport.city} ({airport.code}) - {airport.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 rotate-45 h-4 w-4 text-gray-400" />
                  </div>
                </div>
                
                {/* Swap button */}
                <div className="hidden md:flex items-center justify-center">
                  <div 
                    className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center cursor-pointer hover:bg-blue-200 transition-colors"
                    onClick={swapOriginDestination}
                  >
                    <ArrowRightLeft className="h-5 w-5 text-blue-600" />
                  </div>
                </div>
                
                <div className="space-y-2 col-span-full md:col-span-1">
                  <Label htmlFor="destination">To</Label>
                  <div className="relative">
                    <Select value={destination} onValueChange={setDestination}>
                      <SelectTrigger className="pl-10">
                        <SelectValue placeholder="Destination city or airport" />
                      </SelectTrigger>
                      <SelectContent>
                        {airports.map(airport => (
                          <SelectItem key={airport.code} value={airport.code}>
                            {airport.city} ({airport.code}) - {airport.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 -rotate-45 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="space-y-2">
                  <Label>Departure Date</Label>
                  <div className="relative">
                    <Popover open={openCalendar} onOpenChange={setOpenCalendar}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full pl-10 text-left font-normal"
                        >
                          <CalendarIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                          {departureDate ? (
                            format(departureDate, "MMM dd, yyyy")
                          ) : (
                            <span>Select date</span>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={departureDate}
                          onSelect={(date) => {
                            setDepartureDate(date);
                            setOpenCalendar(false);
                          }}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                
                {tripType === "round-trip" && (
                  <div className="space-y-2">
                    <Label>Return Date</Label>
                    <div className="relative">
                      <Popover open={openReturnCalendar} onOpenChange={setOpenReturnCalendar}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full pl-10 text-left font-normal"
                          >
                            <CalendarIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            {returnDate ? (
                              format(returnDate, "MMM dd, yyyy")
                            ) : (
                              <span>Select date</span>
                            )}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={returnDate}
                            onSelect={(date) => {
                              setReturnDate(date);
                              setOpenReturnCalendar(false);
                            }}
                            disabled={(date) => date < (departureDate || new Date())}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="passengers">Passengers</Label>
                  <div className="relative">
                    <Select value={passengers} onValueChange={setPassengers}>
                      <SelectTrigger className="pl-10">
                        <SelectValue placeholder="1" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => (
                          <SelectItem key={num} value={num.toString()}>
                            {num} {num === 1 ? 'Passenger' : 'Passengers'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cabinClass">Cabin Class</Label>
                  <div className="relative">
                    <Select value={cabinClass} onValueChange={setCabinClass}>
                      <SelectTrigger className="pl-10">
                        <SelectValue placeholder="Economy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="economy">Economy</SelectItem>
                        <SelectItem value="premium_economy">Premium Economy</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="first">First Class</SelectItem>
                      </SelectContent>
                    </Select>
                    <Luggage className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Search Flights
              </Button>
            </form>
          </CardContent>
        </Card>
        
        {/* Search Results */}
        {hasSearched && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Flight Results</h2>
              
              <div className="flex items-center gap-3">
                <Select value={sortOption} onValueChange={setSortOption}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by: Price" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price">Price: Low to High</SelectItem>
                    <SelectItem value="duration">Duration: Shortest</SelectItem>
                    <SelectItem value="departure">Departure: Earliest</SelectItem>
                    <SelectItem value="arrival">Arrival: Earliest</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button 
                  variant={showFilters ? "default" : "outline"} 
                  className="flex items-center gap-2"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="h-4 w-4" />
                  <span>Filter</span>
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Filters Panel */}
              {showFilters && (
                <div className="col-span-1">
                  <Card className="sticky top-4">
                    <CardHeader>
                      <CardTitle className="text-lg flex justify-between items-center">
                        <span>Filters</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0" 
                          onClick={() => setShowFilters(false)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Price Range */}
                      <div>
                        <h3 className="text-sm font-medium mb-3">Price Range</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-500">{formatPrice(filterPriceMin)}</span>
                            <span className="text-sm text-gray-500">{formatPrice(filterPriceMax)}</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <Input 
                              type="range" 
                              min="0" 
                              max="10000" 
                              step="100"
                              value={filterPriceMax}
                              onChange={(e) => setFilterPriceMax(parseInt(e.target.value))}
                              className="w-full"
                            />
                          </div>
                        </div>
                      </div>
                      
                      {/* Stops */}
                      <div>
                        <h3 className="text-sm font-medium mb-3">Stops</h3>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              id="direct" 
                              checked={filterStops.direct}
                              onCheckedChange={(checked) => 
                                setFilterStops({...filterStops, direct: !!checked})
                              }
                            />
                            <label
                              htmlFor="direct"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Direct
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              id="oneStop" 
                              checked={filterStops.oneStop}
                              onCheckedChange={(checked) => 
                                setFilterStops({...filterStops, oneStop: !!checked})
                              }
                            />
                            <label
                              htmlFor="oneStop"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              1 Stop
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              id="multiStop" 
                              checked={filterStops.multiStop}
                              onCheckedChange={(checked) => 
                                setFilterStops({...filterStops, multiStop: !!checked})
                              }
                            />
                            <label
                              htmlFor="multiStop"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              2+ Stops
                            </label>
                          </div>
                        </div>
                      </div>
                      
                      {/* Airlines */}
                      {airlineList.length > 0 && (
                        <div>
                          <h3 className="text-sm font-medium mb-3">Airlines</h3>
                          <div className="space-y-2 max-h-40 overflow-y-auto">
                            {airlineList.map(airline => (
                              <div key={airline} className="flex items-center space-x-2">
                                <Checkbox 
                                  id={`airline-${airline}`}
                                  checked={filterAirlines.size === 0 || filterAirlines.has(airline)}
                                  onCheckedChange={(checked) => {
                                    setFilterAirlines(prev => {
                                      const newSet = new Set(prev);
                                      if (checked) {
                                        newSet.add(airline);
                                      } else {
                                        newSet.delete(airline);
                                      }
                                      return newSet;
                                    });
                                  }}
                                />
                                <label
                                  htmlFor={`airline-${airline}`}
                                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                >
                                  {airline}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Reset Filters */}
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          setFilterPriceMin(0);
                          setFilterPriceMax(10000);
                          setFilterStops({ direct: true, oneStop: true, multiStop: true });
                          setFilterAirlines(new Set());
                        }}
                      >
                        Reset Filters
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              )}
              
              {/* Flight Results */}
              <div className={`col-span-1 ${showFilters ? 'lg:col-span-3' : 'lg:col-span-4'}`}>
                {isLoading && (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Card key={i} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="p-6 space-y-4">
                            <div className="flex items-center justify-between">
                              <Skeleton className="h-6 w-32" />
                              <Skeleton className="h-6 w-24" />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <Skeleton className="h-12 w-full" />
                              <Skeleton className="h-12 w-full" />
                              <Skeleton className="h-12 w-full" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
                
                {isError && (
                  <Card className="bg-red-50 border-red-200">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 text-red-600">
                        <AlertCircle className="h-5 w-5" />
                        <div>
                          <h3 className="font-medium">Error loading flights</h3>
                          <p className="text-sm">There was a problem fetching flight results. Please try again later.</p>
                          {error && <p className="text-xs mt-2 text-red-500">Error details: {(error as any)?.message}</p>}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {!isLoading && !isError && sortedFlights.length === 0 && (
                  <Card className="bg-yellow-50 border-yellow-200">
                    <CardContent className="p-6">
                      <p className="text-center text-gray-500">No flights found for your search criteria. Try different dates or destinations.</p>
                    </CardContent>
                  </Card>
                )}
                
                {!isLoading && !isError && sortedFlights.length > 0 && (
                  <div className="space-y-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-blue-700">
                        <span className="font-medium">{sortedFlights.length}</span> flights found from <span className="font-medium">{origin}</span> to <span className="font-medium">{destination}</span>
                      </p>
                    </div>
                    
                    {sortedFlights.map((flight: Flight) => (
                      <Card key={flight.id} className="overflow-hidden hover:shadow-md transition-shadow border-l-4 border-l-blue-500">
                        <CardContent className="p-0">
                          <div className="p-6">
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                                  <Plane className="h-5 w-5" />
                                </div>
                                <div>
                                  <h3 className="font-medium">{flight.airline}</h3>
                                  <p className="text-sm text-gray-500">Flight #{flight.id}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-lg font-bold">{formatPrice(flight.price)}</p>
                                <p className="text-sm text-gray-500">{flight.class || 'Economy'}</p>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              {/* Departure */}
                              <div className="flex flex-col">
                                <p className="text-sm text-gray-500">Departure</p>
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-gray-400" />
                                  <p className="font-medium">{format(new Date(flight.departure), 'h:mm a')}</p>
                                </div>
                                <p className="text-sm">{format(new Date(flight.departure), 'MMM d, yyyy')}</p>
                                <p className="text-sm font-medium">{flight.from}</p>
                              </div>
                              
                              {/* Flight Info */}
                              <div className="flex flex-col items-center justify-center">
                                <div className="flex items-center w-full">
                                  <div className="h-px bg-gray-300 flex-1"></div>
                                  <ArrowRight className="h-4 w-4 text-gray-400 mx-2" />
                                  <div className="h-px bg-gray-300 flex-1"></div>
                                </div>
                                <p className="text-sm text-gray-500 mt-1">
                                  {flight.duration}
                                </p>
                                <p className="text-sm text-gray-500">
                                  {flight.stops === 0 
                                    ? 'Direct flight'
                                    : `${flight.stops} ${flight.stops === 1 ? 'stop' : 'stops'}`
                                  }
                                </p>
                              </div>
                              
                              {/* Arrival */}
                              <div className="flex flex-col">
                                <p className="text-sm text-gray-500">Arrival</p>
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-gray-400" />
                                  <p className="font-medium">{format(new Date(flight.arrival), 'h:mm a')}</p>
                                </div>
                                <p className="text-sm">{format(new Date(flight.arrival), 'MMM d, yyyy')}</p>
                                <p className="text-sm font-medium">{flight.to}</p>
                              </div>
                            </div>
                            
                            {/* Amenities */}
                            {flight.amenities && flight.amenities.length > 0 && (
                              <div className="mt-4 flex flex-wrap gap-2">
                                {flight.amenities.map((amenity, idx) => (
                                  <Badge key={idx} variant="outline" className="text-xs">
                                    {amenity}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                          
                          <Separator />
                          
                          <div className="p-4 bg-gray-50 flex justify-between items-center">
                            <div className="flex items-center gap-3">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                className={`p-0 h-8 w-8 ${favoriteFlights.has(flight.id) ? 'text-red-500' : 'text-gray-400'}`}
                                onClick={() => toggleFavorite(flight.id)}
                              >
                                <Heart className="h-5 w-5" fill={favoriteFlights.has(flight.id) ? "currentColor" : "none"} />
                              </Button>
                              <div className="flex items-center text-yellow-500">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className="h-4 w-4"
                                    fill={i < 4 ? "currentColor" : "none"}
                                  />
                                ))}
                              </div>
                              <span className="text-sm text-gray-500">4.0 (250+ reviews)</span>
                            </div>
                            <div className="flex gap-2">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => viewFlightDetails(flight.id)}
                              >
                                View Details
                              </Button>
                              <Button 
                                size="sm" 
                                className="bg-blue-600 hover:bg-blue-700"
                                onClick={() => {
                                  setSelectedFlight(flight);
                                  setShowBookingFlow(true);
                                }}
                              >
                                Book Now
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Popular Destinations - Only show if no search performed */}
        {!hasSearched && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Popular Destinations</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { city: 'New Delhi', code: 'DEL', image: 'blue' },
                { city: 'Mumbai', code: 'BOM', image: 'indigo' },
                { city: 'Bangalore', code: 'BLR', image: 'purple' },
                { city: 'Goa', code: 'GOI', image: 'teal' },
                { city: 'Kolkata', code: 'CCU', image: 'green' },
                { city: 'Chennai', code: 'MAA', image: 'orange' }
              ].map((item) => (
                <Card 
                  key={item.city} 
                  className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden"
                  onClick={() => {
                    setDestination(item.code);
                    document.getElementById("oneWay")?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  <div className={`h-40 bg-gradient-to-r from-${item.image}-400 to-${item.image}-600 relative`}>
                    <div className="absolute inset-0 flex items-end">
                      <div className="p-4 text-white">
                        <h3 className="font-bold text-xl">{item.city}</h3>
                        <p className="text-blue-100">Explore flights to {item.code}</p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}