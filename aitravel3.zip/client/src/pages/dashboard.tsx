import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { FlightBooking, HotelBooking, RideBooking, DiningBooking, OnlineUser } from "@shared/schema";
import { socket } from "@/lib/socket";
import TopNav from "@/components/layout/top-nav";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Building2,
  Car,
  Plane,
  UtensilsCrossed,
  Bed,
  Search,
  Calendar,
  Users,
  MapPin,
  Star,
  ArrowRight,
  TrendingUp,
  Heart,
  Clock,
  Globe,
  Brain,
  Sparkles,
  Bot,
  MessageCircle,
  Compass,
  PenTool,
  Zap,
  X,
  Music,
  CreditCard
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PopularDestinations } from "@/components/ui/popular-destinations";
import { ProactiveSuggestions } from "@/components/ui/proactive-suggestions";
import { PopularActivities } from "@/components/ui/popular-activities";
import { LocalEvents } from "@/components/ui/local-events";
import { ChatRoom } from "@/components/ui/chat-room";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { generateHotels, generateRides, generateDining } from "@shared/mockData";
import { UserPresenceMap } from "@/components/ui/user-presence-map";
import { useIsMobile } from "@/hooks/use-mobile";
import { useMobileOptimization } from "@/hooks/use-mobile-optimization";
import { ResponsiveContainer, ResponsivePage } from "@/components/layout/responsive-container";


const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
console.log('Dashboard - Google Maps API Key Status:', GOOGLE_MAPS_API_KEY ? 'Present' : 'Missing');

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [showChat, setShowChat] = useState(false);
  const [showMap, setShowMap] = useState(true); // Show map by default
  const [searchParams, setSearchParams] = useState({
    destination: "",
    checkIn: "",
    guests: "2-0-1"
  });

  // Real-time data fetching for different services
  const { data: hotels = [], isLoading: hotelsLoading } = useQuery<HotelBooking[]>({
    queryKey: ["/api/hotels"],
    initialData: generateHotels(8),
  });

  const { data: flights = [], isLoading: flightsLoading } = useQuery<FlightBooking[]>({
    queryKey: ["/api/flights"],
    initialData: [],
  });

  const { data: rides = [], isLoading: ridesLoading } = useQuery<RideBooking[]>({
    queryKey: ["/api/rides"],
    initialData: generateRides(8),
  });

  const { data: dining = [], isLoading: diningLoading } = useQuery<DiningBooking[]>({
    queryKey: ["/api/dining"],
    initialData: generateDining(8),
  });

  // Calculate user stats with proper date comparisons
  const calculateStats = () => {
    const now = new Date();

    // Count total bookings across all services
    const totalBookings =
      (hotels?.length || 0) +
      (flights?.length || 0) +
      (rides?.length || 0) +
      (dining?.length || 0);

    // Count pending trips (future bookings)
    const pendingTrips = (
      (hotels?.filter(h => new Date(h.checkIn) > now).length || 0) +
      (flights?.filter(f => new Date(f.departure) > now).length || 0) +
      (rides?.filter(r => new Date(r.pickupTime) > now).length || 0) +
      (dining?.filter(d => new Date(d.reservationTime) > now).length || 0)
    );

    // Count saved/favorited items
    const savedItems =
      (hotels?.filter(h => h.isFavorite)?.length || 0) +
      (flights?.filter(f => f.isFavorite)?.length || 0);

    return {
      totalBookings,
      pendingTrips,
      savedItems
    };
  };

  const userStats = calculateStats();

  const handleSearch = () => {
    if (!searchParams.destination) {
      toast({
        title: "Destination Required",
        description: "Please enter a destination to search",
        variant: "destructive"
      });
      return;
    }

    // Construct search parameters
    const params = new URLSearchParams({
      location: searchParams.destination,
      checkIn: searchParams.checkIn,
      guests: searchParams.guests
    });

    // Redirect to hotels page with search parameters
    setLocation(`/hotels?${params.toString()}`);
  };

  // Online users state with real-time updates from Socket.IO
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);

  // Listen for user_list updates from socket.io
  useEffect(() => {
    const handleUserList = (users: OnlineUser[]) => {
      console.log('Received user list update:', users);
      setOnlineUsers(users);
    };

    // Register event handler
    socket.on('user_list', handleUserList);

    // Cleanup
    return () => {
      socket.off('user_list', handleUserList);
    };
  }, []);

  // Send location update if user is logged in
  useEffect(() => {
    if (!user) return;

    // Authenticate with socket when component mounts
    const authenticateSocket = () => {
      console.log('Authenticating socket with user:', user.username);
      socket.emit('auth', {
        id: user.id,
        username: user.username,
        colorScheme: 'default' // Using default theme since preferences.theme is not defined in schema
      });
    };

    // If socket is not connected, connect it
    if (!socket.connected) {
      console.log('Socket not connected, connecting...');
      socket.connect();
      socket.on('connect', () => {
        console.log('Socket connected, authenticating...');
        authenticateSocket();
      });
    } else {
      authenticateSocket();
    }

    const sendLocationUpdate = async () => {
      try {
        // First try to get browser geolocation
        try {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              enableHighAccuracy: true,
              timeout: 10000,
              maximumAge: 60000
            });
          });

          // Send location to server
          socket.emit('update_location', {
            userId: user.id,
            location: {
              lat: position.coords.latitude, 
              lng: position.coords.longitude
            }
          });
          
          console.log('Sent real location update:', {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          return; // Exit if we successfully got and sent the location
        } catch (geoError) {
          console.warn('Browser geolocation failed, using fallback location:', geoError);
          // Continue to fallback
        }

        // Fallback: Send a random location near a major city to ensure the map shows something
        // This is only for testing and ensures travelers appear on the map
        const fallbackLocations = [
          { lat: 40.7128, lng: -74.006 }, // New York
          { lat: 34.0522, lng: -118.2437 }, // Los Angeles
          { lat: 51.5074, lng: -0.1278 }, // London
          { lat: 48.8566, lng: 2.3522 }, // Paris
          { lat: 35.6762, lng: 139.6503 }, // Tokyo
        ];
        
        // Pick a random location and add slight variation
        const baseLocation = fallbackLocations[Math.floor(Math.random() * fallbackLocations.length)];
        const randomLocation = {
          lat: baseLocation.lat + (Math.random() * 0.02 - 0.01), // Add +/- 0.01 degree variation
          lng: baseLocation.lng + (Math.random() * 0.02 - 0.01)
        };
        
        // Send location to server
        socket.emit('update_location', {
          userId: user.id,
          location: randomLocation
        });
        
        console.log('Sent fallback location update:', randomLocation);
      } catch (error) {
        console.error('Error in location update process:', error);
        // If we can't get location, at least still authenticate the socket
        if (!socket.connected) {
          socket.connect();
          socket.on('connect', authenticateSocket);
        } else {
          authenticateSocket();
        }
      }
    };

    // Initially send location and then periodically update
    sendLocationUpdate();
    const locationInterval = setInterval(sendLocationUpdate, 60 * 1000); // Every minute

    // Setup a heartbeat to keep the connection alive
    const heartbeatInterval = setInterval(() => {
      if (socket.connected) {
        socket.emit('heartbeat', { userId: user.id });
      } else {
        console.log('Socket disconnected, reconnecting...');
        socket.connect();
        socket.on('connect', authenticateSocket);
      }
    }, 30 * 1000); // Every 30 seconds

    return () => {
      clearInterval(locationInterval);
      clearInterval(heartbeatInterval);
      socket.off('connect', authenticateSocket);
    };
  }, [user]);

  const isMobile = useIsMobile();
  const deviceInfo = useMobileOptimization();

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <TopNav />
      <ResponsivePage className="py-6 space-y-8">
        {/* AI Trip Planner Section */}
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-[#003580] to-[#00224f] rounded-lg opacity-95" />
          <div className="relative p-8 text-white">
            <div className="flex items-start justify-between mb-8">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Brain className="w-8 h-8" />
                  <h1 className="text-3xl font-bold">AI Trip Planner</h1>
                </div>
                <p className="text-lg text-white/90">Let our AI create your perfect travel experience</p>
              </div>
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                onClick={() => setLocation("/trip-planner")}
              >
                <PenTool className="w-4 h-4 mr-2" />
                Create Custom Plan
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-white/10 backdrop-blur border-0">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-full bg-white/20">
                      <Bot className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold">Smart Assistant</h3>
                  </div>
                  <p className="text-white/80 mb-4">
                    Get personalized recommendations and travel tips from our AI
                  </p>
                  <Button
                    variant="outline"
                    className="w-full bg-white/10 hover:bg-white/20 text-white border-white/20"
                    onClick={() => setLocation("/trip-planner")}
                  >
                    <Bot className="w-4 h-4 mr-2" />
                    Start Planning
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur border-0 border-2 border-yellow-400">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-full bg-white/20">
                      <Compass className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex items-center">
                      <h3 className="text-lg font-semibold">Destination Guide</h3>
                      <span className="ml-2 bg-yellow-400 text-black text-xs px-2 py-0.5 rounded-full font-semibold">NEW</span>
                    </div>
                  </div>
                  <p className="text-white/80 mb-4">
                    Discover amazing destinations with our comprehensive travel guides
                  </p>
                  <Button
                    variant="outline"
                    className="w-full bg-white/10 hover:bg-white/20 text-white border-white/20 gap-2 border-yellow-400"
                    onClick={() => setLocation("/destinations/explore")}
                  >
                    <Compass className="w-4 h-4" />
                    Explore Guide
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur border-0">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-full bg-white/20">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold">Quick Plan</h3>
                  </div>
                  <p className="text-white/80 mb-4">
                    Generate an instant itinerary for your next adventure
                  </p>
                  <Link href="/trip-planner/quick">
                    <Button
                      variant="outline"
                      className="w-full bg-white/10 hover:bg-white/20 text-white border-white/20"
                    >
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Now
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Welcome Section */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Welcome back, {user?.username}</h2>
            <p className="text-gray-600">Your travel dashboard</p>
          </div>
          <div className="flex gap-4">
            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  <span>{userStats.totalBookings} Bookings</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{userStats.pendingTrips} Pending Trips</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4" />
                  <span>{userStats.savedItems} Saved Items</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Search Section */}
        <Card className="bg-white shadow-lg border-0">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-4">
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Where are you going?"
                    className="pl-10 h-12"
                    value={searchParams.destination}
                    onChange={(e) => setSearchParams({ ...searchParams, destination: e.target.value })}
                  />
                </div>
              </div>
              <div className="md:col-span-3">
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    type="date"
                    className="pl-10 h-12"
                    value={searchParams.checkIn}
                    onChange={(e) => setSearchParams({ ...searchParams, checkIn: e.target.value })}
                    min={format(new Date(), 'yyyy-MM-dd')}
                  />
                </div>
              </div>
              <div className="md:col-span-3">
                <div className="relative">
                  <Users className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Select
                    value={searchParams.guests}
                    onValueChange={(value) => setSearchParams({ ...searchParams, guests: value })}
                  >
                    <SelectTrigger className="h-12 pl-10">
                      <SelectValue placeholder="2 adults · 0 children · 1 room" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2-0-1">2 adults · 0 children · 1 room</SelectItem>
                      <SelectItem value="2-1-1">2 adults · 1 child · 1 room</SelectItem>
                      <SelectItem value="2-2-1">2 adults · 2 children · 1 room</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="md:col-span-2">
                <Button
                  className="w-full h-12 bg-[#003580] hover:bg-[#00224f]"
                  onClick={handleSearch}
                >
                  <Search className="w-5 h-5 mr-2" />
                  Search
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Access Categories */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          {[
            { icon: Bed, label: "Stays", color: "bg-blue-100 text-blue-600", path: "/hotels", loading: hotelsLoading, count: hotels?.length },
            { icon: Plane, label: "Flights", color: "bg-purple-100 text-purple-600", path: "/flights", loading: flightsLoading, count: flights?.length },
            { icon: Car, label: "Car Rentals", color: "bg-green-100 text-green-600", path: "/rides", loading: ridesLoading, count: rides?.length },
            { icon: UtensilsCrossed, label: "Restaurants", color: "bg-orange-100 text-orange-600", path: "/dining", loading: diningLoading, count: dining?.length },
            { icon: Music, label: "Travel Soundtrack", color: "bg-pink-100 text-pink-600", path: "/soundtrack", loading: false, count: "New" },
            { icon: CreditCard, label: "Checkout", color: "bg-amber-100 text-amber-600", path: "/checkout", loading: false, count: "Secure" }
          ].map((item, index) => (
            <Link key={index} href={item.path}>
              <motion.div
                className="cursor-pointer"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <Card className={`${item.color} border-0`}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <item.icon className="h-6 w-6" />
                      <div>
                        <span className="font-medium">{item.label}</span>
                        {item.loading ? (
                          <Skeleton className="h-4 w-8 mt-1" />
                        ) : (
                          <p className="text-sm opacity-75">{item.count} Available</p>
                        )}
                      </div>
                    </div>
                    <ArrowRight className="h-5 w-5" />
                  </CardContent>
                </Card>
              </motion.div>
            </Link>
          ))}
        </div>

        {/* Proactive Suggestions Section */}
        <div className="dashboard-header rounded-lg shadow-sm p-6">
          <h2 className="text-2xl font-bold mb-6 text-white">AI Travel Recommendations</h2>
          <ProactiveSuggestions />
        </div>

        {/* Popular Activities */}
        <div className="mb-10">
          <PopularActivities />
        </div>
        
        {/* Local Events */}
        <div className="mb-10">
          <LocalEvents />
        </div>
        
        {/* Popular Destinations */}
        <div className="mb-10">
          <div className="relative p-4 bg-gradient-to-r from-[#003580] to-[#00224f] rounded-lg mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Compass className="w-6 h-6 text-white" />
                <h2 className="text-2xl font-bold text-white">Destination Guide Showcase</h2>
                <span className="bg-yellow-400 text-black text-xs px-2 py-0.5 rounded-full font-semibold">ACTIVE</span>
              </div>
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white/20"
                onClick={() => setLocation("/destinations/explore")}
              >
                View All Destinations
              </Button>
            </div>
          </div>
          <PopularDestinations />
        </div>

        {/* Chat and Map buttons */}
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
          <Button
            className="rounded-full h-14 w-14 bg-[#003580] hover:bg-[#002255] shadow-lg flex items-center justify-center"
            onClick={() => setShowMap(!showMap)}
          >
            <Globe className="h-6 w-6 text-white" />
          </Button>

          <Button
            className="rounded-full h-14 w-14 bg-[#003580] hover:bg-[#002255] shadow-lg flex items-center justify-center"
            onClick={() => setShowChat(!showChat)}
          >
            <MessageCircle className="h-6 w-6 text-white" />
          </Button>

          <AnimatePresence>
            {showMap && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute bottom-20 right-0 w-[800px]"
              >
                <Card className="overflow-hidden">
                  <CardHeader className="border-b bg-white shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Globe className="w-5 h-5 text-primary" />
                        <CardTitle>Travelers Map</CardTitle>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setShowMap(false)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <UserPresenceMap onlineUsers={onlineUsers} />
                </Card>
              </motion.div>
            )}

            {showChat && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute bottom-20 right-0 w-[800px]"
              >
                <ChatRoom />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </ResponsivePage>
    </div>
  );
}