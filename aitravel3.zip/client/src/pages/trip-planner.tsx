import React from "react";
import DashboardNav from "@/components/layout/dashboard-nav";
import { TripPlanningWorkflow } from "@/components/trip-workflow/trip-planning-workflow";

export default function TripPlannerPage() {
  return (
    <div className="flex min-h-screen flex-col lg:flex-row bg-gradient-to-b from-background to-secondary/10">
      <aside className="w-full lg:w-64 border-b lg:border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <DashboardNav />
      </aside>
      <main className="flex-1 overflow-hidden">
        <div className="h-full flex flex-col">
          <div className="bg-primary/5 border-b px-4 sm:px-8 py-4 sm:py-6">
            <div className="max-w-7xl mx-auto">
              <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                AI Trip Planner
              </h1>
              <p className="text-base sm:text-lg text-muted-foreground mt-2">
                Let AI create your perfect travel itinerary
              </p>
            </div>
          </div>

          <div className="flex-1 px-4 sm:px-8 py-4 sm:py-6 overflow-auto">
            <div className="max-w-7xl mx-auto">
              <TripPlanningWorkflow />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}