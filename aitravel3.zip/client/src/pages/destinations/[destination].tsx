import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Sun, Coins, Camera, Globe2, Heart, Clock, Users, Coffee } from "lucide-react";
import TopNav from "@/components/layout/top-nav";
import { cn } from "@/lib/utils";

// Define destination gallery images
const destinationGallery: Record<string, string[]> = {
  "Tokyo": [
    "https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80"
  ],
  "Paris": [
    "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1468413253725-0d5181091126?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1503917988258-f87a78e3c995?auto=format&fit=crop&q=80"
  ],
  "New York": [
    "https://images.unsplash.com/photo-1522083165195-3424ed129620?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1500916434205-0c77489c6cf7?auto=format&fit=crop&q=80",
    "https://images.unsplash.com/photo-1536599018102-9f803c140fc1?auto=format&fit=crop&q=80"
  ],
  // Add more destinations as needed
};

const defaultImages = [
  "https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&q=80"
];

export default function DestinationPage() {
  const [location] = useLocation();
  const destination = decodeURIComponent(location.split('/').pop() || '');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const images = destinationGallery[destination] || defaultImages;

  // Get query parameters
  const params = new URLSearchParams(window.location.search);
  const timing = params.get('timing');
  const budget = params.get('budget');
  const weather = params.get('weather');
  const activities = params.get('activities')?.split(',') || [];

  const { data: destinationData, isLoading } = useQuery({
    queryKey: ['/api/destinations', destination],
    queryFn: async () => {
      const response = await fetch(`/api/destinations/${encodeURIComponent(destination)}`);
      if (!response.ok) throw new Error('Failed to fetch destination data');
      return response.json();
    }
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [images.length]);

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"/>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <TopNav />

      {/* Hero Section with Parallax */}
      <div className="relative h-[70vh] overflow-hidden">
        <motion.div
          className="absolute inset-0"
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.7 }}
        >
          <div className="absolute inset-0 bg-black/40 z-10" />
          <img
            src={images[currentImageIndex]}
            alt={destination}
            className="w-full h-full object-cover transition-opacity duration-1000"
          />
        </motion.div>

        <div className="absolute inset-0 z-20 flex items-center justify-center">
          <div className="text-center text-white">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-6xl font-bold mb-4"
            >
              {destination}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-white/90"
            >
              Discover the magic of {destination}
            </motion.p>
          </div>
        </div>

        <Button
          variant="outline"
          size="icon"
          className={cn(
            "absolute top-4 right-4 z-30 bg-white/20 backdrop-blur-sm",
            "hover:bg-white/30 transition-colors"
          )}
          onClick={() => setIsFavorite(!isFavorite)}
        >
          <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
        </Button>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Quick Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="bg-blue-50">
            <CardContent className="p-6 flex items-center gap-4">
              <Calendar className="w-8 h-8 text-blue-500" />
              <div>
                <h3 className="font-medium">Best Time</h3>
                <p className="text-sm text-gray-600">{timing}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-green-50">
            <CardContent className="p-6 flex items-center gap-4">
              <Sun className="w-8 h-8 text-green-500" />
              <div>
                <h3 className="font-medium">Weather</h3>
                <p className="text-sm text-gray-600">{weather}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-purple-50">
            <CardContent className="p-6 flex items-center gap-4">
              <Coins className="w-8 h-8 text-purple-500" />
              <div>
                <h3 className="font-medium">Budget</h3>
                <p className="text-sm text-gray-600">${budget}/day</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-orange-50">
            <CardContent className="p-6 flex items-center gap-4">
              <Globe2 className="w-8 h-8 text-orange-500" />
              <div>
                <h3 className="font-medium">Activities</h3>
                <p className="text-sm text-gray-600">{activities.length} Available</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Photo Gallery Grid */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Camera className="w-6 h-6" />
            Photo Gallery
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {images.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative aspect-square overflow-hidden rounded-lg group cursor-pointer"
                onClick={() => setSelectedImage(image)}
              >
                <img
                  src={image}
                  alt={`${destination} ${index + 1}`}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Camera className="w-8 h-8 text-white" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Activities Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Popular Activities</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {activities.map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="overflow-hidden">
                  <img
                    src={images[index % images.length]}
                    alt={activity}
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="p-4">
                    <h3 className="font-medium mb-2">{activity}</h3>
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{destination}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Lightbox for Selected Image */}
        {selectedImage && (
          <div
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <motion.img
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              src={selectedImage}
              alt="Selected view"
              className="max-w-full max-h-[90vh] object-contain rounded-lg"
            />
            <Button
              variant="outline"
              size="icon"
              className="absolute top-4 right-4 bg-white/10"
              onClick={() => setSelectedImage(null)}
            >
              ✕
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}