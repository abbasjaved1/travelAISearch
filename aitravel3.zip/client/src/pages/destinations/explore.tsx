import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import TopNav from "@/components/layout/top-nav";
import { ExploreDestinations } from "@/components/ui/explore-destinations";
import { VideoPlayerModal } from "@/components/ui/video-player-modal";
import { 
  Globe, 
  TrendingUp, 
  MapPin, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  X, 
  Info, 
  Compass, 
  History, 
  Utensils,
  Camera,
  BookOpen,
  Hotel,
  Calendar,
  HeartPulse,
  Users,
  Landmark,
  ExternalLink,
  Mountain,
  Palmtree,
  Waves,
  Award,
  FileVideo,
  Briefcase,
  Coffee,
  Headphones
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogHeader, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";

export default function ExplorePage() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const heroVideoRef = useRef<HTMLVideoElement>(null);
  const [selectedVideo, setSelectedVideo] = useState<null | {
    title: string;
    src: string;
    isPlaying: boolean;
    source?: string;
    index: number;  // Added index to match what VideoPlayerModal expects
  }>(null);
  
  // Optimized video loading and playing approach
  useEffect(() => {
    // Display content quickly regardless of video state
    const quickShowTimer = setTimeout(() => {
      setIsLoaded(true); // Always ensure content is visible within 1.5s max
    }, 1500);
    
    const videoElement = heroVideoRef.current;
    if (videoElement) {
      // Preload attribute should be set to "auto" in the HTML
      // Quick check for already loaded video (common for repeat visits due to browser cache)
      if (videoElement.readyState >= 3) {
        clearTimeout(quickShowTimer);
        setIsLoaded(true);
        videoElement.play()
          .then(() => setIsPlaying(true))
          .catch(() => {/* Silent catch - play button is visible */});
        return;
      }
      
      // Single optimized handler for play events
      const handleVideoReady = () => {
        clearTimeout(quickShowTimer);
        setIsLoaded(true);
        
        // Try playing but don't wait for result - show content anyway
        videoElement.play()
          .then(() => setIsPlaying(true))
          .catch(() => {/* Silent catch - play button is visible */});
      };
      
      // Use the most compatible event - loadeddata is supported widely
      videoElement.addEventListener('loadeddata', handleVideoReady);
      
      // Backup check for slower connections - ensure UI is responsive
      const backupTimer = setTimeout(() => {
        if (!isLoaded) {
          setIsLoaded(true);
        }
      }, 2000);
      
      return () => {
        clearTimeout(quickShowTimer);
        clearTimeout(backupTimer);
        videoElement.removeEventListener('loadeddata', handleVideoReady);
      };
    }
  }, [isLoaded]);
  
  const handlePlayPause = () => {
    const video = heroVideoRef.current;
    if (video) {
      if (isPlaying) {
        video.pause();
        setIsPlaying(false);
      } else {
        // Create a promise to catch any play errors
        const playPromise = video.play();
        
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              console.log("Video playback started successfully");
              setIsPlaying(true);
            })
            .catch(error => {
              console.error("Error playing video:", error);
              // If autoplay is prevented, show a message and keep the button in "play" state
              alert("Video autoplay was prevented by your browser. Please click play again or check your browser settings.");
              setIsPlaying(false);
            });
        } else {
          // For older browsers that don't return a promise
          setIsPlaying(true);
        }
      }
    }
  };
  
  const handleMuteUnmute = () => {
    const video = heroVideoRef.current;
    if (video) {
      // Toggle mute state
      video.muted = !video.muted;
      setIsMuted(video.muted);
      
      // Log for debugging
      console.log("Video muted state changed:", video.muted);
      console.log("Video volume:", video.volume);
      
      // Ensure volume is set if unmuting
      if (!video.muted && video.volume === 0) {
        video.volume = 0.7; // Set to 70% volume when unmuting
        console.log("Set volume to 0.7");
      }
      
      // If unmuting and video is paused, try to play it
      if (!video.muted && !isPlaying) {
        try {
          const playPromise = video.play();
          if (playPromise !== undefined) {
            playPromise
              .then(() => {
                setIsPlaying(true);
                console.log("Video started playing after unmute");
              })
              .catch(err => {
                console.error("Failed to play video after unmuting:", err);
                // Show user-friendly message
                alert("Browser prevented video from playing with sound. Please click the play button.");
              });
          } else {
            setIsPlaying(true);
          }
        } catch (e) {
          console.error("Exception when trying to play video after unmuting:", e);
        }
      }
    }
  };
  
  const handleVideoCardClick = (videoTitle: string, index: number, source: string) => {
    // Simplified video handling with our new component
    console.log("Opening video:", videoTitle, "index:", index);
    
    // We need to convert the index to a number to ensure it works with the video player
    const videoIndex = typeof index === 'number' ? index : 0;
    
    setSelectedVideo({
      title: videoTitle,
      src: "", // We need this for type compatibility
      isPlaying: true,
      source: source,
      index: videoIndex // Explicitly adding index to fix video selection
    });
  };
  
  const closeVideoModal = () => {
    setSelectedVideo(null);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <TopNav />
      <main className="w-full max-w-[1140px] mx-auto px-4 py-6 space-y-8">
        {/* Hero Section */}
        <div className="relative rounded-lg overflow-hidden h-[400px]">
          <div className="absolute inset-0 bg-black">
            {/* Removed conditional rendering to ensure loading indicator doesn't get stuck */}
              <div className={`absolute inset-0 flex items-center justify-center bg-black z-20 transition-opacity duration-500 ${isLoaded ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
                <div className="flex flex-col items-center gap-3">
                  <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
                  <p className="text-white/80 text-sm animate-pulse">Loading amazing destinations...</p>
                </div>
              </div>
            
            {/* Static image that shows immediately while video loads (using a cached image for instant display) */}
            <div className={`absolute inset-0 z-10 transition-opacity duration-300 ${isLoaded ? 'opacity-0' : 'opacity-100'}`}>
              <img 
                src="https://images.unsplash.com/photo-1523482580672-f109ba8cb9be?ixlib=rb-4.0.3&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1600&h=400&fit=crop" 
                alt="Australia landscape"
                className="w-full h-full object-cover"
                loading="eager"
                decoding="async"
              />
            </div>
            
            <video 
              ref={heroVideoRef}
              className={`w-full h-full object-cover opacity-80 transition-opacity duration-500 ${isLoaded ? 'opacity-80' : 'opacity-0'}`}
              poster="https://images.unsplash.com/photo-1523482580672-f109ba8cb9be?ixlib=rb-4.0.3&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1600&h=400&fit=crop"
              loop
              playsInline
              preload="auto"
              crossOrigin="anonymous"
              // volume must be set via JavaScript, not as a direct attribute
              // Default muted is controlled in useEffect to allow sound when user unmutes
              onLoadedMetadata={(e) => {
                // Set initial volume
                e.currentTarget.volume = 0.7;
                // Start muted initially
                e.currentTarget.muted = true;
              }}
              // fetchpriority not supported in React's HTML attributes
            >
              {/* Using multiple sources for better reliability */}
              <source 
                src="https://assets.mixkit.co/videos/preview/mixkit-aerial-view-of-a-beach-and-hotel-zone-1625-large.mp4" 
                type="video/mp4" 
              />
              {/* Fallback options from different CDNs */}
              <source 
                src="https://static.videezy.com/system/resources/previews/000/005/781/original/Beach_Day.mp4" 
                type="video/mp4" 
              />
              <source 
                src="https://static.videezy.com/system/resources/previews/000/044/583/original/DSC_8581.mp4" 
                type="video/mp4" 
              />
              <source 
                src="https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4" 
                type="video/mp4" 
              />
              Your browser does not support the video tag.
            </video>
            
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent" />
          </div>

          <div className="relative p-8 md:p-12 text-white h-full flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <img src="/logos/aitraveglobe-logo.svg" alt="AITraveGlobe" className="w-6 h-6" onError={(e) => (e.currentTarget.style.display = 'none')} />
                <span className="text-sm font-medium bg-primary/70 px-2 py-1 rounded-full">Destination Guide</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Explore Amazing Destinations
              </h1>
              <p className="text-lg md:text-xl text-white/90 max-w-2xl">
                Discover breathtaking places around the world. From pristine beaches to bustling cities,
                find your next adventure here.
              </p>
            </div>
            
            <div className="flex gap-3">
              <Button 
                variant="secondary" 
                size="sm" 
                className="flex items-center gap-2 bg-black/50 hover:bg-black/70"
                onClick={handlePlayPause}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isPlaying ? "Pause" : "Play"} Video
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="bg-black/30 hover:bg-black/50 border-0"
                onClick={handleMuteUnmute}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Popular Searches */}
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Popular Searches
          </h2>
          <div className="flex flex-wrap gap-2">
            {[
              { term: "Beach Resorts", type: "beach", icon: <Waves className="w-4 h-4" /> },
              { term: "European Cities", type: "city", icon: <Landmark className="w-4 h-4" /> },
              { term: "Mountain Retreats", type: "mountain", icon: <Mountain className="w-4 h-4" /> },
              { term: "Island Getaways", type: "island", icon: <Palmtree className="w-4 h-4" /> },
              { term: "Cultural Tours", type: "cultural", icon: <History className="w-4 h-4" /> },
              { term: "Adventure Sports", type: "adventure", icon: <MapPin className="w-4 h-4" /> }
            ].map((item, index) => (
              <Card 
                key={index} 
                className="cursor-pointer hover:bg-primary hover:text-white transition-colors"
                onClick={() => {
                  // Scroll to the destinations section
                  const destinationsSection = document.getElementById('explore-destinations-section');
                  if (destinationsSection) {
                    destinationsSection.scrollIntoView({ behavior: 'smooth' });
                  }
                  
                  // Set the search type and trigger a search
                  const exploreComponent = document.getElementById('explore-destinations-component');
                  if (exploreComponent) {
                    // Dispatch a custom event that ExploreDestinations component will listen for
                    const searchEvent = new CustomEvent('setSearchType', { 
                      detail: { type: item.type, term: item.term }
                    });
                    exploreComponent.dispatchEvent(searchEvent);
                  }
                }}
              >
                <CardContent className="p-3 flex items-center gap-2">
                  {item.icon}
                  <span>{item.term}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Main Search and Results */}
        <div id="explore-destinations-section">
          <ExploreDestinations id="explore-destinations-component" />
        </div>
        
        {/* Featured Travel Videos */}
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Play className="w-5 h-5 text-primary" />
            Featured Travel Videos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Great Barrier Reef Underwater",
                location: "Queensland, Australia",
                duration: "4:25",
                views: "42K",
                thumbnail: "https://images.pexels.com/photos/3601425/pexels-photo-3601425.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop",
                source: "Travel Guide"
              },
              {
                title: "Sydney Harbour Timelapse",
                location: "Sydney, Australia",
                duration: "3:45",
                views: "31K",
                thumbnail: "https://images.pexels.com/photos/1878293/pexels-photo-1878293.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop",
                source: "Travel Guide"
              },
              {
                title: "Outback Journey: Australian Wildlife",
                location: "Northern Territory, Australia",
                duration: "5:12",
                views: "28K",
                thumbnail: "https://images.pexels.com/photos/162318/cheetah-animal-predator-speed-162318.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop",
                source: "Travel Guide"
              }
            ].map((video, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="relative">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title}
                    className="w-full h-48 object-cover" 
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Button 
                      variant="secondary" 
                      size="icon"
                      className="bg-black/30 hover:bg-primary border-0 rounded-full w-12 h-12"
                      onClick={() => handleVideoCardClick(video.title, index, video.source)}
                    >
                      <Play className="w-6 h-6" />
                    </Button>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    {video.duration}
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold">{video.title}</h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {video.location}
                      </p>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {video.views} views
                    </div>
                  </div>
                  <div className="flex items-center mt-3 justify-between">
                    <div className="flex items-center">
                      <img src="/logos/aitraveglobe-logo.svg" alt="AITraveGlobe" className="w-5 h-5 mr-2" />
                      <span className="text-xs font-medium">Travel Guide</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {video.source}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Cultural Immersion Experience - Virtual Tour Section */}
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Landmark className="w-5 h-5 text-primary" />
            Virtual Culture Immersion
          </h2>
          
          <Tabs defaultValue="asia" className="w-full">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="asia">Asia</TabsTrigger>
              <TabsTrigger value="europe">Europe</TabsTrigger>
              <TabsTrigger value="americas">Americas</TabsTrigger>
              <TabsTrigger value="africa">Africa</TabsTrigger>
            </TabsList>
            
            <TabsContent value="asia" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/3800117/pexels-photo-3800117.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="Japan" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Featured</Badge>
                      <h3 className="text-xl font-semibold">Japan</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Cuisine
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <History className="w-3 h-3" /> Heritage
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> Festivals
                      </Badge>
                    </div>
                    
                    {/* Active travel planning information */}
                    <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Best Time to Visit</span>
                        <span>March-May (Cherry blossoms)<br/>Oct-Nov (Fall colors)</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Weather</span>
                        <span>Four distinct seasons<br/>Mild spring & autumn</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Budget (per day)</span>
                        <span>Budget: $70-100<br/>Luxury: $200-300</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Top Activities</span>
                        <span>Temple visits, Hot springs,<br/>Food tours, Hiking</span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">
                      Immerse yourself in the blend of ancient traditions and cutting-edge modernity. From samurai culture to anime, Japan offers a unique cultural experience.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.japan.travel/en/', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/5766675/pexels-photo-5766675.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="India" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Popular</Badge>
                      <h3 className="text-xl font-semibold">India</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Cuisine
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <History className="w-3 h-3" /> Heritage
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Users className="w-3 h-3" /> Traditions
                      </Badge>
                    </div>
                    
                    {/* Active travel planning information */}
                    <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Best Time to Visit</span>
                        <span>Oct-Mar (Cool & dry)<br/>Varies by region</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Weather</span>
                        <span>Tropical south<br/>Alpine north</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Budget (per day)</span>
                        <span>Budget: $30-50<br/>Luxury: $150-250</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Top Activities</span>
                        <span>Taj Mahal, Kerala backwaters,<br/>Food tours, Yoga retreats</span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">
                      Discover the colorful tapestry of cultures, languages, and traditions. From the Himalayan peaks to tropical beaches, experience India's rich diversity.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.incredibleindia.org/', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Virtual Experiences for Asia */}
              <div className="bg-primary/5 rounded-lg p-4">
                <h3 className="text-lg font-medium flex items-center gap-2 mb-3">
                  <Camera className="w-5 h-5 text-primary" />
                  Virtual Experiences
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    {
                      title: "Tokyo Street Food Tour",
                      url: "https://artsandculture.google.com/story/HAWx9OYeADQqKg",
                      icon: <Utensils className="w-4 h-4" />
                    },
                    {
                      title: "Kyoto Temple Virtual Tour",
                      url: "https://artsandculture.google.com/partner/kyoto-national-museum",
                      icon: <Landmark className="w-4 h-4" />
                    },
                    {
                      title: "Taj Mahal 360° Tour",
                      url: "https://artsandculture.google.com/partner/taj-mahal",
                      icon: <Compass className="w-4 h-4" />
                    },
                    {
                      title: "Bangkok Canal Journey",
                      url: "https://artsandculture.google.com/story/the-stories-and-secrets-of-bangkok-s-canals-the-golden-triangle-asian-elephant-foundation/gQURRn9OfBfLLQ",
                      icon: <Compass className="w-4 h-4" />
                    }
                  ].map((exp, index) => (
                    <Button 
                      key={index}
                      variant="ghost" 
                      className="h-auto flex-col items-center justify-start gap-2 p-2 text-xs"
                      onClick={() => window.open(exp.url, '_blank')}
                    >
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                        {exp.icon}
                      </div>
                      <span className="text-center">{exp.title}</span>
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Popular Events and Sports in Asia */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  Popular Events & Sports
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Japan */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">Japan</CardTitle>
                        <img src="https://flagcdn.com/w40/jp.png" alt="Japan Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Cherry Blossom Festival</span>
                            <p className="text-xs text-muted-foreground">March-April | Nationwide celebration of sakura blooms with picnics and night illuminations</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Award className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Sumo Tournament</span>
                            <p className="text-xs text-muted-foreground">Jan, Mar, May, Jul, Sep, Nov | Grand Sumo tournaments in Tokyo, Osaka, Nagoya and Fukuoka</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* India */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">India</CardTitle>
                        <img src="https://flagcdn.com/w40/in.png" alt="India Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Holi Festival</span>
                            <p className="text-xs text-muted-foreground">March | The colorful spring festival celebrating love and triumph of good over evil</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Award className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">IPL Cricket</span>
                            <p className="text-xs text-muted-foreground">March-May | The Indian Premier League attracts the world's best cricket players</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Singapore */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">Singapore</CardTitle>
                        <img src="https://flagcdn.com/w40/sg.png" alt="Singapore Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Singapore F1 Grand Prix</span>
                            <p className="text-xs text-muted-foreground">September | The only night race in Formula 1, spectacular views of Marina Bay</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Utensils className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Singapore Food Festival</span>
                            <p className="text-xs text-muted-foreground">July | Showcases local cuisine, innovative food experiences, and culinary workshops</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Thailand */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">Thailand</CardTitle>
                        <img src="https://flagcdn.com/w40/th.png" alt="Thailand Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Songkran Water Festival</span>
                            <p className="text-xs text-muted-foreground">April | Thai New Year celebrated with water fights throughout the country</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Award className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Muay Thai Boxing</span>
                            <p className="text-xs text-muted-foreground">Year-round | Watch authentic matches at Bangkok's Rajadamnern Stadium</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="europe" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/1797161/pexels-photo-1797161.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="Italy" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Featured</Badge>
                      <h3 className="text-xl font-semibold">Italy</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Cuisine
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <History className="w-3 h-3" /> Architecture
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" /> Art
                      </Badge>
                    </div>
                    
                    {/* Active travel planning information */}
                    <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Best Time to Visit</span>
                        <span>Apr-Jun & Sep-Oct<br/>(Mild weather, fewer crowds)</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Weather</span>
                        <span>Mediterranean climate<br/>Hot summers, mild winters</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Budget (per day)</span>
                        <span>Budget: €60-100<br/>Luxury: €200-350</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Top Activities</span>
                        <span>Colosseum, Venice canals,<br/>Food tours, Art galleries</span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">
                      Experience the cradle of Western civilization with rich art, delicious cuisine, and architectural wonders spanning from ancient Rome to Renaissance masterpieces.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.italia.it/en', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/532826/pexels-photo-532826.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="France" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Popular</Badge>
                      <h3 className="text-xl font-semibold">France</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Cuisine
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" /> Arts
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Hotel className="w-3 h-3" /> Landmarks
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Dive into a world of exquisite cuisine, fashion, art, and architecture. From the romantic streets of Paris to the lavender fields of Provence.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.france.fr/en', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Virtual Experiences for Europe */}
              <div className="bg-primary/5 rounded-lg p-4">
                <h3 className="text-lg font-medium flex items-center gap-2 mb-3">
                  <Camera className="w-5 h-5 text-primary" />
                  Virtual Experiences
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    {
                      title: "Louvre Museum Tour",
                      url: "https://www.louvre.fr/en/online-tours",
                      icon: <BookOpen className="w-4 h-4" />
                    },
                    {
                      title: "Vatican Museums",
                      url: "https://www.museivaticani.va/content/museivaticani/en/collezioni/musei/tour-virtuali-elenco.html",
                      icon: <Landmark className="w-4 h-4" />
                    },
                    {
                      title: "Amsterdam Canals",
                      url: "https://artsandculture.google.com/partner/van-gogh-museum",
                      icon: <Compass className="w-4 h-4" />
                    },
                    {
                      title: "Greek Acropolis",
                      url: "https://artsandculture.google.com/story/the-acropolis-of-athens-acropolis-museum/bgJCgPpf5wZMJQ",
                      icon: <History className="w-4 h-4" />
                    }
                  ].map((exp, index) => (
                    <Button 
                      key={index}
                      variant="ghost" 
                      className="h-auto flex-col items-center justify-start gap-2 p-2 text-xs"
                      onClick={() => window.open(exp.url, '_blank')}
                    >
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                        {exp.icon}
                      </div>
                      <span className="text-center">{exp.title}</span>
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Popular Events and Sports in Europe */}
              <div className="space-y-4 mt-6">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  Popular Events & Sports
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Spain */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">Spain</CardTitle>
                        <img src="https://flagcdn.com/w40/es.png" alt="Spain Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">La Tomatina</span>
                            <p className="text-xs text-muted-foreground">Last Wednesday of August | Famous tomato-throwing festival in Buñol</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Award className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">El Clásico</span>
                            <p className="text-xs text-muted-foreground">Twice per season | The legendary football match between FC Barcelona and Real Madrid</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* United Kingdom */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">United Kingdom</CardTitle>
                        <img src="https://flagcdn.com/w40/gb.png" alt="UK Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Wimbledon</span>
                            <p className="text-xs text-muted-foreground">Late June to early July | The oldest tennis tournament in the world</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Headphones className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Glastonbury Festival</span>
                            <p className="text-xs text-muted-foreground">Last weekend in June | One of the world's most famous music festivals</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Germany */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">Germany</CardTitle>
                        <img src="https://flagcdn.com/w40/de.png" alt="Germany Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Coffee className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Oktoberfest</span>
                            <p className="text-xs text-muted-foreground">Late September to early October | World's largest beer festival in Munich</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Award className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Bundesliga</span>
                            <p className="text-xs text-muted-foreground">August to May | Germany's primary football competition</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* France */}
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">France</CardTitle>
                        <img src="https://flagcdn.com/w40/fr.png" alt="France Flag" className="h-5" />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3 pt-0">
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <Globe className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Tour de France</span>
                            <p className="text-xs text-muted-foreground">July | The world's most prestigious bicycle race</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                            <FileVideo className="w-3 h-3 text-primary" />
                          </div>
                          <div>
                            <span className="font-medium">Cannes Video Festival</span>
                            <p className="text-xs text-muted-foreground">May | One of the world's most prestigious film festivals</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="americas" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/2834219/pexels-photo-2834219.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="Peru" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Historical</Badge>
                      <h3 className="text-xl font-semibold">Peru</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <History className="w-3 h-3" /> Inca Culture
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Landmark className="w-3 h-3" /> Archaeological Sites
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Diverse Cuisine
                      </Badge>
                    </div>
                    
                    {/* Active travel planning information */}
                    <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Best Time to Visit</span>
                        <span>May-Sep (Dry season)<br/>Best for Machu Picchu</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Weather</span>
                        <span>Varies by altitude<br/>Dry highlands, humid jungle</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Budget (per day)</span>
                        <span>Budget: $40-70<br/>Comfort: $100-200</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Top Activities</span>
                        <span>Machu Picchu, Cusco,<br/>Sacred Valley, Lake Titicaca</span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">
                      Discover the ancient civilization of the Incas, explore Machu Picchu, and experience the rich cultural heritage blending indigenous and colonial influences.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.peru.travel/en', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/2363/france-landmark-lights-night.jpg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="Mexico" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Vibrant</Badge>
                      <h3 className="text-xl font-semibold">Mexico</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> Festivals
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Cuisine
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <History className="w-3 h-3" /> Ancient Civilizations
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Experience a colorful blend of indigenous traditions and Spanish heritage through vibrant festivals, world-renowned cuisine, and archaeological wonders.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.visitmexico.com/en/', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Virtual Experiences for Americas */}
              <div className="bg-primary/5 rounded-lg p-4">
                <h3 className="text-lg font-medium flex items-center gap-2 mb-3">
                  <Camera className="w-5 h-5 text-primary" />
                  Virtual Experiences
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    {
                      title: "Machu Picchu Tour",
                      url: "https://artsandculture.google.com/story/explore-machu-picchu-the-lost-city-of-the-inca-museo-larco/QQXhieXpEBxBLw",
                      icon: <Landmark className="w-4 h-4" />
                    },
                    {
                      title: "Mayan Ruins",
                      url: "https://artsandculture.google.com/story/9gVBGzeLLGIYKw",
                      icon: <History className="w-4 h-4" />
                    },
                    {
                      title: "Grand Canyon",
                      url: "https://artsandculture.google.com/story/fAVB22Uk_nzyLQ",
                      icon: <Compass className="w-4 h-4" />
                    },
                    {
                      title: "Day of the Dead",
                      url: "https://artsandculture.google.com/story/8QVhv7Yd9anxrw",
                      icon: <Calendar className="w-4 h-4" />
                    }
                  ].map((exp, index) => (
                    <Button 
                      key={index}
                      variant="ghost" 
                      className="h-auto flex-col items-center justify-start gap-2 p-2 text-xs"
                      onClick={() => window.open(exp.url, '_blank')}
                    >
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                        {exp.icon}
                      </div>
                      <span className="text-center">{exp.title}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="africa" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/3889843/pexels-photo-3889843.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="Morocco" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Colorful</Badge>
                      <h3 className="text-xl font-semibold">Morocco</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Landmark className="w-3 h-3" /> Architecture
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Utensils className="w-3 h-3" /> Cuisine
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Users className="w-3 h-3" /> Traditions
                      </Badge>
                    </div>
                    
                    {/* Active travel planning information */}
                    <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Best Time to Visit</span>
                        <span>Mar-May & Sep-Nov<br/>(Mild temps, fewer crowds)</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Weather</span>
                        <span>Mediterranean coast<br/>Hot desert interior</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Budget (per day)</span>
                        <span>Budget: $40-70<br/>Comfort: $100-200</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Top Activities</span>
                        <span>Marrakech medina, Fes,<br/>Sahara desert tours, Atlas hikes</span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">
                      Explore labyrinthine medinas, taste flavorful tagines, and discover the rich Berber heritage in this vibrant North African cultural crossroads.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://www.visitmorocco.com/en', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="overflow-hidden">
                  <div className="relative h-48">
                    <img 
                      src="https://images.pexels.com/photos/59989/elephant-calf-tsavo-kenya-59989.jpeg?auto=compress&cs=tinysrgb&w=800&h=450&fit=crop" 
                      alt="Kenya" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <Badge className="bg-primary mb-2">Natural</Badge>
                      <h3 className="text-xl font-semibold">Kenya</h3>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <HeartPulse className="w-3 h-3" /> Wildlife
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Users className="w-3 h-3" /> Maasai Culture
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> Tribal Traditions
                      </Badge>
                    </div>
                    
                    {/* Active travel planning information */}
                    <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Best Time to Visit</span>
                        <span>Jun-Oct & Jan-Feb<br/>(Dry season for safaris)</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Weather</span>
                        <span>Warm year-round<br/>Higher elevations cooler</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Budget (per day)</span>
                        <span>Budget: $50-100<br/>Safari: $200-500</span>
                      </div>
                      <div className="bg-primary/5 p-2 rounded">
                        <span className="font-semibold text-primary block">Top Activities</span>
                        <span>Maasai Mara safari, Amboseli,<br/>Cultural visits, Beaches</span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">
                      Witness the Maasai culture, experience stunning wildlife safaris in the savanna, and learn about the rich tribal heritage and traditions.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.open('https://magicalkenya.com/', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" /> Explore Official Guide
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Virtual Experiences for Africa */}
              <div className="bg-primary/5 rounded-lg p-4">
                <h3 className="text-lg font-medium flex items-center gap-2 mb-3">
                  <Camera className="w-5 h-5 text-primary" />
                  Virtual Experiences
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    {
                      title: "Serengeti Safari",
                      url: "https://artsandculture.google.com/story/HAWxpYn4VgtIJg",
                      icon: <HeartPulse className="w-4 h-4" />
                    },
                    {
                      title: "Egyptian Pyramids",
                      url: "https://artsandculture.google.com/story/gwVx69ShdiVBKA",
                      icon: <Landmark className="w-4 h-4" />
                    },
                    {
                      title: "Moroccan Medinas",
                      url: "https://artsandculture.google.com/story/explore-moroccan-medinas-and-markets-the-british-museum/ZwXREP0lD1MWLA",
                      icon: <Compass className="w-4 h-4" />
                    },
                    {
                      title: "Cape Town Culture",
                      url: "https://artsandculture.google.com/story/bSWRVhXa-R-W_w",
                      icon: <Users className="w-4 h-4" />
                    }
                  ].map((exp, index) => (
                    <Button 
                      key={index}
                      variant="ghost" 
                      className="h-auto flex-col items-center justify-start gap-2 p-2 text-xs"
                      onClick={() => window.open(exp.url, '_blank')}
                    >
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                        {exp.icon}
                      </div>
                      <span className="text-center">{exp.title}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Cultural Knowledge Hub */}
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" />
            Cultural Knowledge Hub
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold flex items-center gap-2 mb-3">
                  <Calendar className="w-5 h-5 text-primary" />
                  Upcoming Global Festivals
                </h3>
                <ScrollArea className="h-48 rounded-md">
                  <div className="space-y-3 pr-3">
                    {[
                      {
                        name: "Diwali Festival of Lights",
                        location: "India",
                        date: "November 1-5, 2025",
                        url: "https://www.incredibleindia.org/content/incredible-india-v2/en/experiences/spiritual/diwali.html"
                      },
                      {
                        name: "Cherry Blossom Festival",
                        location: "Japan",
                        date: "March-April 2026",
                        url: "https://www.japan.travel/en/story/hanami/"
                      },
                      {
                        name: "Carnival of Venice",
                        location: "Italy",
                        date: "February 14-28, 2026",
                        url: "https://www.carnevale.venezia.it/en/"
                      },
                      {
                        name: "Día de los Muertos",
                        location: "Mexico",
                        date: "November 1-2, 2025",
                        url: "https://www.visitmexico.com/en/cultural-tourism/day-of-the-dead-in-mexico"
                      },
                      {
                        name: "Songkran Water Festival",
                        location: "Thailand",
                        date: "April 13-15, 2026",
                        url: "https://www.tourismthailand.org/Attraction/songkran-festival"
                      }
                    ].map((festival, index) => (
                      <div key={index} className="pb-3 border-b last:border-0">
                        <div className="font-medium">{festival.name}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1 mb-1.5">
                          <MapPin className="w-3 h-3" /> {festival.location}
                        </div>
                        <div className="text-xs text-muted-foreground mb-1.5">{festival.date}</div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="p-0 h-auto text-primary text-xs hover:underline"
                          onClick={() => window.open(festival.url, '_blank')}
                        >
                          Learn more <ExternalLink className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold flex items-center gap-2 mb-3">
                  <Utensils className="w-5 h-5 text-primary" />
                  Global Culinary Journeys
                </h3>
                <ScrollArea className="h-48 rounded-md">
                  <div className="space-y-3 pr-3">
                    {[
                      {
                        cuisine: "Thai Cuisine",
                        dish: "Pad Thai & Tom Yum",
                        description: "Complex flavors balancing sweet, sour, salty and spicy elements",
                        url: "https://www.tourismthailand.org/Articles/thai-food-culture"
                      },
                      {
                        cuisine: "Mediterranean Diet",
                        dish: "Greek & Italian Specialties",
                        description: "Olive oil, fresh vegetables, and seafood form the foundation",
                        url: "https://www.visitgreece.gr/experiences/culture/gastronomy/"
                      },
                      {
                        cuisine: "Mexican Flavors",
                        dish: "Tacos & Mole Sauces",
                        description: "Rich in variety with corn, beans, chilies and chocolate",
                        url: "https://www.visitmexico.com/en/gastronomic-tourism/mexican-gastronomy"
                      },
                      {
                        cuisine: "Japanese Tradition",
                        dish: "Sushi & Ramen",
                        description: "Seasonal, minimal, and respectful of ingredients",
                        url: "https://www.japan.travel/en/guide/japanese-food-guide/"
                      },
                      {
                        cuisine: "Moroccan Flavors",
                        dish: "Tagine & Couscous",
                        description: "Aromatic spices like cumin, coriander and cinnamon",
                        url: "https://www.visitmorocco.com/en/moroccan-gastronomy"
                      }
                    ].map((food, index) => (
                      <div key={index} className="pb-3 border-b last:border-0">
                        <div className="font-medium">{food.cuisine}</div>
                        <div className="text-sm text-muted-foreground mb-1">{food.dish}</div>
                        <div className="text-xs text-muted-foreground mb-1.5">{food.description}</div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="p-0 h-auto text-primary text-xs hover:underline"
                          onClick={() => window.open(food.url, '_blank')}
                        >
                          Explore recipes <ExternalLink className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold flex items-center gap-2 mb-3">
                  <Landmark className="w-5 h-5 text-primary" />
                  Heritage Sites Explorer
                </h3>
                <ScrollArea className="h-48 rounded-md">
                  <div className="space-y-3 pr-3">
                    {[
                      {
                        site: "Machu Picchu",
                        location: "Peru",
                        description: "15th century Inca citadel set against a breathtaking mountain backdrop",
                        url: "https://www.peru.travel/en/attractions/machu-picchu"
                      },
                      {
                        site: "Angkor Wat",
                        location: "Cambodia",
                        description: "Largest religious monument in the world, built in the early 12th century",
                        url: "https://www.tourismcambodia.com/attractions/angkor.htm"
                      },
                      {
                        site: "Taj Mahal",
                        location: "India",
                        description: "Ivory-white marble mausoleum commissioned in 1632 by the Mughal emperor",
                        url: "https://www.incredibleindia.org/content/incredible-india-v2/en/destinations/agra/taj-mahal.html"
                      },
                      {
                        site: "Acropolis of Athens",
                        location: "Greece",
                        description: "Ancient citadel containing the Parthenon and other monuments of ancient Athens",
                        url: "https://www.visitgreece.gr/mainland/attica/the-acropolis-of-athens/"
                      },
                      {
                        site: "Petra",
                        location: "Jordan",
                        description: "Archaeological city famous for its rock-cut architecture and water conduit system",
                        url: "https://www.visitjordan.com/petra/"
                      }
                    ].map((site, index) => (
                      <div key={index} className="pb-3 border-b last:border-0">
                        <div className="font-medium">{site.site}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1 mb-1">
                          <MapPin className="w-3 h-3" /> {site.location}
                        </div>
                        <div className="text-xs text-muted-foreground mb-1.5">{site.description}</div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="p-0 h-auto text-primary text-xs hover:underline"
                          onClick={() => window.open(site.url, '_blank')}
                        >
                          View virtual tour <ExternalLink className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* Featured Regions */}
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Featured Regions
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "Europe", count: "234 destinations" },
              { name: "Asia", count: "186 destinations" },
              { name: "Americas", count: "167 destinations" },
              { name: "Africa", count: "89 destinations" }
            ].map((region, index) => (
              <Card key={index} className="cursor-pointer hover:bg-primary hover:text-white transition-colors">
                <CardContent className="p-4">
                  <h3 className="font-semibold">{region.name}</h3>
                  <p className="text-sm text-muted-foreground">{region.count}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      {/* Video Player Modal */}
      <VideoPlayerModal 
        isOpen={selectedVideo !== null}
        onClose={closeVideoModal}
        videoData={selectedVideo ? { 
          title: selectedVideo.title,
          source: selectedVideo.source || "Travel Guide",
          index: selectedVideo.index // Use the index passed when calling handleVideoCardClick
        } : null}
      />
    </div>
  );
}