import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { LocalExperiences } from "@/components/ui/local-experiences";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, MapPin, Sun, Users, Coins } from "lucide-react";
import TopNav from "@/components/layout/top-nav";

export default function DestinationPage() {
  const [match, params] = useRoute("/destinations/:id");
  const destinationId = params?.id;
  console.log('Destination route params:', { match, destinationId });

  const searchParams = new URLSearchParams(window.location.search);

  const { data: destination, isLoading } = useQuery({
    queryKey: ['/api/destinations', destinationId],
    queryFn: async () => {
      if (!destinationId) {
        throw new Error('No destination ID provided');
      }
      const apiUrl = `/api/destinations/${encodeURIComponent(destinationId)}`;
      console.log('Fetching destination data from:', apiUrl);

      const response = await fetch(apiUrl);
      if (!response.ok) {
        const error = await response.text();
        console.error('Destination fetch error:', error);
        throw new Error(`Failed to fetch destination: ${error}`);
      }
      return response.json();
    },
    enabled: !!destinationId
  });

  if (!destinationId) {
    return (
      <div className="min-h-screen bg-background">
        <TopNav />
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-2xl">Destination not found</h1>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <TopNav />
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-64 w-full mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      <div 
        className="h-64 bg-cover bg-center relative"
        style={{ backgroundImage: `url(${destination?.image})` }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <h1 className="text-4xl font-bold text-white">{destination?.name}</h1>
          <p className="text-white/90 mt-2">{destination?.description}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4">Overview</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-[#003580]" />
                  <span>Best time to visit: {searchParams.get('timing')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-[#003580]" />
                  <span>Location: {destination?.region}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Sun className="w-5 h-5 text-[#003580]" />
                  <span>Weather: {destination?.weather}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#003580]" />
                  <span>Typical crowd: {destination?.crowdLevel}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Coins className="w-5 h-5 text-[#003580]" />
                  <span>Average budget: ${searchParams.get('budget')}/day</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="md:col-span-2">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Local Events</h3>
                <div className="space-y-4">
                  {destination?.events?.map((event) => (
                    <div key={event.id} className="p-4 bg-muted rounded-lg">
                      <h4 className="font-medium">{event.name}</h4>
                      <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-sm">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{event.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{event.venue}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-6">Local Experiences</h2>
          <LocalExperiences location={destinationId} />
        </div>
      </div>
    </div>
  );
}