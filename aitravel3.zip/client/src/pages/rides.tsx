import { useQuery } from "@tanstack/react-query";
import { RideBooking } from "@shared/schema";
import DashboardNav from "@/components/layout/dashboard-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Clock, Car, Shield, Star, Search, MapPin } from "lucide-react";
import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { PaymentForm } from "@/components/PaymentForm";
import { StripeProvider } from "@/components/StripeProvider";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { generateRides } from "@shared/mockData";
import { LocationSearch, type Location } from "@/components/ui/location-search";
import { RideLocationMap } from "@/components/ui/ride-location-map";

export default function RidesPage() {
  const { toast } = useToast();
  const [showPayment, setShowPayment] = useState(false);
  const [selectedRide, setSelectedRide] = useState<RideBooking | null>(null);
  const [driverEta, setDriverEta] = useState<string | null>(null);
  const [pickupLocation, setPickupLocation] = useState<Location | null>(null);
  const [dropLocation, setDropLocation] = useState<Location | null>(null);

  const { data: rides, isLoading } = useQuery<RideBooking[]>({
    queryKey: ["/api/rides"],
    initialData: generateRides(8),
  });

  // Simulate route calculation
  const calculateRoute = useCallback(() => {
    if (!pickupLocation || !dropLocation) {
      toast({
        title: "Invalid Locations",
        description: "Please select both pickup and drop-off locations.",
        variant: "destructive",
      });
      return;
    }

    // Create a ride booking with the selected locations
    const newRide = {
      id: Date.now().toString(),
      pickupLocation: pickupLocation.description, //Corrected to use actual location
      dropoffLocation: dropLocation.description, //Corrected to use actual location
      price: Math.floor(Math.random() * 50) + 30,
      type: "Standard",
      status: "available",
      from: pickupLocation.description,
      to: dropLocation.description
    };

    setSelectedRide(newRide as RideBooking);

    // Simulate driver ETA calculation
    const driverMinutes = Math.floor(Math.random() * 6) + 5;
    setDriverEta(`${driverMinutes} minutes`);
  }, [pickupLocation, dropLocation, toast]);

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <aside className="w-64 border-r bg-white shadow-sm fixed h-full z-10">
        <DashboardNav />
      </aside>
      <main className="ml-64">
        {/* Hero Search Section */}
        <div className="bg-[#003580] text-white p-4 sm:p-8">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-6">Book your ride</h1>
            <p className="text-base sm:text-lg mb-6 sm:mb-8 text-white/90">
              Safe, reliable rides at great prices
            </p>

            <Card className="bg-white shadow-lg border-0">
              <CardContent className="p-4 sm:p-6">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  {/* Pickup Location */}
                  <div className="md:col-span-5">
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Pickup Location
                    </label>
                    <LocationSearch
                      onLocationSelect={setPickupLocation}
                      placeholder="Enter pickup location"
                      className="w-full"
                    />
                  </div>

                  {/* Drop-off Location */}
                  <div className="md:col-span-5">
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Drop-off Location
                    </label>
                    <LocationSearch
                      onLocationSelect={setDropLocation}
                      placeholder="Enter drop-off location"
                      className="w-full"
                    />
                  </div>

                  {/* Search Button */}
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      &nbsp;
                    </label>
                    <Button 
                      className="w-full h-12 bg-[#006CE4] hover:bg-[#003580] text-white text-lg font-semibold"
                      size="lg"
                      onClick={calculateRoute}
                      disabled={!pickupLocation || !dropLocation}
                    >
                      <Search className="w-5 h-5 mr-2" />
                      Search
                    </Button>
                  </div>
                </div>

                {/* Mock Map Visualization */}
                {selectedRide && (
                  <div className="mt-6">
                    <RideLocationMap ride={selectedRide} />
                  </div>
                )}

                {driverEta && (
                  <div className="mt-4 p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2 text-green-700">
                      <Car className="w-5 h-5" />
                      <span className="font-medium">
                        Nearest driver is {driverEta} away
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Available Rides */}
        <div className="max-w-6xl mx-auto p-8">
          <h2 className="text-2xl font-bold mb-6">Available Vehicles</h2>
          <div className="grid grid-cols-1 gap-6">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="border-0 shadow">
                  <CardContent className="p-6">
                    <Skeleton className="h-32" />
                  </CardContent>
                </Card>
              ))
            ) : (
              rides?.map((ride) => (
                <Card key={ride.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-0">
                    <div className="flex">
                      {/* Car Image */}
                      <div 
                        className="relative w-72 bg-cover bg-center"
                        style={{ 
                          backgroundImage: `url(https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&q=80&w=300)` 
                        }}
                      >
                        {ride.price < 100 && (
                          <Badge className="absolute top-4 left-4 bg-green-600">
                            Special Offer
                          </Badge>
                        )}
                      </div>

                      {/* Car Details */}
                      <div className="flex-1 p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-semibold">{ride.type}</h3>
                            <p className="text-sm text-gray-500">or similar</p>
                          </div>
                          <div className="flex items-center bg-[#003580] text-white px-2 py-1 rounded">
                            <Star className="w-4 h-4 fill-current" />
                            <span className="ml-1 font-bold">4.8</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
                          <Shield className="w-5 h-5 text-green-600" />
                          <span className="text-green-600 font-medium">Free cancellation</span>
                        </div>

                        <div className="flex items-center justify-between mt-6">
                          <div className="text-right">
                            <div className="text-2xl font-bold text-[#003580]">
                              ${ride.price}
                              <span className="text-sm font-normal text-gray-500 ml-1">per day</span>
                            </div>
                            <Dialog
                              open={showPayment && selectedRide?.id === ride.id}
                              onOpenChange={(open) => {
                                if (!open) {
                                  setShowPayment(false);
                                  setSelectedRide(null);
                                }
                              }}
                            >
                              <DialogTrigger asChild>
                                <Button
                                  size="lg"
                                  className="mt-2 bg-[#006CE4] hover:bg-[#003580] text-white"
                                  onClick={() => {
                                    setSelectedRide(ride);
                                    setShowPayment(true);
                                  }}
                                >
                                  Book Now
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-md">
                                <StripeProvider 
                                  amount={ride.price}
                                  bookingType="ride"
                                  bookingDetails={{
                                    ride: {
                                      type: ride.type,
                                      from: ride.from,
                                      to: ride.to,
                                      price: ride.price,
                                      id: ride.id
                                    }
                                  }}
                                >
                                  <PaymentForm
                                    amount={ride.price}
                                    details={{
                                      ride: {
                                        type: ride.type,
                                        from: ride.from,
                                        to: ride.to,
                                        price: ride.price,
                                        id: ride.id
                                      },
                                      flight: null,
                                      hotel: null,
                                      dining: null,
                                      passengers: 1
                                    }}
                                    bookingType="ride" 
                                    onSuccess={async () => {
                                      try {
                                        const res = await fetch(`/api/rides/${ride.id}/book`, {
                                          method: "POST",
                                          credentials: "include",
                                        });
                                        if (!res.ok) throw new Error("Booking failed");
                                        setShowPayment(false);
                                        setSelectedRide(null);
                                        toast({
                                          title: "Booking Successful",
                                          description: "Your car has been reserved successfully.",
                                        });
                                      } catch (error) {
                                        console.error("Booking error:", error);
                                        toast({
                                          title: "Booking Failed",
                                          description: "Failed to reserve the car. Please try again.",
                                          variant: "destructive",
                                        });
                                      }
                                    }}
                                    onCancel={() => {
                                      setShowPayment(false);
                                      setSelectedRide(null);
                                    }}
                                  />
                                </StripeProvider>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}