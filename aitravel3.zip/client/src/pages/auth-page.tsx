import { useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertUserSchema, verificationSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  Brain,
  Bot,
  Map,
  Clock,
  Shield,
  Sparkles,
  User,
  Phone,
  Mail,
  LockKeyhole,
  Copy as CopyIcon
} from "lucide-react";
import { SiGoogle } from "react-icons/si";
import { Logo } from "@/components/ui/logo";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";

const loginSchema = insertUserSchema.pick({
  username: true,
  password: true,
}).transform((data) => ({
  ...data,
  username: data.username.trim(),
}));

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [showOTPDialog, setShowOTPDialog] = useState(false);
  const [recipientValue, setRecipientValue] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [verificationMethod, setVerificationMethod] = useState<'email' | 'phone'>('email');
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const form = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
      phone_number: "",
    },
  });

  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const otpForm = useForm({
    resolver: zodResolver(verificationSchema.pick({ otp: true })),
    defaultValues: {
      otp: "",
    },
  });

  const [testOtp, setTestOtp] = useState<string | null>(null);

  const sendOTPMutation = useMutation({
    mutationFn: async (recipient: string) => {
      const res = await apiRequest("POST", "/api/send-otp", { recipient });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to send verification code');
      }
      return res.json();
    },
    onSuccess: (data) => {
      // Check if we're in test mode and have a test OTP code
      if (data.isTestMode && data.testOtp) {
        setTestOtp(data.testOtp);
        toast({
          title: "Test Mode Active",
          description: `Test OTP Code: ${data.testOtp}`,
          duration: 10000, // Show for 10 seconds
        });
      } else {
        toast({
          title: "Verification Code Sent",
          description: "Please check your phone for the verification code.",
        });
        setTestOtp(null);
      }
      setShowOTPDialog(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Send Code",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const verifyOTPMutation = useMutation({
    mutationFn: async (data: { recipient: string; otp: string }) => {
      const res = await apiRequest("POST", "/api/verify-otp", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to verify code');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Verification Successful",
        description: "Your email/phone has been verified successfully.",
      });
      setIsVerified(true);
      setShowOTPDialog(false);

      // Proceed with registration
      const formData = form.getValues();
      registerMutation.mutate(formData);
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
      // Don't close dialog on error to allow retry
    },
  });

  const handleVerification = (recipient: string) => {
    if (!recipient) {
      toast({
        title: "Email or Phone Required",
        description: "Please enter an email address or phone number to proceed.",
        variant: "destructive",
      });
      return;
    }
    setRecipientValue(recipient);
    sendOTPMutation.mutate(recipient);
  };

  const handleVerifyOTP = (data: { otp: string }) => {
    verifyOTPMutation.mutate({
      recipient: recipientValue,
      otp: data.otp,
    });
  };

  return (
    <div className="min-h-screen bg-[#003580]">
      {/* Top Logo Bar */}
      <div className="container mx-auto px-6 py-8">
        <Logo size="lg" className="text-white" />
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 pb-16">
        <div className="flex flex-col md:flex-row gap-8 items-stretch">
          {/* Left Side - Benefits */}
          <div className="md:w-1/2 space-y-8">
            <div className="text-white space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold">
                Your Journey Begins Here
              </h1>
              <p className="text-xl opacity-90">
                Join millions of travelers who choose AItravelGlobe for the best deals and personalized experiences
              </p>
            </div>

            <div className="grid gap-4">
              {[
                {
                  icon: Brain,
                  title: "AI-Powered Trip Planning",
                  description: "Get personalized itineraries with our advanced AI planner",
                },
                {
                  icon: Bot,
                  title: "Smart Travel Assistant",
                  description: "24/7 AI assistance for recommendations and support",
                },
                {
                  icon: Map,
                  title: "Intelligent Recommendations",
                  description: "AI learns your preferences for better travel suggestions",
                },
                {
                  icon: Shield,
                  title: "Secure Booking",
                  description: "Your data is protected with bank-level security",
                },
              ].map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/10 backdrop-blur-lg rounded-lg p-4 hover:bg-white/20 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded-full bg-white/20">
                      <benefit.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{benefit.title}</h3>
                      <p className="text-white/80 text-sm">{benefit.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right Side - Auth Form */}
          <div className="md:w-1/2">
            <Card className="backdrop-blur-xl bg-white/95 border-0 shadow-2xl">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl">Welcome Back</CardTitle>
                <CardDescription>
                  Sign in or create an account to get started
                  <div className="mt-2 text-sm bg-gray-50/50 p-2 rounded">
                    <strong>Test Account:</strong> test@example.com / test123
                  </div>
                </CardDescription>
              </CardHeader>

              <CardContent>
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-8">
                    <TabsTrigger value="login">Sign in</TabsTrigger>
                    <TabsTrigger value="register">Create account</TabsTrigger>
                  </TabsList>

                  <TabsContent value="login">
                    <Form {...loginForm}>
                      <form
                        onSubmit={loginForm.handleSubmit(async (data) => {
                          try {
                            await loginMutation.mutateAsync(data);
                          } catch (error) {
                            console.error("Login error:", error);
                          }
                        })}
                        className="space-y-6"
                      >
                        <FormField
                          control={loginForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-lg font-medium">Email or Phone number</FormLabel>
                              <FormControl>
                                <div className="relative group">
                                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-hover:text-[#003580] transition-colors" />
                                  <Input 
                                    {...field} 
                                    className="pl-10 h-12 text-lg bg-white/50 backdrop-blur border-2 border-gray-200 focus:border-[#003580] hover:border-[#003580]/50 transition-all duration-300 shadow-sm hover:shadow" 
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex justify-between items-center">
                                <FormLabel className="text-lg font-medium">Password</FormLabel>
                                <Button 
                                  type="button"
                                  variant="link" 
                                  className="p-0 h-auto text-sm font-medium text-[#0055CC] hover:text-[#003580] hover:underline"
                                  onClick={() => window.location.href = '/forgot-password'}
                                >
                                  Forgot password?
                                </Button>
                              </div>
                              <FormControl>
                                <div className="relative group">
                                  <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400 group-hover:text-[#003580] transition-colors" />
                                  <Input
                                    type="password"
                                    {...field}
                                    className="pl-10 h-12 text-lg bg-white/50 backdrop-blur border-2 border-gray-200 focus:border-[#003580] hover:border-[#003580]/50 transition-all duration-300 shadow-sm hover:shadow"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="submit"
                          className="w-full h-14 bg-gradient-to-r from-[#003580] to-[#006CE4] hover:from-[#002255] hover:to-[#0055CC] text-lg font-semibold transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl"
                          disabled={loginMutation.isPending}
                        >
                          {loginMutation.isPending ? (
                            <>
                              <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                              Signing in...
                            </>
                          ) : (
                            <>
                              <User className="w-6 h-6 mr-2" />
                              Sign in
                            </>
                          )}
                        </Button>
                        

                      </form>
                    </Form>

                    <div className="mt-8 space-y-6">
                      <div className="space-y-3">
                        <Button
                          onClick={() => {
                            const redirectUri = `${window.location.origin}/auth/google/callback`;
                            // Show dialog with instructions instead of redirecting
                            toast({
                              title: "Google OAuth Setup Required",
                              description: (
                                <div className="space-y-2">
                                  <p>You need to add this redirect URI to your Google Cloud Console:</p>
                                  <div className="p-2 bg-gray-100 rounded text-sm font-mono overflow-x-auto">
                                    {redirectUri}
                                  </div>
                                  <p className="text-xs text-gray-500">
                                    For testing purposes, please use the guest login below.
                                  </p>
                                </div>
                              ),
                              duration: 10000,
                            });
                            // Uncomment the line below when Google OAuth is properly set up
                            // window.location.href = `/auth/google`;
                          }}
                          variant="outline"
                          className="w-full h-14 flex items-center justify-center gap-4 bg-white hover:bg-gray-50 border-2 border-gray-200 hover:border-[#4285F4] transition-all duration-300 transform hover:scale-[1.02] shadow-md hover:shadow-lg"
                        >
                          <div className="bg-white p-2 rounded-full shadow-inner">
                            <SiGoogle className="w-6 h-6 text-[#4285F4]" />
                          </div>
                          <span className="text-lg font-semibold text-gray-700">Continue with Google</span>
                        </Button>
                        <p className="text-xs text-center text-gray-500">
                          Google login requires additional setup in Google Cloud Console
                        </p>
                      </div>

                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-gray-300" />
                        </div>
                        <div className="relative flex justify-center text-sm uppercase">
                          <span className="px-4 text-gray-500 bg-white font-medium">Or</span>
                        </div>
                      </div>

                      <Button
                        variant="outline"
                        className="w-full h-14 bg-gradient-to-r from-[#003580]/5 to-[#006CE4]/5 hover:from-[#003580]/10 hover:to-[#006CE4]/10 border-2 border-[#003580]/20 hover:border-[#003580]/30 transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl flex items-center justify-center gap-4"
                        onClick={() => {
                          loginForm.setValue("username", "test@example.com");
                          loginForm.setValue("password", "test123");
                          loginForm.handleSubmit(async (data) => {
                            try {
                              await loginMutation.mutateAsync(data);
                            } catch (error) {
                              console.error("Guest login error:", error);
                            }
                          })();
                        }}
                      >
                        <div className="bg-[#003580]/10 p-2 rounded-full">
                          <Sparkles className="w-6 h-6 text-[#003580]" />
                        </div>
                        <span className="text-lg font-semibold text-[#003580]">Continue as Guest</span>
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="register">
                    <Form {...form}>
                      <form className="space-y-4">
                        <FormField
                          control={form.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email address</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input {...field} className="pl-10 h-12" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="phone_number"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone number (E.164 format)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input
                                    {...field}
                                    placeholder="+1234567890"
                                    className="pl-10 h-12"
                                    type="tel"
                                    disabled={sendOTPMutation.isPending || verifyOTPMutation.isPending}
                                  />
                                </div>
                              </FormControl>
                              <FormDescription className="text-xs text-gray-500">
                                Enter your phone number in international format (e.g., +1234567890)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input
                                    type="password"
                                    {...field}
                                    className="pl-10 h-12"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="button"
                          className="w-full h-12 bg-[#006CE4] hover:bg-[#003580] transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                          onClick={() => handleVerification(form.getValues("username"))}
                          disabled={
                            sendOTPMutation.isPending || 
                            verifyOTPMutation.isPending || 
                            !form.getValues("username")
                          }
                        >
                          {sendOTPMutation.isPending ? (
                            <>
                              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                              Sending Code...
                            </>
                          ) : (
                            <>
                              <Mail className="w-5 h-5 mr-2" />
                              Verify & Create Account
                            </>
                          )}
                        </Button>
                      </form>
                    </Form>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* OTP Verification Dialog */}
      <Dialog open={showOTPDialog} onOpenChange={setShowOTPDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{verificationMethod === 'email' ? 'Email' : 'Phone'} Verification</DialogTitle>
            <DialogDescription>
              Enter the verification code sent to your {verificationMethod === 'email' ? 'email' : 'phone'} {recipientValue}
            </DialogDescription>
            {testOtp && (
              <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md">
                <p className="text-sm font-medium text-blue-700">Test Mode Active</p>
                <p className="text-sm">Your verification code is: <span className="font-bold">{testOtp}</span></p>
                <div className="mt-1 flex justify-between items-center">
                  <p className="text-xs text-gray-500">In production, this code would be sent via {verificationMethod === 'email' ? 'email' : 'SMS'}</p>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => {
                      otpForm.setValue('otp', testOtp);
                    }}
                  >
                    <CopyIcon className="mr-1 h-3 w-3" />
                    Auto-fill
                  </Button>
                </div>
              </div>
            )}
          </DialogHeader>
          <Form {...otpForm}>
            <form onSubmit={otpForm.handleSubmit(handleVerifyOTP)} className="space-y-4">
              <FormField
                control={otpForm.control}
                name="otp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Code</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <Input 
                          {...field} 
                          className="pl-10 h-12" 
                          placeholder="Enter 6-digit code"
                          value={field.value}
                          onChange={(e) => {
                            field.onChange(e);
                            // Auto fill if test OTP is available and input is empty
                            if (testOtp && e.target.value === '') {
                              setTimeout(() => field.onChange({ target: { value: testOtp } } as any), 100);
                            }
                          }}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => handleVerification(recipientValue)}
                  disabled={sendOTPMutation.isPending}
                  className="hover:bg-gray-50/80 border-2"
                >
                  {sendOTPMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Resending...
                    </>
                  ) : (
                    "Resend Code"
                  )}
                </Button>
                <Button 
                  type="submit" 
                  disabled={verifyOTPMutation.isPending}
                  className="bg-[#006CE4] hover:bg-[#003580]"
                >
                  {verifyOTPMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    "Verify"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}