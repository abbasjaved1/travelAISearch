
import * as React from "react";
import { useIsMobile } from "./use-mobile";

export function useResponsiveGrid<T>(items: T[] | undefined, mobileColumns = 1, tabletColumns = 2, desktopColumns = 3) {
  const isMobile = useIsMobile();
  
  const gridTemplateColumns = React.useMemo(() => {
    if (!items || items.length === 0) return "";
    
    if (isMobile) {
      return `repeat(${mobileColumns}, 1fr)`;
    } else if (window.innerWidth < 1024) {
      return `repeat(${tabletColumns}, 1fr)`;
    } else {
      return `repeat(${desktopColumns}, 1fr)`;
    }
  }, [items, isMobile, mobileColumns, tabletColumns, desktopColumns]);
  
  return {
    gridTemplateColumns,
    isMobile,
  };
}
