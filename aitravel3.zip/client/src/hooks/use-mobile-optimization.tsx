
import { useEffect, useState } from 'react';
import { useIsMobile } from './use-mobile';

// Detect iOS/iPhone
function isIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) || 
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

// Detect Android
function isAndroid() {
  return /Android/.test(navigator.userAgent);
}

export function useMobileOptimization() {
  const isMobile = useIsMobile();
  const [deviceInfo, setDeviceInfo] = useState({
    isIOS: false,
    isAndroid: false,
    isMobileDevice: false
  });
  
  useEffect(() => {
    if (!isMobile) return;
    
    // Set device-specific information
    setDeviceInfo({
      isIOS: isIOS(),
      isAndroid: isAndroid(),
      isMobileDevice: true
    });
    
    // Handle iOS vh unit bug (100vh includes the address bar)
    const setVh = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    };

    // Prevent pull to refresh on mobile browsers (important for both iOS and Android)
    const preventPullToRefresh = (e: TouchEvent) => {
      const touchY = e.touches[0].clientY;
      const isAtTop = window.scrollY <= 0;
      if (isAtTop && touchY > 10) {
        e.preventDefault();
      }
    };

    // Fast click implementation for eliminating 300ms delay
    const enableFastClick = () => {
      document.addEventListener('touchstart', function() {}, {passive: true});
    };
    
    // Handle keyboard interactions (especially for iOS)
    const handleKeyboardShow = () => {
      // iOS-specific keyboard adjustments
      if (isIOS()) {
        document.body.classList.add('ios-keyboard-open');
      }
    };
    
    const handleKeyboardHide = () => {
      // Add a slight delay to ensure the viewport has adjusted
      setTimeout(() => {
        window.scrollTo(0, 0);
        if (isIOS()) {
          document.body.classList.remove('ios-keyboard-open');
        }
      }, 100);
    };
    
    // Handle safe areas for modern devices (iPhone X and newer)
    const setSafeAreas = () => {
      if (isIOS()) {
        document.documentElement.style.setProperty('--safe-area-inset-top', 'env(safe-area-inset-top)');
        document.documentElement.style.setProperty('--safe-area-inset-bottom', 'env(safe-area-inset-bottom)');
      } else {
        document.documentElement.style.setProperty('--safe-area-inset-top', '0px');
        document.documentElement.style.setProperty('--safe-area-inset-bottom', '0px');
      }
    };
    
    // Add viewport meta tags for proper scaling
    const setViewportTags = () => {
      let viewportMeta = document.querySelector('meta[name="viewport"]') as HTMLMetaElement;
      if (!viewportMeta) {
        viewportMeta = document.createElement('meta');
        viewportMeta.setAttribute('name', 'viewport');
        document.head.appendChild(viewportMeta);
      }
      
      viewportMeta.setAttribute('content', 
        'width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1, user-scalable=no, viewport-fit=cover');
    };

    // Run optimizations
    setVh();
    setSafeAreas();
    setViewportTags();
    window.addEventListener('resize', setVh);
    window.addEventListener('orientationchange', setVh);
    document.addEventListener('touchmove', preventPullToRefresh, { passive: false });
    document.addEventListener('focusin', handleKeyboardShow);
    document.addEventListener('focusout', handleKeyboardHide);
    enableFastClick();
    
    // Add device-specific classes
    if (isIOS()) {
      document.body.classList.add('ios-device');
    } else if (isAndroid()) {
      document.body.classList.add('android-device');
    }
    document.body.classList.add('mobile-device');
    
    // Clean up
    return () => {
      window.removeEventListener('resize', setVh);
      window.removeEventListener('orientationchange', setVh);
      document.removeEventListener('touchmove', preventPullToRefresh);
      document.removeEventListener('focusin', handleKeyboardShow);
      document.removeEventListener('focusout', handleKeyboardHide);
      document.body.classList.remove('ios-device', 'android-device', 'mobile-device', 'ios-keyboard-open');
    };
  }, [isMobile]);
  
  return deviceInfo;
}
