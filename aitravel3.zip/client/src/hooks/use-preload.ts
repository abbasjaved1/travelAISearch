import { useEffect } from 'react';

/**
 * Preloads specified lazy-loaded components when the application starts
 * This improves performance for commonly accessed pages
 * @param components - Array of import promises for the components to preload
 */
export function usePreloadComponents(components: Array<() => Promise<any>>) {
  useEffect(() => {
    // Define a function to preload each component
    const preloadComponent = async (importFn: () => Promise<any>) => {
      try {
        await importFn();
      } catch (error) {
        console.error('Error preloading component:', error);
      }
    };

    // Start preloading after the main application has loaded
    const timer = setTimeout(() => {
      components.forEach(preloadComponent);
    }, 1000); // Wait 1 second to ensure main app UI is visible first

    return () => {
      clearTimeout(timer);
    };
  }, [components]);
}