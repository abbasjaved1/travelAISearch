// Import types from the main schema file
import { TripPlan, Activity, DayPlan, EmotionalWeather } from '../../shared/schema';

// Re-export types for client-side usage
export type { TripPlan, Activity, DayPlan, EmotionalWeather };