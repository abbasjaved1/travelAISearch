import { format } from 'date-fns';

export interface EmergencyContact {
  country: string;
  police: string;
  ambulance: string;
  fire: string;
  general?: string;
}

interface ValidationResult {
  isValid: boolean;
  correctedNumber?: string;
  message?: string;
  lastVerified: string;
}

// Database of emergency numbers with additional validation rules
const emergencyNumbersDB: Record<string, EmergencyContact & { 
  alternativeNumbers?: string[];
  format?: string;
  validationRules?: {
    minLength: number;
    maxLength: number;
    prefix?: string[];
  }
}> = {
  'US': {
    country: 'United States',
    police: '911',
    ambulance: '911',
    fire: '911',
    general: '911',
    alternativeNumbers: ['112'],
    validationRules: {
      minLength: 3,
      maxLength: 3
    }
  },
  'GB': {
    country: 'United Kingdom',
    police: '999',
    ambulance: '999',
    fire: '999',
    general: '112',
    alternativeNumbers: ['112', '101'],
    validationRules: {
      minLength: 3,
      maxLength: 3
    }
  },
  'IN': {
    country: 'India',
    police: '100',
    ambulance: '102',
    fire: '101',
    general: '112',
    alternativeNumbers: ['112'],
    validationRules: {
      minLength: 3,
      maxLength: 3
    }
  },
  'EU': {
    country: 'European Union',
    police: '112',
    ambulance: '112',
    fire: '112',
    general: '112',
    validationRules: {
      minLength: 3,
      maxLength: 3
    }
  }
};

export class EmergencyValidationService {
  private static instance: EmergencyValidationService;
  private lastValidationTime: Record<string, string> = {};

  private constructor() {}

  static getInstance(): EmergencyValidationService {
    if (!EmergencyValidationService.instance) {
      EmergencyValidationService.instance = new EmergencyValidationService();
    }
    return EmergencyValidationService.instance;
  }

  async validateEmergencyNumber(
    number: string,
    type: 'police' | 'ambulance' | 'fire' | 'general',
    countryCode: string
  ): Promise<ValidationResult> {
    try {
      // Get country info
      const countryInfo = emergencyNumbersDB[countryCode];
      if (!countryInfo) {
        return {
          isValid: false,
          message: 'Country not found in validation database',
          lastVerified: format(new Date(), 'yyyy-MM-dd HH:mm:ss')
        };
      }

      // Get the correct number for the service type
      const correctNumber = countryInfo[type];

      // Basic format validation
      if (countryInfo.validationRules) {
        const { minLength, maxLength, prefix } = countryInfo.validationRules;
        if (
          number.length < minLength || 
          number.length > maxLength ||
          (prefix && !prefix.some(p => number.startsWith(p)))
        ) {
          return {
            isValid: false,
            correctedNumber: correctNumber,
            message: `Invalid number format for ${countryInfo.country}`,
            lastVerified: format(new Date(), 'yyyy-MM-dd HH:mm:ss')
          };
        }
      }

      // Check if the number matches the correct number or any alternative
      const isValid = 
        number === correctNumber || 
        (countryInfo.alternativeNumbers?.includes(number) ?? false);

      // Update last validation time
      this.lastValidationTime[`${countryCode}-${type}`] = format(new Date(), 'yyyy-MM-dd HH:mm:ss');

      return {
        isValid,
        correctedNumber: isValid ? undefined : correctNumber,
        message: isValid ? 
          'Number validated successfully' : 
          `Incorrect number. The correct emergency number for ${type} in ${countryInfo.country} is ${correctNumber}`,
        lastVerified: this.lastValidationTime[`${countryCode}-${type}`]
      };
    } catch (error) {
      console.error('Error validating emergency number:', error);
      return {
        isValid: false,
        message: 'Error validating emergency number',
        lastVerified: format(new Date(), 'yyyy-MM-dd HH:mm:ss')
      };
    }
  }

  async validateAllEmergencyNumbers(countryCode: string): Promise<Record<string, ValidationResult>> {
    const results: Record<string, ValidationResult> = {};
    const types: Array<'police' | 'ambulance' | 'fire' | 'general'> = ['police', 'ambulance', 'fire', 'general'];

    const countryInfo = emergencyNumbersDB[countryCode];
    if (!countryInfo) {
      return types.reduce((acc, type) => {
        acc[type] = {
          isValid: false,
          message: 'Country not found in validation database',
          lastVerified: format(new Date(), 'yyyy-MM-dd HH:mm:ss')
        };
        return acc;
      }, {} as Record<string, ValidationResult>);
    }

    for (const type of types) {
      if (countryInfo[type]) {
        results[type] = await this.validateEmergencyNumber(countryInfo[type], type, countryCode);
      }
    }

    return results;
  }

  getLastValidationTime(countryCode: string, type: string): string | undefined {
    return this.lastValidationTime[`${countryCode}-${type}`];
  }
}

export const emergencyValidationService = EmergencyValidationService.getInstance();
