import axios from 'axios';
import { rapidApiService } from './rapidApiService';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

interface RapidAPIAttraction {
  location_id: string;
  name: string;
  description?: string;
  photo?: {
    images: {
      original: {
        url: string;
      },
      large: {
        url: string;
      },
      medium?: {
        url: string;
      }
    }
  };
  rating?: string;
  price_level?: string;
  price?: string;
  web_url?: string;
  address?: string;
  ranking?: string;
  num_reviews?: string;
  latitude?: string | number;
  longitude?: string | number;
  category?: {
    key: string;
    name: string;
  };
  subcategory?: {
    key: string;
    name: string;
  }[];
  timezone?: string;
  hours?: string;
}

export interface Destination {
  id: string;
  name: string;
  description: string;
  region: string;
  country: string;
  weather: string;
  rating: number;
  priceRange: string;
  crowdLevel: string;
  bestTimeToVisit: string;
  type: string;
  events: Array<{
    id: string;
    name: string;
    date: string;
    location: string;
    description: string;
  }>;
  image: string;
  videoUrl?: string;
  latitude?: number;
  longitude?: number;
  webUrl?: string;
  subcategories?: string;
  ranking?: string;
  reviewCount?: number;
  featured?: boolean;
  featuredCountry?: string;
  budget?: {
    perDay: number;
    currency: string;
    costLevel: 'low' | 'medium' | 'high';
  };
  weather_details?: {
    current?: string;
    temperature?: number;
    condition?: 'sunny' | 'cloudy' | 'rainy' | 'stormy' | 'snowy';
    forecast?: {
      min: number;
      max: number;
      condition: string;
    }[];
  };
  activities?: {
    count: number;
    popular: string[];
  };
}

interface FeaturedCountry {
  name: string;
  capital: string;
  code: string;
  continent: string;
  featured: boolean;
  lastFeaturedDate?: string;
}

class DestinationService {
  private static COUNTRY_CACHE_FILE = './.country-cache.json';
  private featuredCountries: FeaturedCountry[] = [
    { name: 'France', capital: 'Paris', code: 'FR', continent: 'Europe', featured: false },
    { name: 'Japan', capital: 'Tokyo', code: 'JP', continent: 'Asia', featured: false },
    { name: 'Australia', capital: 'Canberra', code: 'AU', continent: 'Oceania', featured: false },
    { name: 'Brazil', capital: 'Brasilia', code: 'BR', continent: 'South America', featured: false },
    { name: 'Canada', capital: 'Ottawa', code: 'CA', continent: 'North America', featured: false },
    { name: 'Egypt', capital: 'Cairo', code: 'EG', continent: 'Africa', featured: false },
    { name: 'Italy', capital: 'Rome', code: 'IT', continent: 'Europe', featured: false },
    { name: 'Thailand', capital: 'Bangkok', code: 'TH', continent: 'Asia', featured: false },
    { name: 'South Africa', capital: 'Pretoria', code: 'ZA', continent: 'Africa', featured: false },
    { name: 'Mexico', capital: 'Mexico City', code: 'MX', continent: 'North America', featured: false },
    { name: 'India', capital: 'New Delhi', code: 'IN', continent: 'Asia', featured: false },
    { name: 'Spain', capital: 'Madrid', code: 'ES', continent: 'Europe', featured: false },
    { name: 'Indonesia', capital: 'Jakarta', code: 'ID', continent: 'Asia', featured: false },
    { name: 'United Kingdom', capital: 'London', code: 'GB', continent: 'Europe', featured: false },
    { name: 'Argentina', capital: 'Buenos Aires', code: 'AR', continent: 'South America', featured: false },
    { name: 'New Zealand', capital: 'Wellington', code: 'NZ', continent: 'Oceania', featured: false },
    { name: 'Greece', capital: 'Athens', code: 'GR', continent: 'Europe', featured: false },
    { name: 'Vietnam', capital: 'Hanoi', code: 'VN', continent: 'Asia', featured: false },
    { name: 'Peru', capital: 'Lima', code: 'PE', continent: 'South America', featured: false },
    { name: 'Morocco', capital: 'Rabat', code: 'MA', continent: 'Africa', featured: false },
    { name: 'Turkey', capital: 'Ankara', code: 'TR', continent: 'Europe', featured: false },
    { name: 'United States', capital: 'Washington, D.C.', code: 'US', continent: 'North America', featured: false },
    { name: 'Switzerland', capital: 'Bern', code: 'CH', continent: 'Europe', featured: false },
    { name: 'Colombia', capital: 'Bogotá', code: 'CO', continent: 'South America', featured: false },
    { name: 'China', capital: 'Beijing', code: 'CN', continent: 'Asia', featured: false },
    { name: 'Portugal', capital: 'Lisbon', code: 'PT', continent: 'Europe', featured: false },
    { name: 'Singapore', capital: 'Singapore', code: 'SG', continent: 'Asia', featured: false },
    { name: 'Kenya', capital: 'Nairobi', code: 'KE', continent: 'Africa', featured: false },
    { name: 'Ireland', capital: 'Dublin', code: 'IE', continent: 'Europe', featured: false },
    { name: 'Costa Rica', capital: 'San José', code: 'CR', continent: 'North America', featured: false },
  ];
  private currentFeaturedCountry: FeaturedCountry | null = null;

  constructor() {
    this.loadCountryCache();
    this.selectDailyFeaturedCountry();
  }

  private loadCountryCache(): void {
    try {
      if (fs.existsSync(DestinationService.COUNTRY_CACHE_FILE)) {
        const cacheData = fs.readFileSync(DestinationService.COUNTRY_CACHE_FILE, 'utf8');
        const cache = JSON.parse(cacheData);
        
        if (cache && cache.featuredCountries) {
          this.featuredCountries = cache.featuredCountries;
          this.currentFeaturedCountry = cache.currentFeaturedCountry || null;
          console.log('Loaded country cache data');
        }
      }
    } catch (error) {
      console.error('Error loading country cache:', error);
    }
  }

  private saveCountryCache(): void {
    try {
      const cacheData = JSON.stringify({
        featuredCountries: this.featuredCountries,
        currentFeaturedCountry: this.currentFeaturedCountry,
        lastUpdated: new Date().toISOString()
      });
      
      fs.writeFileSync(DestinationService.COUNTRY_CACHE_FILE, cacheData, 'utf8');
      console.log('Saved country cache data');
    } catch (error) {
      console.error('Error saving country cache:', error);
    }
  }

  private selectDailyFeaturedCountry(): void {
    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Check if we already have a featured country for today
    if (this.currentFeaturedCountry && 
        this.currentFeaturedCountry.lastFeaturedDate === today) {
      console.log(`Already featuring ${this.currentFeaturedCountry.name} for today (${today})`);
      return;
    }

    // Mark all countries as not featured
    this.featuredCountries.forEach(country => {
      country.featured = false;
    });
    
    // Calculate a deterministic "random" country for today
    // Using the date string to seed the random selection ensures the same country
    // is featured throughout the day, but changes each day
    const dateHash = crypto.createHash('md5').update(today).digest('hex');
    const seed = parseInt(dateHash.substring(0, 8), 16);
    const randomIndex = seed % this.featuredCountries.length;
    
    // Set the new featured country
    this.featuredCountries[randomIndex].featured = true;
    this.featuredCountries[randomIndex].lastFeaturedDate = today;
    this.currentFeaturedCountry = this.featuredCountries[randomIndex];
    
    console.log(`Selected ${this.currentFeaturedCountry.name} as featured country for ${today}`);
    
    // Save the updated cache
    this.saveCountryCache();
  }

  public getCurrentFeaturedCountry(): FeaturedCountry | null {
    // Ensure we have the correct country for today
    this.selectDailyFeaturedCountry();
    return this.currentFeaturedCountry;
  }

  public async getFeaturedDestinations(): Promise<Destination[]> {
    const featuredCountry = this.getCurrentFeaturedCountry();
    if (!featuredCountry) {
      return [];
    }

    try {
      console.log(`Fetching destinations for featured country: ${featuredCountry.name}`);
      // Try to get destinations for both the country and its capital
      const countryDestinations = await this.getDestinations(featuredCountry.name);
      const capitalDestinations = await this.getDestinations(featuredCountry.capital);
      
      // Combine and filter out duplicates (using ID)
      const allDestinations = [...countryDestinations];
      const existingIds = new Set(countryDestinations.map(d => d.id));
      
      for (const destination of capitalDestinations) {
        if (!existingIds.has(destination.id)) {
          allDestinations.push(destination);
          existingIds.add(destination.id);
        }
      }
      
      // Mark these destinations as featured
      return allDestinations.map(destination => ({
        ...destination,
        featured: true,
        featuredCountry: featuredCountry.name
      }));
    } catch (error) {
      console.error(`Error fetching featured destinations for ${featuredCountry.name}:`, error);
      return [];
    }
  }
  private async transformAttractionsToDestinations(attractions: RapidAPIAttraction[]): Promise<Destination[]> {
    // Enhanced type mapping for better categorization
    const typeMap: Record<string, string> = {
      'attractions': 'attraction',
      'restaurants': 'dining',
      'accommodations': 'hotel',
      'beaches': 'beach',
      'casinos_and_gambling': 'entertainment',
      'museums': 'cultural',
      'landmarks': 'landmark',
      'nature_and_parks': 'nature',
      'outdoor_activities': 'adventure',
      'amusement_parks': 'entertainment',
      'shopping': 'shopping',
      'tours': 'tour',
      'nightlife': 'nightlife',
      'fun_and_games': 'entertainment',
      'classes_and_workshops': 'educational',
      'zoos_and_aquariums': 'nature',
      'spas_and_wellness': 'wellness'
    };

    // Generate price ranges based on price_level
    const getPriceRange = (priceLevel?: string): string => {
      if (!priceLevel) return '$$$';
      
      switch(priceLevel) {
        case '$':
          return '$';
        case '$$ - $$$':
          return '$$';
        case '$$$$':
          return '$$$$';
        default:
          return '$$$';
      }
    };

    // Enhanced crowd level generator with error handling
    const generateCrowdLevel = (ranking?: string): string => {
      if (!ranking) return 'Moderate';
      
      try {
        const rankNumber = parseInt(ranking.split(' ')[0]);
        if (rankNumber <= 10) return 'High';
        if (rankNumber <= 50) return 'Moderate';
        return 'Low';
      } catch (e) {
        console.log('Error parsing ranking:', ranking);
        return 'Moderate';
      }
    };

    // Smarter best time to visit calculation
    const getBestTimeToVisit = (name: string, timezone?: string, address?: string): string => {
      // Try to infer from both timezone and address for more accurate results
      const nameL = name.toLowerCase();
      
      // Beach destinations are best in summer
      if (nameL.includes('beach') || nameL.includes('shore') || nameL.includes('coast') || nameL.includes('island')) {
        if (address?.includes('Hawaii') || address?.includes('Caribbean')) return 'Year-round';
        if (timezone?.includes('Europe') || address?.includes('Europe')) return 'June to September';
        if (timezone?.includes('Asia') || address?.includes('Asia')) return 'November to April';
        if (timezone?.includes('America/North') || address?.includes('United States')) return 'June to August';
        if (timezone?.includes('America/South') || address?.includes('Brazil') || address?.includes('Argentina')) return 'December to March';
        if (timezone?.includes('Australia') || address?.includes('Australia')) return 'December to February';
      }
      
      // Mountain destinations
      if (nameL.includes('mountain') || nameL.includes('peak') || nameL.includes('hill') || nameL.includes('ski')) {
        if (nameL.includes('ski')) {
          if (timezone?.includes('Europe') || address?.includes('Europe')) return 'December to March';
          if (timezone?.includes('America/North') || address?.includes('United States')) return 'December to March';
          if (timezone?.includes('Australia') || address?.includes('Australia')) return 'June to August';
        } else {
          // For hiking and summer mountain activities
          if (timezone?.includes('Europe') || address?.includes('Europe')) return 'May to September';
          if (timezone?.includes('America/North') || address?.includes('United States')) return 'June to September';
          if (timezone?.includes('Australia') || address?.includes('Australia')) return 'December to February';
        }
      }
      
      // City destinations are often good in shoulder seasons
      if (nameL.includes('city')) {
        if (timezone?.includes('Europe') || address?.includes('Europe')) return 'April to June, September to October';
        if (timezone?.includes('Asia') || address?.includes('Asia')) return 'March to May, September to November';
        if (timezone?.includes('America/North') || address?.includes('United States')) return 'April to June, September to October';
      }
      
      // Museums, indoor attractions
      if (nameL.includes('museum') || nameL.includes('gallery') || nameL.includes('indoor')) {
        return 'Year-round';
      }

      // Default recommendations by region
      if (timezone?.includes('Europe') || address?.includes('Europe')) return 'April to October';
      if (timezone?.includes('Asia') || address?.includes('Asia')) return 'October to March';
      if (timezone?.includes('America/North') || address?.includes('United States')) return 'May to October';
      if (timezone?.includes('America/South') || address?.includes('Brazil')) return 'November to March';
      if (timezone?.includes('Australia') || address?.includes('Australia')) return 'December to February';
      if (timezone?.includes('Africa') || address?.includes('Africa')) return 'May to October';
      
      // Default seasonal assignment if we couldn't determine
      return 'June to September';
    };

    // Smart weather classification
    const getWeatherType = (name: string, address?: string): string => {
      const nameL = name.toLowerCase();
      const addressL = address?.toLowerCase() || '';
      
      // Detect tropical locations
      if (addressL.includes('hawaii') || 
          addressL.includes('caribbean') ||
          addressL.includes('thailand') ||
          addressL.includes('bali') ||
          addressL.includes('philippine')) {
        return 'Tropical';
      }
      
      // Detect desert locations
      if (nameL.includes('desert') || 
          addressL.includes('dubai') ||
          addressL.includes('egypt') ||
          addressL.includes('arizona') ||
          addressL.includes('nevada')) {
        return 'Hot and Dry';
      }
      
      // Detect alpine/mountain areas
      if (nameL.includes('mountain') || 
          nameL.includes('alps') || 
          addressL.includes('swiss') ||
          addressL.includes('alps')) {
        return 'Alpine';
      }
      
      // Mediterranean areas
      if (addressL.includes('italy') ||
          addressL.includes('greece') ||
          addressL.includes('spain') ||
          addressL.includes('croatia')) {
        return 'Mediterranean';
      }
      
      // Coastal areas
      if (nameL.includes('beach') || 
          nameL.includes('coast') || 
          nameL.includes('ocean')) {
        return 'Maritime';
      }
      
      return 'Seasonal';
    };

    // Smart extraction of region and country
    const extractLocation = (address?: string): { region: string, country: string } => {
      if (!address) return { region: 'Global', country: 'International' };
      
      const parts = address.split(',').map(part => part.trim());
      
      if (parts.length === 1) {
        return { region: parts[0], country: parts[0] };
      }
      
      if (parts.length === 2) {
        return { region: parts[0], country: parts[1] };
      }
      
      // With longer addresses, typically the last part is the country, and second-to-last is the region/state/province
      return {
        region: parts[parts.length - 2] || 'Unknown',
        country: parts[parts.length - 1] || 'International'
      };
    };

    // Enhanced description generator
    const generateDescription = (attraction: RapidAPIAttraction, type: string, location: { region: string, country: string }): string => {
      if (attraction.description && attraction.description.length > 40) {
        return attraction.description;
      }

      let description = `Explore ${attraction.name}, a popular ${type} destination in ${location.region}. `;
      
      if (parseFloat(attraction.rating || '0') > 4) {
        description += `This highly-rated attraction offers excellent experiences for visitors. `;
      }
      
      if (attraction.ranking) {
        description += `Currently ranked ${attraction.ranking} in the area. `;
      }
      
      const bestTime = getBestTimeToVisit(attraction.name, attraction.timezone, attraction.address);
      if (bestTime !== 'Year-round') {
        description += `The best time to visit is during ${bestTime}. `;
      } else {
        description += `You can visit this destination year-round. `;
      }
      
      return description;
    };

    console.log(`Transforming ${attractions.length} attractions to destinations...`);

    // Filter out invalid entries and transform
    return attractions
      .filter(attraction => {
        // Only include attractions with a name and either a photo or a description
        return attraction.name && (attraction.photo || attraction.description);
      })
      .map(attraction => {
        try {
          const categoryKey = attraction.category?.key || 'attractions';
          const subcategoryKeys = attraction.subcategory?.map(sc => sc.key) || [];
          
          let type = typeMap[categoryKey] || 'attraction';
          
          // Smarter type classification
          if (subcategoryKeys.includes('beaches')) type = 'beach';
          if (subcategoryKeys.includes('mountains')) type = 'mountain';
          if (subcategoryKeys.includes('island')) type = 'island';
          if (subcategoryKeys.includes('city_tours')) type = 'city';
          
          // Further refine based on name
          const lowerName = attraction.name.toLowerCase();
          if (lowerName.includes('beach') || lowerName.includes('shore') || lowerName.includes('coast')) type = 'beach';
          if (lowerName.includes('mountain') || lowerName.includes('hill') || lowerName.includes('peak')) type = 'mountain';
          if (lowerName.includes('island')) type = 'island';
          if (lowerName.includes('city') || lowerName.includes('urban')) type = 'city';
          
          // Extract location data
          const location = extractLocation(attraction.address);
          
          // Generate a better description
          const description = generateDescription(attraction, type, location);
          
          // Get weather info
          const weather = getWeatherType(attraction.name, attraction.address);
          
          // Get best time to visit
          const bestTimeToVisit = getBestTimeToVisit(attraction.name, attraction.timezone, attraction.address);
          
          // Parse coordinates
          let latitude = 0, longitude = 0;
          try {
            if (attraction.latitude) latitude = parseFloat(attraction.latitude as string) || 0;
            if (attraction.longitude) longitude = parseFloat(attraction.longitude as string) || 0;
          } catch (e) {
            console.log('Error parsing coordinates for', attraction.name);
          }
          
          // Generate budget info based on price range and location
          const budgetPerDay = (() => {
            if (getPriceRange(attraction.price_level) === '$') return Math.floor(Math.random() * 30) + 30;
            if (getPriceRange(attraction.price_level) === '$$') return Math.floor(Math.random() * 50) + 80;
            if (getPriceRange(attraction.price_level) === '$$$') return Math.floor(Math.random() * 70) + 130;
            if (getPriceRange(attraction.price_level) === '$$$$') return Math.floor(Math.random() * 100) + 200;
            return Math.floor(Math.random() * 60) + 100;
          })();
          
          // Determine budget cost level based on price range
          const costLevel = (() => {
            if (getPriceRange(attraction.price_level) === '$') return 'low';
            if (getPriceRange(attraction.price_level) === '$$') return 'medium';
            if (getPriceRange(attraction.price_level) === '$$$') return 'high';
            if (getPriceRange(attraction.price_level) === '$$$$') return 'high';
            return 'medium';
          })() as 'low' | 'medium' | 'high';
          
          // Generate weather details
          const weatherDetails = {
            current: weather === 'Tropical' ? 'Sunny' : 
                     weather === 'Hot and Dry' ? 'Sunny' :
                     weather === 'Alpine' ? 'Cloudy' :
                     weather === 'Mediterranean' ? 'Sunny' :
                     weather === 'Maritime' ? 'Partly Cloudy' : 'Seasonal',
            temperature: weather === 'Tropical' ? Math.floor(Math.random() * 10) + 80 : 
                         weather === 'Hot and Dry' ? Math.floor(Math.random() * 15) + 85 :
                         weather === 'Alpine' ? Math.floor(Math.random() * 15) + 50 :
                         weather === 'Mediterranean' ? Math.floor(Math.random() * 15) + 70 :
                         Math.floor(Math.random() * 20) + 65,
            condition: weather === 'Tropical' ? 'sunny' : 
                       weather === 'Hot and Dry' ? 'sunny' :
                       weather === 'Alpine' ? 'cloudy' :
                       weather === 'Mediterranean' ? 'sunny' :
                       weather === 'Maritime' ? 'cloudy' : 'sunny'
          } as const;
          
          // Generate popular activities based on destination type
          const activityCount = Math.floor(Math.random() * 20) + 5;
          const popularActivities = (() => {
            if (type === 'beach') return ['Swimming', 'Sunbathing', 'Snorkeling', 'Beach Volleyball', 'Surfing'];
            if (type === 'mountain') return ['Hiking', 'Climbing', 'Mountain Biking', 'Skiing', 'Photography'];
            if (type === 'cultural') return ['Museum Tours', 'Guided Walks', 'Art Galleries', 'Historical Sites', 'Local Cuisine'];
            if (type === 'landmark') return ['Guided Tours', 'Photography', 'Souvenir Shopping', 'Cultural Events', 'Walking Tours'];
            if (type === 'nature') return ['Wildlife Watching', 'Hiking', 'Camping', 'Photography', 'Bird Watching'];
            if (type === 'adventure') return ['Zip-lining', 'Rafting', 'Climbing', 'Trekking', 'Paragliding'];
            if (type === 'city') return ['City Tours', 'Shopping', 'Dining', 'Nightlife', 'Museums'];
            if (type === 'dining') return ['Fine Dining', 'Food Tours', 'Cooking Classes', 'Wine Tasting', 'Street Food'];
            if (type === 'entertainment') return ['Shows', 'Performances', 'Theme Parks', 'Nightlife', 'Gaming'];
            return ['Sightseeing', 'Photography', 'Local Experiences', 'Dining', 'Relaxation'];
          })();

          // Generate best time to visit as array of months/seasons
          const bestTimeArray = bestTimeToVisit.split(',').map(time => time.trim());
          
          return {
            id: attraction.location_id,
            name: attraction.name,
            description: description,
            region: location.region,
            country: location.country,
            weather: weather,
            rating: parseFloat(attraction.rating || '4.0'),
            priceRange: getPriceRange(attraction.price_level),
            crowdLevel: generateCrowdLevel(attraction.ranking),
            bestTimeToVisit: bestTimeToVisit,
            type,
            events: [],
            image: attraction.photo?.images?.large?.url || attraction.photo?.images?.original?.url || '',
            latitude: latitude,
            longitude: longitude,
            webUrl: attraction.web_url || '',
            subcategories: attraction.subcategory?.map(sc => sc.name).join(', ') || '',
            ranking: attraction.ranking || '',
            
            // Add the additional enriched fields
            budget: {
              perDay: budgetPerDay,
              currency: 'USD',
              costLevel: costLevel
            },
            weather_details: {
              current: weatherDetails.current,
              temperature: weatherDetails.temperature,
              condition: weatherDetails.condition
            },
            activities: {
              count: activityCount,
              popular: popularActivities
            }
          };
        } catch (e) {
          console.error('Error processing attraction:', attraction.name, e);
          // Return a minimal valid destination object rather than failing entirely
          return {
            id: attraction.location_id || "unknown",
            name: attraction.name || "Unknown Destination",
            description: `Information about ${attraction.name || "this destination"} is currently being updated.`,
            region: "Global",
            country: "International",
            weather: "Seasonal",
            rating: 4.0,
            priceRange: "$$$",
            crowdLevel: "Moderate",
            bestTimeToVisit: "Year-round",
            type: "attraction",
            events: [],
            image: attraction.photo?.images?.large?.url || attraction.photo?.images?.original?.url || '',
            latitude: 0,
            longitude: 0,
            budget: {
              perDay: 100,
              currency: "USD",
              costLevel: "medium"
            },
            weather_details: {
              current: "Seasonal",
              temperature: 72,
              condition: "sunny"
            },
            activities: {
              count: 10,
              popular: ["Sightseeing", "Photography", "Local Cuisine", "Shopping", "Museums"]
            }
          };
        }
      });
  }

  async getDestinations(query?: string, type?: string, priceRange?: string): Promise<Destination[]> {
    try {
      // Use RapidAPI to get real destination data
      const attractions = await rapidApiService.searchAttractions(query || 'popular destinations');
      
      // Transform to our Destination format
      let destinations = await this.transformAttractionsToDestinations(attractions);
      
      // Filter by type if specified
      if (type && type !== 'all') {
        destinations = destinations.filter(d => d.type === type);
      }
      
      // Filter by price range if specified
      if (priceRange && priceRange !== 'all') {
        destinations = destinations.filter(d => d.priceRange.length <= priceRange.length);
      }
      
      return destinations;
    } catch (error) {
      console.error('Error fetching destinations:', error);
      // Return minimal set of fallback destinations with proper attribution
      return this.getBackupDestinations(query, type, priceRange);
    }
  }

  async getDestinationByName(name: string): Promise<Destination | null> {
    try {
      // For a specific destination, search by name
      const attractions = await rapidApiService.searchAttractions(name);
      
      // Find the closest match
      const matchingAttractions = attractions.filter(
        (a: RapidAPIAttraction) => a.name.toLowerCase().includes(name.toLowerCase())
      );
      
      if (matchingAttractions.length === 0) {
        throw new Error('No matching destination found');
      }
      
      // Transform and return the first match
      const destinations = await this.transformAttractionsToDestinations(matchingAttractions);
      return destinations[0] || null;
      
    } catch (error) {
      console.error(`Error fetching destination '${name}':`, error);
      return null;
    }
  }

  private getBackupDestinations(query?: string, type?: string, priceRange?: string): Destination[] {
    // This backup data is only used when the API is completely unavailable
    // Note: This should be removed when the API is reliably working
    const backupDestinations: Destination[] = [
      {
        id: "1",
        name: "Paris",
        description: "The City of Light draws millions of visitors every year with its unforgettable ambiance. The city is known for being a global center of art, fashion, gastronomy, and culture.",
        region: "France",
        country: "France",
        weather: "Temperate",
        rating: 4.8,
        priceRange: "$$$$",
        crowdLevel: "High",
        bestTimeToVisit: "April to October",
        type: "city",
        events: [],
        image: "https://source.unsplash.com/800x600/?paris,eiffel",
        budget: {
          perDay: 180,
          currency: "USD",
          costLevel: "high"
        },
        weather_details: {
          current: "Partly Cloudy",
          temperature: 68,
          condition: "cloudy"
        },
        activities: {
          count: 24,
          popular: ["Eiffel Tower", "Louvre Museum", "Seine River Cruise", "Notre Dame Cathedral", "Montmartre"]
        }
      },
      {
        id: "2",
        name: "Bali",
        description: "Known for its volcanic mountains, iconic rice paddies, beaches and coral reefs, Bali is Indonesia's most famous island.",
        region: "Indonesia",
        country: "Indonesia",
        weather: "Tropical",
        rating: 4.6,
        priceRange: "$$$",
        crowdLevel: "Moderate",
        bestTimeToVisit: "April to October",
        type: "beach",
        events: [],
        image: "https://source.unsplash.com/800x600/?bali,beach",
        budget: {
          perDay: 60,
          currency: "USD",
          costLevel: "medium"
        },
        weather_details: {
          current: "Sunny",
          temperature: 82,
          condition: "sunny"
        },
        activities: {
          count: 22,
          popular: ["Ubud Monkey Forest", "Rice Terraces", "Uluwatu Temple", "Kuta Beach", "Snorkeling"]
        }
      }
    ];
    
    let filteredDestinations = backupDestinations;
    
    // Apply filters to backup data too
    if (query) {
      filteredDestinations = filteredDestinations.filter(d => 
        d.name.toLowerCase().includes(query.toLowerCase()) || 
        d.description.toLowerCase().includes(query.toLowerCase())
      );
    }
    
    if (type && type !== 'all') {
      filteredDestinations = filteredDestinations.filter(d => d.type === type);
    }
    
    if (priceRange && priceRange !== 'all') {
      filteredDestinations = filteredDestinations.filter(d => d.priceRange.length <= priceRange.length);
    }
    
    return filteredDestinations;
  }
}

export const destinationService = new DestinationService();