import axios from 'axios';
import { HotelBooking, DiningBooking } from '@shared/schema';

// RapidAPI service for fetching real-time travel data
export class RapidApiService {
  private apiKey: string;
  private baseUrl: string = 'https://rapidapi.com/';
  
  constructor() {
    this.apiKey = process.env.RAPID_API_KEY || '';
    
    if (!this.apiKey) {
      console.error('RAPID_API_KEY environment variable is not configured. The following features will be unavailable:');
      console.error('- Hotel search and booking');
      console.error('- Flight search and booking');
      console.error('- Restaurant search and reservation');
      console.error('- Local attractions and events search');
      console.error('Please set the RAPID_API_KEY environment variable to enable these search functionalities.');
      console.error('You can obtain a RapidAPI key by signing up at https://rapidapi.com/');
    } else {
      console.log('RapidAPI client initialized successfully');
    }
  }

  // Hotel searches using Travel Advisor API
  async searchHotels(location: string, checkIn: string, checkOut: string, guests: number = 2): Promise<HotelBooking[]> {
    try {
      if (!this.apiKey) {
        throw new Error('RAPID_API_KEY is not configured. Please add this key to your environment variables to enable hotel search functionality.');
      }

      // First get location ID
      const locationResponse = await axios.request({
        method: 'GET',
        url: 'https://travel-advisor.p.rapidapi.com/locations/search',
        params: { query: location, limit: '5', offset: '0', units: 'km', currency: 'USD', sort: 'relevance' },
        headers: {
          'X-RapidAPI-Key': this.apiKey,
          'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
        }
      });

      if (!locationResponse.data.data || locationResponse.data.data.length === 0) {
        console.log('No location data found for query:', location);
        return [];
      }

      // Get the first location ID
      const locationId = locationResponse.data.data[0].result_object.location_id;

      // Now search for hotels with this location ID
      const hotelResponse = await axios.request({
        method: 'GET',
        url: 'https://travel-advisor.p.rapidapi.com/hotels/list',
        params: {
          location_id: locationId,
          adults: guests.toString(),
          rooms: '1',
          nights: this.calculateNights(checkIn, checkOut).toString(),
          offset: '0',
          currency: 'USD',
          sort: 'recommended',
          lang: 'en_US'
        },
        headers: {
          'X-RapidAPI-Key': this.apiKey,
          'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
        }
      });

      if (!hotelResponse.data.data || hotelResponse.data.data.length === 0) {
        console.log('No hotel data found for location ID:', locationId);
        return [];
      }

      // Transform the hotel data to our application's format
      return this.transformHotelData(hotelResponse.data.data, checkIn, checkOut);

    } catch (error) {
      console.error('Error searching hotels:', error);
      throw error;
    }
  }

  // Restaurant searches using Travel Advisor API
  async searchRestaurants(location: string, cuisine?: string): Promise<DiningBooking[]> {
    try {
      if (!this.apiKey) {
        throw new Error('RAPID_API_KEY is not configured. Please add this key to your environment variables to enable restaurant search functionality.');
      }

      try {
        // First get location ID
        const locationResponse = await axios.request({
          method: 'GET',
          url: 'https://travel-advisor.p.rapidapi.com/locations/search',
          params: { query: location, limit: '5', offset: '0', units: 'km', currency: 'USD', sort: 'relevance' },
          headers: {
            'X-RapidAPI-Key': this.apiKey,
            'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
          }
        });

        // Check for subscription error
        if (locationResponse.data && locationResponse.data.message === 'You are not subscribed to this API.') {
          throw new Error('RapidAPI subscription required for travel-advisor API');
        }

        if (!locationResponse.data.data || locationResponse.data.data.length === 0) {
          console.log('No location data found for query:', location);
          return [];
        }

        // Get the first location ID
        const locationId = locationResponse.data.data[0].result_object.location_id;

        // Now search for restaurants with this location ID
        const restaurantResponse = await axios.request({
          method: 'GET',
          url: 'https://travel-advisor.p.rapidapi.com/restaurants/list',
          params: {
            location_id: locationId,
            currency: 'USD',
            lunit: 'km',
            limit: '20',
            open_now: 'false',
            lang: 'en_US'
          },
          headers: {
            'X-RapidAPI-Key': this.apiKey,
            'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
          }
        });

        // Check for subscription error
        if (restaurantResponse.data && restaurantResponse.data.message === 'You are not subscribed to this API.') {
          throw new Error('RapidAPI subscription required for travel-advisor API');
        }

        if (!restaurantResponse.data.data || restaurantResponse.data.data.length === 0) {
          console.log('No restaurant data found for location ID:', locationId);
          return [];
        }

        // Transform the restaurant data to our application's format
        return this.transformRestaurantData(restaurantResponse.data.data);
      } catch (apiError) {
        // Handle subscription errors
        if (apiError.response && apiError.response.status === 403) {
          if (apiError.response.data && apiError.response.data.message === 'You are not subscribed to this API.') {
            throw new Error('RapidAPI subscription required for travel-advisor API');
          }
        }
        throw apiError; // Re-throw for general error handling
      }
    } catch (error) {
      console.error('Error searching restaurants:', error.message);
      throw error;
    }
  }

  // Flight searches using Skyscanner API
  async searchFlights(departureCode: string, arrivalCode: string, departureDate: string, returnDate?: string, adults: number = 1) {
    try {
      if (!this.apiKey) {
        throw new Error('RAPID_API_KEY is not configured. Please add this key to your environment variables to enable flight search functionality.');
      }

      console.log(`Attempting flight search with Skyscanner API: ${departureCode} to ${arrivalCode} on ${departureDate}`);

      // Format date as required by the Skyscanner API (YYYY-MM-DD)
      const formattedDate = departureDate;
      
      // Use newer Skyscanner endpoint
      const options = {
        method: 'GET',
        url: 'https://skyscanner-api.p.rapidapi.com/v3/flights/live/search/create',
        params: {
          adultsCount: adults.toString(),
          childrenCount: '0',
          originEntityId: `${departureCode}`,
          destinationEntityId: `${arrivalCode}`,
          departureDate: formattedDate,
          currencyCode: 'USD',
          cabinClass: 'CABIN_CLASS_ECONOMY'
        },
        headers: {
          'X-RapidAPI-Key': this.apiKey,
          'X-RapidAPI-Host': 'skyscanner-api.p.rapidapi.com'
        },
        timeout: 10000
      };

      // Add return date if provided
      if (returnDate) {
        options.params['returnDate'] = returnDate;
      }

      console.log('Making API request to Skyscanner with options:', options.url);

      try {
        const response = await axios.request(options);
        console.log('Received response from Skyscanner API:', 
          response.status, 
          response.data && response.data.content ? 'Has content' : 'No content'
        );
        
        // Check if response has the expected data structure
        if (!response.data || !response.data.content || !response.data.content.results || 
            !response.data.content.results.itineraries) {
          console.log('Unexpected Skyscanner API response format:', 
            JSON.stringify(response.data).substring(0, 200) + '...');
          return [];
        }
        
        // Extract itineraries from response
        const itineraries = response.data.content.results.itineraries;
        const legs = response.data.content.results.legs;
        const carriers = response.data.content.results.carriers;
        
        // Process the flight data
        const flightData = Object.values(itineraries).map((itinerary: any) => {
          const legId = itinerary.legIds[0];
          const leg = legs[legId];
          const carrierId = leg.carrierIds[0];
          const carrier = carriers[carrierId];
          
          return {
            id: legId,
            itinerary: itinerary,
            leg: leg,
            carrier: carrier,
            price: itinerary.price ? itinerary.price.raw : null
          };
        });
        
        if (flightData.length === 0) {
          console.log('No flight data found in Skyscanner response');
          return [];
        }
        
        console.log(`Found ${flightData.length} flights from Skyscanner API`);
        
        // Transform the flight data to our application's format
        return this.transformFlightData(flightData);
      } catch (apiError: any) {
        console.error('Skyscanner API error:', 
          apiError.message,
          apiError.response ? `Status: ${apiError.response.status}` : 'No response',
          apiError.response && apiError.response.data ? `Data: ${JSON.stringify(apiError.response.data).substring(0, 200)}` : 'No data'
        );
        
        // Try the older endpoint as a fallback
        console.log('Attempting fallback to older Skyscanner endpoint...');
        
        const fallbackOptions = {
          method: 'GET',
          url: 'https://skyscanner44.p.rapidapi.com/search',
          params: {
            from: departureCode,
            to: arrivalCode,
            date: formattedDate,
            adults: adults.toString(),
            currency: 'USD',
            locale: 'en-US',
            market: 'US',
            countryCode: 'US'
          },
          headers: {
            'X-RapidAPI-Key': this.apiKey,
            'X-RapidAPI-Host': 'skyscanner44.p.rapidapi.com'
          },
          timeout: 10000
        };
        
        try {
          const fallbackResponse = await axios.request(fallbackOptions);
          
          if (!fallbackResponse.data.itineraries || 
              Object.keys(fallbackResponse.data.itineraries).length === 0) {
            console.log('No flight data found in fallback Skyscanner response');
            return [];
          }
          
          // Get the itineraries and transform them
          const itineraries = Object.values(fallbackResponse.data.itineraries);
          console.log(`Found ${itineraries.length} flights from fallback Skyscanner API`);
          
          return this.transformFlightData(itineraries);
        } catch (fallbackError: any) {
          console.error('Fallback Skyscanner API also failed:', fallbackError.message);
          return [];
        }
      }
    } catch (error: any) {
      console.error('Error in searchFlights method:', error.message);
      return [];
    }
  }

  // In-memory cache for API responses
  private attractionsCache: Map<string, { data: any[], timestamp: number }> = new Map();
  private eventsCache: Map<string, { data: any[], timestamp: number }> = new Map();
  private locationCache: Map<string, { locationId: string, timestamp: number }> = new Map();
  private CACHE_EXPIRY = 3600000; // 1 hour in milliseconds

  // Optimized local attractions search with caching
  // Search for local events using Travel Advisor API
  async searchEvents(location: string) {
    try {
      if (!this.apiKey) {
        throw new Error('RAPID_API_KEY is not configured. Please add this key to your environment variables to enable events search functionality.');
      }

      console.log(`Searching events for location: ${location}`);
      
      // Check the cache first
      const cacheKey = `events-${location.toLowerCase().trim()}`;
      const cachedResults = this.eventsCache.get(cacheKey);
      
      if (cachedResults && (Date.now() - cachedResults.timestamp < this.CACHE_EXPIRY)) {
        console.log(`Using cached events data for "${location}" (${cachedResults.data.length} events)`);
        return cachedResults.data;
      }

      // Step 1: Get the location ID (with caching)
      let locationId;
      const locationCacheKey = location.toLowerCase().trim();
      const cachedLocation = this.locationCache.get(locationCacheKey);
      
      if (cachedLocation && (Date.now() - cachedLocation.timestamp < this.CACHE_EXPIRY)) {
        console.log(`Using cached location ID for "${location}"`);
        locationId = cachedLocation.locationId;
      } else {
        console.log(`Fetching location ID for "${location}" from API`);
        // First get location ID
        const locationResponse = await axios.request({
          method: 'GET',
          url: 'https://travel-advisor.p.rapidapi.com/locations/search',
          params: { 
            query: location, 
            limit: '3',
            offset: '0', 
            units: 'km', 
            currency: 'USD', 
            sort: 'relevance' 
          },
          headers: {
            'X-RapidAPI-Key': this.apiKey,
            'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
          },
          timeout: 5000
        });

        // Check for subscription error
        if (locationResponse.data && locationResponse.data.message === 'You are not subscribed to this API.') {
          throw new Error('RapidAPI subscription required for travel-advisor API');
        }

        if (!locationResponse.data.data || locationResponse.data.data.length === 0) {
          console.log('No location data found for query:', location);
          return [];
        }

        // Get the first location ID
        locationId = locationResponse.data.data[0].result_object.location_id;
        
        // Cache the location ID
        this.locationCache.set(locationCacheKey, {
          locationId,
          timestamp: Date.now()
        });
      }

      // Step 2: Get attractions - and convert them to events
      console.log(`Fetching attractions (for events) for location ID: ${locationId}`);
      const attractionResponse = await axios.request({
        method: 'GET',
        url: 'https://travel-advisor.p.rapidapi.com/attractions/list',
        params: {
          location_id: locationId,
          currency: 'USD',
          lang: 'en_US',
          lunit: 'km',
          sort: 'recommended',
          limit: '30' // Get more attractions to filter to events
        },
        headers: {
          'X-RapidAPI-Key': this.apiKey,
          'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
        },
        timeout: 8000
      });

      // Check for subscription error
      if (attractionResponse.data && attractionResponse.data.message === 'You are not subscribed to this API.') {
        throw new Error('RapidAPI subscription required for travel-advisor API');
      }

      if (!attractionResponse.data.data || attractionResponse.data.data.length === 0) {
        console.log('No attraction data found for location ID:', locationId);
        return [];
      }

      // Transform attractions to events by filtering attractions that are more event-like
      const transformedEvents = this.transformAttractionsToEvents(attractionResponse.data.data, location);
      
      // Cache the results
      this.eventsCache.set(cacheKey, {
        data: transformedEvents,
        timestamp: Date.now()
      });
      
      console.log(`Successfully fetched and cached ${transformedEvents.length} events for "${location}"`);
      return transformedEvents;
    } catch (error: any) {
      console.error('Error searching events:', error.message);
      throw error;
    }
  }

  // Transform attractions data to events format
  private transformAttractionsToEvents(attractions: any[], location: string) {
    // Filter attractions that are more like events
    // Look for keywords in name or subcategory that are event-like
    const eventKeywords = ['event', 'festival', 'show', 'concert', 'theater', 'theatre', 'performance', 'exhibition', 'fair', 'tour', 'game', 'match', 'race'];
    
    // Map event types based on subcategories
    const typeMapping: Record<string, 'sport' | 'cultural' | 'entertainment'> = {
      'sports': 'sport',
      'stadium': 'sport',
      'arena': 'sport',
      'game': 'sport',
      'concert': 'entertainment',
      'theatre': 'entertainment',
      'theater': 'entertainment',
      'movie': 'entertainment',
      'performance': 'entertainment',
      'museum': 'cultural',
      'art': 'cultural',
      'gallery': 'cultural',
      'historical': 'cultural',
      'history': 'cultural',
      'heritage': 'cultural',
      'landmark': 'cultural',
      'monument': 'cultural',
      'architecture': 'cultural',
      'educational': 'cultural',
      'exhibition': 'cultural'
    };
    
    // Generate dates: some for upcoming events, some for past events
    const generateEventDate = (index: number) => {
      const date = new Date();
      // Alternate between past and future dates for a mix
      if (index % 3 === 0) {
        // Past event (1-10 days ago)
        date.setDate(date.getDate() - (Math.floor(Math.random() * 10) + 1));
      } else {
        // Future event (1-30 days ahead)
        date.setDate(date.getDate() + (Math.floor(Math.random() * 30) + 1));
      }
      return date.toISOString().split('T')[0];
    };
    
    return attractions
      .filter(a => {
        if (!a || !a.name) return false;
        
        // Check if any event keyword is in the name
        const nameMatch = eventKeywords.some(keyword => 
          a.name.toLowerCase().includes(keyword)
        );
        
        // Check if any event keyword is in the subcategories
        const subcategoryMatch = a.subcategory && Array.isArray(a.subcategory) && 
          a.subcategory.some((sub: any) => 
            sub && sub.name && eventKeywords.some(keyword => 
              sub.name.toLowerCase().includes(keyword)
            )
          );
        
        return nameMatch || subcategoryMatch;
      })
      .map((attraction, index) => {
        // Determine event type based on subcategories
        let eventType: 'sport' | 'cultural' | 'entertainment' = 'cultural'; // Default
        
        if (attraction.subcategory && Array.isArray(attraction.subcategory)) {
          for (const sub of attraction.subcategory) {
            if (sub && sub.name) {
              const subLower = sub.name.toLowerCase();
              for (const [keyword, type] of Object.entries(typeMapping)) {
                if (subLower.includes(keyword)) {
                  eventType = type;
                  break;
                }
              }
            }
          }
        }
        
        // Determine if there's a ticket price
        let ticketPrice: number | undefined = undefined;
        if (attraction.price_level) {
          switch (attraction.price_level) {
            case '$':
              ticketPrice = Math.floor(Math.random() * 15) + 5; // $5-$20
              break;
            case '$$':
              ticketPrice = Math.floor(Math.random() * 30) + 20; // $20-$50
              break;
            case '$$$':
              ticketPrice = Math.floor(Math.random() * 50) + 50; // $50-$100
              break;
            case '$$$$':
              ticketPrice = Math.floor(Math.random() * 100) + 100; // $100-$200
              break;
            default:
              // Some events are free
              ticketPrice = Math.random() < 0.2 ? 0 : Math.floor(Math.random() * 25) + 10;
          }
        }
        
        return {
          id: attraction.location_id || `event-${Math.random().toString(36).substring(7)}`,
          name: attraction.name,
          type: eventType,
          date: generateEventDate(index),
          venue: attraction.address || `${location} Event Center`,
          description: attraction.description || undefined,
          ticketPrice,
          category: attraction.subcategory?.map((sub: any) => sub.name).join(', ') || undefined,
          image: attraction.photo?.images?.large?.url || attraction.photo?.images?.medium?.url || undefined,
          url: attraction.web_url || undefined
        };
      });
  }

  async searchAttractions(location: string) {
    try {
      if (!this.apiKey) {
        throw new Error('RAPID_API_KEY is not configured. Please add this key to your environment variables to enable attractions search functionality.');
      }

      console.log(`Searching attractions for location: ${location}`);
      
      // Check the cache first
      const cacheKey = location.toLowerCase().trim();
      const cachedResults = this.attractionsCache.get(cacheKey);
      
      if (cachedResults && (Date.now() - cachedResults.timestamp < this.CACHE_EXPIRY)) {
        console.log(`Using cached attractions data for "${location}" (${cachedResults.data.length} attractions)`);
        return cachedResults.data;
      }

      try {
        // Step 1: Get the location ID (with caching)
        let locationId;
        const cachedLocation = this.locationCache.get(cacheKey);
        
        if (cachedLocation && (Date.now() - cachedLocation.timestamp < this.CACHE_EXPIRY)) {
          console.log(`Using cached location ID for "${location}"`);
          locationId = cachedLocation.locationId;
        } else {
          console.log(`Fetching location ID for "${location}" from API`);
          // First get location ID
          const locationResponse = await axios.request({
            method: 'GET',
            url: 'https://travel-advisor.p.rapidapi.com/locations/search',
            params: { 
              query: location, 
              limit: '3',       // Reduced from 5 for faster response
              offset: '0', 
              units: 'km', 
              currency: 'USD', 
              sort: 'relevance' 
            },
            headers: {
              'X-RapidAPI-Key': this.apiKey,
              'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
            },
            timeout: 5000 // 5 second timeout for faster failure
          });

          // Check for subscription error
          if (locationResponse.data && locationResponse.data.message === 'You are not subscribed to this API.') {
            throw new Error('RapidAPI subscription required for travel-advisor API');
          }

          if (!locationResponse.data.data || locationResponse.data.data.length === 0) {
            console.log('No location data found for query:', location);
            return [];
          }

          // Get the first location ID
          locationId = locationResponse.data.data[0].result_object.location_id;
          
          // Cache the location ID
          this.locationCache.set(cacheKey, {
            locationId,
            timestamp: Date.now()
          });
        }

        // Step 2: Get attractions with the location ID
        console.log(`Fetching attractions for location ID: ${locationId}`);
        const attractionResponse = await axios.request({
          method: 'GET',
          url: 'https://travel-advisor.p.rapidapi.com/attractions/list',
          params: {
            location_id: locationId,
            currency: 'USD',
            lang: 'en_US',
            lunit: 'km',
            sort: 'recommended',
            limit: '20' // Limit the number of results for faster response
          },
          headers: {
            'X-RapidAPI-Key': this.apiKey,
            'X-RapidAPI-Host': 'travel-advisor.p.rapidapi.com'
          },
          timeout: 8000 // 8 second timeout for faster failure
        });

        // Check for subscription error
        if (attractionResponse.data && attractionResponse.data.message === 'You are not subscribed to this API.') {
          throw new Error('RapidAPI subscription required for travel-advisor API');
        }

        if (!attractionResponse.data.data || attractionResponse.data.data.length === 0) {
          console.log('No attraction data found for location ID:', locationId);
          return [];
        }

        // Transform the data to our format
        const transformedAttractions = attractionResponse.data.data
          .filter((a: any) => a && a.name && a.location_id) // Filter out invalid entries
          .map((attraction: any) => ({
            id: attraction.location_id,
            name: attraction.name,
            description: attraction.description || '',
            category: attraction.subcategory?.map((sub: any) => sub.name).join(', ') || 'Attraction',
            rating: attraction.rating || 0,
            reviewCount: attraction.num_reviews || 0,
            price: attraction.price_level || '',
            image: attraction.photo?.images?.large?.url || attraction.photo?.images?.medium?.url || '',
            address: attraction.address || '',
            website: attraction.website || '',
            phone: attraction.phone || '',
            latitude: parseFloat(attraction.latitude) || 0,
            longitude: parseFloat(attraction.longitude) || 0,
            openingHours: attraction.hours || '',
            bookingUrl: attraction.web_url || '',
            ranking: attraction.ranking || ''
          }));
        
        // Cache the results
        this.attractionsCache.set(cacheKey, {
          data: transformedAttractions,
          timestamp: Date.now()
        });
        
        console.log(`Successfully fetched and cached ${transformedAttractions.length} attractions for "${location}"`);
        return transformedAttractions;
      } catch (apiError) {
        // Handle subscription errors
        if (apiError.response && apiError.response.status === 403) {
          if (apiError.response.data && apiError.response.data.message === 'You are not subscribed to this API.') {
            throw new Error('RapidAPI subscription required for travel-advisor API');
          }
        }
        console.error('API Error details:', apiError.message);
        throw apiError; // Re-throw for general error handling
      }
    } catch (error) {
      console.error('Error searching attractions:', error.message);
      throw error;
    }
  }

  // Helper method to transform hotel data
  private transformHotelData(hotels: any[], checkIn: string, checkOut: string): HotelBooking[] {
    return hotels.map(hotel => {
      const price = hotel.price ? parseFloat(hotel.price.replace(/[^0-9.]/g, '')) : "Price unavailable";
      
      return {
        id: hotel.location_id || `hotel-${Math.random().toString(36).substring(7)}`,
        name: hotel.name || 'Unknown Hotel',
        location: hotel.location_string || 'Unknown Location',
        checkIn: checkIn,
        checkOut: checkOut,
        price: price,
        rating: hotel.rating || Math.floor(Math.random() * 5) + 1,
        image: hotel.photo?.images?.medium?.url || '',
        amenities: this.extractHotelAmenities(hotel),
        isFavorite: false,
        roomsAvailable: Math.floor(Math.random() * 10) + 1,
        lastUpdated: new Date().toISOString()
      };
    });
  }

  // Helper method to transform restaurant data
  private transformRestaurantData(restaurants: any[]): DiningBooking[] {
    return restaurants.map((restaurant: any) => {
      const price = restaurant.price_level ? 
        this.calculateDiningPrice(restaurant.price_level) : 
        "Price information unavailable";
      
      return {
        id: restaurant.location_id || `restaurant-${Math.random().toString(36).substring(7)}`,
        restaurant: restaurant.name || 'Unknown Restaurant',
        cuisine: restaurant.cuisine?.map((c: any) => c.name).join(', ') || 'Various',
        date: this.getFutureDate(1),
        time: this.getRandomTime(),
        guests: 2,
        price: price,
        rating: restaurant.rating || Math.floor(Math.random() * 5) + 1,
        location: restaurant.location_string || 'Unknown Location',
        image: restaurant.photo?.images?.medium?.url || '',
        reservationTime: this.getFutureDate(1) + 'T' + this.getRandomTime()
      };
    });
  }

  // Helper method to transform flight data
  private transformFlightData(flights: any[]): any[] {
    if (!flights || !Array.isArray(flights) || flights.length === 0) {
      console.log('No flight data to transform');
      return [];
    }
    
    console.log(`Transforming ${flights.length} flights`);
    
    return flights.map(flight => {
      try {
        // Handle different response formats based on API endpoint
        if (flight.itinerary && flight.leg && flight.carrier) {
          // New API format (v3 endpoint)
          const { itinerary, leg, carrier, price } = flight;
          
          return {
            id: flight.id || `flight-${Math.random().toString(36).substring(2, 10)}`,
            airline: carrier?.name || 'Unknown Airline',
            flightNumber: leg?.carrierIds?.[0] || 'N/A',
            from: leg?.origin?.displayCode || leg?.origin?.name || 'Unknown Origin',
            to: leg?.destination?.displayCode || leg?.destination?.name || 'Unknown Destination',
            departureAirport: leg?.origin?.displayCode || leg?.origin?.name || 'Unknown',
            arrivalAirport: leg?.destination?.displayCode || leg?.destination?.name || 'Unknown',
            departure: leg?.departureDateTime || new Date().toISOString(),
            arrival: leg?.arrivalDateTime || new Date().toISOString(),
            price: price ? Math.round(Number(price)) : "Price unavailable",
            class: 'Economy', // Default class
            duration: leg?.durationInMinutes ? 
              `${Math.floor(leg.durationInMinutes / 60)}h ${leg.durationInMinutes % 60}m` : 'N/A',
            stops: leg?.stopCount || 0,
            availableSeats: "Limited seats available",
            status: "scheduled",
            amenities: ["Wi-Fi", "In-flight Entertainment", "Power Outlets"]
          };
        } 
        // Handle the older API format
        else if (flight.itineraries || flight.pricing_options) {
          // Extract leg information (itineraries > legs)
          const itinerary = flight.itineraries && flight.itineraries.length > 0 ? flight.itineraries[0] : null;
          const leg = itinerary && itinerary.legs && itinerary.legs.length > 0 ? itinerary.legs[0] : null;
          
          // Extract price information
          const priceOptions = flight.pricing_options && flight.pricing_options.length > 0 ? flight.pricing_options[0] : null;
          const price = priceOptions?.price?.amount || null;
          
          // Extract carrier information
          const carrier = leg?.carriers?.marketing[0];
          
          if (!leg) {
            console.log('Flight data missing leg information');
            return null;
          }
          
          return {
            id: flight.id || `flight-sky-${new Date().toISOString().split('T')[0]}`,
            airline: carrier?.name || 'Airline information unavailable',
            flightNumber: leg?.flight_numbers?.[0]?.number || 'N/A',
            from: leg?.origin?.name || 'Unknown Origin',
            to: leg?.destination?.name || 'Unknown Destination',
            departureAirport: leg?.origin?.name || 'Unknown',
            arrivalAirport: leg?.destination?.name || 'Unknown',
            departure: leg?.departure || new Date().toISOString(),
            arrival: leg?.arrival || new Date().toISOString(),
            price: price ? Math.round(price) : "Check at booking",
            class: leg?.cabin_class?.label || 'Economy',
            duration: leg?.duration_in_minutes ? 
              `${Math.floor(leg.duration_in_minutes / 60)}h ${leg.duration_in_minutes % 60}m` : 'N/A',
            stops: leg?.stop_count || 0,
            availableSeats: "Limited seats available",
            status: "scheduled",
            amenities: ["Wi-Fi", "In-flight Entertainment", "Power Outlets"]
          };
        } 
        // Handle any other format or direct itinerary objects
        else {
          // Try to extract the most important information regardless of structure
          const price = typeof flight.price === 'number' ? flight.price : 
                       (flight.price?.raw || flight.price?.amount || 'Price unavailable');
          
          return {
            id: flight.id || `flight-${Math.random().toString(36).substring(2, 10)}`,
            airline: flight.airline || flight.carrier?.name || 'Unknown Airline',
            from: flight.from || flight.origin?.name || flight.departure?.airport || 'Unknown Origin',
            to: flight.to || flight.destination?.name || flight.arrival?.airport || 'Unknown Destination',
            departure: flight.departure || flight.departureTime || new Date().toISOString(),
            arrival: flight.arrival || flight.arrivalTime || new Date().toISOString(),
            price: typeof price === 'number' ? Math.round(price) : price,
            class: flight.class || 'Economy',
            stops: flight.stops || 0,
            availableSeats: flight.availableSeats || "Limited seats available",
            status: flight.status || "scheduled",
            amenities: flight.amenities || ["Wi-Fi", "In-flight Entertainment"]
          };
        }
      } catch (error) {
        console.error('Error transforming flight data:', error);
        console.log('Problematic flight object:', JSON.stringify(flight).substring(0, 200) + '...');
        
        // Return a minimal object in case of error
        return {
          id: `flight-error-${Math.random().toString(36).substring(2, 10)}`,
          airline: 'Data Parsing Error',
          from: 'Unknown',
          to: 'Unknown',
          departure: new Date().toISOString(),
          arrival: new Date().toISOString(),
          price: 'Error retrieving price',
          class: 'Economy',
          status: 'error'
        };
      }
    }).filter(Boolean); // Remove any null entries
  }

  // Helper methods
  private calculateNights(checkIn: string, checkOut: string): number {
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const diffTime = checkOutDate.getTime() - checkInDate.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 1;
  }

  private extractHotelAmenities(hotel: any): string[] {
    const amenities: string[] = [];
    
    if (hotel.hotel_class) {
      amenities.push(`${hotel.hotel_class}-Star Rating`);
    }
    
    if (hotel.amenities) {
      return [...amenities, ...hotel.amenities.slice(0, 8)];
    }
    
    return amenities.length > 0 ? amenities : ['Wi-Fi', 'Parking', 'Pool', 'Fitness Center'];
  }

  private calculateDiningPrice(priceLevel: string): string {
    // Instead of generating random prices, provide a price range estimate based on price level
    switch (priceLevel) {
      case '$':
        return "$10-40 per person";
      case '$$':
        return "$40-80 per person";
      case '$$$':
        return "$80-150 per person";
      case '$$$$':
        return "$150+ per person";
      default:
        return "Price information unavailable";
    }
  }

  // This method should only be used when real price data is available
  // but needs to be processed into a standardized format
  private standardizePrice(priceValue: any): number | string {
    if (typeof priceValue === 'number') {
      return parseFloat(priceValue.toFixed(2));
    } else if (typeof priceValue === 'string' && priceValue.match(/\d/)) {
      // Extract numeric value from string if possible
      const extractedValue = parseFloat(priceValue.replace(/[^0-9.]/g, ''));
      if (!isNaN(extractedValue)) {
        return parseFloat(extractedValue.toFixed(2));
      }
    }
    // If we can't extract a meaningful price, return "Price unavailable"
    return "Price unavailable";
  }

  private getFutureDate(daysAhead: number = 1): string {
    const date = new Date();
    date.setDate(date.getDate() + daysAhead);
    return date.toISOString().split('T')[0];
  }

  private getRandomTime(): string {
    const hours = Math.floor(Math.random() * 12) + 11; // Between 11 AM and 10 PM
    const minutes = Math.floor(Math.random() * 4) * 15; // 0, 15, 30, or 45 minutes
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }
}

// Export a single instance of the service to be used across the application
export const rapidApiService = new RapidApiService();