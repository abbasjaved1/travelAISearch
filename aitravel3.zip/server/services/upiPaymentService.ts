import { BookingType } from '@shared/schema';
import { db } from '../db';
import { sql } from 'drizzle-orm';
import crypto from 'crypto';

// Define UPI Payment Record structure
interface UPIPaymentRecord {
  id: string;
  userId: number;
  bookingType: BookingType;
  amount: number;
  status: 'pending' | 'success' | 'failed' | 'expired';
  upiId: string;
  referenceId: string;
  metadata: any;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * UPI Payment Service for handling payments through India's Unified Payments Interface
 */
export class UPIPaymentService {
  
  /**
   * Create a new UPI Payment request
   */
  async createPaymentRequest(amount: number, bookingType: BookingType, metadata: any, upiId?: string) {
    try {
      if (!amount || amount <= 0) {
        throw new Error('Invalid payment amount: amount must be greater than 0');
      }
      
      if (!bookingType) {
        throw new Error('Missing booking type: a valid booking type is required');
      }
      
      if (!metadata || !metadata.userId) {
        console.warn('Missing user ID in payment metadata - this may cause issues with future analytics');
      }
      
      console.log('Creating UPI payment request with:', { amount, bookingType, metadata, upiId });
      
      // Generate a unique reference ID for this payment
      const referenceId = `UPI_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
      
      // Store payment request in database - wrapped in try/catch to avoid blocking payment flow
      try {
        await db.execute(sql`
          INSERT INTO upi_payment_records 
          (id, user_id, booking_type, amount, status, upi_id, reference_id, metadata, created_at) 
          VALUES 
          (${referenceId}, ${metadata.userId || 0}, ${bookingType}, ${amount}, 'pending', ${upiId || null}, ${referenceId}, ${JSON.stringify(metadata)}, NOW())
        `);
      } catch (dbError) {
        console.error('Failed to record UPI payment attempt:', dbError);
        // Continue even if db recording fails - this shouldn't block the payment flow
      }
      
      // In a real implementation, this would create a UPI payment intent with a payment gateway
      // For now, we're simulating the process with a local reference
      return {
        referenceId,
        amount,
        upiDetails: {
          upiId: upiId || '',
          merchantName: 'TravelBuddy',
          transactionNote: `Payment for ${bookingType} booking`,
          amount: amount
        },
        paymentUrl: `upi://pay?pa=${upiId || 'example@upi'}&pn=TravelBuddy&am=${amount}&tn=Payment%20for%20${bookingType}%20booking&tr=${referenceId}`,
        qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=${upiId || 'example@upi'}&pn=TravelBuddy&am=${amount}&tn=Payment%20for%20${bookingType}%20booking&tr=${referenceId}`,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000) // 30 minutes from now
      };
    } catch (error: any) {
      console.error('UPI payment request creation failed:', error);
      throw new Error(`Failed to create UPI payment request: ${error.message}`);
    }
  }
  
  /**
   * Verify UPI Payment status
   */
  async verifyPayment(referenceId: string) {
    try {
      if (!referenceId) {
        throw new Error('Missing reference ID: Required for verifying UPI payment');
      }
      
      console.log('Verifying UPI payment:', referenceId);
      
      // In a real implementation, this would check the status with a UPI payment gateway
      // For now, we simulate with a successful response
      const status = 'success';
      
      // Update payment record in database
      try {
        await db.execute(sql`
          UPDATE upi_payment_records 
          SET status = ${status}, 
              updated_at = NOW()
          WHERE reference_id = ${referenceId}
        `);
      } catch (dbError) {
        console.error('Failed to update UPI payment record:', dbError);
      }
      
      return {
        referenceId,
        status,
        transactionId: `TXNID_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
        message: 'Payment successful'
      };
    } catch (error: any) {
      console.error('UPI payment verification failed:', error);
      throw new Error(`Failed to verify UPI payment: ${error.message}`);
    }
  }
}

// Export a singleton instance of the service
export const upiPaymentService = new UPIPaymentService();