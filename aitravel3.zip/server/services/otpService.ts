import { scrypt, randomBytes, randomInt } from "crypto";
import { promisify } from "util";
import axios from 'axios';
import { storage } from '../storage';

const scryptAsync = promisify(scrypt);

// Check required environment variables
const REQUIRED_ENV_VARS = [
  'GETOTP_API_KEY'
];

function validateEnvVars() {
  // Check if GetOTP API is configured
  if (!process.env.GETOTP_API_KEY) {
    console.warn('GetOTP API key missing - OTP features will be disabled');
    return false;
  }

  return true;
}

// Validate GetOTP API configuration
const isGetOTPConfigured = validateEnvVars();
if (isGetOTPConfigured) {
  console.log('GetOTP API configuration validated successfully');
} else {
  console.log('GetOTP API not configured properly.');
}

// Regex for email validation
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

export class OTPService {
  private generateOTP(): string {
    return randomInt(100000, 999999).toString();
  }

  private getExpiryTime(): Date {
    const date = new Date();
    date.setMinutes(date.getMinutes() + 10); // OTP expires in 10 minutes
    return date;
  }

  private validatePhoneNumber(phoneNumber: string): string {
    // Remove any non-digit characters except +
    const cleaned = phoneNumber.replace(/[^\d+]/g, '');

    // Check basic E.164 format
    if (!cleaned.startsWith('+')) {
      throw new Error('Phone number must start with + and include country code (e.g., +1234567890)');
    }

    if (cleaned.length < 10 || cleaned.length > 15) {
      throw new Error('Invalid phone number length. Must be between 10 and 15 digits including country code.');
    }

    return cleaned;
  }

  private validateEmail(email: string): string {
    if (!EMAIL_REGEX.test(email)) {
      throw new Error('Invalid email format');
    }
    return email.toLowerCase().trim();
  }

  private isEmail(recipient: string): boolean {
    return EMAIL_REGEX.test(recipient);
  }

  async sendOTP(recipient: string): Promise<{ success: boolean; message?: string }> {
    try {
      console.log('Attempting to send OTP to:', recipient);
      
      let formattedRecipient: string;
      let channel: 'email' | 'sms';
      
      // Determine if recipient is email or phone
      if (this.isEmail(recipient)) {
        formattedRecipient = this.validateEmail(recipient);
        channel = 'email';
      } else {
        formattedRecipient = this.validatePhoneNumber(recipient);
        channel = 'sms';
      }

      // Generate and store OTP
      const otp = this.generateOTP();
      const expiryTime = this.getExpiryTime();

      // Test mode for development
      const isTestMode = true; // Always use test mode for easier debugging
      if (isTestMode) {
        console.log('=========================================');
        console.log('DEVELOPMENT MODE: REAL MESSAGE NOT SENT');
        console.log(`Recipient: ${formattedRecipient}`);
        console.log(`Channel: ${channel}`);
        console.log(`TEST OTP CODE: ${otp}`);
        console.log('Use this code for verification');
        console.log('=========================================');
        
        if (channel === 'email') {
          await storage.updateUserEmailOTP(formattedRecipient, otp, expiryTime);
        } else {
          await storage.updateUserOTP(formattedRecipient, otp, expiryTime);
        }
        
        // Log clearly visible test code to console
        console.log('\x1b[33m%s\x1b[0m', `📱 TEST VERIFICATION CODE: ${otp} 📱`);
        console.log('\x1b[33m%s\x1b[0m', `Recipients: ${formattedRecipient} via ${channel}`);
        
        return { 
          success: true, 
          message: 'Test mode active: Check server logs for OTP code. Code is: ' + otp
        };
      }

      // Update user OTP in storage first
      if (channel === 'email') {
        await storage.updateUserEmailOTP(formattedRecipient, otp, expiryTime);
      } else {
        await storage.updateUserOTP(formattedRecipient, otp, expiryTime);
      }

      // Then attempt to send OTP via GetOTP API
      if (isGetOTPConfigured) {
        try {
          const getOtpApiUrl = 'https://api.getotp.dev/v1/send';
          const response = await axios.post(getOtpApiUrl, {
            recipient: formattedRecipient,
            message: `Your AItravelGlobe verification code is: ${otp}. Valid for 10 minutes.`,
            channel: channel,
            template: 'verification',
            code: otp,  // Send OTP code separately if API supports structured data
            expires_in: 600  // 10 minutes in seconds
          }, {
            headers: {
              'Authorization': `Bearer ${process.env.GETOTP_API_KEY}`,
              'Content-Type': 'application/json'
            }
          });

          if (response.status === 200 || response.status === 201) {
            console.log(`OTP sent successfully via GetOTP API (${channel}):`, response.data);
            return { 
              success: true, 
              message: `Verification code sent successfully to your ${channel === 'email' ? 'email' : 'phone'}`
            };
          } else {
            throw new Error(`GetOTP API returned status ${response.status}: ${JSON.stringify(response.data)}`);
          }
        } catch (apiError: any) {
          console.error('GetOTP API error:', apiError.message);
          console.error('Response:', apiError.response?.data);
          
          // Rethrow for the outer catch block to handle
          throw apiError;
        }
      } else {
        console.warn('GetOTP API not configured. Skipping message.');
        return { 
          success: true, 
          message: `OTP stored successfully (${channel} service disabled)` 
        };
      }

    } catch (error: any) {
      console.error('Error in sendOTP:', error);

      // API specific error handling
      if (error.response) {
        // The request was made and the server responded with a status code outside the 2xx range
        console.error('GetOTP API error response:', error.response.data);
        
        if (error.response.status === 400) {
          return {
            success: false,
            message: 'Invalid recipient format. Please check and try again.'
          };
        } else if (error.response.status === 401 || error.response.status === 403) {
          return {
            success: false,
            message: 'Authentication error with verification service. Please contact support.'
          };
        } else if (error.response.status === 429) {
          return {
            success: false,
            message: 'Too many requests. Please try again later.'
          };
        }
      } else if (error.request) {
        // The request was made but no response was received
        console.error('GetOTP API no response received:', error.request);
        return {
          success: false,
          message: 'Unable to connect to verification service. Please try again later.'
        };
      }

      // Generic error message
      return {
        success: false,
        message: 'Failed to send verification code. Please try again later.'
      };
    }
  }

  async verifyOTP(recipient: string, otp: string): Promise<{ success: boolean; message?: string }> {
    try {
      // Determine if recipient is email or phone
      let user;
      let channel: 'email' | 'sms';
      
      if (this.isEmail(recipient)) {
        const formattedEmail = this.validateEmail(recipient);
        user = await storage.getUserByEmail(formattedEmail);
        channel = 'email';
      } else {
        const formattedPhone = this.validatePhoneNumber(recipient);
        user = await storage.getUserByPhone(formattedPhone);
        channel = 'sms';
      }

      if (!user) {
        console.log(`User not found for ${channel === 'email' ? 'email' : 'phone'}: ${recipient}`);
        return {
          success: false,
          message: 'Invalid verification attempt. Please request a new code.'
        };
      }

      // Check for OTP in the proper field based on channel
      const storedOtp = channel === 'email' ? user.email_otp : user.otp;
      const otpExpires = channel === 'email' ? user.email_otp_expires : user.otp_expires;
      
      console.log(`Verifying ${channel} OTP for ${recipient}. User data:`, { 
        email: user.email,
        hasEmailOtp: !!user.email_otp,
        hasOtp: !!user.otp,
        providedOtp: otp,
        storedOtp,
        otpExpires,
        now: new Date()
      });

      if (!storedOtp || !otpExpires) {
        return {
          success: false,
          message: 'No verification code found. Please request a new code.'
        };
      }

      if (new Date(otpExpires) < new Date()) {
        return {
          success: false,
          message: 'Verification code has expired. Please request a new code.'
        };
      }

      // First check our local stored OTP
      if (storedOtp !== otp) {
        // If the local OTP doesn't match and GetOTP API is configured, attempt to verify with the API
        if (isGetOTPConfigured) {
          try {
            // Verify code via GetOTP API
            const getOtpVerifyUrl = 'https://api.getotp.dev/v1/verify';
            const response = await axios.post(getOtpVerifyUrl, {
              recipient: recipient,
              code: otp,
              channel: channel
            }, {
              headers: {
                'Authorization': `Bearer ${process.env.GETOTP_API_KEY}`,
                'Content-Type': 'application/json'
              }
            });

            if (response.status === 200 && response.data.valid === true) {
              // If API validates the OTP, proceed with verification
              if (channel === 'email') {
                await storage.verifyUserEmail(recipient);
                console.log('Email verification successful for:', recipient);
              } else {
                await storage.verifyUserPhone(recipient);
                console.log('Phone verification successful for:', recipient);
              }
              
              return {
                success: true,
                message: `${channel === 'email' ? 'Email' : 'Phone'} verified successfully via API`
              };
            } else {
              return {
                success: false,
                message: 'Invalid verification code. Please try again.'
              };
            }
          } catch (apiError: any) {
            console.error('GetOTP API verification error:', apiError.message);
            console.error('Response:', apiError.response?.data);
            
            return {
              success: false,
              message: 'Verification service error. Please try again.'
            };
          }
        } else {
          return {
            success: false,
            message: 'Invalid verification code. Please try again.'
          };
        }
      }

      // If local OTP matched, verify the recipient
      if (channel === 'email') {
        await storage.verifyUserEmail(recipient);
        console.log('Email verification successful for:', recipient);
        return {
          success: true,
          message: 'Email verified successfully'
        };
      } else {
        await storage.verifyUserPhone(recipient);
        console.log('Phone verification successful for:', recipient);
        return {
          success: true,
          message: 'Phone number verified successfully'
        };
      }

    } catch (error: any) {
      console.error('Error in verifyOTP:', error);
      return {
        success: false,
        message: error.message || 'Failed to verify code. Please try again.'
      };
    }
  }
}

export const otpService = new OTPService();