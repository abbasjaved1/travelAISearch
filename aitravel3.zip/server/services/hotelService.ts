import { EventEmitter } from 'events';
import { HotelBooking } from "@shared/schema";

class HotelDataEmitter extends EventEmitter {}

export class HotelService {
  private eventEmitter: HotelDataEmitter;
  private updateInterval: NodeJS.Timeout | null = null;
  private cachedHotels: Map<string, HotelBooking[]> = new Map();
  private hotelData: HotelBooking[] = [
    {
      id: "1",
      name: "Luxury Palace Hotel",
      location: "New York",
      rating: 5,
      price: 299,
      checkIn: new Date("2025-03-01").toISOString(),
      checkOut: new Date("2025-03-05").toISOString(),
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800",
      amenities: ["pool", "spa", "gym", "restaurant"],
      roomsAvailable: 15,
      lastUpdated: new Date().toISOString()
    },
    {
      id: "2",
      name: "Business Comfort Inn",
      location: "London",
      rating: 4,
      price: 199,
      checkIn: new Date("2025-03-02").toISOString(),
      checkOut: new Date("2025-03-06").toISOString(),
      image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=800",
      amenities: ["wifi", "breakfast", "meeting rooms"],
      roomsAvailable: 8,
      lastUpdated: new Date().toISOString()
    },
    {
      id: "3",
      name: "Seaside Resort",
      location: "Tokyo",
      rating: 5,
      price: 399,
      checkIn: new Date("2025-03-03").toISOString(),
      checkOut: new Date("2025-03-07").toISOString(),
      image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800",
      amenities: ["beach access", "pool", "restaurants"],
      roomsAvailable: 22,
      lastUpdated: new Date().toISOString()
    },
    {
      id: "4",
      name: "Mountain View Lodge",
      location: "Switzerland",
      rating: 4,
      price: 299,
      checkIn: new Date("2025-03-04").toISOString(),
      checkOut: new Date("2025-03-08").toISOString(),
      image: "https://images.unsplash.com/photo-1585544314038-a0d3769d0193?auto=format&fit=crop&w=800",
      amenities: ["hiking trails", "skiing", "restaurant"],
      roomsAvailable: 10,
      lastUpdated: new Date().toISOString()
    },
    {
      id: "5",
      name: "Desert Oasis Resort",
      location: "Dubai",
      rating: 5,
      price: 499,
      checkIn: new Date("2025-03-05").toISOString(),
      checkOut: new Date("2025-03-09").toISOString(),
      image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800",
      amenities: ["pool", "spa", "golf course", "restaurants"],
      roomsAvailable: 18,
      lastUpdated: new Date().toISOString()
    }
  ];

  constructor() {
    this.eventEmitter = new HotelDataEmitter();
    this.startPeriodicUpdates();
  }

  private startPeriodicUpdates() {
    // Update hotel data every 5 minutes
    this.updateInterval = setInterval(() => {
      try {
        this.updateHotelAvailability();
      } catch (error) {
        console.error('Error updating hotel data:', error);
      }
    }, 5 * 60 * 1000); // 5 minutes
  }

  private updateHotelAvailability() {
    const updatedHotels = this.hotelData.map(hotel => ({
      ...hotel,
      roomsAvailable: Math.floor(Math.random() * 20) + 1, // Simulate room availability changes
      price: this.adjustPrice(hotel.price), // Simulate dynamic pricing
      lastUpdated: new Date().toISOString()
    }));

    this.hotelData = updatedHotels;
    this.eventEmitter.emit('hotelsUpdated', updatedHotels);
  }

  private adjustPrice(basePrice: number): number {
    // Simulate dynamic pricing based on availability and demand
    const variation = (Math.random() - 0.5) * 50; // +/- $25
    return Math.round(basePrice + variation);
  }

  async searchHotels(filters: {
    location?: string;
    rating?: number;
    priceRange?: string;
    checkIn?: string;
    checkOut?: string;
  }): Promise<HotelBooking[]> {
    let filteredHotels = [...this.hotelData];

    if (filters.location) {
      filteredHotels = filteredHotels.filter(hotel =>
        hotel.location.toLowerCase().includes(filters.location!.toLowerCase())
      );
    }

    if (filters.rating) {
      filteredHotels = filteredHotels.filter(hotel =>
        hotel.rating >= filters.rating!
      );
    }

    if (filters.priceRange) {
      const priceRanges = {
        budget: { min: 0, max: 150 },
        mid: { min: 151, max: 300 },
        luxury: { min: 301, max: Infinity }
      };
      const range = priceRanges[filters.priceRange as keyof typeof priceRanges];
      if (range) {
        filteredHotels = filteredHotels.filter(hotel =>
          hotel.price >= range.min && hotel.price <= range.max
        );
      }
    }

    // Sort by availability and last update time
    filteredHotels.sort((a, b) => {
      if (a.roomsAvailable !== b.roomsAvailable) {
        return b.roomsAvailable - a.roomsAvailable;
      }
      return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
    });

    return filteredHotels;
  }

  async getHotel(id: string): Promise<HotelBooking | undefined> {
    return this.hotelData.find(hotel => hotel.id === id);
  }

  onHotelsUpdated(callback: (hotels: HotelBooking[]) => void) {
    this.eventEmitter.on('hotelsUpdated', callback);
  }

  stopUpdates() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }
}

export const hotelService = new HotelService();