import Stripe from 'stripe';
import { BookingType } from '@shared/schema';
import { db } from '../db';
import { sql } from 'drizzle-orm';

// Define payment record structure for the enhanced service
interface PaymentRecord {
  id: string;
  userId: number;
  bookingType: BookingType;
  amount: number;
  status: 'pending' | 'succeeded' | 'failed' | 'refunded';
  metadata: any;
  paymentMethod?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Enhanced payment service implementation
class StripePaymentService {
  private stripe: Stripe;
  
  constructor(apiKey: string) {
    this.stripe = new Stripe(apiKey, {
      typescript: true,
    });
  }
  
  async createPaymentIntent(amount: number, bookingType: BookingType, metadata: any) {
    try {
      if (!amount || amount <= 0) {
        throw new Error('Invalid payment amount: amount must be greater than 0');
      }
      
      if (!bookingType) {
        throw new Error('Missing booking type: a valid booking type is required');
      }
      
      if (!metadata || !metadata.userId) {
        console.warn('Missing user ID in payment metadata - this may cause issues with future analytics');
      }
      
      console.log('Creating payment intent with:', { amount, bookingType, metadata });
      
      // Validate Stripe API key format is likely valid
      if (!this.stripe || typeof this.stripe.paymentIntents !== 'object') {
        console.error('Stripe client initialization appears to have failed - check API key is valid');
        throw new Error('Payment system is misconfigured. Please contact support.');
      }
      
      // Create a payment intent with expanded payment method options
      // Note: We cannot use both automatic_payment_methods and payment_method_types together
      const paymentIntent = await this.stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: 'usd',
        metadata: {
          bookingType,
          ...metadata
        },
        // Use automatic payment methods for maximum flexibility
        automatic_payment_methods: {
          enabled: true,
          allow_redirects: 'always'
        }
      });
      
      console.log('Payment intent created successfully:', paymentIntent.id);
      
      // Store payment attempt in database - wrapped in try/catch to avoid blocking payment flow
      try {
        await db.execute(sql`
          INSERT INTO payment_records 
          (id, user_id, booking_type, amount, status, created_at) 
          VALUES 
          (${paymentIntent.id}, ${metadata.userId || 0}, ${bookingType}, ${amount}, 'pending', NOW())
        `);
      } catch (dbError) {
        console.error('Failed to record payment attempt:', dbError);
        // Continue even if db recording fails - this shouldn't block the payment flow
      }
      
      return {
        clientSecret: paymentIntent.client_secret,
        id: paymentIntent.id,
        paymentMethods: [
          'card',       // Credit/Debit cards
          'upi',        // UPI payments (India)
          'netbanking', // Online banking (India)
          'paytm',      // Paytm wallet (India)
          'gpay',       // Google Pay
          'paypal'      // PayPal
        ]
      };
    } catch (error: any) {
      console.error('Payment intent creation failed:', error);
      
      // Handle specific Stripe error types
      if (error.type) {
        switch (error.type) {
          case 'StripeCardError':
            // Card declined or failed validation
            console.error('Card error:', error.message);
            throw new Error(`Card error: ${error.message}`);
          
          case 'StripeRateLimitError':
            // Too many requests made to the Stripe API too quickly
            console.error('Rate limit exceeded:', error.message);
            throw new Error('Payment system is currently busy. Please try again in a few moments.');
          
          case 'StripeInvalidRequestError':
            // Invalid parameters were supplied to Stripe's API
            console.error('Invalid request:', error.message);
            throw new Error(`Invalid payment request: ${error.message}`);
          
          case 'StripeAPIError':
            // Stripe API error
            console.error('Stripe API error:', error.message);
            throw new Error('Payment system encountered an error. Please try again later.');
          
          case 'StripeConnectionError':
            // Network communication with Stripe failed
            console.error('Connection error:', error.message);
            throw new Error('Unable to connect to payment service. Please check your internet connection and try again.');
          
          case 'StripeAuthenticationError':
            // Stripe API key or authentication error
            console.error('Authentication error:', error.message);
            throw new Error('Payment system is misconfigured. Please contact support.');
          
          default:
            // Other Stripe errors
            console.error('Other Stripe error:', error.message);
            throw new Error(`Payment error: ${error.message}`);
        }
      }
      
      // For non-Stripe errors or untyped errors
      console.error('Error details:', error instanceof Error ? error.message : String(error));
      console.error('Error stack:', error.stack || 'No stack trace available');
      throw new Error('Failed to initialize payment. Please try again or contact support.');
    }
  }

  async confirmPayment(paymentIntentId: string) {
    try {
      if (!paymentIntentId) {
        throw new Error('Missing payment intent ID: Required for confirming payment');
      }
      
      const paymentIntent = await this.stripe.paymentIntents.retrieve(paymentIntentId);
      const succeeded = paymentIntent.status === 'succeeded';
      
      // Log detailed payment status info for debugging purposes
      console.log(`Payment status confirmation: ID ${paymentIntentId}, Status: ${paymentIntent.status}`);
      
      if (paymentIntent.status === 'requires_payment_method') {
        console.warn('Payment requires payment method - possible card decline or authentication failure');
      }
      
      if (paymentIntent.last_payment_error) {
        console.error('Payment error details:', paymentIntent.last_payment_error);
      }
      
      // Update payment record in database
      try {
        await db.execute(sql`
          UPDATE payment_records 
          SET status = ${paymentIntent.status}, 
              payment_method = ${paymentIntent.payment_method_types?.[0] || 'unknown'},
              updated_at = NOW()
          WHERE id = ${paymentIntentId}
        `);
      } catch (dbError) {
        console.error('Failed to update payment record:', dbError);
        // Continue even if db update fails
      }
      
      return {
        status: paymentIntent.status,
        succeeded,
        paymentIntent,
        errorMessage: paymentIntent.last_payment_error?.message || null
      };
    } catch (error: any) {
      console.error('Payment confirmation failed:', error);
      
      // Handle specific Stripe error types
      if (error.type) {
        switch (error.type) {
          case 'StripeCardError':
            // Card declined or failed validation
            console.error('Card error during confirmation:', error.message);
            throw new Error(`Card error: ${error.message}`);
          
          case 'StripeInvalidRequestError':
            // Invalid parameters were supplied to Stripe's API
            console.error('Invalid request during confirmation:', error.message);
            throw new Error(`Invalid payment confirmation: ${error.message}`);
          
          default:
            // Other Stripe errors
            console.error('Stripe error during confirmation:', error.message);
            throw new Error(`Payment confirmation error: ${error.message}`);
        }
      }
      
      // For non-Stripe errors
      console.error('Error details:', error instanceof Error ? error.message : String(error));
      throw new Error('Failed to confirm payment status. Please check your dashboard for the current status.');
    }
  }
  
  async createSetupIntent(userId: number, metadata: any = {}) {
    try {
      const setupIntent = await this.stripe.setupIntents.create({
        usage: 'off_session',
        metadata: {
          userId,
          ...metadata
        }
      });
      
      return {
        clientSecret: setupIntent.client_secret,
        id: setupIntent.id
      };
    } catch (error) {
      console.error('Setup intent creation failed:', error);
      throw new Error('Failed to initialize card setup');
    }
  }
  
  async createSubscription(customerId: string, priceId: string, metadata: any = {}) {
    try {
      const subscription = await this.stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: priceId }],
        metadata
      });
      
      return subscription;
    } catch (error) {
      console.error('Subscription creation failed:', error);
      throw new Error('Failed to create subscription');
    }
  }
  
  async createCustomer(email: string, name?: string, metadata: any = {}) {
    try {
      const customer = await this.stripe.customers.create({
        email,
        name,
        metadata
      });
      
      return customer;
    } catch (error) {
      console.error('Customer creation failed:', error);
      throw new Error('Failed to create customer');
    }
  }
  
  async refundPayment(paymentIntentId: string, amount?: number) {
    try {
      const refundParams: Stripe.RefundCreateParams = {
        payment_intent: paymentIntentId
      };
      
      if (amount) {
        refundParams.amount = Math.round(amount * 100);
      }
      
      const refund = await this.stripe.refunds.create(refundParams);
      
      // Update payment record
      try {
        await db.execute(sql`
          UPDATE payment_records 
          SET status = 'refunded', updated_at = NOW()
          WHERE id = ${paymentIntentId}
        `);
      } catch (dbError) {
        console.error('Failed to update payment record for refund:', dbError);
      }
      
      return refund;
    } catch (error) {
      console.error('Refund failed:', error);
      throw new Error('Failed to process refund');
    }
  }
  
  async getPaymentMethods(customerId: string) {
    try {
      const paymentMethods = await this.stripe.paymentMethods.list({
        customer: customerId,
        type: 'card'
      });
      
      return paymentMethods.data;
    } catch (error) {
      console.error('Failed to retrieve payment methods:', error);
      throw new Error('Unable to get saved payment methods');
    }
  }
  
  async createPaymentMethod(params: Stripe.PaymentMethodCreateParams) {
    try {
      const paymentMethod = await this.stripe.paymentMethods.create(params);
      return paymentMethod;
    } catch (error) {
      console.error('Failed to create payment method:', error);
      throw new Error('Unable to create payment method');
    }
  }
  
  async attachPaymentMethod(paymentMethodId: string, customerId: string) {
    try {
      const paymentMethod = await this.stripe.paymentMethods.attach(
        paymentMethodId,
        { customer: customerId }
      );
      return paymentMethod;
    } catch (error) {
      console.error('Failed to attach payment method:', error);
      throw new Error('Unable to attach payment method to customer');
    }
  }
  
  async detachPaymentMethod(paymentMethodId: string) {
    try {
      const paymentMethod = await this.stripe.paymentMethods.detach(paymentMethodId);
      return paymentMethod;
    } catch (error) {
      console.error('Failed to detach payment method:', error);
      throw new Error('Unable to remove payment method');
    }
  }
  
  async updateCustomerDefaultMethod(customerId: string, paymentMethodId: string) {
    try {
      const customer = await this.stripe.customers.update(customerId, {
        invoice_settings: {
          default_payment_method: paymentMethodId
        }
      });
      return customer;
    } catch (error) {
      console.error('Failed to update default payment method:', error);
      throw new Error('Unable to set default payment method');
    }
  }
  
  async generateInvoice(customerId: string, items: Array<{amount: number, description: string}>) {
    try {
      const invoice = await this.stripe.invoices.create({
        customer: customerId,
        auto_advance: true,
      });
      
      // Add items to the invoice
      for (const item of items) {
        await this.stripe.invoiceItems.create({
          customer: customerId,
          invoice: invoice.id,
          amount: Math.round(item.amount * 100),
          description: item.description,
          currency: 'usd'
        });
      }
      
      // Finalize the invoice
      const finalizedInvoice = await this.stripe.invoices.finalizeInvoice(invoice.id);
      
      return finalizedInvoice;
    } catch (error) {
      console.error('Invoice generation failed:', error);
      throw new Error('Failed to create invoice');
    }
  }
}

// Create a mock service for testing that faithfully simulates the real one
class MockPaymentService {
  async createPaymentIntent(amount: number, bookingType: BookingType, metadata: any) {
    console.log('MOCK: Creating payment intent for', {amount, bookingType, metadata});
    
    // Also log some helpful information for debugging
    console.log('MOCK: Using mock payment service because STRIPE_SECRET_KEY is not available or not valid');
    console.log('MOCK: If you want to use real Stripe, please set a valid STRIPE_SECRET_KEY environment variable');
    
    // Match the validation from the real service
    if (!amount || amount <= 0) {
      throw new Error('Invalid payment amount: amount must be greater than 0');
    }
    
    if (!bookingType) {
      throw new Error('Missing booking type: a valid booking type is required');
    }
    
    if (!metadata || !metadata.userId) {
      console.warn('Missing user ID in payment metadata - this may cause issues with future analytics');
    }
    
    // Generate a mock ID that looks like a Stripe ID
    const mockId = `mock_pi_${Date.now()}${Math.floor(Math.random() * 1000)}`;
    
    // Simulate occasional errors (5% of the time)
    const randomOutcome = Math.random();
    if (randomOutcome < 0.05) {
      console.log('MOCK: Simulating a payment intent creation error');
      
      const errorTypes = [
        { type: 'StripeCardError', message: 'Your card has insufficient funds.' },
        { type: 'StripeRateLimitError', message: 'Too many requests made to the API too quickly.' },
        { type: 'StripeInvalidRequestError', message: 'Invalid parameters were supplied to Stripe\'s API.' },
        { type: 'StripeAPIError', message: 'An error occurred with Stripe\'s API.' }
      ];
      
      const randomError = errorTypes[Math.floor(Math.random() * errorTypes.length)];
      const error = new Error(randomError.message);
      (error as any).type = randomError.type;
      throw error;
    }
    
    return {
      clientSecret: `${mockId}_secret_mock`,
      id: mockId,
      paymentMethods: [
        'card',       // Credit/Debit cards
        'upi',        // UPI payments (India)
        'netbanking', // Online banking (India)
        'paytm',      // Paytm wallet (India)
        'gpay',       // Google Pay
        'paypal'      // PayPal
      ]
    };
  }

  async confirmPayment(paymentIntentId: string) {
    console.log('MOCK: Confirming payment', paymentIntentId);
    
    if (!paymentIntentId) {
      throw new Error('Missing payment intent ID: Required for confirming payment');
    }
    
    // Simulate occasional payment failures (15% of the time)
    const randomOutcome = Math.random();
    if (randomOutcome < 0.15) {
      console.log('MOCK: Simulating a payment failure');
      
      return {
        status: 'requires_payment_method',
        succeeded: false,
        paymentIntent: {
          id: paymentIntentId,
          status: 'requires_payment_method',
          amount: 1000,
          currency: 'usd',
          last_payment_error: {
            code: 'card_declined',
            message: 'Your card was declined. Try using a different payment method.'
          }
        },
        errorMessage: 'Your card was declined. Try using a different payment method.'
      };
    }
    
    // Default success case
    return {
      status: 'succeeded',
      succeeded: true,
      paymentIntent: {
        id: paymentIntentId,
        status: 'succeeded',
        amount: 1000,
        currency: 'usd',
        last_payment_error: null
      },
      errorMessage: null
    };
  }
  
  async createSetupIntent(userId: number, metadata: any = {}) {
    const mockId = `mock_seti_${Date.now()}`;
    
    return {
      clientSecret: `${mockId}_secret`,
      id: mockId
    };
  }
  
  async createSubscription(customerId: string, priceId: string, metadata: any = {}) {
    return {
      id: `mock_sub_${Date.now()}`,
      status: 'active',
      customer: customerId,
      items: {
        data: [{ price: { id: priceId } }]
      }
    };
  }
  
  async createCustomer(email: string, name?: string, metadata: any = {}) {
    return {
      id: `mock_cus_${Date.now()}`,
      email,
      name
    };
  }
  
  async refundPayment(paymentIntentId: string, amount?: number) {
    return {
      id: `mock_re_${Date.now()}`,
      payment_intent: paymentIntentId,
      status: 'succeeded',
      amount: amount ? Math.round(amount * 100) : 1000
    };
  }
  
  async getPaymentMethods(customerId: string) {
    return [
      {
        id: `mock_pm_${Date.now()}`,
        type: 'card',
        card: {
          brand: 'visa',
          last4: '4242',
          exp_month: 12,
          exp_year: 2030
        }
      }
    ];
  }
  
  async createPaymentMethod(params: any) {
    console.log('MOCK: Creating payment method', params);
    return {
      id: `mock_pm_${Date.now()}`,
      type: 'card',
      card: {
        brand: 'visa',
        last4: params.card?.number?.slice(-4) || '4242',
        exp_month: params.card?.exp_month || 12,
        exp_year: params.card?.exp_year || 30
      }
    };
  }
  
  async attachPaymentMethod(paymentMethodId: string, customerId: string) {
    console.log(`MOCK: Attaching payment method ${paymentMethodId} to customer ${customerId}`);
    return {
      id: paymentMethodId,
      type: 'card',
      customer: customerId
    };
  }
  
  async detachPaymentMethod(paymentMethodId: string) {
    console.log(`MOCK: Detaching payment method ${paymentMethodId}`);
    return {
      id: paymentMethodId,
      type: 'card'
    };
  }
  
  async updateCustomerDefaultMethod(customerId: string, paymentMethodId: string) {
    console.log(`MOCK: Setting ${paymentMethodId} as default for customer ${customerId}`);
    return {
      id: customerId,
      invoice_settings: {
        default_payment_method: paymentMethodId
      }
    };
  }
  
  async generateInvoice(customerId: string, items: Array<{amount: number, description: string}>) {
    return {
      id: `mock_in_${Date.now()}`,
      customer: customerId,
      status: 'paid',
      total: items.reduce((sum, item) => sum + Math.round(item.amount * 100), 0)
    };
  }
}

// If Stripe key is available, use real Stripe service, otherwise use mock
export const paymentService = process.env.STRIPE_SECRET_KEY
  ? new StripePaymentService(process.env.STRIPE_SECRET_KEY)
  : new MockPaymentService();