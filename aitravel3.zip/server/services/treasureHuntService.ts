import { format } from 'date-fns';
import OpenAI from "openai";

interface Location {
  lat: number;
  lng: number;
}

interface Clue {
  id: string;
  text: string;
  hint: string;
  location: {
    lat: number;
    lng: number;
    radius: number;
  };
  points: number;
  icon: string;
}

class TreasureHuntService {
  private static instance: TreasureHuntService;
  private openai: OpenAI;

  private constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  static getInstance(): TreasureHuntService {
    if (!TreasureHuntService.instance) {
      TreasureHuntService.instance = new TreasureHuntService();
    }
    return TreasureHuntService.instance;
  }

  // Generate interesting locations near the user
  private async generateNearbyLocations(userLocation: Location): Promise<Location[]> {
    try {
      // Use OpenStreetMap Nominatim API to find interesting places
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?` +
        `format=json&lat=${userLocation.lat}&lon=${userLocation.lng}&zoom=16&addressdetails=1`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch location data');
      }

      const data = await response.json();
      
      // Generate 3-5 locations within 1km radius
      const locations: Location[] = [];
      const radius = 0.01; // Roughly 1km in coordinates

      for (let i = 0; i < 5; i++) {
        const randomLat = userLocation.lat + (Math.random() - 0.5) * radius;
        const randomLng = userLocation.lng + (Math.random() - 0.5) * radius;
        locations.push({ lat: randomLat, lng: randomLng });
      }

      return locations;
    } catch (error) {
      console.error('Error generating nearby locations:', error);
      throw error;
    }
  }

  // Generate clues for locations using AI
  private async generateClues(locations: Location[]): Promise<Clue[]> {
    try {
      const clues: Clue[] = [];
      const icons = ['MapPin', 'Building', 'Trees', 'Coffee', 'Store', 'Park'];

      for (let i = 0; i < locations.length; i++) {
        const location = locations[i];
        
        // Get location details from OpenStreetMap
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?` +
          `format=json&lat=${location.lat}&lon=${location.lng}&zoom=18&addressdetails=1`
        );

        if (!response.ok) continue;

        const locationData = await response.json();
        const address = locationData.address;

        // Generate clue using AI
        const prompt = `Create a fun and cryptic clue for a location treasure hunt game. The location is near ${
          address.road || address.neighbourhood || address.suburb || 'a mysterious place'
        }. Include a straightforward hint that can help if the player is stuck. Format the response as JSON with 'clue' and 'hint' fields.`;

        const completion = await this.openai.chat.completions.create({
          messages: [{ role: "user", content: prompt }],
          model: "gpt-3.5-turbo",
        });

        const content = completion.choices[0]?.message?.content;
        if (!content) continue;

        const aiResponse = JSON.parse(content);

        clues.push({
          id: `clue-${i + 1}`,
          text: aiResponse.clue,
          hint: aiResponse.hint,
          location: {
            lat: location.lat,
            lng: location.lng,
            radius: 50 // 50 meters radius
          },
          points: 100 + (i * 50), // Increasing points for each clue
          icon: icons[i % icons.length]
        });
      }

      return clues;
    } catch (error) {
      console.error('Error generating clues:', error);
      throw error;
    }
  }

  // Start a new treasure hunt game
  async startGame(userLocation: Location): Promise<Clue> {
    try {
      const locations = await this.generateNearbyLocations(userLocation);
      const clues = await this.generateClues(locations);
      // Store clues in memory for this session (could be moved to database later)
      (global as any).currentGameClues = clues;
      return clues[0];
    } catch (error) {
      console.error('Error starting game:', error);
      throw error;
    }
  }

  // Get next clue
  async getNextClue(currentClueId: string): Promise<{ clue: Clue | null, gameComplete: boolean }> {
    const clues = (global as any).currentGameClues || [];
    const currentIndex = clues.findIndex((c: Clue) => c.id === currentClueId);
    
    if (currentIndex === -1 || currentIndex === clues.length - 1) {
      return { clue: null, gameComplete: true };
    }

    return { 
      clue: clues[currentIndex + 1],
      gameComplete: false
    };
  }
}

export const treasureHuntService = TreasureHuntService.getInstance();
