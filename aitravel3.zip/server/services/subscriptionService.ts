import { db } from '../db';
import {
  User, BusinessAccount, Subscription, CommissionRecord, Referral, AffiliateLink,
  SubscriptionTier, businessAccounts, subscriptions, commissionRecords, referrals, affiliateLinks
} from '../../shared/schema';
import { eq, and, gte } from 'drizzle-orm';
import { generateRandomString } from '../utils/helpers';

export class SubscriptionService {
  private static instance: SubscriptionService;

  private constructor() {}

  static getInstance(): SubscriptionService {
    if (!SubscriptionService.instance) {
      SubscriptionService.instance = new SubscriptionService();
    }
    return SubscriptionService.instance;
  }

  /**
   * Create or update a user's subscription
   */
  async createOrUpdateSubscription(
    userId: number,
    tier: string,
    endDate: Date,
    stripeSubscriptionId?: string
  ): Promise<Subscription> {
    // Check if subscription exists
    const existingSubscription = await db.query.subscriptions.findFirst({
      where: and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.status, 'active')
      )
    });

    if (existingSubscription) {
      // Update existing subscription
      const [updated] = await db
        .update(subscriptions)
        .set({
          tier,
          endDate,
          stripeSubscriptionId,
          updatedAt: new Date(),
        })
        .where(eq(subscriptions.id, existingSubscription.id))
        .returning();
      
      return updated;
    } else {
      // Create new subscription
      const [created] = await db
        .insert(subscriptions)
        .values({
          userId,
          tier,
          endDate,
          stripeSubscriptionId,
          status: 'active',
        })
        .returning();
      
      // Update user's subscription tier
      await db
        .update(db.schema.users)
        .set({ 
          subscription_tier: tier,
          subscription_expires: endDate
        })
        .where(eq(db.schema.users.id, userId));
      
      return created;
    }
  }

  /**
   * Get a user's active subscription
   */
  async getUserSubscription(userId: number): Promise<Subscription | null> {
    const subscription = await db.query.subscriptions.findFirst({
      where: and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.status, 'active'),
        gte(subscriptions.endDate, new Date())
      )
    });
    
    return subscription || null;
  }

  /**
   * Cancel a user's subscription
   */
  async cancelSubscription(subscriptionId: number): Promise<boolean> {
    const [updated] = await db
      .update(subscriptions)
      .set({
        status: 'cancelled',
        updatedAt: new Date(),
      })
      .where(eq(subscriptions.id, subscriptionId))
      .returning();
    
    if (updated) {
      // Also update the user's subscription tier to free
      await db
        .update(db.schema.users)
        .set({ 
          subscription_tier: SubscriptionTier.FREE,
        })
        .where(eq(db.schema.users.id, updated.userId));
      
      return true;
    }
    
    return false;
  }

  /**
   * Record a commission for a booking
   */
  async recordCommission(
    bookingId: number,
    userId: number,
    bookingType: string,
    baseAmount: number,
    commissionRate: number,
    partnerName?: string,
    partnerReferenceId?: string
  ): Promise<CommissionRecord> {
    const commissionAmount = baseAmount * (commissionRate / 100);
    
    const [record] = await db
      .insert(commissionRecords)
      .values({
        bookingId,
        userId,
        bookingType,
        baseAmount,
        commissionRate,
        commissionAmount,
        partnerName,
        partnerReferenceId,
        status: 'pending',
      })
      .returning();
    
    return record;
  }

  /**
   * Create a business account
   */
  async createBusinessAccount(
    name: string,
    contactEmail: string,
    maxUsers: number = 5,
    address?: string,
    taxId?: string,
    contactPhone?: string
  ): Promise<BusinessAccount> {
    const [account] = await db
      .insert(businessAccounts)
      .values({
        name,
        contactEmail,
        maxUsers,
        address,
        taxId,
        contactPhone,
      })
      .returning();
    
    return account;
  }

  /**
   * Associate a user with a business account
   */
  async assignUserToBusinessAccount(
    userId: number,
    businessAccountId: number
  ): Promise<boolean> {
    const [updated] = await db
      .update(db.schema.users)
      .set({ business_account_id: businessAccountId })
      .where(eq(db.schema.users.id, userId))
      .returning();
    
    return !!updated;
  }

  /**
   * Create a referral code for a user
   */
  async createReferralCode(userId: number): Promise<string> {
    const code = generateRandomString(8);
    
    await db
      .update(db.schema.users)
      .set({ referral_code: code })
      .where(eq(db.schema.users.id, userId));
    
    return code;
  }

  /**
   * Process a referral when a new user signs up
   */
  async processReferral(
    referrerCode: string,
    newUserId: number
  ): Promise<Referral | null> {
    // Find the referring user
    const referrer = await db.query.users.findFirst({
      where: eq(db.schema.users.referral_code, referrerCode)
    });
    
    if (!referrer) {
      return null;
    }
    
    // Create referral record
    const [referral] = await db
      .insert(referrals)
      .values({
        referrerId: referrer.id,
        referredId: newUserId,
        status: 'pending',
        rewardAmount: 10.0, // $10 reward for successful referrals
      })
      .returning();
    
    // Update the new user to track who referred them
    await db
      .update(db.schema.users)
      .set({ referred_by: referrer.id })
      .where(eq(db.schema.users.id, newUserId));
    
    return referral;
  }

  /**
   * Complete a referral after qualifying action (e.g., subscription purchase)
   */
  async completeReferral(referralId: number): Promise<boolean> {
    const [updated] = await db
      .update(referrals)
      .set({
        status: 'completed',
        rewardIssued: true,
      })
      .where(eq(referrals.id, referralId))
      .returning();
    
    return !!updated;
  }

  /**
   * Create affiliate link for a user
   */
  async createAffiliateLink(
    userId: number,
    destination: string,
    description?: string
  ): Promise<AffiliateLink> {
    const code = generateRandomString(10);
    
    const [link] = await db
      .insert(affiliateLinks)
      .values({
        userId,
        code,
        destination,
        description,
      })
      .returning();
    
    return link;
  }

  /**
   * Track affiliate link click
   */
  async trackAffiliateLinkClick(code: string): Promise<boolean> {
    const [updated] = await db
      .update(affiliateLinks)
      .set({
        clicks: db.sql`${affiliateLinks.clicks} + 1`,
      })
      .where(eq(affiliateLinks.code, code))
      .returning();
    
    return !!updated;
  }

  /**
   * Track affiliate link conversion
   */
  async trackAffiliateLinkConversion(
    code: string,
    commissionAmount: number
  ): Promise<boolean> {
    const [updated] = await db
      .update(affiliateLinks)
      .set({
        conversions: db.sql`${affiliateLinks.conversions} + 1`,
        commission: db.sql`${affiliateLinks.commission} + ${commissionAmount}`,
      })
      .where(eq(affiliateLinks.code, code))
      .returning();
    
    return !!updated;
  }
}

export const subscriptionService = SubscriptionService.getInstance();