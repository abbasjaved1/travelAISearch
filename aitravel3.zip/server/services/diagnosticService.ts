import { flightService } from './flightService';
import { rapidApiService } from './rapidApiService';
import { hotelService } from './hotelService';
import { rideService } from './rideService';
import { aiService } from './aiService';
import { soundtrackService } from './soundtrackService';
import OpenAI from 'openai';
import axios from 'axios';

/**
 * Service to diagnose and verify connectivity with external APIs
 */
export class DiagnosticService {
  /**
   * Test all API connections and return their status
   */
  async testAllConnections(): Promise<Record<string, any>> {
    const results: Record<string, any> = {};
    
    // Check environment variables first
    results.environment = this.checkEnvironmentVariables();
    
    // Test individual services
    results.openai = await this.testOpenAIConnection();
    results.rapidApi = await this.testRapidApiConnection();
    results.aviation = await this.testAviationApiConnection();
    results.amadeus = await this.testAmadeusConnection();
    results.stripe = await this.testStripeConnection();
    results.google_maps = await this.testGoogleMapsConnection();
    results.twilio = await this.testTwilioConnection();
    
    return results;
  }
  
  /**
   * Check which environment variables are set
   */
  private checkEnvironmentVariables(): Record<string, boolean> {
    return {
      OPENAI_API_KEY: !!process.env.OPENAI_API_KEY,
      RAPID_API_KEY: !!process.env.RAPID_API_KEY,
      AVIATION_API_KEY: !!process.env.AVIATION_API_KEY,
      AMADEUS_API_KEY: !!process.env.AMADEUS_API_KEY,
      STRIPE_SECRET_KEY: !!process.env.STRIPE_SECRET_KEY,
      GOOGLE_MAPS_API_KEY: !!process.env.GOOGLE_MAPS_API_KEY,
      TWILIO_ACCOUNT_SID: !!process.env.TWILIO_ACCOUNT_SID,
      TWILIO_AUTH_TOKEN: !!process.env.TWILIO_AUTH_TOKEN,
      TWILIO_PHONE_NUMBER: !!process.env.TWILIO_PHONE_NUMBER
    };
  }
  
  /**
   * Test OpenAI API connection
   */
  private async testOpenAIConnection(): Promise<any> {
    try {
      if (!process.env.OPENAI_API_KEY) {
        return {
          status: 'unavailable',
          message: 'API key not configured'
        };
      }
      
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
      
      // Make a simple models list request to test connectivity
      const response = await openai.models.list();
      
      return {
        status: 'ok',
        message: `Connected successfully. ${response.data.length} models available.`
      };
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message,
        details: error.status ? `Status code: ${error.status}` : undefined
      };
    }
  }
  
  /**
   * Test RapidAPI connection
   */
  private async testRapidApiConnection(): Promise<any> {
    try {
      if (!process.env.RAPID_API_KEY) {
        return {
          status: 'unavailable',
          message: 'API key not configured'
        };
      }
      
      // Try a simple hotel search to test connectivity
      const testLocation = 'New York';
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const dayAfter = new Date();
      dayAfter.setDate(dayAfter.getDate() + 2);
      
      const checkIn = tomorrow.toISOString().split('T')[0];
      const checkOut = dayAfter.toISOString().split('T')[0];
      
      try {
        const hotels = await rapidApiService.searchHotels(
          testLocation,
          checkIn,
          checkOut,
          1
        );
        
        return {
          status: 'ok',
          message: `Connected successfully. Retrieved ${hotels.length} hotels.`
        };
      } catch (error: any) {
        throw error;
      }
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message,
        details: error.response ? `Status code: ${error.response.status}` : undefined
      };
    }
  }
  
  /**
   * Test Aviation API connection
   */
  private async testAviationApiConnection(): Promise<any> {
    try {
      if (!process.env.AVIATION_API_KEY) {
        return {
          status: 'unavailable',
          message: 'API key not configured'
        };
      }
      
      // Try a simple flight search to test connectivity
      try {
        const flights = await flightService.searchFlights({
          dep_iata: 'JFK',
          arr_iata: 'LAX',
          flight_date: new Date().toISOString().split('T')[0]
        });
        
        return {
          status: 'ok',
          message: `Connected successfully. Retrieved ${flights.length} flights.`
        };
      } catch (error: any) {
        throw error;
      }
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message,
        details: error.response ? `Status code: ${error.response.status}` : undefined
      };
    }
  }
  
  /**
   * Test Amadeus API connection
   */
  private async testAmadeusConnection(): Promise<any> {
    try {
      if (!process.env.AMADEUS_API_KEY) {
        return {
          status: 'unavailable',
          message: 'API key not configured'
        };
      }
      
      // For now, we'll just check if the key exists since we're not using it directly
      return {
        status: 'configured',
        message: 'API key is configured but connection not directly tested'
      };
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message
      };
    }
  }
  
  /**
   * Test Stripe API connection
   */
  private async testStripeConnection(): Promise<any> {
    try {
      if (!process.env.STRIPE_SECRET_KEY) {
        return {
          status: 'unavailable',
          message: 'API key not configured'
        };
      }
      
      // Make a simple request to test connectivity
      try {
        // Import Stripe using dynamic import instead of require
        const stripe = await import('stripe').then(module => {
          const Stripe = module.default;
          return new Stripe(process.env.STRIPE_SECRET_KEY as string, {
            apiVersion: '2023-10-16'
          });
        });
        
        const customers = await stripe.customers.list({ limit: 1 });
        
        return {
          status: 'ok',
          message: 'Connected successfully to Stripe API'
        };
      } catch (error: any) {
        throw error;
      }
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message,
        details: error.statusCode ? `Status code: ${error.statusCode}` : undefined
      };
    }
  }
  
  /**
   * Test Google Maps API connection
   */
  private async testGoogleMapsConnection(): Promise<any> {
    try {
      if (!process.env.GOOGLE_MAPS_API_KEY) {
        return {
          status: 'unavailable',
          message: 'API key not configured'
        };
      }
      
      // Test with a simple geocoding request
      try {
        const response = await axios.get(
          `https://maps.googleapis.com/maps/api/geocode/json?address=New York&key=${process.env.GOOGLE_MAPS_API_KEY}`
        );
        
        if (response.data.status === 'OK') {
          return {
            status: 'ok',
            message: 'Connected successfully to Google Maps API'
          };
        } else {
          return {
            status: 'error',
            message: `API returned status: ${response.data.status}`,
            details: response.data.error_message
          };
        }
      } catch (error: any) {
        throw error;
      }
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message,
        details: error.response ? `Status code: ${error.response.status}` : undefined
      };
    }
  }
  
  /**
   * Test Twilio API connection
   */
  private async testTwilioConnection(): Promise<any> {
    try {
      if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
        return {
          status: 'unavailable',
          message: 'API credentials not configured'
        };
      }
      
      // We'll just check if the SID and token are present
      return {
        status: 'configured',
        message: 'API credentials are configured but connection not directly tested',
        phone_number: process.env.TWILIO_PHONE_NUMBER ? 'configured' : 'missing'
      };
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message
      };
    }
  }
}

export const diagnosticService = new DiagnosticService();