import { User } from '@shared/schema';
import { aiService } from './aiService';

export interface SoundtrackMood {
  name: string;
  description: string;
  intensity: 'calm' | 'moderate' | 'energetic';
  emotionalTone: 'happy' | 'melancholic' | 'excited' | 'relaxed' | 'adventurous';
}

export interface SoundtrackTrack {
  title: string;
  artist: string;
  genre: string;
  mood: string;
  intensity: number; // 1-10 scale
  url?: string;
  imageUrl?: string;
  previewUrl?: string;
  duration?: string;
}

export interface SoundtrackPlaylist {
  id: string;
  name: string;
  description: string;
  destination: string;
  mood: SoundtrackMood;
  tracks: SoundtrackTrack[];
  coverImageUrl?: string;
  duration?: string;
  createdAt: string;
}

export interface SoundtrackRequest {
  destination: string;
  mood?: string;
  genres?: string[];
  intensity?: number;
  preferences?: {
    favoriteArtists?: string[];
    favoriteGenres?: string[];
    excludeGenres?: string[];
  };
  duration?: number; // in minutes
}

export const PRESET_MOODS = [
  {
    name: 'Beach Relaxation',
    description: 'Calm, soothing tracks perfect for lounging on a tropical beach',
    intensity: 'calm' as const,
    emotionalTone: 'relaxed' as const
  },
  {
    name: 'Urban Explorer',
    description: 'Eclectic city sounds for navigating busy streets and urban adventures',
    intensity: 'moderate' as const,
    emotionalTone: 'adventurous' as const
  },
  {
    name: 'Mountain Serenity',
    description: 'Peaceful, ambient sounds inspired by mountain landscapes',
    intensity: 'calm' as const,
    emotionalTone: 'relaxed' as const
  },
  {
    name: 'Road Trip Energy',
    description: 'Upbeat, energetic tracks for long drives and scenic routes',
    intensity: 'energetic' as const,
    emotionalTone: 'excited' as const
  },
  {
    name: 'Cultural Immersion',
    description: 'Traditional and contemporary sounds from your destination',
    intensity: 'moderate' as const,
    emotionalTone: 'adventurous' as const
  },
  {
    name: 'Sunset Reflection',
    description: 'Mellow, emotional tracks for watching the sunset at your destination',
    intensity: 'calm' as const,
    emotionalTone: 'melancholic' as const
  },
  {
    name: 'Adventure Mode',
    description: 'High-energy, inspiring tracks for outdoor adventures',
    intensity: 'energetic' as const,
    emotionalTone: 'excited' as const
  },
  {
    name: 'Romantic Getaway',
    description: 'Intimate, warm sounds for romantic travel moments',
    intensity: 'calm' as const,
    emotionalTone: 'happy' as const
  }
] as const;

class SoundtrackService {
  private playlists: Map<string, SoundtrackPlaylist> = new Map();
  private nextId = 1;

  constructor() {
    console.log('SoundtrackService initialized');
  }

  async generateSoundtrack(
    request: SoundtrackRequest,
    user?: User
  ): Promise<SoundtrackPlaylist> {
    try {
      console.log('Generating soundtrack for:', {
        destination: request.destination,
        mood: request.mood,
        userPreferences: !!user?.preferences
      });

      // Use this to generate the actual soundtrack using AI
      // Currently creating a mock response
      const playlist = this.createSoundtrackPlaylist(request, user);
      
      // Store the playlist for retrieval
      this.playlists.set(playlist.id, playlist);
      
      console.log('Generated soundtrack playlist:', {
        id: playlist.id,
        name: playlist.name,
        trackCount: playlist.tracks.length
      });
      
      return playlist;
    } catch (error) {
      console.error('Error generating soundtrack:', error);
      throw new Error(`Failed to generate soundtrack: ${error.message}`);
    }
  }

  async getSoundtrack(id: string): Promise<SoundtrackPlaylist | undefined> {
    return this.playlists.get(id);
  }

  async getUserSoundtracks(userId: number): Promise<SoundtrackPlaylist[]> {
    // In a real implementation, this would filter by userId from the database
    return Array.from(this.playlists.values());
  }

  private createSoundtrackPlaylist(
    request: SoundtrackRequest,
    user?: User
  ): SoundtrackPlaylist {
    // Select a mood from the presets or use the one provided
    const selectedMood = 
      PRESET_MOODS.find(m => m.name.toLowerCase() === request.mood?.toLowerCase()) || 
      PRESET_MOODS[Math.floor(Math.random() * PRESET_MOODS.length)];
    
    // Generate playlist name based on destination and mood
    const playlistName = `${request.destination} ${selectedMood.name}`;
    
    // Create a mock playlist with tracks
    const playlist: SoundtrackPlaylist = {
      id: `playlist_${this.nextId++}`,
      name: playlistName,
      description: `A personalized soundtrack for your trip to ${request.destination}, featuring ${selectedMood.description.toLowerCase()}.`,
      destination: request.destination,
      mood: selectedMood as SoundtrackMood,
      tracks: this.generateMockTracks(request, selectedMood),
      createdAt: new Date().toISOString(),
      coverImageUrl: `https://source.unsplash.com/featured/?${encodeURIComponent(request.destination)},travel`,
      duration: '45:32' // Mock duration
    };
    
    return playlist;
  }

  private generateMockTracks(request: SoundtrackRequest, mood: any): SoundtrackTrack[] {
    // This is a placeholder for mock tracks
    // In a real implementation, this would use an external API or AI to generate tracks
    
    const mockGenres = this.getGenresForMood(mood);
    const trackCount = Math.floor(Math.random() * 5) + 8; // 8-12 tracks
    
    const tracks: SoundtrackTrack[] = [];
    
    for (let i = 0; i < trackCount; i++) {
      const intensity = 
        mood.intensity === 'calm' ? Math.floor(Math.random() * 3) + 1 :
        mood.intensity === 'moderate' ? Math.floor(Math.random() * 3) + 4 :
        Math.floor(Math.random() * 3) + 7;
      
      const genre = mockGenres[Math.floor(Math.random() * mockGenres.length)];
      
      tracks.push({
        title: `Track ${i + 1}`,
        artist: `Artist ${i + 1}`,
        genre,
        mood: mood.name,
        intensity,
        duration: `${Math.floor(Math.random() * 3) + 2}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`
      });
    }
    
    return tracks;
  }

  private getGenresForMood(mood: any): string[] {
    switch (mood.emotionalTone) {
      case 'happy':
        return ['Pop', 'Reggae', 'Funk', 'Dance'];
      case 'melancholic':
        return ['Indie', 'Ambient', 'Folk', 'Jazz'];
      case 'excited':
        return ['Rock', 'Electronic', 'Hip-Hop', 'Dance'];
      case 'relaxed':
        return ['Ambient', 'Classical', 'Lofi', 'Acoustic'];
      case 'adventurous':
        return ['World', 'Instrumental', 'Rock', 'Cinematic'];
      default:
        return ['Pop', 'Rock', 'Indie', 'Electronic'];
    }
  }

  // For AI implementation, integrate with external music APIs
  async enhanceSoundtrackWithAI(
    request: SoundtrackRequest,
    user?: User
  ): Promise<SoundtrackPlaylist> {
    try {
      // This would be the implementation using AI to generate a more personalized soundtrack
      // For now, using mock data
      return this.createSoundtrackPlaylist(request, user);
    } catch (error) {
      console.error('Error generating AI soundtrack:', error);
      throw new Error(`Failed to generate AI soundtrack: ${error.message}`);
    }
  }
}

export const soundtrackService = new SoundtrackService();