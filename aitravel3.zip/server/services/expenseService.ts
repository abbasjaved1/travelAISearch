import { db } from '../db';
import * as schema from '@shared/schema';
import { eq, and, gte, lte, desc, sql } from 'drizzle-orm';
import { Expense, BookingType } from '@shared/schema';
import { PgSelect } from 'drizzle-orm/pg-core';

/**
 * Service to handle expense tracking and management
 */
export class ExpenseService {
  /**
   * Get all user expenses including bookings from flight, hotel, and ride services
   */
  async getUserExpenses(userId: number, startDate?: string, endDate?: string): Promise<Expense[]> {
    const expenses: Expense[] = [];
    
    try {
      // Get itineraries (for flight, hotel, ride bookings)
      const baseQuery = db.select().from(schema.itineraries)
        .where(eq(schema.itineraries.userId, userId));
        
      // Add date filters separately with SQL for type safety
      const filters = [eq(schema.itineraries.userId, userId)];
      
      if (startDate) {
        filters.push(gte(schema.itineraries.bookingDate, new Date(startDate)));
      }
      
      if (endDate) {
        filters.push(lte(schema.itineraries.bookingDate, new Date(endDate)));
      }
      
      const query = db.select().from(schema.itineraries)
        .where(and(...filters))
        .orderBy(desc(schema.itineraries.bookingDate));
        
      const itineraries = await query;
      
      // Process each itinerary
      for (const itinerary of itineraries) {
        const bookingDetails = typeof itinerary.bookingDetails === 'string' 
          ? JSON.parse(itinerary.bookingDetails)
          : itinerary.bookingDetails;
        
        // Extract flight expenses
        if (bookingDetails.flight) {
          const flight = bookingDetails.flight;
          const expenseDate = flight.departure 
            ? new Date(flight.departure).toISOString() 
            : itinerary.bookingDate ? new Date(itinerary.bookingDate).toISOString() : new Date().toISOString();
          
          expenses.push({
            id: `flight-${itinerary.id}-${flight.id || Math.random().toString(36).substring(2, 9)}`,
            title: `Flight: ${flight.airline} - ${flight.from} to ${flight.to}`,
            category: 'transportation',
            amount: typeof flight.price === 'number' ? flight.price : itinerary.totalAmount,
            date: expenseDate,
            location: `${flight.from} ✈ ${flight.to}`,
            paymentMethod: 'Credit Card',
            status: this.mapPaymentStatus(itinerary.paymentStatus),
            bookingType: 'flight',
            bookingId: itinerary.id.toString(),
            icon: 'plane',
            tags: [flight.airline, flight.class]
          });
        }
        
        // Extract hotel expenses
        if (bookingDetails.hotel) {
          const hotel = bookingDetails.hotel;
          const expenseDate = hotel.checkIn 
            ? new Date(hotel.checkIn).toISOString() 
            : itinerary.bookingDate ? new Date(itinerary.bookingDate).toISOString() : new Date().toISOString();
          
          expenses.push({
            id: `hotel-${itinerary.id}-${hotel.id || Math.random().toString(36).substring(2, 9)}`,
            title: `Hotel: ${hotel.name}`,
            category: 'accommodation',
            amount: typeof hotel.price === 'number' ? hotel.price : itinerary.totalAmount,
            date: expenseDate,
            location: hotel.location,
            paymentMethod: 'Credit Card',
            status: this.mapPaymentStatus(itinerary.paymentStatus),
            bookingType: 'hotel',
            bookingId: itinerary.id.toString(),
            icon: 'hotel',
            tags: hotel.amenities?.slice(0, 3) || []
          });
        }
        
        // Extract ride expenses
        if (bookingDetails.ride) {
          const ride = bookingDetails.ride;
          const expenseDate = ride.pickupTime 
            ? new Date(ride.pickupTime).toISOString() 
            : itinerary.bookingDate ? new Date(itinerary.bookingDate).toISOString() : new Date().toISOString();
          
          const rideStatus = itinerary.paymentStatus === 'completed' 
            ? 'completed' 
            : typeof ride.status === 'string' ? this.mapRideStatus(ride.status) : this.mapPaymentStatus(itinerary.paymentStatus);
          
          expenses.push({
            id: `ride-${itinerary.id}-${ride.id || Math.random().toString(36).substring(2, 9)}`,
            title: `Ride: ${ride.type} - ${ride.from} to ${ride.to}`,
            category: 'transportation',
            amount: typeof ride.price === 'number' ? ride.price : itinerary.totalAmount,
            date: expenseDate,
            location: `${ride.from} to ${ride.to}`,
            paymentMethod: 'Credit Card',
            status: rideStatus,
            bookingType: 'ride',
            bookingId: itinerary.id.toString(),
            icon: 'car'
          });
        }
        
        // Extract dining expenses
        if (bookingDetails.dining) {
          const dining = bookingDetails.dining;
          const expenseDate = dining.date 
            ? new Date(dining.date).toISOString() 
            : itinerary.bookingDate ? new Date(itinerary.bookingDate).toISOString() : new Date().toISOString();
          
          expenses.push({
            id: `dining-${itinerary.id}-${dining.id || Math.random().toString(36).substring(2, 9)}`,
            title: `Dining: ${dining.restaurant}`,
            category: 'food',
            amount: typeof dining.price === 'number' ? dining.price : itinerary.totalAmount,
            date: expenseDate,
            location: dining.location || 'Unknown',
            paymentMethod: 'Credit Card',
            status: this.mapPaymentStatus(itinerary.paymentStatus),
            bookingType: 'dining',
            bookingId: itinerary.id.toString(),
            icon: 'utensils',
            tags: dining.cuisine ? [dining.cuisine] : []
          });
        }
      }
      
      // Fetch any standalone payment records
      const paymentRecords = await db.query.paymentRecords.findMany({
        where: eq(schema.paymentRecords.userId, userId)
      });
      
      // Add payment records as expenses if they're not already included in booking expenses
      for (const payment of paymentRecords) {
        let bookingType: BookingType | undefined = undefined;
        let metadataObj: Record<string, any> = {};
        
        try {
          if (payment.metadata && typeof payment.metadata === 'string') {
            metadataObj = JSON.parse(payment.metadata);
            if (metadataObj && typeof metadataObj === 'object' && 'bookingType' in metadataObj) {
              const bt = metadataObj.bookingType;
              if (typeof bt === 'string' && (
                bt === 'flight' || bt === 'hotel' || bt === 'ride' || bt === 'dining'
              )) {
                bookingType = bt;
              }
            }
          }
        } catch (e) {
          console.error('Error parsing payment metadata:', e);
        }
        
        // Skip if this payment is for a booking we already processed
        const paymentBookingId = payment.bookingId ? payment.bookingId.toString() : undefined;
        if (bookingType && paymentBookingId && 
            expenses.some(e => e.bookingType === bookingType && e.bookingId === paymentBookingId)) {
          continue;
        }
        
        // Convert amount to number if needed
        let amount = 0;
        if (typeof payment.amount === 'number') {
          amount = payment.amount;
        } else if (typeof payment.amount === 'string') {
          amount = parseFloat(payment.amount) || 0;
        }
        
        // Add as a general expense
        expenses.push({
          id: `payment-${payment.id}`,
          title: payment.description || `Payment: #${payment.id}`,
          category: this.getCategoryFromPaymentDescription(payment.description || undefined),
          amount: amount,
          date: payment.createdAt?.toISOString() || new Date().toISOString(),
          location: 'Online',
          paymentMethod: payment.paymentMethod || 'Credit Card',
          status: this.mapPaymentStatus(payment.status),
          receiptUrl: payment.receiptUrl || undefined,
          bookingType: bookingType,
          bookingId: paymentBookingId
        });
      }
      
      return expenses;
    } catch (error) {
      console.error('Error fetching user expenses:', error);
      return [];
    }
  }

  /**
   * Get spending summary by category
   */
  getSpendingSummaryByCategory(expenses: Expense[]): Record<string, number> {
    const categories = {
      accommodation: 0,
      transportation: 0,
      food: 0,
      activities: 0,
      other: 0
    };
    
    expenses.forEach(expense => {
      categories[expense.category] += expense.amount;
    });
    
    return categories;
  }

  /**
   * Get spending summary by date range (daily, weekly, monthly)
   */
  getSpendingSummaryByDateRange(
    expenses: Expense[],
    timeframe: 'daily' | 'weekly' | 'monthly'
  ): Array<{ date: string, amount: number }> {
    const sortedExpenses = [...expenses].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    if (timeframe === 'daily') {
      // Group by day
      const dailyData: {[key: string]: number} = {};
      sortedExpenses.forEach(expense => {
        const date = new Date(expense.date).toISOString().split('T')[0];
        dailyData[date] = (dailyData[date] || 0) + expense.amount;
      });
      
      return Object.entries(dailyData).map(([date, amount]) => ({ date, amount }));
    } else if (timeframe === 'weekly') {
      // Group by week
      const weeklyData: {[key: string]: number} = {};
      sortedExpenses.forEach(expense => {
        const date = new Date(expense.date);
        const weekNumber = this.getWeekNumber(date);
        const weekLabel = `Week ${weekNumber}`;
        weeklyData[weekLabel] = (weeklyData[weekLabel] || 0) + expense.amount;
      });
      
      return Object.entries(weeklyData).map(([date, amount]) => ({ date, amount }));
    } else {
      // Group by month
      const monthlyData: {[key: string]: number} = {};
      sortedExpenses.forEach(expense => {
        const date = new Date(expense.date);
        const monthLabel = date.toLocaleString('default', { month: 'short' });
        monthlyData[monthLabel] = (monthlyData[monthLabel] || 0) + expense.amount;
      });
      
      return Object.entries(monthlyData).map(([date, amount]) => ({ date, amount }));
    }
  }

  /**
   * Helper method to get week number from date
   */
  private getWeekNumber(d: Date): number {
    const date = new Date(d.getTime());
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
    const week1 = new Date(date.getFullYear(), 0, 4);
    return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
  }

  /**
   * Maps a payment status from the database to a valid Expense status
   */
  private mapPaymentStatus(status: string | null | undefined): 'completed' | 'pending' | 'refunded' {
    if (!status) return 'pending';
    
    const normalizedStatus = status.toLowerCase();
    
    if (normalizedStatus === 'completed' || normalizedStatus === 'success' || normalizedStatus === 'succeeded') {
      return 'completed';
    }
    
    if (normalizedStatus === 'refunded' || normalizedStatus === 'refund' || normalizedStatus === 'canceled' || normalizedStatus === 'cancelled') {
      return 'refunded';
    }
    
    return 'pending';
  }
  
  /**
   * Maps a ride status to a valid Expense status
   */
  private mapRideStatus(status: string): 'completed' | 'pending' | 'refunded' {
    const normalizedStatus = status.toLowerCase();
    
    if (normalizedStatus === 'completed' || normalizedStatus === 'in_progress') {
      return 'completed';
    }
    
    if (normalizedStatus === 'cancelled' || normalizedStatus === 'canceled') {
      return 'refunded';
    }
    
    return 'pending';
  }

  /**
   * Helper method to determine expense category from payment description
   */
  private getCategoryFromPaymentDescription(description?: string | null): 'accommodation' | 'transportation' | 'food' | 'activities' | 'other' {
    if (!description) return 'other';
    
    const lowerDesc = description.toLowerCase();
    
    if (lowerDesc.includes('hotel') || lowerDesc.includes('accommodation') || lowerDesc.includes('lodging') || lowerDesc.includes('stay')) {
      return 'accommodation';
    }
    
    if (lowerDesc.includes('flight') || lowerDesc.includes('airline') || lowerDesc.includes('ride') || 
        lowerDesc.includes('taxi') || lowerDesc.includes('transport') || lowerDesc.includes('train') || 
        lowerDesc.includes('bus') || lowerDesc.includes('travel')) {
      return 'transportation';
    }
    
    if (lowerDesc.includes('food') || lowerDesc.includes('restaurant') || lowerDesc.includes('dining') || 
        lowerDesc.includes('meal') || lowerDesc.includes('cafe') || lowerDesc.includes('breakfast') || 
        lowerDesc.includes('lunch') || lowerDesc.includes('dinner')) {
      return 'food';
    }
    
    if (lowerDesc.includes('tour') || lowerDesc.includes('activity') || lowerDesc.includes('ticket') || 
        lowerDesc.includes('attraction') || lowerDesc.includes('museum') || lowerDesc.includes('park') || 
        lowerDesc.includes('show') || lowerDesc.includes('event')) {
      return 'activities';
    }
    
    return 'other';
  }
}

// Export a singleton instance
export const expenseService = new ExpenseService();