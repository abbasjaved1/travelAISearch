import axios from 'axios';

interface IrctcFlightSearchParams {
  source: string;
  destination: string;
  date: string; // YYYY-MM-DD format
  travellers?: number;
  travelClass?: string; // E for Economy, B for Business, etc.
}

interface IrctcFlightData {
  flightNumber: string;
  airline: {
    name: string;
    code: string;
    logo?: string;
  };
  departure: {
    airport: string;
    city: string;
    code: string;
    terminal: string;
    time: string; // ISO date string
  };
  arrival: {
    airport: string;
    city: string;
    code: string;
    terminal: string;
    time: string; // ISO date string
  };
  duration: string; // Format: "2h 30m"
  stops: number;
  price: {
    amount: number;
    currency: string;
  };
  seatsAvailable: number;
  refundable: boolean;
  cabinClass: string;
  aircraft?: string;
}

export class IrctcAirService {
  private baseUrl: string;
  
  constructor() {
    // Using the correct endpoint for IRCTC Air API (currently a proxy to avoid CORS issues)
    this.baseUrl = process.env.IRCTC_AIR_API_URL || 'https://irctc-air-proxy.fly.dev/api/v1';
    console.log('IRCTC Air API service initialized with baseUrl:', this.baseUrl);
  }

  /**
   * Search for flights using IRCTC Air integration
   */
  async searchFlights(params: IrctcFlightSearchParams): Promise<IrctcFlightData[]> {
    try {
      console.log('Searching IRCTC flights with params:', params);
      
      // Check if we have the IRCTC API key for authentication
      const apiKey = process.env.IRCTC_API_KEY;
      
      if (!apiKey) {
        console.warn('No IRCTC_API_KEY found in environment variables');
        return [];
      }
      
      // If we have an API key, attempt to fetch real flight data from the API
      console.log(`Making request to ${this.baseUrl}/flights/search`);
      const response = await axios.get(`${this.baseUrl}/flights/search`, {
        params: {
          source: params.source,
          destination: params.destination,
          date: params.date,
          adults: params.travellers || 1,
          class: params.travelClass || 'E'
        },
        headers: {
          'X-API-Key': apiKey,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        timeout: 10000 // 10 second timeout
      });
      
      if (response.status === 200 && response.data && Array.isArray(response.data.flights)) {
        console.log(`Retrieved ${response.data.flights.length} actual flights from IRCTC Air service`);
        
        // Map the API response to our internal format
        const mappedFlights = response.data.flights.map((flight: any) => this.mapApiResponseToInternalFormat(flight));
        return mappedFlights;
      } else {
        console.warn('IRCTC Air API response format not as expected:', response.data);
        throw new Error('Unexpected API response format');
      }
    } catch (error: any) {
      console.error('IRCTC Air flight search error:', error.message);
      
      if (axios.isAxiosError(error)) {
        console.error('IRCTC Air API request failed:', {
          status: error.response?.status,
          statusText: error.response?.statusText,
          data: error.response?.data
        });
      }
      
      // Return empty array on error
      return [];
    }
  }
  
  /**
   * Maps the actual API response to our internal IrctcFlightData format
   */
  private mapApiResponseToInternalFormat(apiFlightData: any): IrctcFlightData {
    // This would be implemented based on the actual API response format
    return {
      flightNumber: apiFlightData.flightNumber || apiFlightData.flight_number || 'Unknown',
      airline: {
        name: apiFlightData.airline?.name || apiFlightData.airline_name || 'Unknown Airline',
        code: apiFlightData.airline?.code || apiFlightData.airline_code || 'XX',
        logo: apiFlightData.airline?.logo || apiFlightData.airline_logo
      },
      departure: {
        airport: apiFlightData.departure?.airport || apiFlightData.departure_airport || 'Unknown Airport',
        city: apiFlightData.departure?.city || apiFlightData.departure_city || 'Unknown City',
        code: apiFlightData.departure?.code || apiFlightData.departure_code || 'XXX',
        terminal: apiFlightData.departure?.terminal || apiFlightData.departure_terminal || 'X',
        time: apiFlightData.departure?.time || apiFlightData.departure_time || new Date().toISOString()
      },
      arrival: {
        airport: apiFlightData.arrival?.airport || apiFlightData.arrival_airport || 'Unknown Airport',
        city: apiFlightData.arrival?.city || apiFlightData.arrival_city || 'Unknown City',
        code: apiFlightData.arrival?.code || apiFlightData.arrival_code || 'XXX',
        terminal: apiFlightData.arrival?.terminal || apiFlightData.arrival_terminal || 'X',
        time: apiFlightData.arrival?.time || apiFlightData.arrival_time || new Date().toISOString()
      },
      duration: apiFlightData.duration || '0h 0m',
      stops: apiFlightData.stops || 0,
      price: {
        amount: apiFlightData.price?.amount || apiFlightData.fare || 0,
        currency: apiFlightData.price?.currency || apiFlightData.currency || 'INR'
      },
      seatsAvailable: apiFlightData.seatsAvailable || apiFlightData.seats_available || 0,
      refundable: apiFlightData.refundable || false,
      cabinClass: apiFlightData.cabinClass || apiFlightData.cabin_class || 'E',
      aircraft: apiFlightData.aircraft || apiFlightData.aircraft_type
    };
  }

  /**
   * Transform flight data from IRCTC format to our application format
   * This is where we would normally parse the response from the IRCTC API
   */
  private transformIrctcFlightData(params: IrctcFlightSearchParams): IrctcFlightData[] {
    // In a real implementation, we would fetch data from IRCTC Air API
    // and transform it to match our application's format
    // For this demonstration, we'll generate realistic flight data based on the search params
    
    // Common Indian airlines
    const airlines = [
      { name: 'Air India', code: 'AI' },
      { name: 'IndiGo', code: '6E' },
      { name: 'SpiceJet', code: 'SG' },
      { name: 'Vistara', code: 'UK' },
      { name: 'AirAsia India', code: 'I5' },
      { name: 'Air India Express', code: 'IX' }
    ];
    
    // Create a deterministic but varying set of flights based on the search params
    const sourceCode = params.source;
    const destCode = params.destination;
    const dateObj = new Date(params.date);
    
    // Number of flights to generate (based on route popularity)
    const popularRoutes = ['DEL-BOM', 'BOM-DEL', 'DEL-BLR', 'BLR-DEL', 'BOM-BLR', 'BLR-BOM'];
    const currentRoute = `${sourceCode}-${destCode}`;
    const flightCount = popularRoutes.includes(currentRoute) ? 8 : 5;
    
    const flights: IrctcFlightData[] = [];
    
    for (let i = 0; i < flightCount; i++) {
      // Deterministic but varying flight generation
      const airline = airlines[i % airlines.length];
      
      // Create realistic departure time starting from 6 AM with ~2 hour gaps
      const departureDate = new Date(dateObj);
      departureDate.setHours(6 + (i * 2), (i * 13) % 60, 0);
      
      // Flight duration between 1.5 to 3 hours depending on route
      const durationMinutes = 90 + (Math.abs(sourceCode.charCodeAt(0) - destCode.charCodeAt(0)) * 10);
      const durationHours = Math.floor(durationMinutes / 60);
      const remainingMinutes = durationMinutes % 60;
      
      // Calculate arrival time
      const arrivalDate = new Date(departureDate);
      arrivalDate.setMinutes(arrivalDate.getMinutes() + durationMinutes);
      
      // Calculate price based on several realistic factors
      // Base price depends on route
      let basePrice = 3000;
      if (popularRoutes.includes(currentRoute)) {
        basePrice = 3500;
      }
      
      // Price varies by airline
      const airlineMultiplier = 0.9 + (airlines.indexOf(airline) * 0.1);
      
      // Price varies by time of day (early morning and late night flights are cheaper)
      const hourOfDay = departureDate.getHours();
      const timeMultiplier = (hourOfDay >= 8 && hourOfDay <= 20) ? 1.1 : 0.9;
      
      // Price varies by day of week (weekends are more expensive)
      const dayOfWeek = departureDate.getDay();
      const dayMultiplier = (dayOfWeek === 0 || dayOfWeek === 6) ? 1.2 : 1.0;
      
      // Price varies by how far in advance booking is made
      const daysUntilFlight = Math.max(1, Math.floor((dateObj.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)));
      const advanceMultiplier = daysUntilFlight > 30 ? 0.8 : daysUntilFlight > 14 ? 0.9 : daysUntilFlight > 7 ? 1.0 : 1.3;
      
      // Calculate final price with some randomness
      const finalPrice = Math.round(basePrice * airlineMultiplier * timeMultiplier * dayMultiplier * advanceMultiplier);
      
      // Generate flight number
      const flightNumber = `${airline.code}${100 + ((sourceCode.charCodeAt(0) + destCode.charCodeAt(0)) % 900)}`;
      
      // Create flight data
      flights.push({
        flightNumber,
        airline: {
          name: airline.name,
          code: airline.code,
        },
        departure: {
          airport: this.getAirportName(sourceCode),
          city: this.getCityName(sourceCode),
          code: sourceCode,
          terminal: `T${1 + (i % 3)}`,
          time: departureDate.toISOString(),
        },
        arrival: {
          airport: this.getAirportName(destCode),
          city: this.getCityName(destCode),
          code: destCode,
          terminal: `T${1 + ((i + 1) % 3)}`,
          time: arrivalDate.toISOString(),
        },
        duration: `${durationHours}h ${remainingMinutes}m`,
        stops: i % 4 === 3 ? 1 : 0, // Most flights direct, some with 1 stop
        price: {
          amount: finalPrice,
          currency: 'INR',
        },
        seatsAvailable: 10 + (i * 7),
        refundable: i % 3 !== 0, // Some flights non-refundable
        cabinClass: params.travelClass || 'E',
        aircraft: this.getAircraftType(airline.code, i),
      });
    }
    
    // Sort by departure time
    flights.sort((a, b) => new Date(a.departure.time).getTime() - new Date(b.departure.time).getTime());
    
    return flights;
  }
  
  /**
   * Get airport name for IATA code
   */
  private getAirportName(code: string): string {
    const airports: Record<string, string> = {
      'DEL': 'Indira Gandhi International Airport',
      'BOM': 'Chhatrapati Shivaji Maharaj International Airport',
      'BLR': 'Kempegowda International Airport',
      'MAA': 'Chennai International Airport',
      'HYD': 'Rajiv Gandhi International Airport',
      'CCU': 'Netaji Subhas Chandra Bose International Airport',
      'SFO': 'San Francisco International Airport',
      'LAX': 'Los Angeles International Airport',
      'JFK': 'John F. Kennedy International Airport',
      'LHR': 'Heathrow Airport',
      'DXB': 'Dubai International Airport'
    };
    
    return airports[code] || `${code} Airport`;
  }
  
  /**
   * Get city name for IATA code
   */
  private getCityName(code: string): string {
    const cities: Record<string, string> = {
      'DEL': 'New Delhi',
      'BOM': 'Mumbai',
      'BLR': 'Bengaluru',
      'MAA': 'Chennai',
      'HYD': 'Hyderabad',
      'CCU': 'Kolkata',
      'SFO': 'San Francisco',
      'LAX': 'Los Angeles',
      'JFK': 'New York',
      'LHR': 'London',
      'DXB': 'Dubai'
    };
    
    return cities[code] || code;
  }
  
  /**
   * Get aircraft type based on airline and index
   */
  private getAircraftType(airlineCode: string, index: number): string {
    const aircraftTypes = [
      'Airbus A320',
      'Boeing 737-800',
      'Airbus A321',
      'Boeing 777-300ER',
      'Boeing 787-9 Dreamliner'
    ];
    
    return aircraftTypes[index % aircraftTypes.length];
  }
  
  /**
   * Convert IRCTC flight data to our application's format
   * This would be used to transform the actual API response in production
   */
  transformToAppFormat(irctcFlights: IrctcFlightData[]): any[] {
    return irctcFlights.map(flight => {
      // Base flight object
      return {
        id: `${flight.airline.code}-${flight.flightNumber}-${new Date(flight.departure.time).toISOString().split('T')[0]}`,
        airline: flight.airline.name,
        flightNumber: flight.flightNumber,
        departure: {
          airport: flight.departure.airport,
          code: flight.departure.code,
          terminal: flight.departure.terminal,
          gate: 'TBA',
          time: new Date(flight.departure.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        },
        arrival: {
          airport: flight.arrival.airport,
          code: flight.arrival.code,
          terminal: flight.arrival.terminal,
          gate: 'TBA',
          time: new Date(flight.arrival.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        },
        duration: flight.duration,
        price: flight.price.amount,
        availableSeats: flight.seatsAvailable,
        class: flight.cabinClass === 'E' ? 'Economy' : flight.cabinClass === 'B' ? 'Business' : 'First',
        stops: flight.stops.toString(),
        amenities: [
          { name: 'Wi-Fi', included: Math.random() > 0.3 },
          { name: 'Power Outlet', included: Math.random() > 0.4 },
          { name: 'Entertainment', included: Math.random() > 0.5 },
          { name: 'Meal Service', included: Math.random() > 0.2 }
        ],
        flight_status: 'scheduled',
        status_color: 'green',
        delay_minutes: 0,
        aircraft: flight.aircraft
      };
    });
  }
}

export const irctcAirService = new IrctcAirService();