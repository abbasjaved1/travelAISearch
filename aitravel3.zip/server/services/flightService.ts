import axios from 'axios';

const AVIATION_STACK_API_URL = 'https://api.aviationstack.com/v1';

interface FlightSearchParams {
  flight_status?: string;
  dep_iata?: string;
  arr_iata?: string;
  flight_date?: string;
  airline_name?: string;
}

interface FlightData {
  flight: {
    iata: string;
    icao: string;
  };
  departure: {
    airport: string;
    iata: string;
    icao: string;
    terminal: string;
    gate: string;
    scheduled: string;
    estimated: string;
    actual: string | null;
  };
  arrival: {
    airport: string;
    iata: string;
    icao: string;
    terminal: string;
    gate: string;
    scheduled: string;
    estimated: string;
    actual: string | null;
  };
  airline: {
    name: string;
    iata: string;
    icao: string;
  };
  flight_status: string;
  status_color?: string;
  delay_minutes?: number;
  price?: number;
}

export class FlightService {
  private apiKey: string | null;
  private isDevelopment: boolean;

  constructor() {
    this.apiKey = process.env.AVIATION_API_KEY || null;
    this.isDevelopment = process.env.NODE_ENV === 'development';

    if (!this.apiKey) {
      console.warn('Aviation Stack API key is not configured. Real-time flight data may be limited.');
    } else {
      console.log('Aviation API client initialized successfully');
    }
  }

  // No mock data generation - only using real flight API data

  async searchFlights(params: FlightSearchParams): Promise<FlightData[]> {
    try {
      // If API key is missing, throw error
      if (!this.apiKey) {
        throw new Error('Aviation Stack API key is not configured');
      }

      console.log('Searching flights with params:', params);
      this.validateSearchParams(params);

      if (params.flight_date) {
        params.flight_date = this.formatDate(params.flight_date);
      }

      const searchParams = {
        access_key: this.apiKey,
        limit: 10,
        ...params
      };

      console.log('Aviation API URL:', `${AVIATION_STACK_API_URL}/flights`);
      console.log('Aviation API Key (first 3 chars):', this.apiKey ? this.apiKey.substring(0, 3) + '...' : 'none');
      
      const response = await axios.get(`${AVIATION_STACK_API_URL}/flights`, {
        params: searchParams,
        timeout: 10000
      });

      console.log('Aviation API response status:', response.status);
      console.log('Aviation API response type:', typeof response.data);
      console.log('Aviation API response has data array?', !!response.data?.data && Array.isArray(response.data.data));
      
      if (!response.data?.data || !Array.isArray(response.data.data)) {
        console.warn('Invalid API response from Aviation Stack API');
        return [];
      }

      return response.data.data
        .filter((flight: any) => flight?.departure && flight?.arrival)
        .map((flight: any) => this.transformFlightData(flight));

    } catch (error: any) {
      console.error('Flight search error:', error.message);
      if (error.response) {
        console.error('Aviation API error details:', {
          status: error.response.status,
          statusText: error.response.statusText,
          data: error.response.data
        });
      }
      // Return empty array on error
      return [];
    }
  }

  private formatDate(date: string): string {
    return new Date(date).toISOString().split('T')[0];
  }

  private validateSearchParams(params: FlightSearchParams): void {
    if (!params.dep_iata && !params.arr_iata && !params.flight_date) {
      throw new Error('At least one search parameter is required');
    }

    if (params.dep_iata && params.dep_iata.length !== 3) {
      throw new Error('Invalid departure airport code');
    }

    if (params.arr_iata && params.arr_iata.length !== 3) {
      throw new Error('Invalid arrival airport code');
    }
  }

  private transformFlightData(rawFlight: any): FlightData {
    return {
      flight: {
        iata: rawFlight.flight?.iata || rawFlight.flight?.number || 'N/A',
        icao: rawFlight.flight?.icao || 'N/A'
      },
      departure: {
        airport: rawFlight.departure?.airport || 'N/A',
        iata: rawFlight.departure?.iata || 'N/A',
        icao: rawFlight.departure?.icao || 'N/A',
        terminal: rawFlight.departure?.terminal || 'N/A',
        gate: rawFlight.departure?.gate || 'N/A',
        scheduled: rawFlight.departure?.scheduled || new Date().toISOString(),
        estimated: rawFlight.departure?.estimated || rawFlight.departure?.scheduled || new Date().toISOString(),
        actual: rawFlight.departure?.actual || null
      },
      arrival: {
        airport: rawFlight.arrival?.airport || 'N/A',
        iata: rawFlight.arrival?.iata || 'N/A',
        icao: rawFlight.arrival?.icao || 'N/A',
        terminal: rawFlight.arrival?.terminal || 'N/A',
        gate: rawFlight.arrival?.gate || 'N/A',
        scheduled: rawFlight.arrival?.scheduled || new Date().toISOString(),
        estimated: rawFlight.arrival?.estimated || rawFlight.arrival?.scheduled || new Date().toISOString(),
        actual: rawFlight.arrival?.actual || null
      },
      airline: {
        name: rawFlight.airline?.name || 'N/A',
        iata: rawFlight.airline?.iata || 'N/A',
        icao: rawFlight.airline?.icao || 'N/A'
      },
      flight_status: rawFlight.flight_status || 'unknown',
      // The Aviation Stack API doesn't include price data
      // Price will need to be obtained from another API
      price: undefined
    };
  }

  async getFlightByNumber(flightNumber: string): Promise<FlightData | null> {
    try {
      // Check if API key is available
      if (!this.apiKey) {
        throw new Error('Aviation Stack API key is not configured');
      }

      const response = await axios.get(`${AVIATION_STACK_API_URL}/flights`, {
        params: {
          access_key: this.apiKey,
          flight_iata: flightNumber.toUpperCase()
        },
        timeout: 10000
      });

      if (!response.data?.data?.[0]) {
        console.log('No flight found with number:', flightNumber);
        return null;
      }

      return this.transformFlightData(response.data.data[0]);
    } catch (error: any) {
      console.error('Flight lookup error:', error.message);
      return null;
    }
  }
}

export const flightService = new FlightService();