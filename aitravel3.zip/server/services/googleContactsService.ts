import axios from 'axios';
import { storage } from '../storage';

// Types for Google Contacts
interface GoogleContact {
  resourceName: string;
  etag: string;
  names?: [{ displayName: string }];
  emailAddresses?: [{ value: string }];
  phoneNumbers?: [{ value: string }];
  photos?: [{ url: string }];
}

interface GoogleContactsResponse {
  connections: GoogleContact[];
  nextPageToken?: string;
  totalPeople?: number;
  nextSyncToken?: string;
}

interface ContactEntry {
  id: string;
  name: string;
  email: string;
  phoneNumber?: string;
  photoUrl?: string;
}

// Store Google tokens for each user
interface UserGoogleTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: Date;
}

// In-memory token cache
const userTokensCache = new Map<number, UserGoogleTokens>();

// Store the contact list for each user
const userContactsCache = new Map<number, Map<string, ContactEntry>>();

// Check if a user is in another user's contacts
export async function isInGmailContacts(
  userId: number, 
  targetUserId: number
): Promise<boolean> {
  try {
    // Get the target user's email
    const targetUser = await storage.getUser(targetUserId);
    if (!targetUser || !targetUser.email) {
      console.log(`isInGmailContacts: Target user ${targetUserId} not found or has no email`);
      return false;
    }

    // Get user's contacts
    const userContacts = await getUserContacts(userId);
    if (!userContacts) {
      console.log(`isInGmailContacts: No contacts available for user ${userId}`);
      return false;
    }

    // Check if target user's email is in contacts
    const targetEmail = targetUser.email.toLowerCase();
    for (const contact of userContacts.values()) {
      if (contact.email && contact.email.toLowerCase() === targetEmail) {
        return true;
      }
    }

    return false;
  } catch (error) {
    console.error('Error checking Gmail contacts:', error);
    return false;
  }
}

// Get Google Contacts for a user
export async function getUserContacts(userId: number): Promise<Map<string, ContactEntry> | null> {
  try {
    // Check cache first
    if (userContactsCache.has(userId)) {
      return userContactsCache.get(userId)!;
    }

    // Get user tokens
    const tokens = await getUserTokens(userId);
    if (!tokens) {
      console.log(`No Google tokens available for user ${userId}`);
      return null;
    }

    // Fetch contacts from People API
    const contacts = await fetchGoogleContacts(tokens.accessToken);
    if (!contacts || contacts.length === 0) {
      console.log(`No contacts found for user ${userId}`);
      return null;
    }

    // Process and cache contacts
    const contactsMap = new Map<string, ContactEntry>();
    for (const contact of contacts) {
      if (contact.emailAddresses && contact.emailAddresses.length > 0) {
        const email = contact.emailAddresses[0].value;
        const name = contact.names && contact.names.length > 0 
          ? contact.names[0].displayName 
          : email.split('@')[0];
        
        const phoneNumber = contact.phoneNumbers && contact.phoneNumbers.length > 0
          ? contact.phoneNumbers[0].value
          : undefined;
          
        const photoUrl = contact.photos && contact.photos.length > 0
          ? contact.photos[0].url
          : undefined;
          
        contactsMap.set(email, {
          id: contact.resourceName,
          name,
          email,
          phoneNumber,
          photoUrl
        });
      }
    }

    // Cache the contacts
    userContactsCache.set(userId, contactsMap);
    
    return contactsMap;
  } catch (error) {
    console.error('Error getting user contacts:', error);
    return null;
  }
}

// Fetch contacts from Google People API
async function fetchGoogleContacts(accessToken: string): Promise<GoogleContact[]> {
  try {
    const response = await axios.get(
      'https://people.googleapis.com/v1/people/me/connections',
      {
        params: {
          personFields: 'names,emailAddresses,phoneNumbers,photos',
          pageSize: 1000
        },
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      }
    );

    const data = response.data as GoogleContactsResponse;
    return data.connections || [];
  } catch (error) {
    console.error('Error fetching Google contacts:', error);
    return [];
  }
}

// Get user's tokens (either from cache or session)
async function getUserTokens(userId: number): Promise<UserGoogleTokens | null> {
  // Check cache first
  if (userTokensCache.has(userId)) {
    const tokens = userTokensCache.get(userId)!;
    
    // If tokens are expired, we'd need to refresh them
    // This is simplified - in a real app you'd use refresh token to get new access token
    if (tokens.expiresAt > new Date()) {
      return tokens;
    }
  }

  // Tokens not in cache or expired - we'd need to get them from storage
  // This is where we'd normally use the refresh token to get a new access token
  // For this implementation, we'll just return null
  // In a real implementation, you would integrate with your session/user management
  
  return null;
}

// Store user's Google tokens
export function storeUserTokens(
  userId: number,
  accessToken: string,
  refreshToken: string,
  expiresIn: number = 3600
): void {
  // Calculate expiration date
  const expiresAt = new Date();
  expiresAt.setSeconds(expiresAt.getSeconds() + expiresIn);
  
  // Store in cache
  userTokensCache.set(userId, {
    accessToken,
    refreshToken,
    expiresAt
  });
}

// Clear cached contacts for a user
export function clearUserContactsCache(userId: number): void {
  userContactsCache.delete(userId);
}

// Get emails of all contacts for a user
export async function getContactEmails(userId: number): Promise<string[]> {
  const contacts = await getUserContacts(userId);
  if (!contacts) return [];
  
  // Convert Map to Array first to avoid TypeScript iteration issues
  const contactArray = Array.from(contacts.values());
  return contactArray.map(contact => contact.email);
}