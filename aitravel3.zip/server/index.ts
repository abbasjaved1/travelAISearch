import 'dotenv/config';
import express from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { getDatabaseStatus } from "./db";
import { setupAuth } from "./auth";
import { setupWebSocket } from "./websocket";
import cors from "cors";
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Function to ensure build directories and loading pages exist

// Add global error handlers
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  // Don't exit process
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Don't exit process
});

function setupBuildDirectories() {
  try {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const distPath = path.resolve(__dirname, "../dist/public");

    // Create build directory if it doesn't exist
    if (!fs.existsSync(distPath)) {
      console.log(`Creating missing build directory: ${distPath}`);
      fs.mkdirSync(distPath, { recursive: true });

      // Create minimal index.html fallback that redirects immediately
      const indexPath = path.join(distPath, "index.html");
      if (!fs.existsSync(indexPath)) {
        console.log("Creating minimal index redirect page");
        fs.writeFileSync(indexPath, `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Travel Globe</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      background: #f5f7fa;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    div {
      text-align: center;
      padding: 2rem;
    }
  </style>
  <script>
    // Immediately redirect to the app
    window.location.href = "/";
  </script>
</head>
<body>
  <div>
    <h1>Redirecting to AI Travel Globe...</h1>
  </div>
</body>
</html>
        `);
      }

      // Create loaded marker file
      const markerPath = path.join(distPath, "loaded-index.html");
      if (!fs.existsSync(markerPath)) {
        console.log("Creating loaded marker file");
        fs.writeFileSync(markerPath, `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AI Travel Globe - Fully Loaded</title>
</head>
<body>
  <h1>AI Travel Globe - Fully Loaded</h1>
  <script>window.location.href = '/';</script>
</body>
</html>
        `);
      }
    }
  } catch (error) {
    console.error("Error setting up build directories:", error);
    console.log("Application will continue with fallback mechanism");
  }
}

// Try to setup directories early
try {
  setupBuildDirectories();
} catch (err) {
  console.log("Failed initial directory setup, will retry later:", err);
}

const app = express();

// Trust proxies for better custom domain support
app.set("trust proxy", true);
app.enable('trust proxy');
app.set('x-powered-by', false); // Security: Hide Express

// Handle potential deployment issues by setting appropriate headers
app.use((req, res, next) => {
  // Get hostname for dynamic CSP
  const hostname = req.hostname || '';

  // Log hostname for debugging
  console.log(`Request hostname: ${hostname}`);

  // Disable CSP in production to test if that's causing the 502 issue
  if (process.env.NODE_ENV === 'production' || process.env.REPL_SLUG) {
    // In production, skip CSP setting for now to troubleshoot 502 errors
    next();
    return;
  }

  // During development, set a more permissive CSP
  // res.setHeader(
  //   'Content-Security-Policy',
  //   [
  //     "default-src 'self'",
  //     "connect-src 'self' ws: wss: * https://*.replit.app https://*.replit.dev https://*.repl.co https://*.aitravelglobe.com https://*.stripe.com https://*.openstreetmap.org",
  //     "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.stripe.com",
  //     "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  //     "font-src 'self' https://fonts.gstatic.com",
  //     "img-src 'self' data: https: https://*.stripe.com https://*.openstreetmap.org",
  //     "frame-src 'self' https://*.stripe.com",
  //     "frame-ancestors 'self'",
  //     "base-uri 'self'",
  //     "worker-src 'self' blob:",
  //     "media-src 'self' blob:",
  //     "upgrade-insecure-requests"
  //   ].join('; ')
  // );
   next();
});

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Setup CORS with deployment domain support
app.use(cors({
  origin: (origin, callback) => {
    const allowedOrigins = [
      'https://user-access-manager-ltest-1-abbasjaved11.replit.app',
      process.env.NODE_ENV === 'development' ? 'http://localhost:5000' : null
    ].filter(Boolean);

    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(null, true); // Allow all origins in development
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-User-Id', 'X-Username', 'X-Client-Version', 'X-Client-Type']
}));

// Add OPTIONS pre-flight handling for custom domains
app.options('*', cors());

// Add a direct response handler early in the pipeline for basic connectivity
app.get('/status', (req, res) => {
  res.status(200).send('ok');
});

// Add direct fallback handler for custom domains
app.get('/_replit-custom-domain-check', (req, res) => {
  res.status(200).send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Replit Custom Domain Verification</title>
    </head>
    <body>
      <h1>Custom Domain Connection Verified</h1>
      <p>Your custom domain is correctly connected to this Replit app.</p>
      <p>Server time: ${new Date().toISOString()}</p>
      <p>Hostname: ${req.hostname}</p>
    </body>
    </html>
  `);
});

// Simple request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    log(`${req.method} ${req.path} ${res.statusCode} ${duration}ms`);
  });
  next();
});

// Add health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

// Function to manually reset all test user passwords
async function resetAllTestPasswords() {
  try {
    console.log("Starting server initialization...");

    // Reset test user passwords
    console.log('Setting up auth with development mode:', true);

    // Create or update test users
    const testUsers = [
      { username: 'test123', password: 'test123', display_name: 'Test User 1', email: 'test@example.com' },
      { username: 'test456', password: 'test456', display_name: 'Test User 2', email: 'test456@example.com' }
    ];

    const { hashPassword } = await import('./auth');
    const { storage } = await import('./storage');

    for (const testUser of testUsers) {
      let user = await storage.getUserByUsername(testUser.username);

      if (user) {
        console.log(`Getting user by username: ${testUser.username} found`);
        console.log('Updating existing test user password');
        const hashedPassword = await hashPassword(testUser.password);
        await storage.updateUserPassword(user.id, hashedPassword);
        console.log(`Updated password for user: ${user.id}`);
        console.log('Test user password updated successfully');
      }
    }

    console.log("Authentication setup completed successfully");
  } catch (error) {
    console.error("Error resetting passwords:", error);
  }
}

// Initialize server
async function initializeServer() {
  try {
    // Check database connection first with better error handling
    log('Checking database connection...');
    try {
      const dbStatus = await getDatabaseStatus();
      if (!dbStatus.isConnected) {
        console.warn(`Database connection failed: ${dbStatus.error}`);
        console.warn('Continuing with InMemoryStorage as fallback. Data will not persist between restarts.');
      } else {
        log('Database connection successful');
      }
    } catch (dbError) {
      console.warn('Error checking database connection:', dbError);
      console.warn('Continuing with InMemoryStorage as fallback. Data will not persist between restarts.');
    }

    // Setup authentication
    log('Setting up authentication...');
    try {
      await setupAuth(app);
      log('Authentication setup complete');
    } catch (error) {
      console.error('Authentication setup error:', error);
      log('Continuing with limited authentication functionality');
    }

    // Reset test user passwords to ensure they work
    try {
      await resetAllTestPasswords();
    } catch (error) {
      console.error('Password reset error:', error);
    }

    // Register API routes
    log('Registering API routes...');
    const server = await registerRoutes(app);
    log('API routes registered successfully');

    // Add special diagnostic endpoints for custom domains
    app.get('/health', (req, res) => {
      res.status(200).json({
        status: 'ok',
        hostname: req.hostname,
        headers: req.headers,
        env: {
          NODE_ENV: process.env.NODE_ENV,
          REPL_SLUG: process.env.REPL_SLUG,
          REPL_OWNER: process.env.REPL_OWNER,
          PORT: process.env.PORT
        }
      });
    });

    // Add special diagnostic endpoint for troubleshooting custom domain 502 errors
    app.get('/aitravelglobe-status', (req, res) => {
      res.status(200).json({
        status: 'ok',
        message: 'AIT Travel Globe API is running',
        timestamp: new Date().toISOString(),
        hostname: req.hostname,
        headers: {
          host: req.headers.host,
          'x-forwarded-host': req.headers['x-forwarded-host'],
          'x-forwarded-proto': req.headers['x-forwarded-proto'],
          'x-forwarded-for': req.headers['x-forwarded-for']
        },
        environment: {
          NODE_ENV: process.env.NODE_ENV,
          REPL_SLUG: process.env.REPL_SLUG ? 'set' : 'not set',
          PORT: process.env.PORT
        }
      });
    });

    // Simple HTML status page for browser testing
    app.get('/aitravelglobe-check', (req, res) => {
      res.status(200).send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>AI Travel Globe - Status Check</title>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <style>
            body { font-family: system-ui, sans-serif; margin: 2rem; line-height: 1.5; text-align: center; }
            h1 { color: #0078d7; }
            .success { color: green; font-weight: bold; }
            .message { max-width: 600px; margin: 0 auto; }
            .details { background: #f5f5f5; padding: 1rem; border-radius: 5px; text-align: left; margin-top: 2rem; }
          </style>
        </head>
        <body>
          <div class="message">
            <h1>AI Travel Globe</h1>
            <p class="success">✓ Server is running correctly</p>
            <p>If you're seeing this page, the backend server is operational.</p>
            <p>This is a special diagnostic page for custom domain troubleshooting.</p>
            <div class="details">
              <h3>Server Information</h3>
              <p>Time: ${new Date().toISOString()}</p>
              <p>Hostname: ${req.hostname}</p>
              <p>Headers: ${JSON.stringify({
                host: req.headers.host,
                'x-forwarded-host': req.headers['x-forwarded-host'],
                'x-forwarded-proto': req.headers['x-forwarded-proto']
              }, null, 2)}</p>
            </div>
          </div>
        </body>
        </html>
      `);
    });

    // Add a direct path to redirect the loading route to the main app
    app.get('/loading', (req, res) => {
      console.log('Redirecting /loading to homepage');
      res.redirect('/');
    });

    // Configure and start the server
    const port = parseInt(process.env.PORT || '5000', 10);
    const host = '0.0.0.0'; // Explicitly bind to all network interfaces for public access
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const staticPath = path.resolve(__dirname, '../dist/public');

    console.log(`Starting server on port ${port}`);
    console.log('Starting server with configuration:', {
      port,
      host,
      env: process.env.NODE_ENV,
      staticPath
    });

    // Configure static file serving for production
    if (process.env.NODE_ENV === 'production') {
      const __filename = fileURLToPath(import.meta.url);
      const __dirname = dirname(__filename);
      const distPath = path.resolve(__dirname, '../dist');
      const publicPath = path.join(distPath, 'public');
      
      console.log('Serving static files with configuration:', {
        distPath,
        publicPath,
        exists: fs.existsSync(publicPath),
        indexExists: fs.existsSync(path.join(publicPath, 'index.html'))
      });
      
      // Copy index.html to the client directory to match serveStatic's expected path
      const clientPath = path.join(distPath, 'client');
      if (!fs.existsSync(clientPath)) {
        fs.mkdirSync(clientPath, { recursive: true });
      }
      
      if (fs.existsSync(path.join(publicPath, 'index.html'))) {
        try {
          fs.copyFileSync(
            path.join(publicPath, 'index.html'), 
            path.join(clientPath, 'index.html')
          );
          console.log('Successfully copied index.html to client directory');
        } catch (err) {
          console.error('Error copying index.html:', err);
        }
      }
      
      // Serve static files from public directory
      app.use(express.static(publicPath));
      
      // Now call serveStatic to handle the SPA fallback routes
      try {
        serveStatic(app);
        console.log('Static file serving configured successfully');
      } catch (error) {
        console.error('Error configuring static file serving:', error);
        
        // Fallback to direct configuration if serveStatic fails
        app.get('*', (req, res, next) => {
          if (req.path.startsWith('/api/') || req.path.startsWith('/socket.io/')) {
            return next();
          }
          
          const indexPath = path.join(publicPath, 'index.html');
          if (fs.existsSync(indexPath)) {
            res.sendFile(indexPath);
          } else {
            res.status(200).send(`
              <!DOCTYPE html>
              <html>
                <head>
                  <title>TravelAI</title>
                  <meta charset="UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <style>
                    body { font-family: system-ui; margin: 0; padding: 2rem; text-align: center; }
                    h1 { color: #4361ee; }
                  </style>
                </head>
                <body>
                  <h1>TravelAI</h1>
                  <p>Application is in maintenance mode. Please check back later.</p>
                </body>
              </html>
            `);
          }
        });
      }
    }

    // Add enhanced health check endpoint
    app.get(['/health', '/deployment-health'], (req, res) => {
      res.status(200).json({
        status: 'ok',
        message: 'Server is running',
        timestamp: new Date().toISOString(),
        hostname: req.hostname,
        environment: {
          NODE_ENV: process.env.NODE_ENV,
          PORT: port
        }
      });
    });

    // Log the environment setup
    console.log('Environment setup:', {
      NODE_ENV: process.env.NODE_ENV,
      PORT: port,
      REPL_SLUG: process.env.REPL_SLUG || 'not set',
      REPL_OWNER: process.env.REPL_OWNER || 'not set',
      isProduction: process.env.NODE_ENV === 'production' || !!process.env.REPL_SLUG
    });

    // Start the HTTP server after all configurations

    // Start the HTTP server with improved error handling
    const httpServer = server.listen(port, host, () => {
      console.log(`Server listening on http://${host}:${port}`);
      log(`Server running on ${host}:${port} in ${app.get("env")} mode`);
      console.log('Server startup complete');

      // Setup WebSocket server with better error handling
      log('Setting up WebSocket server...');
      try {
        setupWebSocket(server);
        log('WebSocket server setup complete');
      } catch (error) {
        console.error('Failed to setup WebSocket server:', error);
        log('Server continuing without WebSocket support');
      }

      // Setup frontend server with better environment detection and error handling
      log('Setting up frontend server...');

      // Use production mode when deployed, development mode during development
      const forceDevelopmentMode = process.env.NODE_ENV !== 'production';

      if (forceDevelopmentMode) {
        log('Running in development mode, setting up Vite...');
        setupVite(app, server).catch(error => {
          console.error('Failed to setup Vite:', error);
          log('Server continuing without Vite support');
        });
      } else {
        log('Running in production mode - static files already configured');
      }
      log('Frontend server setup complete');
    });

    // Add proper error handling for the server
    httpServer.on('error', (error: any) => {
      console.error('Server error:', error);

      if (error.code === 'EADDRINUSE') {
        console.error(`Port ${port} is already in use. Shutting down.`);
        process.exit(1);
      }
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
initializeServer();