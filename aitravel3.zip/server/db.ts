import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from 'ws';
import * as schema from "@shared/schema";

// Configure WebSocket for Neon
neonConfig.webSocketConstructor = ws;

// Function to get database URL or fallback
function getDatabaseUrl() {
  // Check for DATABASE_URL environment variable
  if (process.env.DATABASE_URL) {
    return process.env.DATABASE_URL;
  }
  
  // Check for individual PG* environment variables and construct the URL
  if (process.env.PGHOST && process.env.PGUSER && process.env.PGPASSWORD && process.env.PGDATABASE) {
    const url = `postgres://${process.env.PGUSER}:${process.env.PGPASSWORD}@${process.env.PGHOST}:${process.env.PGPORT || '5432'}/${process.env.PGDATABASE}`;
    console.log('Constructed database URL from PG* environment variables');
    return url;
  }
  
  // Return a mock URL that will cause the connection to fail gracefully
  console.log('No database configuration found, will fall back to InMemoryStorage');
  return 'postgres://user:password@localhost:5432/fallback_db';
}

// Configure pool with SSL and proper timeouts
export const pool = new Pool({
  connectionString: getDatabaseUrl(),
  ssl: {
    rejectUnauthorized: false // Required for Neon's SSL
  },
  max: 3, // Increased for better availability
  connectionTimeoutMillis: 5000, // Wait 5 seconds
  idleTimeoutMillis: 30000, // 30 seconds idle timeout
  maxUses: 7500, // Close connections after 7500 queries
  allowExitOnIdle: true,
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000
});

// Add connection error handler
pool.on('error', (err) => {
  console.error('Unexpected database error:', err);
  // Don't exit process, attempt recovery
});

export const db = drizzle(pool, { schema });

// Enhanced connection status check with retry logic
export const getDatabaseStatus = async () => {
  let retries = 3;
  let lastError = null;

  while (retries > 0) {
    let client;
    try {
      client = await pool.connect();
      const result = await client.query('SELECT 1');
      console.log('Database connection successful');
      return { 
        isConnected: true, 
        error: null,
        details: `Connected successfully: ${result.rowCount} row(s)` 
      };
    } catch (error: any) {
      console.error(`Database connection attempt failed (${retries} retries left):`, error);
      lastError = error;
      retries--;
      if (retries > 0) {
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second before retry
      }
    } finally {
      if (client) {
        client.release();
      }
    }
  }

  console.error('All database connection attempts failed:', lastError);
  return { 
    isConnected: false, 
    error: lastError?.message,
    details: lastError?.stack 
  };
};

// Initialize database connection with error handling
pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  // Log error but don't exit
  console.error('Database connection error, attempting to recover');
});

// Add connect event handler
pool.on('connect', () => {
  console.log('New database connection established');
});

// Add acquire event handler
pool.on('acquire', () => {
  console.log('Client acquired from pool');
});

// Add remove event handler
pool.on('remove', () => {
  console.log('Client removed from pool');
});