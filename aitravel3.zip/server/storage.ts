import { users, passengers, itineraries, rideHistory, rideTracking, type User, type InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import connectPgSimple from "connect-pg-simple";
import { pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PgSessionStore = connectPgSimple(session);

interface GuestUserParams {
  username: string;
  display_name: string;
  guest: boolean;
  preferences?: {
    theme?: string;
    currency?: string;
    language?: string;
  };
}

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  updateUserPassword(id: number, hashedPassword: string): Promise<void>;
  updateUserOTP(phone: string, otp: string, expiryTime: Date): Promise<void>;
  updateUserEmailOTP(email: string, otp: string, expiryTime: Date): Promise<void>;
  verifyUserPhone(phone: string): Promise<void>;
  verifyUserEmail(email: string): Promise<void>;
  sessionStore: session.Store;
  createGuestUser(params: GuestUserParams): Promise<User>;
}

class InMemoryStorage implements IStorage {
  private users: User[] = [];
  private nextId = 1;
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    console.log('InMemoryStorage initialized');
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<void> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }
    user.password = hashedPassword;
    console.log('Updated password for user:', id);
  }

  async createGuestUser(params: GuestUserParams): Promise<User> {
    console.log('Creating guest user with params:', params);

    // Check if guest user already exists
    const existingUser = await this.getUserByUsername(params.username);
    if (existingUser) {
      console.log('Returning existing guest user:', existingUser.id);
      return existingUser;
    }

    const guestUser: User = {
      id: this.nextId++,
      username: params.username,
      password: `guest_${Date.now()}`,
      phone_number: null,
      phone_verified: false,
      email: null,
      email_verified: false,
      otp: null,
      otp_expires: null,
      display_name: params.display_name || params.username,
      preferences: {
        preferredClass: "",
        budget: 1000, // Default budget for guest users
        cuisinePreferences: [],
        travelStyle: [],
        favoriteDestinations: [],
        accommodationPreferences: [],
        interests: [],
        transportPreferences: [],
        climatePreference: "",
        tripDurationPreference: "",
        ...params.preferences
      },
      google_id: null,
      avatar_url: null,
      last_location: null,
      last_active: null
    };

    this.users.push(guestUser);
    console.log('Guest user created:', { id: guestUser.id, username: guestUser.username });
    return guestUser;
  }

  async getUser(id: number): Promise<User | undefined> {
    const user = this.users.find(u => u.id === id);
    console.log('Getting user by ID:', id, user ? 'found' : 'not found');
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const user = this.users.find(u => u.username === username);
    console.log('Getting user by username:', username, user ? 'found' : 'not found');
    return user;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const user = this.users.find(u => u.phone_number === phone);
    console.log('Getting user by phone:', phone, user ? 'found' : 'not found');
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const user = this.users.find(u => u.email === email);
    console.log('Getting user by email:', email, user ? 'found' : 'not found');
    return user;
  }
  
  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const user = this.users.find(u => u.google_id === googleId);
    console.log('Getting user by Google ID:', googleId, user ? 'found' : 'not found');
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    console.log('Creating new user:', { username: insertUser.username });

    if (!insertUser.password) {
      throw new Error('Password is required');
    }

    const user: User = {
      id: this.nextId++,
      username: insertUser.username,
      password: insertUser.password,
      phone_number: insertUser.phone_number || null,
      phone_verified: insertUser.phone_verified || false,
      email: insertUser.email || null,
      email_verified: insertUser.email_verified || false,
      otp: null,
      otp_expires: null,
      preferences: insertUser.preferences || {
        preferredClass: "",
        budget: 5000,
        cuisinePreferences: [],
        travelStyle: [],
        favoriteDestinations: [],
        accommodationPreferences: [],
        interests: [],
        transportPreferences: [],
        climatePreference: "",
        tripDurationPreference: ""
      },
      google_id: insertUser.google_id || null,
      display_name: insertUser.display_name || insertUser.username,
      avatar_url: insertUser.avatar_url || null,
      last_location: null,
      last_active: null
    };

    this.users.push(user);
    console.log('User created:', { id: user.id, username: user.username });
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }

    const updatedUser: User = {
      ...user,
      ...updates,
      id: user.id,
      username: updates.username || user.username,
      password: updates.password || user.password,
      display_name: updates.display_name || user.display_name
    };

    const userIndex = this.users.findIndex(u => u.id === id);
    this.users[userIndex] = updatedUser;

    console.log('Updated user:', { id: updatedUser.id, username: updatedUser.username });
    return updatedUser;
  }

  async updateUserOTP(phone: string, otp: string, expiryTime: Date): Promise<void> {
    let user = await this.getUserByPhone(phone);

    if (!user) {
      console.log('Creating new user for OTP verification');
      user = await this.createUser({
        username: phone,
        password: `temp.${Date.now()}`,
        phone_number: phone,
        display_name: `User ${phone}`
      });
    }

    user.otp = otp;
    user.otp_expires = expiryTime;
    console.log('Updated OTP for user:', user.id);
  }

  async updateUserEmailOTP(email: string, otp: string, expiryTime: Date): Promise<void> {
    let user = await this.getUserByEmail(email);

    if (!user) {
      console.log('Creating new user for email OTP verification');
      user = await this.createUser({
        username: email,
        password: `temp.${Date.now()}`,
        email: email,
        display_name: `User ${email.split('@')[0]}`
      });
    }

    // Update both email_otp specific fields and regular OTP fields for backwards compatibility
    user.email_otp = otp;
    user.email_otp_expires = expiryTime;
    user.otp = otp;
    user.otp_expires = expiryTime;
    console.log('Updated email OTP for user:', user.id);
  }

  async verifyUserPhone(phone: string): Promise<void> {
    const user = await this.getUserByPhone(phone);
    if (user) {
      user.phone_verified = true;
      user.otp = null;
      user.otp_expires = null;
      console.log('Phone verified for user:', user.id);
    }
  }

  async verifyUserEmail(email: string): Promise<void> {
    const user = await this.getUserByEmail(email);
    if (user) {
      user.email_verified = true;
      user.otp = null;
      user.otp_expires = null;
      user.email_otp = null;
      user.email_otp_expires = null;
      console.log('Email verified for user:', user.id);
    }
  }
}

// Database-backed storage implementation
class PostgresStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    // Create a PostgreSQL-backed session store
    this.sessionStore = new PgSessionStore({
      pool,
      tableName: 'session', // The name of the table to store sessions
      createTableIfMissing: true,
      schemaName: 'public',
      pruneSessionInterval: 60 * 60 // 1 hour
    });
    console.log('PostgresStorage initialized');
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<void> {
    await db.update(users)
      .set({ password: hashedPassword })
      .where(eq(users.id, id));
    console.log('Updated password for user:', id);
  }

  async createGuestUser(params: GuestUserParams): Promise<User> {
    console.log('Creating guest user with params:', params);

    // Check if guest user already exists
    const existingUser = await this.getUserByUsername(params.username);
    if (existingUser) {
      console.log('Returning existing guest user:', existingUser.id);
      return existingUser;
    }

    // Prepare preferences with default values
    const preferences = {
      preferredClass: "",
      budget: 1000, // Default budget for guest users
      cuisinePreferences: [],
      travelStyle: [],
      favoriteDestinations: [],
      accommodationPreferences: [],
      interests: [],
      transportPreferences: [],
      climatePreference: "",
      tripDurationPreference: "",
      ...params.preferences
    };

    // Create new guest user
    const [guestUser] = await db.insert(users)
      .values({
        username: params.username,
        display_name: params.display_name || params.username,
        password: `guest_${Date.now()}`,
        preferences: preferences
      })
      .returning();

    console.log('Created new guest user:', guestUser.id);
    return guestUser;
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    console.log('Getting user by ID:', id, result.length ? 'found' : 'not found');
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    console.log('Getting user by username:', username, result.length ? 'found' : 'not found');
    return result[0];
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.phone_number, phone));
    console.log('Getting user by phone:', phone, result.length ? 'found' : 'not found');
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    console.log('Getting user by email:', email, result.length ? 'found' : 'not found');
    return result[0];
  }
  
  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.google_id, googleId));
    console.log('Getting user by Google ID:', googleId, result.length ? 'found' : 'not found');
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    console.log('Creating user:', insertUser.username);

    if (!insertUser.password) {
      throw new Error('Password is required');
    }

    // Check if username already exists
    const existingUser = await this.getUserByUsername(insertUser.username);
    if (existingUser) {
      throw new Error(`Username ${insertUser.username} is already taken`);
    }

    // Check if phone already exists (if provided)
    if (insertUser.phone_number) {
      const existingPhone = await this.getUserByPhone(insertUser.phone_number);
      if (existingPhone) {
        throw new Error(`Phone number ${insertUser.phone_number} is already registered`);
      }
    }

    // Check if email already exists (if provided)
    if (insertUser.email) {
      const existingEmail = await this.getUserByEmail(insertUser.email);
      if (existingEmail) {
        throw new Error(`Email ${insertUser.email} is already registered`);
      }
    }
    
    // Prepare default preferences if not provided
    const preferences = insertUser.preferences || {
      preferredClass: "",
      budget: 5000,
      cuisinePreferences: [],
      travelStyle: [],
      favoriteDestinations: [],
      accommodationPreferences: [],
      interests: [],
      transportPreferences: [],
      climatePreference: "",
      tripDurationPreference: ""
    };

    // Insert the user into the database
    const [user] = await db.insert(users)
      .values({
        username: insertUser.username,
        password: insertUser.password,
        phone_number: insertUser.phone_number,
        phone_verified: insertUser.phone_verified || false,
        email: insertUser.email,
        email_verified: insertUser.email_verified || false,
        display_name: insertUser.display_name || insertUser.username,
        google_id: insertUser.google_id,
        avatar_url: insertUser.avatar_url,
        preferences: preferences
      })
      .returning();

    console.log('Created user:', { id: user.id, username: user.username });
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }

    // Update the user in the database
    const [updatedUser] = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();

    console.log('Updated user:', { id: updatedUser.id, username: updatedUser.username });
    return updatedUser;
  }

  async updateUserOTP(phone: string, otp: string, expiryTime: Date): Promise<void> {
    let user = await this.getUserByPhone(phone);

    if (!user) {
      console.log('Creating new user for OTP verification');
      user = await this.createUser({
        username: phone,
        password: `temp.${Date.now()}`,
        phone_number: phone,
        display_name: `User ${phone}`
      });
    }

    // Update the OTP information
    await db.update(users)
      .set({
        otp: otp,
        otp_expires: expiryTime
      })
      .where(eq(users.id, user.id));

    console.log('Updated OTP for user:', user.id);
  }

  async updateUserEmailOTP(email: string, otp: string, expiryTime: Date): Promise<void> {
    let user = await this.getUserByEmail(email);

    if (!user) {
      console.log('Creating new user for email OTP verification');
      // Create a temporary username from the email
      const username = email.split('@')[0] + '_' + Date.now().toString().substring(8);
      
      user = await this.createUser({
        username: username,
        password: `temp.${Date.now()}`,
        email: email,
        display_name: `User ${email.split('@')[0]}`
      });
    }

    // Update the OTP information using both email_otp fields and regular OTP fields for backwards compatibility
    await db.update(users)
      .set({
        email_otp: otp,
        email_otp_expires: expiryTime,
        otp: otp,
        otp_expires: expiryTime
      })
      .where(eq(users.id, user.id));

    console.log('Updated email OTP for user:', user.id);
  }

  async verifyUserPhone(phone: string): Promise<void> {
    const user = await this.getUserByPhone(phone);
    if (user) {
      await db.update(users)
        .set({
          phone_verified: true,
          otp: null,
          otp_expires: null
        })
        .where(eq(users.id, user.id));
      console.log('Phone verified for user:', user.id);
    }
  }

  async verifyUserEmail(email: string): Promise<void> {
    const user = await this.getUserByEmail(email);
    if (user) {
      await db.update(users)
        .set({
          email_verified: true,
          otp: null,
          otp_expires: null,
          email_otp: null,
          email_otp_expires: null
        })
        .where(eq(users.id, user.id));
      console.log('Email verified for user:', user.id);
    }
  }
}

// Create a function to initialize the storage system
async function initializeStorage(): Promise<IStorage> {
  try {
    // Check database connection
    await db.select().from(users).limit(1);
    
    // Verify schema is up to date using a more resilient approach
    try {
      // This will fail if columns are missing but won't crash the app
      await db.query.users.findFirst({
        columns: {
          id: true,
          last_location: true,
          subscription_tier: true
        }
      });
    } catch (schemaError) {
      console.warn('Schema verification warning - some columns may be missing. Consider running npm run db:push');
      // We continue anyway since we added the missing columns manually via SQL
    }
    
    console.log('Database connection successful, using PostgresStorage');
    return new PostgresStorage();
  } catch (error) {
    console.error('Database initialization failed, falling back to InMemoryStorage:', error);
    return new InMemoryStorage();
  }
}

// Initialize with PostgresStorage and export it
export let storage: IStorage;

// We need to initialize the storage async, but can't export a promise
// Initialize with InMemoryStorage initially, then replace it
storage = new InMemoryStorage();

// Immediately start the initialization process
(async () => {
  try {
    storage = await initializeStorage();
  } catch (error) {
    console.error('Error initializing storage:', error);
  }
})();