import { Server } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import type { Socket } from 'socket.io';
import { isInGmailContacts } from './services/googleContactsService';
import { storage } from './storage';

interface User {
  id: number;
  username: string;
  email?: string;
  colorScheme?: string;
  currentRoom?: string;
  location?: {
    lat: number;
    lng: number;
  };
  lastActive?: string;
  isGoogleUser?: boolean;
}

interface Message {
  id: string;
  type: 'message' | 'status' | 'typing';
  senderId: number;
  senderName: string;
  content?: string;
  timestamp: string;
  colorScheme?: string;
  roomId?: string;
}

interface Room {
  id: string;
  name: string;
  participants: number[];
}

export class ChatServer {
  private io: SocketIOServer;
  private activeUsers: Map<number, User> = new Map();
  private typingUsers: Set<number> = new Set();
  private rooms: Map<string, Room> = new Map();

  constructor(server: Server) {
    console.log('Initializing Socket.IO server...');

    try {
      // Determine if we're in production-like environment
      const isProd = process.env.NODE_ENV === 'production' || !!process.env.REPL_SLUG;
      const isCustomDomain = process.env.CUSTOM_DOMAIN === 'true' || 
                            process.env.HOSTNAME?.includes('aitravelglobe.com');

      console.log('WebSocket server environment:', {
        isProd,
        isCustomDomain,
        NODE_ENV: process.env.NODE_ENV,
        REPL_SLUG: process.env.REPL_SLUG,
        HOSTNAME: process.env.HOSTNAME
      });

      // Configure Socket.IO with settings optimized for custom domains and Replit
      this.io = new SocketIOServer(server, {
        path: '/socket.io',
        cors: {
          // Super permissive CORS settings to ensure custom domain compatibility
          origin: ['https://aitravelglobe.com', 'http://localhost:3000', 'http://localhost:5000', '*'],
          methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
          credentials: true,
          allowedHeaders: ['*', 'Content-Type', 'Authorization', 'X-User-Id', 'X-Username']
        },
        pingInterval: 20000,     // Less frequent to reduce traffic
        pingTimeout: 10000,      // Longer timeout for slower connections
        transports: ['polling', 'websocket'],  // Start with polling for better compatibility
        allowEIO3: true,         // Support older Socket.IO clients
        maxHttpBufferSize: 1e6,  // 1MB buffer for larger payloads
        connectTimeout: 45000    // Longer connect timeout for slower networks
      });

      this.setupSocketHandlers();
      console.log('Socket.IO server initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Socket.IO server:', error);
      throw error;
    }
  }

  private setupSocketHandlers() {
    this.io.on('connection', (socket: Socket) => {
      console.log('New Socket.IO connection:', {
        id: socket.id,
        headers: socket.handshake.headers
      });

      // Handle authentication
      socket.on('auth', (user: User) => {
        console.log('User authenticated:', user);
        // Add/update user with lastActive timestamp
        this.activeUsers.set(user.id, {
          ...user,
          lastActive: new Date().toISOString()
        });
        socket.join(`user:${user.id}`);
        this.broadcastUserList();
      });

      // Handle heartbeat to keep connections alive
      socket.on('heartbeat', ({ userId }) => {
        if (!userId) return;

        const user = this.activeUsers.get(userId);
        if (user) {
          user.lastActive = new Date().toISOString();
          console.log(`Heartbeat received from user ${user.username} (ID: ${userId})`);
        }
      });

      // Handle chat messages
      socket.on('chat_message', async (message: Message) => {
        console.log('Received message:', {
          id: message.id,
          senderId: message.senderId,
          type: message.type
        });

        const enrichedMessage = {
          ...message,
          id: message.id || Date.now().toString(),
          timestamp: message.timestamp || new Date().toISOString()
        };

        // Get the actual user from socket
        let fromUserId: number | null = null;
        
        // Find the user from the socket rooms
        Array.from(this.activeUsers.entries()).forEach(([id, user]) => {
          if (socket.rooms.has(`user:${id}`)) {
            fromUserId = id;
          }
        });

        if (!fromUserId) {
          console.log('Message from unauthenticated user, ignoring');
          socket.emit('error', { message: 'You must be authenticated to send messages' });
          return;
        }

        // For messages sent to everyone in the global chat
        if (!message.roomId) {
          // Get user info
          const sender = await storage.getUser(fromUserId);
          if (!sender) {
            console.log('Message sender not found in database');
            socket.emit('error', { message: 'User information not found' });
            return;
          }
          
          // Check if user is authenticated via Google
          const isGoogleUser = !!sender.google_id;
          
          // For Google-authenticated users, check Gmail contacts before sending message
          if (isGoogleUser && message.senderId !== fromUserId) {
            try {
              const canSendMessage = await isInGmailContacts(fromUserId, message.senderId);
              if (!canSendMessage) {
                console.log(`User ${fromUserId} attempted to send message to non-contact ${message.senderId}`);
                socket.emit('error', { 
                  message: 'You can only send messages to users in your Gmail contacts'
                });
                return;
              }
            } catch (error) {
              console.error('Gmail contacts check error:', error);
              socket.emit('error', { 
                message: 'There was an issue verifying Gmail contacts. Try again later.'
              });
              return;
            }
          }
          
          if (isGoogleUser) {
            console.log('Filtering message recipients to Gmail contacts only');
            
            // Send message to each valid recipient (those in Gmail contacts)
            const activeUserEntries = Array.from(this.activeUsers.entries());
            for (const [recipientId, recipientUser] of activeUserEntries) {
              // Skip sending to self
              if (recipientId === fromUserId) {
                socket.emit('chat_message', enrichedMessage);
                continue;
              }
              
              // Check if recipient is in sender's Gmail contacts
              const isInContacts = await isInGmailContacts(fromUserId, recipientId);
              
              if (isInContacts) {
                // Send to this recipient
                this.io.to(`user:${recipientId}`).emit('chat_message', enrichedMessage);
              }
            }
          } else {
            // If not a Google user, use regular broadcast
            this.io.emit('chat_message', enrichedMessage);
          }
        } else {
          // For room messages, proceed as normal
          // Broadcast to all connected clients in the room
          this.io.to(`room:${message.roomId}`).emit('chat_message', enrichedMessage);
        }
      });

      // Handle typing status
      socket.on('typing', (userId: number, isTyping: boolean) => {
        if (isTyping) {
          this.typingUsers.add(userId);
        } else {
          this.typingUsers.delete(userId);
        }
        this.broadcastTypingStatus();
      });

      // Handle room joining
      socket.on('join_room', async ({ roomId, roomName }) => {
        console.log(`User attempting to join room: ${roomName} (${roomId})`);

        // Find the user ID from the socket
        let userId: number | null = null;
        let username: string | null = null;

        // Find the user from the socket rooms
        Array.from(this.activeUsers.entries()).forEach(([id, user]) => {
          if (socket.rooms.has(`user:${id}`)) {
            userId = id;
            username = user.username;
          }
        });

        if (!userId || !username) {
          console.log('User not authenticated, cannot join room');
          socket.emit('error', { message: 'You must be authenticated to join a room' });
          return;
        }

        // Check if room exists, create if not
        if (!this.rooms.has(roomId)) {
          this.rooms.set(roomId, {
            id: roomId,
            name: roomName,
            participants: []
          });
          console.log(`Created new room: ${roomName} (${roomId})`);
        }

        // Check if this is a Google-authenticated user
        const dbUser = await storage.getUser(userId);
        const isGoogleUser = dbUser?.google_id ? true : false;

        // For Google users, check if room has other participants and if they are contacts
        if (isGoogleUser && this.rooms.has(roomId)) {
          const room = this.rooms.get(roomId)!;
          
          // If room has participants
          if (room.participants.length > 0) {
            let canJoin = false;
            
            // Check if any of the room participants are in the user's contacts
            for (const participantId of room.participants) {
              if (await isInGmailContacts(userId, participantId)) {
                canJoin = true;
                break;
              }
            }
            
            // If no contacts found in room
            if (!canJoin) {
              console.log(`User ${username} (ID: ${userId}) cannot join room - no contacts`);
              socket.emit('error', { 
                message: 'You can only join rooms with people from your Gmail contacts' 
              });
              return;
            }
          }
        }

        // Get the room and add the user as participant
        const room = this.rooms.get(roomId)!;
        if (!room.participants.includes(userId)) {
          room.participants.push(userId);
        }

        // Update user's current room
        const user = this.activeUsers.get(userId)!;
        user.currentRoom = roomId;

        // Join the socket to the room
        socket.join(`room:${roomId}`);

        // Broadcast updated room info
        this.broadcastRoomInfo(roomId);

        // Send welcome message to the room
        const joinMessage: Message = {
          id: Date.now().toString(),
          type: 'status',
          senderId: 0, // System message
          senderName: 'System',
          content: `${username} has joined the room`,
          timestamp: new Date().toISOString(),
          roomId: roomId
        };

        this.io.to(`room:${roomId}`).emit('chat_message', joinMessage);
        console.log(`User ${username} (ID: ${userId}) joined room ${roomName} (${roomId})`);
      });

      // Handle leaving a room
      socket.on('leave_room', ({ roomId }) => {
        if (!roomId || !this.rooms.has(roomId)) {
          console.log(`Leave room: Room ${roomId} not found`);
          return;
        }

        // Find the user ID from the socket
        let userId: number | null = null;
        let username: string | null = null;

        // Find the user from the active users
        Array.from(this.activeUsers.entries()).forEach(([id, user]) => {
          if (socket.rooms.has(`user:${id}`)) {
            userId = id;
            username = user.username;
          }
        });

        if (!userId || !username) {
          console.log('User not authenticated, cannot leave room');
          return;
        }

        // Get the room and remove the user
        const room = this.rooms.get(roomId)!;
        room.participants = room.participants.filter(id => id !== userId);

        // Update user's current room status
        const user = this.activeUsers.get(userId)!;
        user.currentRoom = undefined;

        // Leave the socket room
        socket.leave(`room:${roomId}`);

        // Send leave message to the room
        const leaveMessage: Message = {
          id: Date.now().toString(),
          type: 'status',
          senderId: 0, // System message
          senderName: 'System',
          content: `${username} has left the room`,
          timestamp: new Date().toISOString(),
          roomId: roomId
        };

        this.io.to(`room:${roomId}`).emit('chat_message', leaveMessage);

        // If room is empty, remove it
        if (room.participants.length === 0) {
          this.rooms.delete(roomId);
          console.log(`Room ${roomId} is empty and has been removed`);
        } else {
          // Otherwise broadcast updated room info
          this.broadcastRoomInfo(roomId);
        }

        console.log(`User ${username} (ID: ${userId}) left room ${roomId}`);
      });

      // Handle room messages
      socket.on('room_message', async (message: Message) => {
        if (!message.roomId) {
          console.log('Room message without roomId, ignoring');
          return;
        }
        
        // Get the user ID from the socket
        let userId: number | null = null;
        
        // Find the user from the socket rooms
        Array.from(this.activeUsers.entries()).forEach(([id, user]) => {
          if (socket.rooms.has(`user:${id}`)) {
            userId = id;
          }
        });
        
        if (!userId) {
          console.log('Room message from unauthenticated user, ignoring');
          socket.emit('error', { message: 'You must be authenticated to send room messages' });
          return;
        }
        
        // Verify the room exists
        if (!this.rooms.has(message.roomId)) {
          console.log(`Room ${message.roomId} not found, can't send message`);
          socket.emit('error', { message: 'The room no longer exists' });
          return;
        }
        
        // Check if user is in the room
        const room = this.rooms.get(message.roomId)!;
        if (!room.participants.includes(userId)) {
          console.log(`User ${userId} not in room ${message.roomId}, can't send message`);
          socket.emit('error', { message: 'You must join the room first' });
          return;
        }
        
        // Check Gmail contacts restriction for Google users
        const dbUser = await storage.getUser(userId);
        const isGoogleUser = dbUser?.google_id ? true : false;
        
        if (isGoogleUser) {
          // For Google users, verify room has at least one contact
          let hasContact = false;
          
          for (const participantId of room.participants) {
            // Skip self check
            if (participantId === userId) continue;
            
            if (await isInGmailContacts(userId, participantId)) {
              hasContact = true;
              break;
            }
          }
          
          if (!hasContact && room.participants.length > 1) {
            console.log(`Google user ${userId} trying to message room with no contacts`);
            socket.emit('error', { 
              message: 'You can only send messages in rooms with your Gmail contacts' 
            });
            return;
          }
        }

        const enrichedMessage = {
          ...message,
          id: message.id || Date.now().toString(),
          timestamp: message.timestamp || new Date().toISOString()
        };

        console.log(`Room message in ${message.roomId}: ${message.content?.substring(0, 50)}...`);

        // Broadcast to the specific room
        this.io.to(`room:${message.roomId}`).emit('chat_message', enrichedMessage);
      });

      // Handle location updates
      socket.on('update_location', ({ userId, location }) => {
        if (!userId || !location) {
          console.log('Location update missing userId or location data, ignoring');
          return;
        }

        // Find the user
        const user = this.activeUsers.get(userId);
        if (!user) {
          console.log(`Location update for non-active user ID ${userId}, ignoring`);
          return;
        }

        // Validate location data
        if (typeof location.lat !== 'number' || typeof location.lng !== 'number') {
          console.log('Invalid location data format, ignoring');
          return;
        }

        // Update user's location and last active time
        user.location = location;
        user.lastActive = new Date().toISOString();

        console.log(`Updated location for user ${user.username} (ID: ${userId}):`, location);

        // Broadcast updated user list to all clients
        this.broadcastUserList();
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
        // Remove user from active users and rooms

        let userId: number | null = null;
        let userRoomId: string | null = null;

        // Find the user from active users
        Array.from(this.activeUsers.entries()).forEach(([id, user]) => {
          if (socket.rooms.has(`user:${id}`)) {
            userId = id;
            userRoomId = user.currentRoom || null;
            this.activeUsers.delete(id);
            this.typingUsers.delete(id);
          }
        });

        // Remove user from room participants if they were in a room
        if (userId && userRoomId && this.rooms.has(userRoomId)) {
          const room = this.rooms.get(userRoomId)!;
          room.participants = room.participants.filter(id => id !== userId);

          // If room is empty, remove it
          if (room.participants.length === 0) {
            this.rooms.delete(userRoomId);
            console.log(`Room ${userRoomId} is empty and has been removed`);
          } else {
            // Otherwise broadcast updated room info
            this.broadcastRoomInfo(userRoomId);
          }
        }

        this.broadcastUserList();
      });
    });
  }

  private async broadcastUserList() {
    // Get a standard user list with typing status
    const userList = Array.from(this.activeUsers.values()).map(user => ({
      ...user,
      isTyping: this.typingUsers.has(user.id)
    }));

    // For each user, send a filtered list based on their Gmail contacts
    // Convert Map entries to array for iteration to avoid TypeScript issues
    const activeUsersArray = Array.from(this.activeUsers.entries());
    for (const [userId, user] of activeUsersArray) {
      // Get the full user details
      const dbUser = await storage.getUser(userId);
      
      if (!dbUser) {
        // If user not found in DB, send regular user list
        this.io.to(`user:${userId}`).emit('user_list', userList);
        continue;
      }
      
      // Check if user is authenticated with Google
      const isGoogleUser = !!dbUser.google_id;
      
      if (isGoogleUser) {
        // Filter user list to only include Gmail contacts
        // First, create an array of promises
        const filterPromises = userList.map(async (otherUser) => {
          // Always include self
          if (otherUser.id === userId) return otherUser;
          
          // Check if other user is in contacts
          const isContact = await isInGmailContacts(userId, otherUser.id);
          return isContact ? otherUser : null;
        });
        
        // Then resolve all promises and filter out nulls
        const filteredList = (await Promise.all(filterPromises)).filter(Boolean);
        
        // Send filtered list to this user
        this.io.to(`user:${userId}`).emit('user_list', filteredList);
      } else {
        // Send the complete list to non-Google users
        this.io.to(`user:${userId}`).emit('user_list', userList);
      }
    }
    
    console.log('Broadcasting filtered user lists completed');
  }

  private broadcastTypingStatus() {
    const typingUsers = Array.from(this.typingUsers).map(userId =>
      this.activeUsers.get(userId)?.username
    ).filter(Boolean);

    this.io.emit('typing_status', typingUsers);
  }

  private broadcastRoomInfo(roomId: string) {
    const room = this.rooms.get(roomId);
    if (!room) {
      console.log(`Room ${roomId} not found, can't broadcast info`);
      return;
    }

    // Get participant details
    const participants = room.participants.map(userId => {
      const user = this.activeUsers.get(userId);
      return user ? {
        id: user.id,
        username: user.username,
        isTyping: this.typingUsers.has(userId)
      } : null;
    }).filter(Boolean);

    const roomInfo = {
      id: room.id,
      name: room.name,
      participants
    };

    console.log(`Broadcasting room info for ${room.name}:`, roomInfo);
    this.io.to(`room:${roomId}`).emit('room_info', roomInfo);
  }

  public cleanup() {
    console.log('Cleaning up Socket.IO server...');
    this.io.close();
  }
}

export function setupWebSocket(server: Server, options?: any) {
  try {
    return new ChatServer(server);
  } catch (error) {
    console.error('Failed to setup Socket.IO server:', error);
    throw error;
  }
}