import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, hashPassword, comparePasswords } from "./auth";
import { aiService } from "./services/aiService";
import { db } from './db';
import { users } from '@shared/schema';
import * as schema from '@shared/schema';
import { storage } from './storage';
import { paymentService } from "./services/paymentService";
import { hotelService } from "./services/hotelService";
import { flightService } from "./services/flightService";
import { rapidApiService } from "./services/rapidApiService";

import { rideService } from "./services/rideService";
import { generateSampleFlights } from "../shared/mockData";
import { rideHistory, rideTracking } from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import { generateHotels, generateRides, generateDining } from "../shared/mockData";
import Stripe from "stripe";
import { User, BookingType } from '@shared/schema';
import { emergencyValidationService } from "./services/emergencyValidationService";
import axios from 'axios';
import { otpService } from "./services/otpService";
import { treasureHuntService } from "./services/treasureHuntService";
import { soundtrackService, PRESET_MOODS } from "./services/soundtrackService";
import { subscriptionService } from "./services/subscriptionService";
import { diagnosticService } from "./services/diagnosticService";
import { expenseService } from "./services/expenseService";
import { Server as SocketIOServer } from 'socket.io';
import subscriptionRoutes from "./routes/subscriptionRoutes";
import { registerTripInspirationRoutes } from "./routes/trip-inspiration";
import aiTripPlannerRoutes from "./routes/ai-trip-planner";
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

// Environment configuration
const isDevelopment = process.env.NODE_ENV !== 'production';

// Initialize Stripe only if the secret key is available
const stripe = process.env.STRIPE_SECRET_KEY ? 
  new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2023-10-16"
  }) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  console.log('Starting server initialization...');
  const httpServer = createServer(app);

  // Store active location trackers - will be handled by WebSocket server
  const locationTrackers = new Map();

  // Set up security headers including CSP
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-User-Id, X-Username');
    res.header('Access-Control-Allow-Credentials', 'true');

    // Temporarily disable CSP headers for custom domain testing
    // This helps diagnose 502 errors by eliminating CSP as a potential cause
    const isProd = process.env.NODE_ENV === 'production' || !!process.env.REPL_SLUG;
    
    // if (!isProd) {
    //   // In development, use a standard CSP header
    //   res.header(
    //     'Content-Security-Policy',
    //     // [
    //     //   "default-src 'self'",
    //     //   "connect-src 'self' ws: wss: * https://*.replit.app https://*.replit.dev https://*.repl.co https://*.aitravelglobe.com https://*.stripe.com https://*.openstreetmap.org",
    //     //   "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.stripe.com",
    //     //   "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    //     //   "font-src 'self' https://fonts.gstatic.com",
    //     //   "img-src 'self' data: https: https://*.stripe.com https://*.openstreetmap.org",
    //     //   "frame-src 'self' https://*.stripe.com",
    //     //   "frame-ancestors 'self'",
    //     //   "base-uri 'self'",
    //     //   "worker-src 'self' blob:",
    //     //   "media-src 'self' blob:",
    //     //   "upgrade-insecure-requests"
    //     // ].join('; ')
    //   );
    // }
    // In production, we're temporarily skipping the CSP header entirely to troubleshoot 502 errors
    next();
  });

  // Set up session middleware explicitly for WebSocket upgrade
  app.use((req, res, next) => {
    if (req.headers.upgrade === 'websocket') {
      console.log('WebSocket upgrade request detected');
      // Allow WebSocket upgrades without authentication in development
      if (app.get('env') === 'development') {
        return next();
      }
    }
    next();
  });

  // Add enhanced health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ 
      status: "ok",
      activeTrackers: locationTrackers.size,
      timestamp: new Date().toISOString()
    });
  });
  
  // Add status endpoint for frontend loading page to check
  app.get("/api/status", (_req, res) => {
    res.json({
      status: "ready",
      message: "Application is fully loaded and ready to use",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      initialized: true
    });
  });
  
  // Add deployment diagnostic endpoint for debugging custom domain issues
  app.get("/api/deployment-diagnostics", async (req, res) => {
    try {
      // Get hostname and request information
      const hostname = req.hostname;
      const headers = req.headers;
      const protocol = req.protocol;
      const secure = req.secure;
      const originalUrl = req.originalUrl;
      
      // Get database status
      const dbStatus = await db.select().from(users).limit(1)
        .then(() => ({ connected: true }))
        .catch(err => ({ connected: false, error: err.message }));
      
      // Server environment information
      const environment = {
        NODE_ENV: process.env.NODE_ENV || 'development',
        PORT: process.env.PORT,
        REPL_SLUG: process.env.REPL_SLUG ? 'set' : 'not set',
        REPL_OWNER: process.env.REPL_OWNER ? 'set' : 'not set',
        REPL_ID: process.env.REPL_ID ? 'set' : 'not set',
        DATABASE_URL: process.env.DATABASE_URL ? 'set' : 'not set',
        isProduction: process.env.NODE_ENV === 'production' || !!process.env.REPL_SLUG
      };
      
      // Check API services
      const services = {
        stripe: !!stripe,
        openai: !!process.env.OPENAI_API_KEY,
        twilioSms: !!process.env.TWILIO_ACCOUNT_SID && !!process.env.TWILIO_AUTH_TOKEN,
        googleMaps: !!process.env.GOOGLE_MAPS_API_KEY
      };
      
      // Send diagnostic information
      res.json({
        status: "ok",
        timestamp: new Date().toISOString(),
        request: {
          hostname,
          protocol,
          secure,
          originalUrl,
          userAgent: headers['user-agent'],
          ip: req.ip,
          headers: {
            host: headers.host,
            origin: headers.origin,
            referer: headers.referer,
            'x-forwarded-for': headers['x-forwarded-for'],
            'x-forwarded-host': headers['x-forwarded-host'],
            'x-forwarded-proto': headers['x-forwarded-proto']
          }
        },
        server: {
          environment,
          database: dbStatus,
          services,
          uptime: process.uptime(),
          memoryUsage: process.memoryUsage()
        }
      });
    } catch (error) {
      console.error('Error in diagnostics endpoint:', error);
      res.status(500).json({
        status: 'error',
        message: 'Failed to get diagnostic information',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Special route to reset test user passwords (development only)
  app.get("/api/reset-test-users", async (req, res) => {
    if (app.get('env') !== 'development') {
      return res.status(404).json({ message: "Not found" });
    }
    
    try {
      console.log("Starting test user password reset");
      
      // Reset test123 user
      const user1 = await storage.getUserByUsername('test123');
      if (user1) {
        const hashedPassword1 = await hashPassword('test123');
        await storage.updateUserPassword(user1.id, hashedPassword1);
        console.log(`Reset test123 user (ID: ${user1.id}) password successfully`);
        
        // Verify password
        const updatedUser1 = await storage.getUserByUsername('test123');
        const check1 = await comparePasswords('test123', updatedUser1?.password || '');
        console.log(`Verification check for test123: ${check1 ? 'PASSED' : 'FAILED'}`);
      }
      
      // Reset test456 user
      const user2 = await storage.getUserByUsername('test456');
      if (user2) {
        const hashedPassword2 = await hashPassword('test456');
        await storage.updateUserPassword(user2.id, hashedPassword2);
        console.log(`Reset test456 user (ID: ${user2.id}) password successfully`);
        
        // Verify password
        const updatedUser2 = await storage.getUserByUsername('test456');
        const check2 = await comparePasswords('test456', updatedUser2?.password || '');
        console.log(`Verification check for test456: ${check2 ? 'PASSED' : 'FAILED'}`);
      }
      
      res.json({ success: true, message: "Test user passwords reset successfully" });
    } catch (error) {
      console.error("Error resetting test users:", error);
      res.status(500).json({ error: "Failed to reset test users" });
    }
  });

  // Add route to get active trackers
  app.get("/api/location/trackers", async (req, res) => {
    try {
      const activeTrackers = Array.from(locationTrackers.entries()).map(([id, data]) => ({
        id,
        ...data
      }));
      res.json(activeTrackers);
    } catch (error) {
      console.error('Error fetching location trackers:', error);
      res.status(500).json({ message: 'Failed to fetch location trackers' });
    }
  });

  // Add route to get specific tracker location
  app.get("/api/location/tracker/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const trackerData = locationTrackers.get(id);

      if (!trackerData) {
        return res.status(404).json({ message: 'Tracker not found' });
      }

      res.json(trackerData);
    } catch (error) {
      console.error('Error fetching tracker location:', error);
      res.status(500).json({ message: 'Failed to fetch tracker location' });
    }
  });
  
  // Add minimal redirector with no middleware - should help with 502 errors
  app.get("/redirect", (req, res) => {
    res.redirect("/aitravelglobe-check");
  });
  
  // Simple HTML diagnostic endpoint
  app.get("/minimal-check", (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>AI Travel Globe - Minimal Check</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body>
        <h1>Server is responding correctly</h1>
        <p>Time: ${new Date().toISOString()}</p>
        <p>Hostname: ${req.hostname}</p>
        <p>Headers: ${JSON.stringify({
          host: req.headers.host,
          'x-forwarded-host': req.headers['x-forwarded-host'],
          'x-forwarded-proto': req.headers['x-forwarded-proto']
        }, null, 2)}</p>
      </body>
      </html>
    `);
  });

  // Setup authentication routes
  try {
    await setupAuth(app);
    console.log('Authentication setup completed successfully');
  } catch (error) {
    console.error('Failed to setup authentication:', error);
  }
  
  // Mount subscription routes
  app.use('/api/subscriptions', subscriptionRoutes);
  console.log('Subscription routes mounted successfully');

  // Password reset request route
  app.post("/api/forgot-password", async (req, res) => {
    try {
      const { identifier } = req.body;
      
      if (!identifier) {
        return res.status(400).json({
          success: false,
          message: 'Username or email is required'
        });
      }
      
      // Determine if identifier is email, phone, or username
      const isEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(identifier);
      const isPhoneNumber = /^\+\d{1,15}$/.test(identifier);
      
      let user;
      if (isEmail) {
        user = await storage.getUserByEmail(identifier);
      } else if (isPhoneNumber) {
        user = await storage.getUserByPhone(identifier);
      } else {
        user = await storage.getUserByUsername(identifier);
      }
      
      if (!user) {
        // For security reasons, don't reveal that the user doesn't exist
        return res.json({
          success: true,
          message: 'If your account exists, a recovery code has been sent to your registered email'
        });
      }
      
      // Get the email to send the OTP to
      let emailToUse = user.email;
      
      // If the identifier is an email and we found a user, use that email directly
      if (isEmail) {
        emailToUse = identifier;
      }
      
      // If we don't have an email to use, return an error
      if (!emailToUse) {
        return res.status(400).json({ 
          success: false,
          message: "Account doesn't have a verified email address. Please contact support." 
        });
      }
      
      // Send OTP to the user's email
      console.log('Sending password reset OTP to email:', emailToUse);
      const result = await otpService.sendOTP(emailToUse);
      
      if (result.success) {
        // Check if we're in test mode and should return the test OTP
        if (process.env.NODE_ENV !== 'production' && result.message && result.message.includes('Code is:')) {
          // Extract the OTP code from the message
          const otpMatch = result.message.match(/Code is: (\d+)/);
          const testOtp = otpMatch ? otpMatch[1] : null;
          
          console.log('TEST OTP CODE for password reset:', testOtp);
          
          return res.json({
            success: true,
            message: 'Recovery code sent to your email address',
            isTestMode: true,
            testOtp: testOtp,
            channel: 'email',
            development_note: 'This is a TEST OTP code shown only in development mode'
          });
        }
        
        // Store info that this OTP is for password reset
        return res.json({
          success: true,
          message: 'Recovery code sent to your email address',
          channel: 'email'
        });
      } else {
        return res.status(500).json({
          success: false,
          message: result.message || "Failed to send verification code"
        });
      }
      
    } catch (error) {
      console.error('Password reset request error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to process password reset request'
      });
    }
  });
  
  // Verify reset code and set new password
  app.post("/api/verify-reset-token", async (req, res) => {
    try {
      const { identifier, otp } = req.body;
      
      if (!identifier || !otp) {
        return res.status(400).json({
          success: false,
          message: 'Identifier and verification code are required'
        });
      }
      
      console.log('Verifying reset token for:', identifier, 'OTP:', otp);
      
      // Determine if identifier is email, phone, or username
      const isEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(identifier);
      const isPhoneNumber = /^\+\d{1,15}$/.test(identifier);
      
      let user;
      if (isEmail) {
        user = await storage.getUserByEmail(identifier);
      } else if (isPhoneNumber) {
        user = await storage.getUserByPhone(identifier);
      } else {
        user = await storage.getUserByUsername(identifier);
      }
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Determine which contact method to verify (prioritize email)
      const verificationRecipient = isEmail ? identifier : (user.email || user.phone_number);
      
      if (!verificationRecipient) {
        return res.status(400).json({
          success: false,
          message: 'No verified contact method available for this account'
        });
      }
      
      console.log('Verifying reset token with recipient:', verificationRecipient, 'OTP:', otp);
      
      // Verify the OTP manually since we're in a password reset flow
      // Check both email_otp and regular otp fields
      const isEmailOtpValid = user.email_otp && user.email_otp === otp && 
                             user.email_otp_expires && new Date(user.email_otp_expires) > new Date();
      
      const isPhoneOtpValid = user.otp && user.otp === otp && 
                             user.otp_expires && new Date(user.otp_expires) > new Date();
      
      console.log('OTP validation check:', {
        email: user.email,
        email_otp: user.email_otp,
        email_otp_expires: user.email_otp_expires,
        phone_otp: user.otp,
        phone_otp_expires: user.otp_expires,
        provided_otp: otp,
        isEmailOtpValid,
        isPhoneOtpValid
      });
      
      // Check if OTP is valid, either through direct check or service
      let isOtpValid = isEmailOtpValid || isPhoneOtpValid;
      let verificationErrorMessage = '';
      
      if (isOtpValid) {
        console.log('OTP is valid through direct check');
      } else {
        console.log('OTP is invalid through direct check, trying OTP service');
        // Fallback to OTP service verification 
        try {
          const verificationResult = await otpService.verifyOTP(verificationRecipient, otp);
          isOtpValid = verificationResult.success;
          verificationErrorMessage = verificationResult.message || 'Invalid verification code';
        } catch (verifyError) {
          console.error('Error in OTP service verification:', verifyError);
          isOtpValid = false;
          verificationErrorMessage = 'Error verifying OTP';
        }
      }
      
      if (!isOtpValid) {
        return res.status(400).json({
          success: false,
          message: verificationErrorMessage || 'Invalid verification code'
        });
      }
      
      // If we get here, OTP is valid
      
      // Generate a secure reset token
      const resetToken = crypto.randomBytes(32).toString('hex');
      
      // Save the reset token in the user's OTP field temporarily
      // In a production system, you would want a dedicated reset_token field with expiry
      if (user.email) {
        await storage.updateUserEmailOTP(
          user.email, 
          resetToken, 
          new Date(Date.now() + 15 * 60 * 1000) // 15 min expiry
        );
      } else if (user.phone_number) {
        await storage.updateUserOTP(
          user.phone_number, 
          resetToken, 
          new Date(Date.now() + 15 * 60 * 1000) // 15 min expiry
        );
      }
      
      res.json({
        success: true,
        message: 'Verification successful',
        token: resetToken
      });
    } catch (error) {
      console.error('OTP verification error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Server error verifying code'
      });
    }
  });

  app.post("/api/reset-password", async (req, res) => {
    try {
      const { identifier, token, password } = req.body;
      
      if (!identifier || !token || !password) {
        return res.status(400).json({
          success: false,
          message: 'All fields are required'
        });
      }
      
      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Password must be at least 6 characters'
        });
      }
      
      // Determine if identifier is email, phone, or username
      const isEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(identifier);
      const isPhoneNumber = /^\+\d{1,15}$/.test(identifier);
      
      let user;
      if (isEmail) {
        user = await storage.getUserByEmail(identifier);
      } else if (isPhoneNumber) {
        user = await storage.getUserByPhone(identifier);
      } else {
        user = await storage.getUserByUsername(identifier);
      }
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Verify token from OTP field (tokens could be in email_otp or regular otp field)
      const validToken = 
        (user.email_otp && user.email_otp === token) || 
        (user.otp && user.otp === token);
        
      if (!validToken) {
        return res.status(400).json({
          success: false,
          message: 'Invalid or expired reset token'
        });
      }
      
      // Check if token is expired - either email_otp_expires or otp_expires
      const tokenExpiry = user.email_otp ? user.email_otp_expires : user.otp_expires;
      
      if (!tokenExpiry || new Date() > new Date(tokenExpiry)) {
        return res.status(400).json({
          success: false,
          message: 'Reset token has expired'
        });
      }
      
      // Hash the new password and update it
      const hashedPassword = await hashPassword(password);
      await storage.updateUserPassword(user.id, hashedPassword);
      
      // Clear both OTP fields
      if (user.email) {
        await storage.updateUserEmailOTP(user.email, "", new Date());
      }
      if (user.phone_number) {
        await storage.updateUserOTP(user.phone_number, "", new Date());
      }
      
      console.log(`Password reset successful for user ID: ${user.id}`);
      
      return res.json({
        success: true,
        message: 'Your password has been reset successfully. You can now log in with your new password.'
      });
      
    } catch (error) {
      console.error('Password reset error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to reset password'
      });
    }
  });

  // Add OTP routes
  app.post("/api/send-otp", async (req, res) => {
    try {
      const { phone_number, email, recipient } = req.body;
      
      // Support both legacy phone_number and new unified recipient parameter
      const actualRecipient = recipient || phone_number || email;

      if (!actualRecipient) {
        return res.status(400).json({
          success: false,
          message: 'Email or phone number is required'
        });
      }

      console.log('Sending OTP to:', actualRecipient);
      const result = await otpService.sendOTP(actualRecipient);

      if (result.success) {
        // If we're in test mode, the OTP will be included in the message
        if (process.env.NODE_ENV !== 'production' && 
            result.message && 
            result.message.includes('Test mode active')) {
          
          // Extract the OTP code from the message
          const otpMatch = result.message.match(/Code is: (\d+)/);
          const testOtp = otpMatch ? otpMatch[1] : null;
          
          return res.json({
            ...result,
            isTestMode: true,
            testOtp: testOtp,
            channel: actualRecipient.includes('@') ? 'email' : 'phone',
            development_note: 'This is a TEST OTP code shown only in development mode'
          });
        }
        
        res.json({
          ...result,
          channel: actualRecipient.includes('@') ? 'email' : 'phone'
        });
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error('OTP send error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to send verification code'
      });
    }
  });

  // For backward compatibility - redirect to the new endpoint
  app.post("/api/send-email-otp", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({
          success: false,
          message: 'Email is required'
        });
      }
      
      // Since we can't use next middleware directly, just call the sendOTP with email
      console.log('Sending OTP to email (legacy endpoint):', email);
      const result = await otpService.sendOTP(email);
      
      if (result.success) {
        // If we're in test mode, the OTP will be included in the message
        if (process.env.NODE_ENV !== 'production' && 
            result.message && 
            result.message.includes('Test mode active')) {
          
          // Extract the OTP code from the message
          const otpMatch = result.message.match(/Code is: (\d+)/);
          const testOtp = otpMatch ? otpMatch[1] : null;
          
          return res.json({
            ...result,
            isTestMode: true,
            testOtp: testOtp,
            channel: 'email',
            development_note: 'This is a TEST OTP code shown only in development mode'
          });
        }
        
        res.json({
          ...result,
          channel: 'email'
        });
      } else {
        res.status(400).json(result);
      }
      
    } catch (error) {
      console.error('Email OTP send error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to send verification code'
      });
    }
  });

  app.post("/api/verify-otp", async (req, res) => {
    try {
      const { phone_number, email, recipient, otp } = req.body;
      
      // Support both new recipient param and legacy params
      const actualRecipient = recipient || phone_number || email;

      if (!actualRecipient || !otp) {
        return res.status(400).json({
          success: false,
          message: 'Recipient (email or phone) and OTP are required'
        });
      }

      console.log('Verifying OTP for:', actualRecipient);
      const result = await otpService.verifyOTP(actualRecipient, otp);

      if (result.success) {
        res.json({
          ...result,
          channel: actualRecipient.includes('@') ? 'email' : 'phone'
        });
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error('OTP verification error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to verify code'
      });
    }
  });


  // Add GetOTP API test endpoint (admin only)
  app.get("/api/diagnostics/getotp", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    
    const user = req.user as User;
    if (!user.is_admin) {
      return res.status(403).json({ success: false, message: 'Admin access required' });
    }

    try {
      // Check GetOTP API configuration
      const getOtpConfigured = !!process.env.GETOTP_API_KEY;
      
      // Simple status check of the GetOTP API
      let apiConnectivity = false;
      if (getOtpConfigured) {
        try {
          const statusUrl = 'https://api.getotp.dev/v1/status'; // Adjust based on actual GetOTP API
          const response = await axios.get(statusUrl, {
            headers: {
              'Authorization': `Bearer ${process.env.GETOTP_API_KEY}`
            }
          });
          apiConnectivity = response.status === 200;
        } catch (error) {
          console.error('GetOTP API status check failed:', error);
          apiConnectivity = false;
        }
      }
      
      res.json({
        success: true,
        getotp: {
          configured: getOtpConfigured,
          apiConnectivity,
          apiKeyPresent: !!process.env.GETOTP_API_KEY,
          apiKeyLength: process.env.GETOTP_API_KEY ? process.env.GETOTP_API_KEY.length : 0
        }
      });
    } catch (error) {
      console.error('GetOTP diagnostic error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to run GetOTP diagnostics'
      });
    }
  });

  // Add session check endpoint
  app.get("/api/session", (req, res) => {
    console.log('Session check:', {
      sessionId: req.session?.id,
      authenticated: req.isAuthenticated(),
      user: req.user
    });
    res.json({
      authenticated: req.isAuthenticated(),
      user: req.user || null
    });
  });
  
  // Add endpoint to get user expenses from bookings
  app.get("/api/expenses", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
      
      const user = req.user as User;
      const { startDate, endDate } = req.query;
      
      // Fetch expenses from the user's bookings
      const expenses = await expenseService.getUserExpenses(
        user.id,
        startDate as string | undefined,
        endDate as string | undefined
      );
      
      console.log(`Fetched ${expenses.length} expenses for user ${user.id}`);
      
      res.json(expenses);
    } catch (error) {
      console.error('Error fetching user expenses:', error);
      res.status(500).json({ message: 'Failed to fetch expenses' });
    }
  });
  
  // Enhanced expense analytics endpoint
  app.get("/api/expenses/analytics", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
      
      const user = req.user as User;
      const { startDate, endDate, timeframe = 'monthly' } = req.query;
      
      // Fetch expenses from the user's bookings
      const expenses = await expenseService.getUserExpenses(
        user.id,
        startDate as string | undefined,
        endDate as string | undefined
      );
      
      // Get spending by category
      const categorySummary = expenseService.getSpendingSummaryByCategory(expenses);
      
      // Get spending by timeframe (daily, weekly, monthly)
      const timeframeSummary = expenseService.getSpendingSummaryByDateRange(
        expenses,
        timeframe as 'daily' | 'weekly' | 'monthly'
      );
      
      // Calculate total spent
      const totalSpent = Object.values(categorySummary).reduce((sum, value) => sum + value, 0);
      
      // Get top expense categories
      const topCategories = Object.entries(categorySummary)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([category, amount]) => ({ 
          category, 
          amount, 
          percentage: totalSpent > 0 ? Math.round((amount / totalSpent) * 100) : 0 
        }));
      
      res.json({
        expenses,
        analytics: {
          totalSpent,
          categorySummary,
          timeframeSummary,
          topCategories
        }
      });
    } catch (error) {
      console.error('Error fetching expense analytics:', error);
      res.status(500).json({ message: 'Failed to fetch expense analytics' });
    }
  });

  // Updated payment routes using enhanced payment service
  app.post("/api/payment/create-intent", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { amount, bookingType, metadata } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ 
          message: 'Invalid amount', 
          details: 'Amount must be a positive number'
        });
      }
      
      if (!bookingType) {
        return res.status(400).json({ 
          message: 'Missing booking type', 
          details: 'A valid booking type (flight, hotel, dining, ride) is required'
        });
      }
      
      const user = req.user as User;
      console.log('Creating payment intent for user:', user.id, user.username);
      console.log('Payment details:', { amount, bookingType, metadata });

      // Add user ID to metadata
      const enhancedMetadata = {
        userId: user.id,
        username: user.username,
        email: user.email || 'no-email',
        ...metadata
      };

      try {
        // Check if STRIPE_SECRET_KEY environment variable is available
        if (!process.env.STRIPE_SECRET_KEY) {
          console.error('STRIPE_SECRET_KEY is missing');
          return res.status(500).json({
            message: 'Payment system is not properly configured',
            details: 'Server configuration issue'
          });
        }
        
        const result = await paymentService.createPaymentIntent(
          amount, 
          bookingType as BookingType, 
          enhancedMetadata
        );

        console.log('Payment intent created successfully:', result.id);
        
        res.json({
          clientSecret: result.clientSecret,
          paymentIntentId: result.id,
          paymentMethods: result.paymentMethods
        });
      } catch (serviceError: any) {
        console.error('Payment service error:', serviceError);
        res.status(500).json({
          message: 'Payment service error',
          error: serviceError.message,
          details: serviceError.stack
        });
      }
    } catch (error: any) {
      console.error('Payment intent creation failed:', error);
      console.error('Error stack:', error.stack);
      res.status(500).json({
        message: 'Failed to create payment intent',
        error: error.message,
        details: error.stack
      });
    }
  });

  // Handle demo/mock payments (no actual payment processing)
  app.post("/api/payment/demo-payment", async (req, res) => {
    try {
      // Verify user is authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in to process payments" });
      }
      
      const user = req.user as User;
      console.log(`Processing demo payment for user: ${user.id} ${user.username}`);
      console.log('Demo payment details:', req.body);
      
      const { amount, bookingType, metadata, paymentMethod = 'card' } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid payment amount" });
      }
      
      // Generate a realistic transaction ID
      const transactionId = `demo_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      
      // Create mock payment record
      const mockPaymentRecord = {
        userId: user.id,
        amount: amount,
        status: 'succeeded',
        paymentMethod: paymentMethod || 'demo',
        paymentMethodType: paymentMethod === 'card' ? 'credit_card' : 
                          paymentMethod === 'upi' ? 'upi_payment' : 
                          paymentMethod === 'wallet' ? 'digital_wallet' : 
                          'demo_payment',
        currency: 'usd',
        description: `Demo payment for ${bookingType}`,
        metadata: {
          demo: true,
          bookingType,
          ...metadata
        },
        createdAt: new Date(),
        transactionId: transactionId
      };
      
      // Insert into payment_records table if table exists
      try {
        await db.insert(schema.paymentRecords).values({
          userId: user.id,
          amount: parseFloat(amount.toString()),
          paymentMethod: mockPaymentRecord.paymentMethodType,
          status: 'succeeded',
          currency: 'usd',
          description: mockPaymentRecord.description,
          createdAt: new Date(),
          metadata: JSON.stringify(mockPaymentRecord.metadata)
        });
        console.log('Demo payment record saved to database');
      } catch (dbError) {
        // It's okay if this fails (table might not exist) - just log it
        console.warn('Could not save demo payment record to database:', dbError);
      }
      
      // If it's a bookable item, save to itineraries table too
      if (['hotel', 'dining', 'flight', 'ride'].includes(bookingType)) {
        try {
          // Prepare booking details based on booking type
          const bookingDetails: any = {};
          bookingDetails[bookingType] = metadata;
          
          // Number of passengers/guests
          const passengerCount = metadata.guests || metadata.passengers || 1;
          
          // Create mock passenger details if needed
          const passengers: any[] = [];
          for (let i = 0; i < passengerCount; i++) {
            passengers.push({
              firstName: i === 0 ? user.display_name?.split(' ')[0] || 'Demo' : `Guest ${i}`,
              lastName: i === 0 ? user.display_name?.split(' ')[1] || 'User' : `${i}`,
              dateOfBirth: '1990-01-01',
              nationality: 'US',
              specialRequirements: ''
            });
          }
          
          // Calculate total amount
          const totalAmount = parseFloat(amount.toString());
          
          // Try to insert into itineraries table
          try {
            await db.insert(schema.itineraries).values({
              userId: user.id,
              bookingDate: new Date(),
              totalAmount: totalAmount,
              paymentStatus: 'completed',
              bookingDetails: JSON.stringify(bookingDetails),
              passengers: passengers as any
            });
            console.log('Demo itinerary saved to database');
          } catch (itineraryError) {
            console.warn('Could not save demo itinerary to database:', itineraryError);
          }
        } catch (bookingError) {
          console.warn('Error creating booking record:', bookingError);
        }
      }
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Return success response
      res.status(200).json({
        success: true,
        message: 'Demo payment processed successfully',
        demoPayment: true,
        amount: amount,
        bookingType: bookingType,
        transactionId: transactionId,
        paymentMethod: paymentMethod,
        paymentMethodType: mockPaymentRecord.paymentMethodType,
        currency: 'usd',
        timestamp: new Date().toISOString(),
        authorizationCode: `AUTH${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
        receiptUrl: `/receipts/${transactionId}`,
        merchantName: bookingType === 'dining' ? metadata.restaurant : 
                      bookingType === 'hotel' ? metadata.hotel?.name || 'Hotel Booking' : 
                      bookingType === 'flight' ? metadata.flight?.airline || 'Air Travel' : 
                      'Travel Global'
      });
    } catch (error) {
      console.error('Error processing demo payment:', error);
      res.status(500).json({ 
        message: 'Failed to process demo payment',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Confirm payment route
  app.post("/api/payment/confirm", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: 'Payment intent ID is required' });
      }

      const result = await paymentService.confirmPayment(paymentIntentId);

      res.json({
        status: result.status,
        succeeded: result.succeeded
      });
    } catch (error: any) {
      console.error('Payment confirmation failed:', error);
      res.status(500).json({
        message: 'Failed to confirm payment',
        error: error.message
      });
    }
  });

  // Create customer and set up payment method
  app.post("/api/payment/setup", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      
      // Create or retrieve customer
      let customerId = user.stripe_customer_id;
      
      if (!customerId) {
        // Create new customer
        const customer = await paymentService.createCustomer(
          user.email || `${user.username}@example.com`,
          user.display_name || user.username
        );
        
        customerId = customer.id;
        
        // Update user with customer ID
        try {
          await storage.updateUser(user.id, { stripe_customer_id: customerId });
        } catch (err) {
          console.error('Failed to update user with customer ID:', err);
        }
      }
      
      // Create setup intent for saving payment method
      const setupIntent = await paymentService.createSetupIntent(user.id);
      
      res.json({
        customerId,
        clientSecret: setupIntent.clientSecret
      });
    } catch (error: any) {
      console.error('Payment setup failed:', error);
      res.status(500).json({
        message: 'Failed to set up payment method',
        error: error.message
      });
    }
  });

  // Get saved payment methods
  app.get("/api/payment/methods", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      
      if (!user.stripe_customer_id) {
        return res.json([]);
      }
      
      // Get saved payment methods from Stripe
      const paymentMethods = await paymentService.getPaymentMethods(user.stripe_customer_id);
      
      // Get default payment method from database
      const savedMethods = await db.query.savedPaymentMethods.findMany({
        where: eq(schema.savedPaymentMethods.userId, user.id)
      });
      
      // Map payment methods to our format
      const formattedMethods = paymentMethods.map(pm => {
        // Find if this payment method is saved in our database
        const savedMethod = savedMethods.find(sm => sm.paymentMethodId === pm.id);
        const isDefault = savedMethod?.isDefault || false;
        
        // Parse metadata if it exists and is a string
        let metadataObj = null;
        if (savedMethod?.metadata && typeof savedMethod.metadata === 'string') {
          try {
            metadataObj = JSON.parse(savedMethod.metadata);
          } catch (err) {
            console.error('Error parsing payment method metadata:', err);
          }
        }
        
        return {
          id: pm.id,
          type: pm.type,
          brand: pm.card?.brand,
          last4: pm.card?.last4 || '****',
          expiryMonth: pm.card?.exp_month,
          expiryYear: pm.card?.exp_year,
          isDefault,
          holderName: metadataObj?.holderName || null
        };
      });
      
      res.json(formattedMethods);
    } catch (error: any) {
      console.error('Failed to get payment methods:', error);
      res.status(500).json({
        message: 'Failed to retrieve payment methods',
        error: error.message
      });
    }
  });
  
  // Add new payment method
  app.post("/api/payment/methods", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      const { number, name, expMonth, expYear, cvc } = req.body;
      
      // Get or create customer in Stripe
      let customerId = user.stripe_customer_id;
      if (!customerId) {
        const customer = await paymentService.createCustomer(
          user.email || `${user.username}@example.com`, 
          user.display_name || user.username
        );
        customerId = customer.id;
        
        // Update user record with customer ID
        await storage.updateUser(user.id, { stripe_customer_id: customerId });
      }
      
      // Create payment method in Stripe
      const paymentMethod = await paymentService.createPaymentMethod({
        type: 'card',
        card: {
          number,
          exp_month: expMonth,
          exp_year: expYear,
          cvc
        },
        billing_details: {
          name
        }
      });
      
      // Attach payment method to customer
      await paymentService.attachPaymentMethod(paymentMethod.id, customerId);
      
      // Check if this is the first payment method (make it default)
      const existingMethods = await db.query.savedPaymentMethods.findMany({
        where: eq(schema.savedPaymentMethods.userId, user.id)
      });
      
      const isDefault = existingMethods.length === 0;
      
      // Save payment method in our database
      await db.insert(schema.savedPaymentMethods).values({
        userId: user.id,
        paymentMethodId: paymentMethod.id,
        type: 'card',
        last4: paymentMethod.card?.last4 || '****',
        brand: paymentMethod.card?.brand || 'unknown',
        expiryMonth: parseInt(expMonth),
        expiryYear: parseInt(expYear),
        isDefault,
        metadata: JSON.stringify({ holderName: name })
      });
      
      // If this is the default method, also update in Stripe
      if (isDefault) {
        await paymentService.updateCustomerDefaultMethod(customerId, paymentMethod.id);
      }
      
      res.json({
        id: paymentMethod.id,
        type: 'card',
        brand: paymentMethod.card?.brand || 'unknown',
        last4: paymentMethod.card?.last4 || '****',
        expiryMonth: parseInt(expMonth),
        expiryYear: parseInt(expYear),
        isDefault,
        holderName: name
      });
    } catch (error: any) {
      console.error('Failed to add payment method:', error);
      res.status(500).json({
        message: 'Failed to add payment method',
        error: error.message
      });
    }
  });
  
  // Set default payment method
  app.post("/api/payment/methods/default", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      const { paymentMethodId } = req.body;
      
      if (!user.stripe_customer_id) {
        return res.status(400).json({ message: 'User does not have a customer ID' });
      }
      
      if (!paymentMethodId) {
        return res.status(400).json({ message: 'Payment method ID is required' });
      }
      
      // Update default payment method in Stripe
      await paymentService.updateCustomerDefaultMethod(user.stripe_customer_id, paymentMethodId);
      
      // Update all payment methods in our database (set all to non-default)
      await db.update(schema.savedPaymentMethods)
        .set({ isDefault: false })
        .where(eq(schema.savedPaymentMethods.userId, user.id));
      
      // Set the chosen payment method as default
      await db.update(schema.savedPaymentMethods)
        .set({ isDefault: true })
        .where(and(
          eq(schema.savedPaymentMethods.userId, user.id),
          eq(schema.savedPaymentMethods.paymentMethodId, paymentMethodId)
        ));
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to set default payment method:', error);
      res.status(500).json({
        message: 'Failed to set default payment method',
        error: error.message
      });
    }
  });
  
  // Delete payment method
  app.delete("/api/payment/methods/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      const paymentMethodId = req.params.id;
      
      if (!paymentMethodId) {
        return res.status(400).json({ message: 'Payment method ID is required' });
      }
      
      // Check if this payment method belongs to the user
      const paymentMethod = await db.query.savedPaymentMethods.findFirst({
        where: and(
          eq(schema.savedPaymentMethods.userId, user.id),
          eq(schema.savedPaymentMethods.paymentMethodId, paymentMethodId)
        )
      });
      
      if (!paymentMethod) {
        return res.status(404).json({ message: 'Payment method not found' });
      }
      
      // Check if this is the default method
      const isDefault = paymentMethod.isDefault;
      
      // Delete payment method from Stripe
      await paymentService.detachPaymentMethod(paymentMethodId);
      
      // Delete payment method from our database
      await db.delete(schema.savedPaymentMethods)
        .where(and(
          eq(schema.savedPaymentMethods.userId, user.id),
          eq(schema.savedPaymentMethods.paymentMethodId, paymentMethodId)
        ));
      
      // If this was the default method, set a new default if available
      if (isDefault) {
        const remainingMethods = await db.query.savedPaymentMethods.findMany({
          where: eq(schema.savedPaymentMethods.userId, user.id)
        });
        
        if (remainingMethods.length > 0) {
          const newDefaultId = remainingMethods[0].paymentMethodId;
          
          // Update default in our database
          await db.update(schema.savedPaymentMethods)
            .set({ isDefault: true })
            .where(and(
              eq(schema.savedPaymentMethods.userId, user.id),
              eq(schema.savedPaymentMethods.paymentMethodId, newDefaultId)
            ));
          
          // Update default in Stripe
          if (user.stripe_customer_id) {
            await paymentService.updateCustomerDefaultMethod(user.stripe_customer_id, newDefaultId);
          }
        }
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete payment method:', error);
      res.status(500).json({
        message: 'Failed to delete payment method',
        error: error.message
      });
    }
  });

  // Process refunds
  app.post("/api/payment/refund", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { paymentIntentId, amount } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: 'Payment intent ID is required' });
      }

      const refund = await paymentService.refundPayment(paymentIntentId, amount);
      
      res.json({
        refundId: refund.id,
        status: refund.status,
        amount: amount ? amount : refund.amount / 100 // Convert from cents
      });
    } catch (error: any) {
      console.error('Refund failed:', error);
      res.status(500).json({
        message: 'Failed to process refund',
        error: error.message
      });
    }
  });

  // Generate invoice
  app.post("/api/payment/invoice", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      const { items } = req.body;
      
      if (!user.stripe_customer_id) {
        return res.status(400).json({ message: 'User does not have a customer ID' });
      }
      
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ message: 'Invoice items are required' });
      }

      const invoice = await paymentService.generateInvoice(user.stripe_customer_id, items);
      
      res.json({
        invoiceId: invoice.id,
        status: invoice.status,
        total: invoice.total / 100, // Convert from cents
        invoiceUrl: invoice.hosted_invoice_url
      });
    } catch (error: any) {
      console.error('Invoice generation failed:', error);
      res.status(500).json({
        message: 'Failed to generate invoice',
        error: error.message
      });
    }
  });

  // Legacy payment route for backward compatibility
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { amount, bookingType, metadata } = req.body;
      const user = req.user as User;

      const result = await paymentService.createPaymentIntent(
        amount, 
        bookingType as BookingType, 
        { userId: user.id, ...metadata }
      );

      res.json({
        clientSecret: result.clientSecret,
        paymentIntentId: result.id
      });
    } catch (error: any) {
      console.error('Legacy payment intent creation failed:', error);
      res.status(500).json({
        message: 'Failed to create payment intent',
        error: error.message
      });
    }
  });
  
  // UPI Payment routes
  app.post("/api/payment/create-upi-request", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
      
      const { upiPaymentService } = await import('./services/upiPaymentService');
      const user = req.user as User;
      const { amount, bookingType, metadata = {}, upiId } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ 
          message: 'Invalid amount', 
          details: 'Amount must be a positive number'
        });
      }
      
      if (!bookingType) {
        return res.status(400).json({ 
          message: 'Missing booking type', 
          details: 'A valid booking type (flight, hotel, dining, ride) is required'
        });
      }
      
      console.log('Creating UPI payment request for user:', user.id, user.username);
      console.log('UPI Payment details:', { amount, bookingType, metadata, upiId });
      
      // Add user info to metadata
      const enrichedMetadata = {
        userId: user.id,
        username: user.username,
        email: user.email || 'no-email',
        ...metadata
      };
      
      // Create the UPI payment request
      const paymentRequest = await upiPaymentService.createPaymentRequest(
        amount,
        bookingType as BookingType,
        enrichedMetadata,
        upiId
      );
      
      res.status(200).json(paymentRequest);
    } catch (error: any) {
      console.error('Error creating UPI payment request:', error);
      res.status(500).json({ 
        message: 'Failed to create UPI payment request',
        details: error.message || 'Unknown error' 
      });
    }
  });
  
  app.post("/api/payment/verify-upi", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
      
      const { upiPaymentService } = await import('./services/upiPaymentService');
      const { referenceId } = req.body;
      
      if (!referenceId) {
        return res.status(400).json({ message: 'Reference ID is required' });
      }
      
      console.log('Verifying UPI payment:', referenceId);
      
      // Verify the UPI payment
      const verification = await upiPaymentService.verifyPayment(referenceId);
      
      res.status(200).json(verification);
    } catch (error: any) {
      console.error('Error verifying UPI payment:', error);
      res.status(500).json({ 
        message: 'Failed to verify UPI payment',
        details: error.message || 'Unknown error' 
      });
    }
  });

  // Keep existing routes...
  app.get("/api/hotels", async (req, res) => {
    try {
      const { location, checkIn, checkOut, guests, rating, priceRange } = req.query;
      
      // Validate required parameters
      if (!location) {
        return res.status(400).json({ message: 'Location is required' });
      }
      
      console.log('Hotel search params:', { location, checkIn, checkOut, guests, rating, priceRange });
      
      // Try to get real-time hotel data from RapidAPI
      try {
        if (location && checkIn && checkOut) {
          const guestCount = guests ? parseInt(guests as string) : 2;
          
          // Use RapidAPI for real-time hotel data
          const rapidApiHotels = await rapidApiService.searchHotels(
            location as string,
            checkIn as string,
            checkOut as string,
            guestCount
          );
          
          if (rapidApiHotels && rapidApiHotels.length > 0) {
            console.log(`Retrieved ${rapidApiHotels.length} hotels from RapidAPI`);
            return res.json(rapidApiHotels);
          }
        }
        
        // If RapidAPI doesn't return results, fallback to our internal hotel service
        console.log('Falling back to internal hotel service');
        const internalHotels = await hotelService.searchHotels({
          location: location as string,
          rating: rating ? parseInt(rating as string) : undefined,
          priceRange: priceRange as string,
        });
        
        if (internalHotels && internalHotels.length > 0) {
          console.log(`Retrieved ${internalHotels.length} hotels from internal service`);
          return res.json(internalHotels);
        }
        
        // If no results are found with either service
        return res.json({
          hotels: [],
          message: 'No hotels found matching your criteria. Try different search parameters.'
        });

      } catch (apiError) {
        console.error('Hotel API search error:', apiError);
        
        // Try the internal service on API error
        try {
          const internalHotels = await hotelService.searchHotels({
            location: location as string,
            rating: rating ? parseInt(rating as string) : undefined,
            priceRange: priceRange as string,
          });
          
          if (internalHotels && internalHotels.length > 0) {
            console.log(`Retrieved ${internalHotels.length} hotels from internal service after API error`);
            return res.json(internalHotels);
          }
          
          // If no hotels found with internal service either
          return res.json({
            hotels: [],
            message: 'No hotels found matching your criteria. Try different search parameters.'
          });
        } catch (internalError) {
          console.error('Internal hotel service error:', internalError);
          return res.status(503).json({
            message: 'Unable to fetch hotel data at this time. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? apiError.message : undefined
          });
        }
      }
    } catch (error) {
      console.error('Hotel search error:', error);
      res.status(500).json({
        message: 'Failed to search for hotels', 
        hotels: []
      });
    }
  });

  app.get("/api/rides", async (req, res) => {
    try {
      const { from, to, type, passengers } = req.query;
      
      // Validate required parameters
      if (!from) {
        return res.status(400).json({ message: 'Origin location is required' });
      }
      
      console.log('Ride search params:', { from, to, type, passengers });
      
      // Get real-time ride data from our ride service
      const rides = await rideService.searchRides({
        from: from as string,
        to: to as string,
        type: type as string,
        passengers: passengers ? parseInt(passengers as string) : undefined
      });
      
      if (rides && rides.length > 0) {
        console.log(`Retrieved ${rides.length} rides from ride service`);
        return res.json(rides);
      }
      
      // If no rides were found, return empty array with message
      return res.json({
        rides: [],
        message: 'No rides available for this route at the moment'
      });
    } catch (error) {
      console.error('Ride search error:', error);
      res.status(500).json({ 
        message: 'Failed to search for rides',
        rides: []
      });
    }
  });
  
  app.get("/api/activities", async (req, res) => {
    try {
      // Default to a popular city if no location is specified
      const { location = "New York" } = req.query;
      
      console.log('Activities search params:', { location });
      
      // Get real-time attractions data from RapidAPI
      try {
        const activities = await rapidApiService.searchAttractions(location as string);
        
        if (activities && activities.length > 0) {
          console.log(`Retrieved ${activities.length} activities from RapidAPI`);
          return res.json(activities);
        }
        
        // If no activities are found, return an empty array
        return res.json([]);
      } catch (apiError: any) {
        console.error('Activities API search error:', apiError.message || apiError);
        // Return empty array on API error to maintain consistent response format
        return res.json([]);
      }
    } catch (error: any) {
      console.error('Activities endpoint error:', error);
      res.status(500).json([]);
    }
  });

  app.get("/api/events", async (req, res) => {
    try {
      // Default to a popular city if no location is specified
      const { location = "New York" } = req.query;
      
      console.log('Events search params:', { location });
      
      // Get real-time events data from RapidAPI
      try {
        const events = await rapidApiService.searchEvents(location as string);
        
        if (events && events.length > 0) {
          console.log(`Retrieved ${events.length} events from RapidAPI`);
          return res.json(events);
        }
        
        // If no events are found, return an empty array
        return res.json([]);
      } catch (apiError: any) {
        console.error('Events API search error:', apiError.message || apiError);
        // Return empty array on API error to maintain consistent response format
        return res.json([]);
      }
    } catch (error: any) {
      console.error('Events endpoint error:', error);
      res.status(500).json([]);
    }
  });

  app.get("/api/attractions", async (req, res) => {
    try {
      const { location } = req.query;
      
      // Validate required parameters
      if (!location) {
        return res.status(400).json({ message: 'Location is required' });
      }
      
      console.log('Attractions search params:', { location });
      
      // Get real-time attractions data from RapidAPI
      try {
        const attractions = await rapidApiService.searchAttractions(location as string);
        
        if (attractions && attractions.length > 0) {
          console.log(`Retrieved ${attractions.length} attractions from RapidAPI`);
          return res.json(attractions);
        }
        
        // If no attractions are found, return an empty array with a message
        return res.json({
          attractions: [],
          message: 'No attractions found for this location'
        });
      } catch (apiError) {
        console.error('Attractions API search error:', apiError);
        // Return empty results on API error
        return res.json({
          attractions: [],
          message: 'Unable to retrieve attractions at this time'
        });
      }
    } catch (error) {
      console.error('Attractions search error:', error);
      res.status(500).json({ 
        message: 'Failed to search for attractions',
        attractions: []
      });
    }
  });

  app.get("/api/dining", async (req, res) => {
    try {
      const { location, cuisine } = req.query;
      
      // Validate required parameters
      if (!location) {
        return res.status(400).json({ message: 'Location is required' });
      }
      
      console.log('Restaurant search params:', { location, cuisine });
      
      // Try to get real-time restaurant data from RapidAPI
      try {
        const restaurants = await rapidApiService.searchRestaurants(
          location as string, 
          cuisine as string
        );
        
        if (restaurants && restaurants.length > 0) {
          console.log(`Retrieved ${restaurants.length} restaurants from RapidAPI`);
          return res.json(restaurants);
        }
        
        // If no results are found, return empty array with a message
        return res.json({
          restaurants: [],
          message: 'No restaurants found for this location and cuisine'
        });
      } catch (apiError) {
        console.error('Restaurant API search error:', apiError);
        // Return an informative error
        return res.status(503).json({
          message: 'Unable to fetch restaurant data at this time. Please try again later.',
          error: process.env.NODE_ENV === 'development' ? apiError.message : undefined
        });
      }
    } catch (error) {
      console.error('Restaurant search error:', error);
      res.status(500).json({
        message: 'Failed to search for restaurants', 
        restaurants: []
      });
    }
  });

  app.post("/api/payment/confirm/:paymentIntentId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { paymentIntentId } = req.params;
      const { bookingDetails } = req.body;

      if (!stripe) {
        return res.status(500).json({ message: 'Stripe not initialized' });
      }

      // Retrieve the payment intent to verify its status
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

      if (paymentIntent.status === 'succeeded') {
        // Create itinerary record
        const [itinerary] = await db
          .insert(schema.itineraries)
          .values({
            userId: (req.user as schema.User).id,
            totalAmount: bookingDetails.amount,
            paymentStatus: 'completed',
            bookingDetails: bookingDetails,
            paymentIntentId: paymentIntentId
          })
          .returning();

        res.json({
          success: true,
          paymentIntent,
          itinerary
        });
      } else {
        res.status(400).json({
          success: false,
          message: `Payment not successful. Status: ${paymentIntent.status}`
        });
      }
    } catch (error) {
      console.error('Payment confirmation failed:', error);
      res.status(500).json({ message: 'Failed to confirm payment' });
    }
  });

  app.get("/api/itineraries/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { id } = req.params;

      const itinerary = await db.query.itineraries.findFirst({
        where: eq(schema.itineraries.id, parseInt(id)),
        with: {
          passengers: true
        }
      });

      if (!itinerary) {
        return res.status(404).json({ message: 'Itinerary not found' });
      }

      if (itinerary.userId !== (req.user as schema.User).id) {
        return res.status(403).json({ message: 'Unauthorized access to itinerary' });
      }

      res.json(itinerary);
    } catch (error) {
      console.error('Failed to retrieve itinerary:', error);
      res.status(500).json({ message: 'Failed to retrieve itinerary' });
    }
  });

  app.post("/api/ai/cultural-insights", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { location } = req.body;
      console.log('Cultural insights request:', {
        userId: (req.user as User)?.id,
        location
      });

      if (!location) {
        return res.status(400).json({ message: 'Location is required' });
      }

      const insights = await aiService.getCulturalInsights(location);
      console.log('Cultural insights generated:', {
        userId: (req.user as User)?.id,
        location,
        hasInsights: !!insights
      });

      res.json({ insights });
    } catch (error) {
      console.error('Cultural insights error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to get cultural insights'
      });
    }
  });

  app.post("/api/ai/smart-booking", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination, dates, preferences } = req.body;

      if (!destination || !dates) {
        return res.status(400).json({ message: 'Destination and dates are required' });
      }

      console.log('Smart booking request:', {
        userId: (req.user as User)?.id,
        destination,
        dates
      });

      const recommendations = await aiService.getSmartBookingRecommendations(
        destination,
        dates,
        preferences
      );

      res.json({ recommendations });
    } catch (error) {
      console.error('Smart booking error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to get booking recommendations'
      });
    }
  });

  app.post("/api/ai/travel-trends", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination } = req.body;

      if (!destination) {
        return res.status(400).json({ message: 'Destination is required' });
      }

      console.log('Travel trends request:', {
        userId: (req.user as User)?.id,
        destination
      });

      const trends = await aiService.analyzeTravelTrends(destination);
      res.json({ trends });
    } catch (error) {
      console.error('Travel trends error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to analyze travel trends'
      });
    }
  });

  // Legacy trip-plan route is now disabled in favor of the new route in ai-trip-planner.ts
  /*
  app.post("/api/ai/trip-plan", async (req, res) => {
    try {
      const isDevelopment = app.get("env") === "development";

      if (!isDevelopment && !req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination, dates, preferences } = req.body;

      if (!destination || !dates) {
        return res.status(400).json({ message: 'Destination and dates are required' });
      }

      console.log('Trip plan request:', {
        userId: req.user?.id || 'guest',
        destination,
        dates,
        preferences
      });
      
      // Check for required API keys
      if (!process.env.RAPID_API_KEY) {
        console.warn('RAPID_API_KEY is not configured. Travel data might be limited.');
        return res.status(503).json({
          message: "Missing travel data API credentials. Please configure RAPID_API_KEY.",
          error: "missing_api_credentials"
        });
      }

      try {
        // Try to generate trip plan with real data
        const tripPlan = await aiService.generateDetailedTripPlan(
          destination,
          dates,
          preferences || {},
          req.user as User || { id: 0, username: 'guest', preferences: {} }
        );

        if (!tripPlan) {
          throw new Error('Failed to generate trip plan');
        }

        res.json({ plan: tripPlan });
      } catch (aiError: any) {
        // Handle OpenAI-specific errors
        if (aiError.message && (
            aiError.message.includes("rate limit") || 
            aiError.message.includes("exceeded your current quota") ||
            aiError.message.includes("insufficient_quota")
          )) {
          console.error('AI API limit reached:', aiError.message);
          
          // Try to continue with basic data without AI enhancement
          return res.status(429).json({
            message: "AI service temporarily unavailable. Please try again later.",
            error: "ai_service_unavailable"
          });
        }
        
        // Re-throw other errors to be caught by the outer catch block
        throw aiError;
      }
    } catch (error: any) {
      console.error('Trip planning error:', error);
      
      let statusCode = 500;
      let errorMessage = "Failed to generate trip plan. Please try again.";
      let errorCode = "server_error";
      
      // Determine specific error types
      if (error.message && error.message.includes('RAPID_API_KEY')) {
        statusCode = 503;
        errorMessage = "Missing travel data API credentials. Please contact support.";
        errorCode = "api_credentials_error";
      } else if (error.response && error.response.status === 429) {
        statusCode = 429;
        errorMessage = "External API rate limit reached. Please try again later.";
        errorCode = "rate_limit_error";
      } else if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
        statusCode = 503;
        errorMessage = "Cannot connect to external API services. Please try again later.";
        errorCode = "api_connection_error";
      }
      
      res.status(statusCode).json({
        message: errorMessage,
        error: isDevelopment ? error.message : errorCode
      });
    }
  });
  */

  app.post("/api/ai/optimize-schedule", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { plan, constraints } = req.body;

      if (!plan) {
        return res.status(400).json({ message: 'Existing plan is required' });
      }

      console.log('Schedule optimization request:', {
        userId: (req.user as User)?.id,
        planId: plan.id
      });

      const optimizedPlan = await aiService.optimizeTripSchedule(plan, constraints);
      res.json({ plan: optimizedPlan });
    } catch (error) {
      console.error('Schedule optimization error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to optimize schedule'
      });
    }
  });

  app.post("/api/ai/activity-alternatives", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { activity, context } = req.body;

      if (!activity || !context) {
        return res.status(400).json({ message: 'Activity and context are required' });
      }

      console.log('Alternative activities request:', {
        userId: (req.user as User)?.id,
        activityId: activity.id
      });

      const alternatives = await aiService.suggestDynamicAlternatives(activity, context);
      res.json({ alternatives });
    } catch (error) {
      console.error('Activity alternatives error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to suggest alternatives'
      });
    }
  });

  app.post("/api/ai/analyze-behavior", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { searchHistory, bookingHistory } = req.body;
      console.log('Analyzing behavior for user:', (req.user as User)?.id);

      const analysis = await aiService.analyzeUserBehavior(
        req.user as User,
        searchHistory,
        bookingHistory
      );

      res.json({ analysis });
    } catch (error) {
      console.error('Behavior analysis error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to analyze behavior'
      });
    }
  });

  app.post("/api/ai/itinerary-optimization", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { itinerary, preferences } = req.body;
      if (!itinerary) {
        return res.status(400).json({ message: 'Itinerary is required' });
      }

      console.log('Itinerary optimization request:', {
        userId: (req.user as User)?.id,
        itineraryLength: itinerary.length
      });

      const optimization = await aiService.getItineraryOptimizations(itinerary, preferences);
      res.json({ optimization });
    } catch (error) {
      console.error('Itinerary optimization error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to optimize itinerary'
      });
    }
  });

  app.post("/api/ai/travel-guide", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination, duration } = req.body;
      if (!destination || !duration) {
        return res.status(400).json({ message: 'Destination and duration are required' });
      }

      console.log('Travel guide request:', {
        userId: (req.user as User)?.id,
        destination,
        duration
      });

      const guide = await aiService.getCustomizedTravelGuide(
        destination,
        (req.user as User).preferences,
        duration
      );
      res.json({ guide });
    } catch (error) {
      console.error('Travel guide error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to generate travel guide'
      });
    }
  });

  // Update the chatbot response handling
  app.post("/api/chatbot", async (req, res) => {
    try {
      const { message, chatHistory, preferences } = req.body;

      // Log incoming request
      console.log('Chatbot request:', {
        messageLength: message.length,
        historyLength: chatHistory?.length || 0,
        hasPreferences: !!preferences
      });

      // Basic message validation
      if (!message || typeof message !== 'string') {
        return res.status(400).json({
          response: {
            message: "Please provide a valid message",
            type: "general",
            suggestions: ["Tell me about travel destinations", "Help plan a trip"]
          }
        });
      }

      // Return default response since aiService.getChatbotResponse is not implemented
      res.json({
        response: {
          message: "I'm here to help with your travel planning! Here are some things I can assist you with:\n• Find destinations based on your interests\n• Plan your itinerary\n• Get local recommendations\n• Help with travel arrangements",
          type: "general",
          suggestions: [
            "Popular destinations",
            "Trip planning help",
            "Local recommendations",
            "Travel tips"
          ],
          context: {
            followUpQuestions: [
              "What are the top destinations to visit?",
              "How can I plan a budget-friendly trip?",
              "What should I pack for my trip?"
            ]
          }
        }
      });
    } catch (error) {
      console.error('Chatbot endpoint error:', error);
      res.status(500).json({
        response: {
          message: "I'm having trouble right now, but I can help you with travel planning when I'm back online.",
          type: "general",
          suggestions: ["Try again later"]
        }
      });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { message, context, history } = req.body;
      const isDevelopment = app.get("env") === "development";

      // Basic validation
      if (!message || typeof message !== 'string') {
        return res.status(400).json({
          message: "Please provide a valid message",
          suggestions: ["Tell me about travel destinations", "Help plan a trip"]
        });
      }

      console.log('Chat request:', {
        messageLength: message.length,
        historyLength: history?.length || 0,
        context
      });

      // Get user from session or use a default user for development
      const user = req.isAuthenticated() 
        ? req.user as User
        : { 
            id: 0, 
            username: 'guest', 
            preferences: {}, 
            guest: true,
            email: null,
            phone: null,
            createdAt: new Date()
          };
      
      try {
        // Use the AIService to get a response
        const result = await aiService.handleChatbotMessage(
          message,
          user,
          undefined, // currentLocation
          history?.map(msg => ({ role: msg.role, content: msg.content })) || []
        );

        res.json(result);
      } catch (error) {
        console.error('OpenAI API error:', error);
        
        // Send a fallback response
        res.json({
          message: "I'm having trouble connecting to my knowledge base right now. I can still help with basic travel inquiries though!",
          suggestions: [
            "Popular destinations",
            "Trip planning help",
            "Travel tips"
          ],
          type: "general"
        });
      }
    } catch (error) {
      console.error('Chat endpoint error:', error);
      const isDevelopment = app.get("env") === "development";
      
      let statusCode = 500;
      let errorMessage = "Internal server error";
      let errorCode = "unknown_error";
      
      if (error instanceof Error) {
        if (error.message.includes('API key')) {
          statusCode = 401;
          errorMessage = "AI service configuration error. Please try again later.";
          errorCode = "api_key_error";
        } else if (error.message.includes('exceeded your current quota')) {
          statusCode = 429;
          errorMessage = "AI service usage limit reached. Please try again later.";
          errorCode = "quota_exceeded";
        } else if (error.message.includes('rate limit')) {
          statusCode = 429;
          errorMessage = "Too many requests. Please try again in a moment.";
          errorCode = "rate_limit_error";
        }
      }
      
      res.status(statusCode).json({
        message: errorMessage,
        error: isDevelopment ? error.message : errorCode
      });
    }
  });

  app.get("/api/ai/proactive-suggestions", async (req, res) => {
    try {
      const isDevelopment = app.get("env") === "development";

      // In development, don't require authentication
      if (!isDevelopment && !req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user || {
        id: 'guest',
        preferences: {}
      };

      console.log('Generating proactive suggestions for user:', user.id);

      try {
        // First, check if OpenAI API is available by doing a simple check
        if (process.env.API_QUOTA_EXCEEDED === 'true') {
          console.log('API quota known to be exceeded, generating data-driven suggestions without analysis');
          // Skip the analyze step and go straight to suggestions with default preferences
          const defaultPreferences = {
            interests: user.preferences?.interests || ['culture', 'food', 'nature'],
            travelStyle: user.preferences?.travelStyle || 'moderate',
            preferredDestinations: user.preferences?.preferredDestinations || [],
            budgetRange: user.preferences?.budgetRange || { min: 1000, max: 3000 },
            seasonalPreferences: user.preferences?.seasonalPreferences || []
          };
          
          // Use our data-driven suggestion generator
          const suggestions = await aiService.createPersonalizedSuggestions(
            defaultPreferences,
            new Date().toISOString()
          );
          
          return res.json({
            suggestions: suggestions,
            userAnalysis: defaultPreferences,
            note: "Generated from user preferences (API quota limit reached)"
          });
        }
        
        // First analyze user behavior with basic preferences
        const analysis = await aiService.analyzeUserBehavior(
          user,
          [], // We'll implement search history tracking later
          []  // We'll implement booking history tracking later
        );

        // Generate suggestions based on the analysis
        const suggestions = await aiService.generateProactiveSuggestions(
          analysis,
          new Date().toISOString()
        );

        // If we have suggestions, enhance them with additional data
        if (suggestions && Array.isArray(suggestions)) {
          try {
            // For each suggestion, fetch relevant local events
            const enhancedSuggestions = await Promise.all(
              suggestions.map(async (suggestion) => {
                let events = [];
                let guide = {};
                let trends = {};
                let bookingOptions = {};
                
                try {
                  // Try to get local events with a timeout
                  events = await Promise.race([
                    aiService.getLocalEvents(suggestion.destination, {
                      start: new Date().toISOString(),
                      end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // Next 30 days
                    }),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Events API timeout')), 5000))
                  ]);
                } catch (eventsError) {
                  console.warn(`Could not fetch events for ${suggestion.destination}:`, eventsError.message);
                  // Continue without events data
                }
                
                try {
                  // Try to get travel guide with a timeout
                  guide = await Promise.race([
                    aiService.getCustomizedTravelGuide(suggestion.destination, user.preferences, 7), // Default to a week-long trip
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Guide API timeout')), 5000))
                  ]);
                } catch (guideError) {
                  console.warn(`Could not fetch travel guide for ${suggestion.destination}:`, guideError.message);
                  // Continue without guide data
                }
                
                try {
                  // Try to get travel trends with a timeout
                  trends = await Promise.race([
                    aiService.analyzeTravelTrends(suggestion.destination),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Trends API timeout')), 5000))
                  ]);
                } catch (trendsError) {
                  console.warn(`Could not fetch trends for ${suggestion.destination}:`, trendsError.message);
                  // Continue without trends data
                }
                
                try {
                  // Try to get booking recommendations with a timeout
                  bookingOptions = await Promise.race([
                    aiService.getSmartBookingRecommendations(
                      suggestion.destination,
                      {
                        start: new Date().toISOString(),
                        end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
                      },
                      user.preferences
                    ),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Booking API timeout')), 5000))
                  ]);
                } catch (bookingError) {
                  console.warn(`Could not fetch booking options for ${suggestion.destination}:`, bookingError.message);
                  // Continue without booking data
                }

                return {
                  ...suggestion,
                  events: events || [],
                  guide: guide || {},
                  trends: trends || {},
                  bookingOptions: bookingOptions || {}
                };
              })
            );
            
            res.json({
              suggestions: enhancedSuggestions,
              userAnalysis: analysis
            });
          } catch (enhancementError) {
            console.error('Error enhancing suggestions:', enhancementError);
            
            // Return the base suggestions without enhancements
            res.json({
              suggestions: suggestions,
              userAnalysis: analysis,
              note: "Basic suggestions provided (enhancement failed)"
            });
          }
        } else {
          // No suggestions were generated, return empty array
          res.json({
            suggestions: [],
            userAnalysis: analysis || {},
            note: "No suggestions could be generated"
          });
        }
      } catch (innerError) {
        console.error('Error in generateProactiveSuggestions inner block:', innerError);
        
        // Fallback to direct user preferences if available
        const defaultPreferences = {
          interests: user.preferences?.interests || ['culture', 'food', 'nature'],
          travelStyle: user.preferences?.travelStyle || 'moderate',
          preferredDestinations: user.preferences?.preferredDestinations || [],
          budgetRange: user.preferences?.budgetRange || { min: 1000, max: 3000 },
          seasonalPreferences: user.preferences?.seasonalPreferences || []
        };
        
        // Use our data-driven suggestion generator as final fallback
        const fallbackSuggestions = await aiService.createPersonalizedSuggestions(
          defaultPreferences,
          new Date().toISOString()
        );
        
        res.json({
          suggestions: fallbackSuggestions,
          userAnalysis: defaultPreferences,
          note: "Generated from user preferences (fallback mechanism)"
        });
      }
    } catch (error) {
      console.error('Enhanced proactive suggestions error:', error);
      
      // Final fallback if everything else fails
      try {
        // Create basic suggestions using hardcoded season-based destinations
        const month = new Date().getMonth();
        let season = '';
        if (month >= 2 && month <= 4) season = 'spring';
        else if (month >= 5 && month <= 7) season = 'summer';
        else if (month >= 8 && month <= 10) season = 'fall';
        else season = 'winter';
        
        const emergencyFallbackSuggestions = [
          {
            destination: season === 'summer' ? 'Barcelona' : season === 'spring' ? 'Tokyo' : season === 'fall' ? 'New York' : 'Zurich',
            reason: `Perfect destination for ${season}`,
            timing: `Best in ${season}`,
            confidence: 0.75,
            estimatedBudget: 2500,
            activities: ['Cultural tours', 'Local cuisine', 'Sightseeing'],
            weatherPrediction: `Typical ${season} weather`,
            localEvents: []
          }
        ];
        
        res.status(500).json({
          suggestions: emergencyFallbackSuggestions,
          userAnalysis: {},
          error: error instanceof Error ? error.message : 'Failed to generate suggestions',
          note: "Emergency fallback suggestions provided"
        });
      } catch (finalError) {
        // Last resort - just return the error
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to generate suggestions',
          suggestions: []
        });
      }
    }
  });

  app.post("/api/log", (req, res) => {
    try {
      // Log client-side errors to server console
      console.error('Client-side error:', req.body);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error logging client error:', error);
      res.status(500).json({ success: false });
    }
  });

  app.post("/api/ai/local-events", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { location, dates } = req.body;

      if (!location || !dates) {
        return res.status(400).json({ message: 'Location and dates are required' });
      }

      const events = await aiService.getLocalEvents(location, dates);
      res.json({ events });
    } catch (error) {
      console.error('Local events error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to fetch local events'
      });
    }
  });

  // General destinations query endpoint
  // Main destinations listing endpoint
  app.get("/api/destinations", async (req, res) => {
    try {
      const { q, type, price } = req.query;
      const { destinationService } = await import('./services/destinationService');
      
      console.log('Searching destinations with params:', { q, type, price });
      
      // Get destinations using real data source
      const destinations = await destinationService.getDestinations(
        q as string, 
        type as string, 
        price as string
      );
      
      console.log(`Fetched ${destinations.length} destinations with query:`, req.query);
      
      res.json(destinations);
    } catch (error) {
      console.error('Error fetching destinations:', error);
      res.status(500).json({
        message: 'Failed to fetch destinations',
        error: app.get("env") === "development" ? (error as Error).message : undefined
      });
    }
  });

  // Explore destinations endpoint with TravelGlobe branding
  app.get("/api/destinations/explore", async (req, res) => {
    try {
      const { destinationService } = await import('./services/destinationService');
      
      // Get featured destinations with TravelGlobe branding
      const destinations = await destinationService.getDestinations('popular attractions');
      
      console.log(`Fetched ${destinations.length} destinations for explore page`);
      
      res.json({
        name: 'explore',
        provider: 'TravelGlobe.au',
        eventCount: destinations.length,
        destinations: destinations.slice(0, 12) // Limit to 12 featured destinations
      });
    } catch (error) {
      console.error('Error getting explore destinations:', error);
      res.status(500).json({ 
        error: 'Failed to fetch explore destinations',
        message: app.get("env") === "development" ? (error as Error).message : undefined 
      });
    }
  });
  
  // Featured country endpoint - returns the current featured country
  app.get("/api/destinations/featured-country", async (req, res) => {
    try {
      const { destinationService } = await import('./services/destinationService');
      
      // Get current featured country
      const featuredCountry = destinationService.getCurrentFeaturedCountry();
      
      if (!featuredCountry) {
        return res.status(404).json({ 
          error: 'No featured country available'
        });
      }
      
      console.log(`Retrieved featured country: ${featuredCountry.name}`);
      
      res.json({
        ...featuredCountry,
        flagUrl: `/public/${featuredCountry.code.toLowerCase()}-flag.svg`,
        provider: 'TravelGlobe.au'
      });
    } catch (error) {
      console.error('Error getting featured country:', error);
      res.status(500).json({ 
        error: 'Failed to fetch featured country',
        message: app.get("env") === "development" ? (error as Error).message : undefined 
      });
    }
  });
  
  // Featured destinations endpoint - returns destinations from the featured country
  app.get("/api/destinations/featured", async (req, res) => {
    try {
      const { destinationService } = await import('./services/destinationService');
      
      // Get destinations for the featured country
      const featuredDestinations = await destinationService.getFeaturedDestinations();
      const featuredCountry = destinationService.getCurrentFeaturedCountry();
      
      console.log(`Fetched ${featuredDestinations.length} destinations for featured country: ${featuredCountry?.name || 'unknown'}`);
      
      res.json({
        name: 'featured',
        provider: 'TravelGlobe.au',
        featuredCountry: featuredCountry?.name || 'Global Destinations',
        featuredCountryCode: featuredCountry?.code || 'GLOBAL',
        eventCount: featuredDestinations.length,
        destinations: featuredDestinations.slice(0, 10) // Limit to 10 featured destinations
      });
    } catch (error) {
      console.error('Error getting featured destinations:', error);
      res.status(500).json({ 
        error: 'Failed to fetch featured destinations',
        message: app.get("env") === "development" ? (error as Error).message : undefined 
      });
    }
  });

  app.get("/api/destinations/:id", async (req, res) => {
    try {
      const isDevelopment = app.get("env") === "development";
      const { id } = req.params;
      const destination = decodeURIComponent(id);

      console.log('Fetching destination data for:', destination);

      // Get destination insights from AI service
      const insights = await aiService.generateTripInsights(
        destination,
        {
          start: new Date().toISOString(),
          end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        }
      ).catch(error => {
        console.error('Error getting trip insights:', error);
        return {
          seasonalHighlights: [],
          weatherInsights: 'Weather information unavailable',
          crowdPredictions: { default: 'Moderate' }
        };
      });

      // Get local events
      const events = await aiService.getLocalEvents(
        destination,
        {
          start: new Date().toISOString(),
          end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        }
      ).catch(error => {
        console.error('Error getting local events:', error);
        return [];
      });

      // Get weather insights - don't require authentication in development
      const userPreferences = (!isDevelopment && req.isAuthenticated())
        ? req.user?.preferences || {}
        : {};

      const weatherInfo = await aiService.getCustomizedTravelGuide(
        destination,
        userPreferences,
        7
      ).catch(error => {
        console.error('Error getting travel guide:', error);
        return { customTips: [] };
      });

      const destinationData = {
        name: destination,
        description: insights.seasonalHighlights.join(' '),
        region: destination.split(',').slice(-1)[0].trim(),
        weather: weatherInfo.customTips.find(tip => tip.includes('weather')) || insights.weatherInsights,
        crowdLevel: insights.crowdPredictions[Object.keys(insights.crowdPredictions)[0]],
        events: events.map(event => ({
          ...event,
          id: `${event.name}-${event.date}`.toLowerCase().replace(/\s+/g, '-')
        })),
        image: `https://source.unsplash.com/1600x900/?${encodeURIComponent(destination)},landmark`
      };

      console.log('Sending destination data:', {
        name: destinationData.name,
        eventCount: destinationData.events.length
      });

      res.json(destinationData);
    } catch (error) {
      console.error('Error fetching destination data:', error);
      res.status(500).json({
        message: 'Failed to fetch destination data',
        error: app.get("env") === "development" ? error.message : undefined
      });
    }
  });


  app.get("/api/flights/search", async (req, res) => {
    try {
      // Make sure we handle both parameter naming conventions
      const { origin, destination, date, passengers, from, to } = req.query;
      
      // Use either origin/destination or from/to parameter sets
      const originCode = origin || from;
      const destinationCode = destination || to;

      // Validate required parameters
      if (!originCode || !destinationCode || !date) {
        return res.status(400).json({ 
          message: 'Origin, destination, and date are required parameters',
          flights: []
        });
      }

      console.log('Searching flights with params:', { origin: originCode, destination: destinationCode, date, passengers });

      // Use real-time flight data from available APIs
      try {
        // Use IATA codes for airports
        const fromCode = String(originCode).trim().toUpperCase();
        const toCode = String(destinationCode).trim().toUpperCase();
        const flightDate = String(date);
        const passengerCount = passengers ? parseInt(String(passengers)) : 1;

        // First try the RapidAPI service (Skyscanner)
        try {
          console.log(`Attempting RapidAPI flight search: ${fromCode} to ${toCode} on ${flightDate}`);
          const flights = await rapidApiService.searchFlights(
            fromCode, 
            toCode, 
            flightDate, 
            undefined, // returnDate
            passengerCount
          );

          console.log('RapidAPI response type:', typeof flights);
          console.log('RapidAPI response array?', Array.isArray(flights));
          console.log('RapidAPI response length:', flights ? flights.length : 'undefined');

          if (flights && flights.length > 0) {
            console.log(`Retrieved ${flights.length} flights from RapidAPI`);
            return res.json(flights);
          }
        } catch (rapidApiError) {
          console.error('RapidAPI flight search error:', rapidApiError);
          // Continue to next data source
        }

        // Try Aviation API if RapidAPI returns no results
        console.log('Trying Aviation API for flight data');
        try {
          const aviationFlights = await flightService.searchFlights({
            dep_iata: fromCode,
            arr_iata: toCode, 
            flight_date: flightDate
          });

          if (aviationFlights && aviationFlights.length > 0) {
            // Transform the data to match our application's format
            const formattedFlights = aviationFlights.map(flight => {
              // Calculate a consistent price based on route distance
              // This would ideally come from a pricing API in production
              const originCode = flight.departure.iata || '';
              const destCode = flight.arrival.iata || '';
              
              return {
                id: `flight-${flight.flight.iata}-${new Date(flight.departure.scheduled).toISOString().split('T')[0]}`,
                airline: flight.airline.name,
                flightNumber: flight.flight.iata,
                from: flight.departure.iata,
                to: flight.arrival.iata,
                departure: flight.departure.scheduled,
                arrival: flight.arrival.scheduled,
                departureAirport: flight.departure.airport,
                arrivalAirport: flight.arrival.airport,
                price: "Check at booking", // Price data would come from a separate pricing API in production
                class: 'Economy',
                availableSeats: "Limited availability", // Seat availability would come from a separate inventory API
                duration: calculateDuration(new Date(flight.departure.scheduled), new Date(flight.arrival.scheduled)),
                stops: 0,
                status: flight.flight_status
              };
            });
            
            console.log(`Retrieved ${formattedFlights.length} flights from Aviation API`);
            return res.json(formattedFlights);
          }
        } catch (aviationApiError) {
          console.error('Aviation API flight search error:', aviationApiError);
          // Continue to return empty results
        }

        // Fallback if all API attempts were made but no flights were found
        console.log('All flight data sources tried, but no flights found. Using generated sample flight data.');
        
        // Use generated sample flight data instead of returning empty results
        try {
          // Use the imported generateSampleFlights function
          const sampleFlights = generateSampleFlights(
            fromCode, 
            toCode, 
            flightDate,
            8  // Generate 8 sample flights
          );
          
          console.log(`Generated ${sampleFlights.length} sample flights for demonstration`);
          return res.json(sampleFlights);
        } catch (generateError) {
          console.error('Error generating sample flights:', generateError);
          
          // In case of generation error, return the standard empty response
          const rapidApiKeyAvailable = process.env.RAPID_API_KEY ? true : false;
          const aviationApiKeyAvailable = process.env.AVIATION_API_KEY ? true : false;
          
          return res.json({
            flights: [],
            error: true,
            message: 'No flights available for this route',
            apiStatus: {
              rapidApi: rapidApiKeyAvailable ? 'Endpoint returned no results' : 'API key not configured',
              aviationStack: aviationApiKeyAvailable ? 'Free tier limitations for flight search' : 'API key not configured'
            }
          });
        }
      } catch (apiError) {
        console.error('All flight search APIs failed:', apiError);
        // Return informative error
        return res.status(503).json({
          message: 'Unable to fetch flight data at this time. Please try again later.',
          error: process.env.NODE_ENV === 'development' ? apiError.message : undefined,
          flights: []
        });
      }
    } catch (error) {
      console.error('Flight search error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to search flights',
        flights: []
      });
    }
  });

  // Helper function to calculate flight duration
  function calculateDuration(departure: Date, arrival: Date): string {
    const durationMs = arrival.getTime() - departure.getTime();
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  }

    app.get("/api/flights/:flightNumber", async (req, res) => {
      try {
        const { flightNumber } = req.params;
        
        if (!flightNumber || flightNumber.trim() === '') {
          return res.status(400).json({ 
            message: 'Flight number is required',
            flight: null
          });
        }
        
        try {
          console.log(`Looking up flight details for flight: ${flightNumber}`);
          const flight = await flightService.getFlightByNumber(flightNumber);

          if (!flight) {
            return res.status(404).json({ 
              message: 'Flight not found or no data available for this flight',
              flight: null
            });
          }

          res.json(flight);
        } catch (apiError) {
          console.error('Flight API lookup error:', apiError);
          return res.status(503).json({
            message: 'Unable to fetch flight details at this time. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? apiError instanceof Error ? apiError.message : 'Unknown error' : undefined,
            flight: null
          });
        }
      } catch (error) {
        console.error('Flight lookup error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to get flight details',
          flight: null
        });
      }
    });

    app.post("/api/log", (req, res) => {
      try {
        // Log client-side errors to server console
        console.error('Client-side error:', req.body);
        res.status(200).json({ success: true });
      } catch (error) {
        console.error('Error logging client error:', error);
        res.status(500).json({ success: false });
      }
    });

    app.get("/api/rides/history", async (req, res) => {
      try {
        if (!req.isAuthenticated()) {
          return res.status(401).json({ message: 'Unauthorized' });
        }

        const history = await db.query.rideHistory.findMany({
          where: eq(rideHistory.userId, (req.user).id),
          orderBy: (rideHistory, { desc }) => [desc(rideHistory.createdAt)]
        });

        res.json(history);
      } catch (error) {
        console.error('Failed to fetch ride history:', error);
        res.status(500).json({ message: 'Failed to fetch ride history' });
      }
    });

    app.get("/api/rides/:rideId/tracking", async (req, res) => {
      try {
        if (!req.isAuthenticated()) {
          return res.status(401).json({ message: 'Unauthorized' });
        }

        const { rideId } = req.params;

        // Get ride history to verify ownership
        const ride = await db.query.rideHistory.findFirst({
          where: eq(rideHistory.rideId, rideId)
        });

        if (!ride) {
          return res.status(404).json({ message: 'Ride not found' });
        }

        if (ride.userId !== (req.user as User).id) {
          return res.status(403).json({ message: 'Unauthorized access to ride tracking' });
        }

        const tracking = await db.query.rideTracking.findFirst({
          where: eq(rideTracking.rideId, rideId)
        });

        res.json(tracking || { message: 'No tracking information available' });
      } catch (error) {
        console.error('Failed to fetch ride tracking:', error);
        res.status(500).json({ message: 'Failed to fetch ride tracking' });
      }
    });

    function gracefulShutdown() {
      console.log('Starting graceful shutdown...');
      httpServer.close(() => {
        console.log('HTTP server closed');
        process.exit(0);
      });
    }

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    app.post("/api/ai/safety-recommendations", async (req, res) => {
      try {
        const { location, preferences, weather } = req.body;

        if (!location) {
          return res.status(400).json({ message: 'Location is required' });
        }

        console.log('Safety recommendations request:', {
          location,
          hasPreferences: !!preferences,
          hasWeather: !!weather
        });

        const recommendations = await aiService.generateSafetyRecommendations(
          location,
          preferences,
          weather
        );

        res.json(recommendations);
      } catch (error) {
        console.error('Safety recommendations error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to generate safety recommendations'
        });
      }
    });

    app.post("/api/validate-emergency-numbers", async (req, res) => {
      try {
        const { countryCode, numbers } = req.body;

        if (!countryCode) {
          return res.status(400).json({ message: 'Country code is required' });
        }

        console.log('Emergency number validation request:', {
          countryCode,
          hasNumbers: !!numbers
        });

        // Remove authentication check to allow pre-login access
        const results = await emergencyValidationService.validateAllEmergencyNumbers(countryCode);

        res.json(results);
      } catch (error) {
        console.error('Emergency number validation error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to validate emergency numbers'
        });
      }
    });

    app.post("/api/validate-emergency-number", async (req, res) => {
      try {
        const { number, type, countryCode } = req.body;

        if (!number || !type || !countryCode) {
          return res.status(400).json({
            message: 'Number, type, and country code are required'
          });
        }

        console.log('Single emergency number validation request:', {
          type,
          countryCode
        });

        // Remove authentication check to allow pre-login access
        const result = await emergencyValidationService.validateEmergencyNumber(
          number,
          type,
          countryCode
        );

        res.json(result);
      } catch (error) {
        console.error('Emergency number validation error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to validate emergency number'
        });
      }
    });

    app.post("/api/games/treasure-hunt/start", async (req, res) => {
      try {
        const { currentLocation } = req.body;

        if (!currentLocation) {
          return res.status(400).json({ message: 'Current location is required' });
        }

        const clue = await treasureHuntService.startGame(currentLocation);
        res.json({ clue });
      } catch (error) {
        console.error('Treasure hunt start error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to start treasure hunt'
        });
      }
    });

    app.post("/api/games/treasure-hunt/next-clue", async (req, res) => {
      try {
        const { currentClueId } = req.body;

        if (!currentClueId) {
          return res.status(400).json({ message: 'Current clue ID is required' });
        }

        const result = await treasureHuntService.getNextClue(currentClueId);
        res.json(result);
      } catch (error) {
        console.error('Next clue error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to get next clue'
        });
      }
    });

    console.log('API routes registered');

    // Add this endpoint after existing chat-related endpoints
    app.post("/api/chat-recommendations", async (req, res) => {
      try {
        if (!req.isAuthenticated()) {
          return res.status(401).json({ message: 'Unauthorized' });
        }

        const { location } = req.body;

        if (!location || !location.latitude || !location.longitude) {
          return res.status(400).json({ message: 'Location coordinates are required' });
        }

        console.log('Chat recommendations request:', {
          userId: (req.user as User)?.id,
          location
        });

        const recommendations = await aiService.getChatRecommendations(
          location,
          (req.user as User)?.preferences
        );

        res.json(recommendations);
      } catch (error) {
        console.error('Chat recommendations error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to get chat recommendations'
        });
      }
    });

    // Set up WebSocket connection handling

    // Soundtrack API Routes
    app.post("/api/soundtrack/generate", async (req, res) => {
      try {
        const { destination, mood, genres, intensity, preferences, duration } = req.body;
        
        if (!destination) {
          return res.status(400).json({ message: 'Destination is required' });
        }
        
        console.log('Soundtrack generation request:', {
          userId: req.user ? (req.user as User).id : 'guest',
          destination,
          mood
        });
        
        const soundtrack = await soundtrackService.generateSoundtrack(
          {
            destination,
            mood,
            genres,
            intensity,
            preferences,
            duration
          },
          req.user as User
        );
        
        res.json({ soundtrack });
      } catch (error) {
        console.error('Soundtrack generation error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to generate soundtrack'
        });
      }
    });
    
    app.get("/api/soundtrack/moods", async (_req, res) => {
      try {
        // Access the preset moods from the imported service
        const moods = PRESET_MOODS;
        res.json({ moods });
      } catch (error) {
        console.error('Soundtrack moods fetch error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to fetch soundtrack moods'
        });
      }
    });
    
    app.get("/api/soundtrack/:id", async (req, res) => {
      try {
        const { id } = req.params;
        
        const soundtrack = await soundtrackService.getSoundtrack(id);
        
        if (!soundtrack) {
          return res.status(404).json({ message: 'Soundtrack not found' });
        }
        
        res.json({ soundtrack });
      } catch (error) {
        console.error('Soundtrack fetch error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to fetch soundtrack'
        });
      }
    });
    
    app.get("/api/user/soundtracks", async (req, res) => {
      try {
        if (!req.isAuthenticated()) {
          return res.status(401).json({ message: 'Unauthorized' });
        }
        
        const userId = (req.user as User).id;
        const soundtracks = await soundtrackService.getUserSoundtracks(userId);
        
        res.json({ soundtracks });
      } catch (error) {
        console.error('User soundtracks fetch error:', error);
        res.status(500).json({
          message: error instanceof Error ? error.message : 'Failed to fetch user soundtracks'
        });
      }
    });

    // API diagnostic endpoint to check all external services
    app.get("/api/diagnostics", async (req, res) => {
      try {
        console.log('Running API diagnostics...');
        const results = await diagnosticService.testAllConnections();
        res.json(results);
      } catch (error) {
        console.error('API diagnostics error:', error);
        res.status(500).json({
          message: 'Failed to run API diagnostics',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    });

    // Detailed API endpoint for a specific service
    app.get("/api/diagnostics/:service", async (req, res) => {
      try {
        const { service } = req.params;
        
        if (!service) {
          return res.status(400).json({ message: 'Service name is required' });
        }
        
        console.log(`Running diagnostics for service: ${service}`);
        const results = await diagnosticService.testAllConnections();
        
        if (service in results) {
          res.json({ 
            [service]: results[service],
            environment: results.environment
          });
        } else {
          res.status(404).json({ message: 'Service not found' });
        }
      } catch (error) {
        console.error(`API diagnostics error for service ${req.params.service}:`, error);
        res.status(500).json({
          message: 'Failed to run API diagnostics',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    });

    // Register trip inspiration routes
    registerTripInspirationRoutes(app);
    
    // Mount AI Trip Planner routes
    app.use('/api/ai', aiTripPlannerRoutes);
    console.log('AI Trip Planner routes mounted successfully');
    console.log('Trip inspiration routes registered successfully');

    return httpServer;
  }