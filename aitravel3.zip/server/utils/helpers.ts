import { randomBytes } from 'crypto';

/**
 * Generates a random string of specified length
 */
export function generateRandomString(length: number = 8): string {
  return randomBytes(Math.ceil(length / 2))
    .toString('hex')
    .slice(0, length);
}

/**
 * Calculates commission amount based on booking type and amount
 */
export function calculateCommission(bookingType: string, amount: number): number {
  const commissionRates: Record<string, number> = {
    'flight': 3, // 3% commission
    'hotel': 10, // 10% commission
    'experience': 20, // 20% commission
    'dining': 7, // 7% commission
    'ride': 12, // 12% commission
    'default': 5, // 5% default commission
  };

  const rate = commissionRates[bookingType] || commissionRates.default;
  return (amount * rate) / 100;
}

/**
 * Format currency amount
 */
export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
  }).format(amount);
}

/**
 * Determines if a user is eligible for special pricing
 */
export function isEligibleForDiscount(
  userSubscriptionTier: string,
  bookingCount: number,
  referralCount: number
): boolean {
  if (userSubscriptionTier === 'premium' || userSubscriptionTier === 'business') {
    return true;
  }
  
  if (bookingCount > 5) {
    return true;
  }
  
  if (referralCount > 2) {
    return true;
  }
  
  return false;
}

/**
 * Calculate discount percentage based on user status
 */
export function calculateDiscountPercentage(
  userSubscriptionTier: string,
  bookingCount: number,
  referralCount: number
): number {
  let discountPercentage = 0;
  
  // Subscription tier discounts
  if (userSubscriptionTier === 'premium') {
    discountPercentage += 5;
  } else if (userSubscriptionTier === 'business') {
    discountPercentage += 10;
  }
  
  // Loyalty discounts
  if (bookingCount >= 20) {
    discountPercentage += 10;
  } else if (bookingCount >= 10) {
    discountPercentage += 5;
  } else if (bookingCount >= 5) {
    discountPercentage += 2;
  }
  
  // Referral discounts
  if (referralCount >= 5) {
    discountPercentage += 7;
  } else if (referralCount >= 3) {
    discountPercentage += 5;
  } else if (referralCount >= 1) {
    discountPercentage += 2;
  }
  
  // Cap the discount at 25%
  return Math.min(discountPercentage, 25);
}