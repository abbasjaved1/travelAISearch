import { Express } from "express";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  // Generate a random salt
  const salt = randomBytes(16).toString("hex");
  console.log(`Hashing password with salt: ${salt.substring(0, 8)}...`);
  
  // Hash the password
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  const hashStr = buf.toString("hex");
  
  // Create a storable hash format
  const result = `${hashStr}.${salt}`;
  console.log(`Generated hash format: hash(${hashStr.substring(0, 10)}...).[salt]`);
  
  return result;
}

export async function comparePasswords(supplied: string, stored: string) {
  try {
    console.log('Comparing password - supplied:', supplied, 'length:', supplied.length);
    console.log('Stored password format:', stored.includes('.') ? 'valid' : 'invalid', 'length:', stored.length);
    
    // Make sure we have a proper format
    if (!stored || !stored.includes('.')) {
      console.error('Invalid stored password format:', stored);
      return false;
    }
    
    const [hashed, salt] = stored.split(".");
    if (!hashed || !salt) {
      console.error('Missing hash or salt components in stored password');
      return false;
    }
    
    console.log('Hash components - hash length:', hashed.length, 'salt length:', salt.length);
    
    // For debugging, calculate what the password hash should be given the salt
    const debugSuppliedHash = (await scryptAsync(supplied, salt, 64) as Buffer).toString('hex');
    console.log('DEBUG - Expected hash first 10 chars:', debugSuppliedHash.substring(0, 10), 
                'Stored hash first 10 chars:', hashed.substring(0, 10));
    console.log('DEBUG - Full expected hash:', debugSuppliedHash);
    console.log('DEBUG - Full stored hash:', hashed);
    
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    
    // For extra safety, compare manually as well
    const hashesMatch = debugSuppliedHash === hashed;
    console.log('Manual hash comparison result:', hashesMatch ? 'MATCH' : 'MISMATCH');
    
    const result = timingSafeEqual(hashedBuf, suppliedBuf);
    console.log('Timing-safe comparison result:', result);
    
    // Return true if either comparison method succeeds
    return result || hashesMatch;
  } catch (error) {
    console.error('Error comparing passwords:', error);
    return false;
  }
}

export async function setupAuth(app: Express) {
  const isDevelopment = app.get("env") === "development";
  const sessionSecret = process.env.SESSION_SECRET || randomBytes(32).toString('hex');

  console.log('Setting up auth with development mode:', isDevelopment);

  try {
    // Create or update test users
    const testUsers = [
      { username: 'test123', password: 'test123', display_name: 'Test User 1', email: 'test@example.com' },
      { username: 'test456', password: 'test456', display_name: 'Test User 2', email: 'test456@example.com' }
    ];

    for (const testUser of testUsers) {
      let user = await storage.getUserByUsername(testUser.username);

      if (!user) {
        console.log('Creating test user account:', testUser.username);
        const hashedPassword = await hashPassword(testUser.password);
        user = await storage.createUser({
          username: testUser.username,
          password: hashedPassword,
          display_name: testUser.display_name,
          email: testUser.email,
          phone_verified: true,
          preferences: {
            theme: 'light',
            currency: 'USD',
            language: 'en'
          }
        });
        console.log('Test user created successfully:', user.id);
      } else {
        console.log('Updating existing test user password');
        const hashedPassword = await hashPassword(testUser.password);
        console.log('Generated hash for password update:', hashedPassword.substring(0, 15) + '...');
        await storage.updateUserPassword(user.id, hashedPassword);
        
        // Verify the password update was successful
        const updatedUser = await storage.getUser(user.id);
        if (updatedUser) {
          console.log('Updated user password format check:', 
            updatedUser.password.includes('.') ? 'valid format' : 'invalid format',
            'length:', updatedUser.password.length);
            
          // Test if the password works with our compare function
          const passwordWorks = await comparePasswords(testUser.password, updatedUser.password);
          console.log('Password verify test after update:', passwordWorks ? 'SUCCESS' : 'FAILED');
        }
        
        console.log('Test user password updated successfully');
      }
    }

    // Basic session configuration first
    app.use(session({
      secret: sessionSecret,
      resave: false,
      saveUninitialized: false,
      store: storage.sessionStore,
      name: 'travel.sid',
      cookie: {
        httpOnly: true,
        path: '/'
      }
    }));

    app.use(passport.initialize());
    app.use(passport.session());

    // Passport configuration
    passport.serializeUser((user: any, done) => {
      console.log('Serializing user:', user.id);
      done(null, user.id);
    });

    passport.deserializeUser(async (id: number, done) => {
      try {
        console.log('Deserializing user:', id);
        const user = await storage.getUser(id);
        if (!user) {
          console.log('User not found during deserialization:', id);
          return done(null, false);
        }
        done(null, user);
      } catch (error) {
        console.error('Error deserializing user:', error);
        done(error, null);
      }
    });

    // Local strategy setup
    passport.use(new LocalStrategy(async (username, password, done) => {
      try {
        console.log('Attempting login for username:', username);
        const user = await storage.getUserByUsername(username);
        if (!user) {
          console.log('User not found:', username);
          return done(null, false, { message: "Invalid credentials" });
        }

        const validPassword = await comparePasswords(password, user.password);
        if (!validPassword) {
          console.log('Invalid password for user:', username);
          return done(null, false, { message: "Invalid credentials" });
        }

        console.log('Login successful for user:', username);
        return done(null, user);
      } catch (error) {
        console.error('Login error:', error);
        return done(error);
      }
    }));

    // Google OAuth strategy
    const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
    const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
    const HOST = process.env.HOST || 'http://localhost:5000';
    
    if (GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET) {
      console.log('Setting up Google OAuth strategy');
      passport.use(new GoogleStrategy({
        clientID: GOOGLE_CLIENT_ID,
        clientSecret: GOOGLE_CLIENT_SECRET,
        callbackURL: `${HOST}/auth/google/callback`,
        scope: ['profile', 'email', 'https://www.googleapis.com/auth/contacts.readonly']
      }, async (accessToken, refreshToken, profile, done) => {
        // Store tokens for later access to Google services
        profile._accessToken = accessToken;
        profile._refreshToken = refreshToken;
        try {
          console.log('Google authentication callback for:', profile.displayName);
          
          // Check if user exists with this Google ID
          const googleId = profile.id;
          let user = await storage.getUserByGoogleId(googleId);
          
          if (user) {
            console.log('Found existing user with Google ID:', user.id);
            return done(null, user);
          }
          
          // If we have an email from Google, check if a user exists with this email
          if (profile.emails && profile.emails.length > 0) {
            const email = profile.emails[0].value;
            user = await storage.getUserByEmail(email);
            
            if (user) {
              // User exists with this email but no Google ID yet
              console.log('Updating existing user with Google ID:', user.id);
              user = await storage.updateUser(user.id, { 
                google_id: googleId 
              });
              return done(null, user);
            }
          }
          
          // Create a new user with Google profile data
          console.log('Creating new user from Google profile');
          
          // Generate a random secure password for this user
          const randomPassword = randomBytes(16).toString('hex');
          const hashedPassword = await hashPassword(randomPassword);
          
          // Extract email and name from the profile
          const email = profile.emails && profile.emails.length > 0 
            ? profile.emails[0].value 
            : `${googleId}@google.user`;
            
          const displayName = profile.displayName || email.split('@')[0];
          
          // Create a new user
          const newUser = await storage.createUser({
            username: email,
            email: email,
            display_name: displayName,
            password: hashedPassword,
            google_id: googleId,
            email_verified: true,
            preferences: {
              theme: 'light',
              currency: 'USD',
              language: 'en'
            }
          });
          
          console.log('Created new user from Google profile:', newUser.id);
          return done(null, newUser);
        } catch (error) {
          console.error('Google authentication error:', error);
          return done(error);
        }
      }));
    } else {
      console.log('Google OAuth is not configured. GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables are required.');
    }

    // Auth routes
    app.post("/api/login", (req, res, next) => {
      console.log('Login attempt:', req.body.username);
      passport.authenticate("local", (err: Error | null, user: SelectUser | false, info: { message: string } | undefined) => {
        if (err) {
          console.error('Login error:', err);
          return res.status(500).json({ message: 'Internal server error' });
        }
        if (!user) {
          console.log('Authentication failed:', info?.message);
          return res.status(401).json({ message: info?.message || "Invalid credentials" });
        }

        req.login(user, (err) => {
          if (err) {
            console.error('Session establishment error:', err);
            return res.status(500).json({ message: 'Failed to establish session' });
          }
          console.log('User logged in successfully:', user.id);
          res.json(user);
        });
      })(req, res, next);
    });

    app.post("/api/logout", (req, res) => {
      const userId = req.user?.id;
      console.log('Logout request for user:', userId);

      if (!req.isAuthenticated()) {
        console.log('No authenticated session to logout');
        res.clearCookie('travel.sid', {
          path: '/',
          httpOnly: true
        });
        return res.sendStatus(200);
      }

      req.logout((err) => {
        if (err) {
          console.error('Logout error:', err);
          return res.status(500).json({ message: 'Failed to logout' });
        }
        req.session.destroy((err) => {
          if (err) {
            console.error('Session destruction error:', err);
            return res.status(500).json({ message: 'Failed to clear session' });
          }
          console.log('User logged out successfully:', userId);
          res.clearCookie('travel.sid', {
            path: '/',
            httpOnly: true
          });
          res.sendStatus(200);
        });
      });
    });

    app.get("/api/user", (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      res.json(req.user);
    });
    
    // Google OAuth routes
    if (GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET) {
      // Route to initiate Google OAuth flow
      app.get("/auth/google", passport.authenticate("google", { 
        scope: ["profile", "email", "https://www.googleapis.com/auth/contacts.readonly"]
      }));
      
      // Google OAuth callback route
      app.get("/auth/google/callback", 
        passport.authenticate("google", { 
          failureRedirect: "/login?error=google-auth-failed" 
        }),
        (req, res) => {
          // Successful authentication
          console.log("Google authentication successful");
          // Redirect to the client-side callback handler
          res.redirect("/google-callback");
        }
      );
    }

    // Registration endpoint
    app.post("/api/register", async (req, res) => {
      try {
        console.log('Registration request:', req.body);

        // Validation
        if (!req.body.username || !req.body.password) {
          return res.status(400).json({ message: "Username and password are required" });
        }

        // Check if phone verification is required and was done
        if (req.body.phone_number) {
          // Phone verification logic should be handled before this endpoint is called
          // This is currently done on the frontend before calling this endpoint
        }

        // Check if username already exists
        const existingUser = await storage.getUserByUsername(req.body.username);
        if (existingUser) {
          return res.status(400).json({ message: "Username already exists" });
        }
        
        // Check if phone number already exists
        if (req.body.phone_number) {
          const existingPhone = await storage.getUserByPhone(req.body.phone_number);
          if (existingPhone) {
            return res.status(400).json({ message: "Phone number already registered with another account" });
          }
        }

        // Hash password
        const hashedPassword = await hashPassword(req.body.password);
        
        // Create user with hashed password
        const userData = {
          ...req.body,
          password: hashedPassword,
          phone_verified: req.body.phone_number ? true : false // Mark as verified if we came from OTP flow
        };

        const newUser = await storage.createUser(userData);
        console.log('User registered successfully:', newUser.id);

        // Auto-login after registration
        req.login(newUser, (err) => {
          if (err) {
            console.error('Session establishment error after registration:', err);
            return res.status(500).json({ message: 'Registration successful, but failed to establish session' });
          }
          
          res.status(201).json(newUser);
        });
      } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ message: "Registration failed", error: error.message });
      }
    });

  } catch (error) {
    console.error('Failed to setup authentication:', error);
    throw error;
  }
}

async function resetTestUserPassword() {
  try {
    console.log('Resetting test user password...');
    const testUser = await storage.getUserByUsername('test@example.com');
    if (!testUser) {
      console.log('Test user not found');
      return;
    }

    const hashedPassword = await hashPassword('test123');
    await storage.updateUserPassword(testUser.id, hashedPassword);
    console.log('Test user password reset successfully');
  } catch (error) {
    console.error('Failed to reset test user password:', error);
    throw error;
  }
}