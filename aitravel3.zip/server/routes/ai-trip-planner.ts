import { Request, Response, Router } from 'express';
import { TripPlan, DayPlan, Activity, EmotionalWeather } from '../../shared/schema';
import { format, addDays, differenceInDays } from 'date-fns';
import axios from 'axios';
import OpenAI from 'openai';
import { v4 as uuidv4 } from 'uuid';
import { storage } from '../storage';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Create router
const router = Router();

// Define types for the request body
interface TripPlanRequest {
  destination: string;
  dates: {
    start: string;
    end: string;
  };
  preferences: {
    pace: 'relaxed' | 'moderate' | 'intensive';
    type: 'leisure' | 'business' | 'family' | 'adventure';
    interests: string[];
  };
  meetingDetails?: {
    time: string;
    duration: number;
    attendees: number;
  };
}

// Define the endpoint
router.post('/trip-plan', async (req: Request, res: Response) => {
  try {
    // Get user information if authenticated
    const user = req.user;
    
    if (!req.body) {
      return res.status(400).json({ error: 'Request body is missing' });
    }
    
    const { 
      destination, 
      dates, 
      preferences,
      meetingDetails 
    } = req.body as TripPlanRequest;
    
    // Validate required fields
    if (!destination) {
      return res.status(400).json({ error: 'Destination is required' });
    }
    
    if (!dates || !dates.start || !dates.end) {
      return res.status(400).json({ error: 'Both start and end dates are required' });
    }
    
    // Calculate number of days
    const startDate = new Date(dates.start);
    const endDate = new Date(dates.end);
    const numberOfDays = differenceInDays(endDate, startDate) + 1;
    
    if (numberOfDays <= 0) {
      return res.status(400).json({ error: 'End date must be after start date' });
    }
    
    if (numberOfDays > 14) {
      return res.status(400).json({ error: 'Trip duration cannot exceed 14 days' });
    }
    
    // Default preferences if not provided
    const defaultPace = preferences?.pace || 'moderate';
    const tripType = preferences?.type || 'leisure';
    const interests = preferences?.interests || [];
    
    const plan = await generateAITripPlan(
      destination, 
      dates.start, 
      dates.end, 
      defaultPace, 
      tripType, 
      interests,
      meetingDetails,
      user ? (user as any).id : undefined
    );
    
    return res.status(200).json({ plan });
  } catch (error) {
    console.error('Error generating trip plan:', error);
    return res.status(500).json({ 
      error: 'Failed to generate trip plan',
      details: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Trip plan generation function
async function generateAITripPlan(
  destination: string,
  startDate: string,
  endDate: string,
  pace: string,
  tripType: string,
  interests: string[],
  meetingDetails?: {
    time: string;
    duration: number;
    attendees: number;
  },
  userId?: number
): Promise<TripPlan> {
  try {
    // Try to use OpenAI API for trip planning
    return await generateWithOpenAI(
      destination,
      startDate,
      endDate,
      pace,
      tripType,
      interests,
      meetingDetails
    );
  } catch (error) {
    console.error('OpenAI API error:', error);
    // Fall back to mock data with personalization
    return generateMockTripPlan(
      destination,
      startDate,
      endDate,
      pace,
      tripType,
      interests,
      meetingDetails
    );
  }
}

// Function to generate trip plan using OpenAI
async function generateWithOpenAI(
  destination: string,
  startDate: string,
  endDate: string,
  pace: string,
  tripType: string,
  interests: string[],
  meetingDetails?: {
    time: string;
    duration: number;
    attendees: number;
  }
): Promise<TripPlan> {
  // Calculate the number of days
  const start = new Date(startDate);
  const end = new Date(endDate);
  const numberOfDays = differenceInDays(end, start) + 1;
  
  // Create a prompt for OpenAI based on the trip details
  let prompt = `Create a detailed travel itinerary for a ${numberOfDays}-day trip to ${destination} from ${format(start, 'MMMM d, yyyy')} to ${format(end, 'MMMM d, yyyy')}. 
The traveler prefers a ${pace} pace and this is a ${tripType} trip.`;

  if (interests && interests.length > 0) {
    prompt += ` The traveler is interested in: ${interests.join(', ')}.`;
  }

  if (tripType === 'business' && meetingDetails) {
    prompt += ` Include a business meeting at ${meetingDetails.time} for ${meetingDetails.duration} minutes with ${meetingDetails.attendees} attendees in the itinerary.`;
  }

  prompt += `
Format the response as a valid JSON object matching this structure:
{
  "days": [
    {
      "date": "YYYY-MM-DD",
      "activities": [
        {
          "id": "unique-id",
          "title": "Activity title",
          "type": "activity type (e.g., Food, Attraction, Tour, etc.)",
          "startTime": "HH:MM AM/PM",
          "endTime": "HH:MM AM/PM",
          "location": "Location name",
          "description": "Brief description",
          "cost": numerical cost estimate (just the number, no currency symbol)
        }
      ],
      "weatherForecast": {
        "condition": "sunny/cloudy/rainy/etc.",
        "temperature": temperature in Celsius (number),
        "chanceOfRain": percentage (number)
      },
      "emotionalWeather": {
        "primary": {
          "emotion": "joy/romance/excitement/calm/melancholy/etc.",
          "intensity": number between 0-100
        },
        "secondary": {
          "emotion": "another emotion",
          "intensity": number between 0-100
        },
        "description": "Brief explanation of the emotional atmosphere for this day"
      }
    }
  ],
  "totalEstimatedCost": total numerical cost for the trip (just the number),
  "notes": ["note 1", "note 2"],
  "currencyCode": "USD" (or local currency code)
}

Be realistic about what can be accomplished each day. Activities should be in chronological order with reasonable durations and travel time between locations. Ensure each activity has a reasonable start and end time. Keep descriptions concise and informative.

For the emotionalWeather objects, analyze the planned activities, the location's cultural context, and typical visitor experiences to create meaningful emotional forecasts. This should represent the emotional atmosphere or mood a traveler would likely experience at that destination on that particular day.`;

  try {
    // Call OpenAI API with the prompt
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an experienced travel planner with knowledge of global destinations, local attractions, and realistic travel logistics." },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Failed to generate trip plan: empty response from AI");
    }

    // Parse the JSON response
    const planData = JSON.parse(content);
    
    // Format the data to match our TripPlan type
    const tripPlan: TripPlan = {
      destination,
      startDate,
      endDate,
      days: planData.days.map((day: any) => ({
        date: day.date,
        activities: day.activities.map((activity: any) => ({
          id: activity.id || uuidv4(),
          title: activity.title,
          type: activity.type,
          startTime: activity.startTime,
          endTime: activity.endTime,
          location: activity.location,
          description: activity.description,
          cost: typeof activity.cost === 'number' ? activity.cost : parseInt(activity.cost, 10) || 0
        })),
        weatherForecast: day.weatherForecast,
        emotionalWeather: day.emotionalWeather
      })),
      totalEstimatedCost: planData.totalEstimatedCost,
      notes: planData.notes,
      currencyCode: planData.currencyCode || 'USD'
    };

    return tripPlan;
    
  } catch (error) {
    console.error('Error generating trip with OpenAI:', error);
    throw error;
  }
}

// Function to generate mock trip plan data
function generateMockTripPlan(
  destination: string,
  startDate: string,
  endDate: string,
  pace: string,
  tripType: string,
  interests: string[],
  meetingDetails?: {
    time: string;
    duration: number;
    attendees: number;
  }
): TripPlan {
  // Calculate the number of days
  const start = new Date(startDate);
  const end = new Date(endDate);
  const numberOfDays = differenceInDays(end, start) + 1;
  
  // Define some mock weather data
  const mockWeatherData: Record<string, { condition: string, temperature: number, chanceOfRain: number }> = {
    'London': { condition: 'cloudy', temperature: 18, chanceOfRain: 30 },
    'New York': { condition: 'sunny', temperature: 24, chanceOfRain: 10 },
    'Tokyo': { condition: 'rainy', temperature: 22, chanceOfRain: 80 },
    'Paris': { condition: 'sunny', temperature: 22, chanceOfRain: 5 },
    'Sydney': { condition: 'sunny', temperature: 28, chanceOfRain: 0 },
    'Bangkok': { condition: 'stormy', temperature: 32, chanceOfRain: 70 }
  };
  
  // Create mock weather for the destination
  let destinationWeather = (destination in mockWeatherData) ? mockWeatherData[destination] : { 
    condition: ['sunny', 'cloudy', 'rainy'][Math.floor(Math.random() * 3)],
    temperature: Math.floor(Math.random() * 15) + 15, // 15-30°C
    chanceOfRain: Math.floor(Math.random() * 100)
  };
  
  // Adjust number of activities based on pace
  let activitiesPerDay: number;
  switch (pace) {
    case 'relaxed':
      activitiesPerDay = 3;
      break;
    case 'intensive':
      activitiesPerDay = 5;
      break;
    case 'moderate':
    default:
      activitiesPerDay = 4;
      break;
  }
  
  // Adjust activities based on trip type
  let activityTypes: string[];
  
  switch (tripType) {
    case 'business':
      activityTypes = ['Business Meeting', 'Networking Event', 'Local Dining', 'Cultural Visit'];
      break;
    case 'family':
      activityTypes = ['Family Attraction', 'Park Visit', 'Kid-Friendly Activity', 'Casual Dining'];
      break;
    case 'adventure':
      activityTypes = ['Outdoor Adventure', 'Hiking', 'Water Activity', 'Local Experience'];
      break;
    case 'leisure':
    default:
      activityTypes = ['Tourist Attraction', 'Museum Visit', 'Local Dining', 'Shopping'];
      break;
  }
  
  // Create days array
  const days: DayPlan[] = [];
  
  for (let i = 0; i < numberOfDays; i++) {
    const currentDate = addDays(start, i);
    const formattedDate = format(currentDate, 'yyyy-MM-dd');
    
    // Create activities for this day
    const activities: Activity[] = [];
    
    // If it's a business trip, add the meeting on the first full day
    if (tripType === 'business' && meetingDetails && i === 1) {
      const meetingStartTime = meetingDetails.time;
      // Calculate end time based on duration
      const [hours, minutes] = meetingDetails.time.split(':').map(Number);
      const meetingEndTime = `${String(hours + Math.floor((minutes + meetingDetails.duration) / 60) % 12 || 12).padStart(2, '0')}:${String((minutes + meetingDetails.duration) % 60).padStart(2, '0')} ${hours + Math.floor((minutes + meetingDetails.duration) / 60) >= 12 ? 'PM' : 'AM'}`;
      
      activities.push({
        id: uuidv4(),
        title: `Business Meeting with ${meetingDetails.attendees} Attendees`,
        type: 'Business Meeting',
        startTime: meetingStartTime.includes('AM') || meetingStartTime.includes('PM') ? meetingStartTime : `${meetingStartTime} AM`,
        endTime: meetingEndTime,
        location: `${destination} Business District`,
        description: `Important business meeting with ${meetingDetails.attendees} attendees to discuss project collaboration.`,
        cost: 0
      });
      
      // Adjust number of remaining activities for this day
      activitiesPerDay = 2;
    }
    
    // Start time (if there's already a meeting, start activities after)
    let startHour = 9;
    if (activities.length > 0) {
      // Extract hour from the endTime of the last activity
      const lastEndTime = activities[activities.length - 1].endTime;
      const match = lastEndTime.match(/(\d+):(\d+)\s*(AM|PM)/);
      if (match) {
        const [_, hour, minute, ampm] = match;
        startHour = parseInt(hour) + (ampm === 'PM' && parseInt(hour) !== 12 ? 12 : 0);
      }
    }
    
    // Generate activities with reasonable timing
    for (let j = 0; j < activitiesPerDay; j++) {
      // Each activity takes 1-2 hours
      const duration = Math.floor(Math.random() * 2) + 1;
      const activityType = activityTypes[j % activityTypes.length];
      
      // Format times
      const startTime = `${startHour % 12 || 12}:00 ${startHour >= 12 ? 'PM' : 'AM'}`;
      startHour += duration;
      const endTime = `${startHour % 12 || 12}:00 ${startHour >= 12 ? 'PM' : 'AM'}`;
      
      // Generate mock cost based on activity type
      const cost = (Math.floor(Math.random() * 50) + 10) * (activityType.includes('Dining') ? 2 : 1);
      
      activities.push({
        id: uuidv4(),
        title: generateActivityTitle(activityType, destination),
        type: activityType,
        startTime,
        endTime,
        location: `${destination} - ${generateMockLocation(destination, activityType)}`,
        description: generateMockDescription(activityType, destination),
        cost
      });
      
      // Add 30min - 1h between activities
      startHour += (Math.random() > 0.5 ? 1 : 0.5);
    }
    
    // Generate slightly different weather each day
    const weatherVariation = {
      temperature: destinationWeather.temperature + (Math.random() * 6 - 3),
      chanceOfRain: Math.max(0, Math.min(100, destinationWeather.chanceOfRain + (Math.random() * 30 - 15))),
    };
    
    // If chance of rain is high, possibly change the condition
    let condition = destinationWeather.condition;
    if (weatherVariation.chanceOfRain > 70) {
      condition = 'rainy';
    } else if (weatherVariation.chanceOfRain < 20) {
      condition = 'sunny';
    }
    
    days.push({
      date: formattedDate,
      activities,
      weatherForecast: {
        condition,
        temperature: Math.round(weatherVariation.temperature),
        chanceOfRain: Math.round(weatherVariation.chanceOfRain)
      },
      emotionalWeather: generateEmotionalWeather(destination, activityTypes, i, tripType)
    });
  }
  
  // Calculate total cost
  const totalCost = days.reduce((total, day) => {
    return total + day.activities.reduce((dayTotal, activity) => {
      return dayTotal + (typeof activity.cost === 'number' ? activity.cost : 0);
    }, 0);
  }, 0);
  
  // Generate trip plan
  const tripPlan: TripPlan = {
    destination,
    startDate,
    endDate,
    days,
    totalEstimatedCost: totalCost,
    notes: generateTripNotes(destination, tripType, pace, interests),
    currencyCode: 'USD'
  };
  
  return tripPlan;
}

// Helper functions for mock data generation
function generateActivityTitle(activityType: string, destination: string): string {
  const titles: Record<string, string[]> = {
    'Tourist Attraction': [
      `Visit to Famous ${destination} Landmark`,
      `${destination} Historical Tour`,
      `${destination} City View Experience`,
      `${destination} Main Square Exploration`
    ],
    'Museum Visit': [
      `${destination} National Museum`,
      `${destination} Art Gallery`,
      `${destination} History Museum`,
      `${destination} Cultural Center`
    ],
    'Local Dining': [
      `Traditional ${destination} Cuisine Experience`,
      `${destination} Food Tour`,
      `Local Restaurant in ${destination}`,
      `Fine Dining in ${destination}`
    ],
    'Shopping': [
      `${destination} Shopping District`,
      `${destination} Local Market`,
      `${destination} Boutique Shopping`,
      `${destination} Souvenir Hunt`
    ],
    'Business Meeting': [
      `Meeting at ${destination} Business Center`,
      `${destination} Conference`,
      `Business Lunch in ${destination}`,
      `${destination} Corporate Event`
    ],
    'Networking Event': [
      `${destination} Industry Meetup`,
      `Networking Cocktail in ${destination}`,
      `${destination} Business Forum`,
      `Professional Gathering in ${destination}`
    ],
    'Family Attraction': [
      `${destination} Amusement Park`,
      `${destination} Zoo Visit`,
      `${destination} Aquarium Adventure`,
      `Family Fun in ${destination}`
    ],
    'Park Visit': [
      `${destination} Central Park Relaxation`,
      `${destination} Gardens Tour`,
      `${destination} Nature Reserve`,
      `${destination} Botanic Gardens`
    ],
    'Kid-Friendly Activity': [
      `${destination} Children's Museum`,
      `${destination} Interactive Exhibition`,
      `Fun Workshop in ${destination}`,
      `${destination} Playground Adventure`
    ],
    'Casual Dining': [
      `Family Restaurant in ${destination}`,
      `${destination} Street Food Experience`,
      `Kid-Friendly Eatery in ${destination}`,
      `Casual Brunch in ${destination}`
    ],
    'Outdoor Adventure': [
      `${destination} Hiking Experience`,
      `${destination} Mountain Exploration`,
      `Adventure Park in ${destination}`,
      `${destination} Outdoor Challenge`
    ],
    'Hiking': [
      `${destination} Nature Trail`,
      `${destination} Mountain Path`,
      `Scenic Hike in ${destination}`,
      `${destination} Forest Trail`
    ],
    'Water Activity': [
      `${destination} Beach Day`,
      `${destination} Water Sports`,
      `${destination} Boat Tour`,
      `${destination} Swimming Adventure`
    ],
    'Local Experience': [
      `${destination} Local Workshop`,
      `${destination} Cultural Immersion`,
      `Meet Locals in ${destination}`,
      `${destination} Hidden Gems Tour`
    ]
  };
  
  const options = (activityType in titles) ? titles[activityType] : [`${activityType} in ${destination}`];
  return options[Math.floor(Math.random() * options.length)];
}

function generateMockLocation(destination: string, activityType: string): string {
  const locations: Record<string, string[]> = {
    'Tourist Attraction': [
      'City Center',
      'Old Town',
      'Historic District',
      'Main Square'
    ],
    'Museum Visit': [
      'Arts District',
      'Cultural Quarter',
      'Museum Row',
      'Heritage Area'
    ],
    'Local Dining': [
      'Food District',
      'Restaurant Row',
      'Downtown',
      'Culinary Quarter'
    ],
    'Shopping': [
      'Shopping District',
      'Market Street',
      'Mall Area',
      'Boutique Quarter'
    ],
    'Business Meeting': [
      'Financial District',
      'Business Center',
      'Corporate Park',
      'Convention Center'
    ],
    'Networking Event': [
      'Conference Center',
      'Hotel District',
      'Business Lounge',
      'Corporate Venue'
    ],
    'Family Attraction': [
      'Entertainment District',
      'Family Park',
      'Fun Zone',
      'Amusement Area'
    ],
    'Park Visit': [
      'Central Park',
      'City Gardens',
      'Nature Reserve',
      'Botanical Gardens'
    ],
    'Kid-Friendly Activity': [
      'Children\'s District',
      'Family Center',
      'Educational Zone',
      'Play Area'
    ],
    'Casual Dining': [
      'Food Court',
      'Family Restaurant Area',
      'Casual Dining District',
      'Street Food Market'
    ],
    'Outdoor Adventure': [
      'Adventure Park',
      'Outdoor Recreation Area',
      'Adventure Zone',
      'Nature Center'
    ],
    'Hiking': [
      'Hiking Trails',
      'Nature Park',
      'Mountain Area',
      'Forest Reserve'
    ],
    'Water Activity': [
      'Beach Area',
      'Waterfront',
      'Marina District',
      'Lake Region'
    ],
    'Local Experience': [
      'Artisan Quarter',
      'Local Village',
      'Cultural District',
      'Traditional Area'
    ]
  };
  
  const options = (activityType in locations) ? locations[activityType] : ['City Center'];
  return options[Math.floor(Math.random() * options.length)];
}

function generateMockDescription(activityType: string, destination: string): string {
  const descriptions: Record<string, string[]> = {
    'Tourist Attraction': [
      `Explore the famous landmarks and historical sites of ${destination}.`,
      `Discover the iconic attractions that make ${destination} famous worldwide.`,
      `Immerse yourself in the historical significance of ${destination}'s main attractions.`,
      `Take memorable photos at the most recognizable spots in ${destination}.`
    ],
    'Museum Visit': [
      `Appreciate the art and culture preserved in ${destination}'s finest museum.`,
      `Explore the rich cultural heritage of ${destination} through its museum collections.`,
      `Discover fascinating exhibits showcasing ${destination}'s history and achievements.`,
      `Learn about the artistic traditions and historical artifacts of ${destination}.`
    ],
    'Local Dining': [
      `Savor the authentic flavors of ${destination}'s traditional cuisine.`,
      `Enjoy a culinary journey through the local specialties of ${destination}.`,
      `Experience the gastronomy that makes ${destination} famous among food lovers.`,
      `Taste the unique dishes that represent ${destination}'s culinary identity.`
    ],
    'Shopping': [
      `Browse for unique souvenirs and local products in ${destination}'s best shopping area.`,
      `Discover local crafts, fashion, and artisanal goods in ${destination}'s markets.`,
      `Shop for authentic mementos to remember your trip to ${destination}.`,
      `Experience the retail therapy ${destination} has to offer with its diverse shops.`
    ],
    'Business Meeting': [
      `Productive business discussion in one of ${destination}'s premier meeting venues.`,
      `Professional engagement with local business partners in ${destination}.`,
      `Strategic meeting to discuss business opportunities in ${destination}.`,
      `Corporate gathering in a well-equipped venue in ${destination}.`
    ],
    'Networking Event': [
      `Connect with professionals and industry experts from ${destination}.`,
      `Expand your professional network at this curated event in ${destination}.`,
      `Meet potential partners and collaborators in the vibrant business scene of ${destination}.`,
      `Exchange ideas and build relationships with ${destination}'s business community.`
    ],
    'Family Attraction': [
      `Fun-filled experience for all ages at ${destination}'s top family attraction.`,
      `Create lasting memories with your family at this entertaining venue in ${destination}.`,
      `Enjoy activities designed for family enjoyment in ${destination}.`,
      `Experience the joy of ${destination}'s most loved family destination.`
    ],
    'Park Visit': [
      `Relax in the natural beauty of ${destination}'s most scenic park.`,
      `Enjoy greenery and fresh air in this tranquil oasis within ${destination}.`,
      `Take a peaceful stroll through the landscaped gardens of ${destination}.`,
      `Connect with nature without leaving the urban area of ${destination}.`
    ],
    'Kid-Friendly Activity': [
      `Interactive and educational fun for children in ${destination}.`,
      `Engage young minds with this specially designed activity in ${destination}.`,
      `Watch your children have fun while learning about ${destination}.`,
      `Entertaining experience tailored for young visitors to ${destination}.`
    ],
    'Casual Dining': [
      `Enjoy a relaxed meal in a family-friendly atmosphere in ${destination}.`,
      `Sample approachable dishes in a comfortable setting in ${destination}.`,
      `Experience the everyday cuisine that locals in ${destination} enjoy.`,
      `Casual and satisfying food options perfect for travelers in ${destination}.`
    ],
    'Outdoor Adventure': [
      `Challenge yourself with this exciting outdoor activity in ${destination}.`,
      `Feel the adrenaline rush while enjoying ${destination}'s natural landscape.`,
      `Experience the thrill of adventure in the beautiful surroundings of ${destination}.`,
      `Push your limits with this action-packed experience in ${destination}.`
    ],
    'Hiking': [
      `Traverse scenic trails offering breathtaking views of ${destination}.`,
      `Explore the natural beauty of ${destination} on foot.`,
      `Connect with nature on this well-marked hiking path near ${destination}.`,
      `Enjoy physical activity while absorbing the stunning landscapes of ${destination}.`
    ],
    'Water Activity': [
      `Refresh yourself with this water-based experience in ${destination}.`,
      `Enjoy the aquatic attractions that ${destination} has to offer.`,
      `Have fun in and around the water in beautiful ${destination}.`,
      `Cool off with this splash-filled activity in ${destination}.`
    ],
    'Local Experience': [
      `Immerse yourself in the authentic culture of ${destination}.`,
      `Experience ${destination} like a local with this insider activity.`,
      `Discover the hidden gems and local secrets of ${destination}.`,
      `Connect with the real essence of ${destination} beyond typical tourist attractions.`
    ]
  };
  
  const options = (activityType in descriptions) ? descriptions[activityType] : [`Enjoy your time in ${destination} with this wonderful activity.`];
  return options[Math.floor(Math.random() * options.length)];
}

function generateEmotionalWeather(destination: string, activityTypes: string[], dayIndex: number, tripType: string): EmotionalWeather {
  // Map destinations to their emotional characteristics
  const destinationEmotions: Record<string, {primary: string, secondary: string, description: string}> = {
    'London': {
      primary: 'nostalgia',
      secondary: 'wonder',
      description: 'A mix of historical charm and modern excitement'
    },
    'New York': {
      primary: 'excitement',
      secondary: 'anticipation',
      description: 'The energetic pulse of a city that never sleeps'
    },
    'Tokyo': {
      primary: 'fascination',
      secondary: 'serenity',
      description: 'A fascinating blend of traditional tranquility and futuristic energy'
    },
    'Paris': {
      primary: 'romance',
      secondary: 'inspiration',
      description: 'A dreamy atmosphere of love and artistic inspiration'
    },
    'Sydney': {
      primary: 'joy',
      secondary: 'relaxation',
      description: 'Carefree coastal vibes with sunny optimism'
    },
    'Bangkok': {
      primary: 'excitement',
      secondary: 'curiosity',
      description: 'A sensory explosion of exotic sights, sounds, and flavors'
    }
  };
  
  // Map trip types to their emotional characteristics
  const tripTypeEmotions: Record<string, {primary: string, secondary: string}> = {
    'business': {
      primary: 'focus',
      secondary: 'anticipation'
    },
    'family': {
      primary: 'joy',
      secondary: 'togetherness'
    },
    'adventure': {
      primary: 'excitement',
      secondary: 'awe'
    },
    'leisure': {
      primary: 'relaxation',
      secondary: 'contentment'
    }
  };
  
  // Default emotions if the destination isn't in our predefined list
  let primaryEmotion = 'curiosity';
  let secondaryEmotion = 'anticipation';
  let description = `Discovering the unique character and atmosphere of ${destination}`;
  
  // Get destination-specific emotions if available
  if (destination in destinationEmotions) {
    const emotions = destinationEmotions[destination as keyof typeof destinationEmotions];
    primaryEmotion = emotions.primary;
    secondaryEmotion = emotions.secondary;
    description = emotions.description;
  }
  
  // Adjust based on trip type
  if (tripType in tripTypeEmotions) {
    const tripEmotions = tripTypeEmotions[tripType as keyof typeof tripTypeEmotions];
    // Blend trip type emotion with destination
    if (dayIndex % 2 === 0) {
      secondaryEmotion = tripEmotions.secondary;
    } else {
      // On alternate days, strengthen the trip type emotion influence
      secondaryEmotion = primaryEmotion;
      primaryEmotion = tripEmotions.primary;
    }
  }
  
  // Adjust intensity based on day index (first day more intense, middle days settled, last days nostalgic)
  let primaryIntensity = 70 + Math.floor(Math.random() * 20); // Base intensity 70-90
  let secondaryIntensity = 40 + Math.floor(Math.random() * 30); // Base intensity 40-70
  
  // Activity types can influence the emotional weather
  const hasOutdoorActivities = activityTypes.some(type => 
    ['Outdoor Adventure', 'Hiking', 'Water Activity', 'Park Visit'].includes(type)
  );
  
  const hasCulturalActivities = activityTypes.some(type => 
    ['Museum Visit', 'Tourist Attraction', 'Local Experience', 'Cultural Visit'].includes(type)
  );
  
  // Adjust description based on activities
  if (hasOutdoorActivities && description.indexOf('nature') === -1) {
    description += '. Connection with natural surroundings enhances the experience';
  }
  
  if (hasCulturalActivities && description.indexOf('cultural') === -1) {
    description += '. Rich cultural encounters deepen the emotional experience';
  }
  
  return {
    primary: {
      emotion: primaryEmotion,
      intensity: primaryIntensity
    },
    secondary: {
      emotion: secondaryEmotion,
      intensity: secondaryIntensity
    },
    description
  };
}

function generateTripNotes(destination: string, tripType: string, pace: string, interests: string[]): string[] {
  const notes = [
    `${destination} is best explored by ${pace === 'relaxed' ? 'taking your time' : pace === 'intensive' ? 'planning ahead' : 'balancing activities'}. This itinerary is designed for a ${pace} pace.`,
    `The best time to visit most attractions in ${destination} is during the early morning to avoid crowds.`
  ];
  
  // Add note based on trip type
  switch (tripType) {
    case 'business':
      notes.push(`Consider booking a hotel in ${destination}'s business district for convenient access to meeting venues.`);
      break;
    case 'family':
      notes.push(`${destination} offers many family-friendly dining options. Remember to make reservations for larger groups.`);
      break;
    case 'adventure':
      notes.push(`Pack appropriate gear for outdoor activities in ${destination}, and check weather forecasts regularly.`);
      break;
    case 'leisure':
      notes.push(`Take advantage of ${destination}'s public transportation to easily navigate between attractions.`);
      break;
  }
  
  // Add note based on interests if any
  if (interests.length > 0) {
    notes.push(`This itinerary focuses on your interests in ${interests.join(', ')}. Consider adding additional activities if time permits.`);
  }
  
  // Add a local tip
  notes.push(`Local tip: Always greet locals in ${destination} with a smile and learn a few basic phrases in the local language.`);
  
  return notes;
}

export default router;