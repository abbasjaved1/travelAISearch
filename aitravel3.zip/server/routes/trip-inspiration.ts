import { Express, Request, Response } from "express";
import axios from "axios";
import { z } from "zod";

interface TripInspiration {
  destination: string;
  description: string;
  activities: string[];
  budget: {
    currency: string;
    range: {
      min: number;
      max: number;
    };
    perDay: number;
  };
  bestTimeToVisit: string[];
  transportationOptions: string[];
  accommodationSuggestions: string[];
  localCuisine: string[];
  culturalTips: string[];
  imageUrl: string;
}

const countries = [
  "Japan", "Italy", "France", "Thailand", "Peru", 
  "Australia", "Morocco", "Greece", "Vietnam", "Canada",
  "Spain", "India", "New Zealand", "South Africa", "Brazil",
  "Portugal", "Iceland", "Norway", "Mexico", "Switzerland",
  "Costa Rica", "Egypt", "Indonesia", "Croatia", "Ireland",
  "Singapore", "Turkey", "Cambodia", "Argentina"
];

const categories = [
  "beach", "mountain", "city", "culture", "adventure",
  "food", "wellness", "nature", "history", "luxury"
];

const durations = ["weekend", "week", "two weeks", "month"];

// Generate a random trip inspiration using OpenAI or fallback to curated content
const generateTripInspiration = async (category?: string, preference?: string): Promise<TripInspiration> => {
  const randomCountry = countries[Math.floor(Math.random() * countries.length)];
  const randomCategory = category || categories[Math.floor(Math.random() * categories.length)];
  const randomDuration = durations[Math.floor(Math.random() * durations.length)];
  
  try {
    // Try OpenAI first for personalized suggestions
    if (process.env.OPENAI_API_KEY) {
      console.log('Using OpenAI for trip inspiration');
      const prompt = `Generate a detailed travel inspiration for a ${randomDuration} trip to ${randomCountry} focusing on ${randomCategory} experiences${preference ? ' with preference for ' + preference : ''}.
        Include destination name, brief description, 5 activities, budget information (range and per day cost), best time to visit (months),
        transportation options, 3 accommodation suggestions, 3 local cuisine recommendations, and 3 cultural tips.
        Format as JSON matching this structure exactly:
        {
          "destination": "string",
          "description": "string",
          "activities": ["string"],
          "budget": {
            "currency": "string",
            "range": {
              "min": number,
              "max": number
            },
            "perDay": number
          },
          "bestTimeToVisit": ["string"],
          "transportationOptions": ["string"],
          "accommodationSuggestions": ["string"],
          "localCuisine": ["string"],
          "culturalTips": ["string"]
        }`;

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'You are a travel expert who creates detailed travel inspirations in JSON format with accurate and helpful information.' },
            { role: 'user', content: prompt }
          ],
          temperature: 0.7,
          max_tokens: 1000
        },
        {
          headers: {
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const content = response.data.choices[0].message.content;
      
      try {
        // Extract JSON from the response
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const jsonContent = jsonMatch[0];
          const parsedData = JSON.parse(jsonContent);
          
          // Get a relevant image URL using Unsplash API
          const imageUrl = await getDestinationImage(parsedData.destination, randomCategory);
          
          return {
            ...parsedData,
            imageUrl
          };
        }
      } catch (parseError) {
        console.error('Error parsing OpenAI response:', parseError);
        // Continue to fallback
      }
    }
    
    // Fallback to curated content
    console.log('Using fallback for trip inspiration');
    return generateFallbackInspiration(randomCountry, randomCategory, randomDuration);
    
  } catch (error) {
    console.error('Error generating trip inspiration:', error);
    // Fallback to curated content
    return generateFallbackInspiration(randomCountry, randomCategory, randomDuration);
  }
};

const getDestinationImage = async (destination: string, category: string): Promise<string> => {
  try {
    // Try to get a real image from Unsplash API
    const response = await axios.get(
      `https://api.unsplash.com/search/photos?query=${encodeURIComponent(destination)}+${encodeURIComponent(category)}&per_page=1`,
      {
        headers: {
          'Authorization': `Client-ID ${process.env.UNSPLASH_ACCESS_KEY || ''}`
        }
      }
    );
    
    if (response.data.results && response.data.results.length > 0) {
      return response.data.results[0].urls.regular;
    }
    
    // Fallback images by category
    return getFallbackImage(category);
    
  } catch (error) {
    console.error('Error fetching destination image:', error);
    return getFallbackImage(category);
  }
};

const getFallbackImage = (category: string): string => {
  const fallbackImages = {
    beach: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
    mountain: "https://images.unsplash.com/photo-1454496522488-7a8e488e8606",
    city: "https://images.unsplash.com/photo-1519501025264-65ba15a82390",
    culture: "https://images.unsplash.com/photo-1551009175-15bdf9dcb580",
    adventure: "https://images.unsplash.com/photo-1602088113235-229c19758e9f",
    food: "https://images.unsplash.com/photo-1504674900247-0877df9cc836",
    wellness: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874",
    nature: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e",
    history: "https://images.unsplash.com/photo-1563127796-0985a6e1c7a7",
    luxury: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    default: "https://images.unsplash.com/photo-1500835556837-99ac94a94552"
  };
  
  return fallbackImages[category as keyof typeof fallbackImages] || fallbackImages.default;
};

// Fallback function for when API calls fail
const generateFallbackInspiration = (country: string, category: string, duration: string): TripInspiration => {
  // Basic template based on country and category
  const baseBudgets: Record<string, { currency: string, low: number, high: number, perDay: number }> = {
    "Japan": { currency: "JPY", low: 80000, high: 150000, perDay: 12000 },
    "Italy": { currency: "EUR", low: 800, high: 1500, perDay: 120 },
    "France": { currency: "EUR", low: 900, high: 1800, perDay: 130 },
    "Thailand": { currency: "THB", low: 15000, high: 35000, perDay: 2500 },
    "Peru": { currency: "PEN", low: 1500, high: 3000, perDay: 250 },
    "Australia": { currency: "AUD", low: 1200, high: 2500, perDay: 180 },
    "Morocco": { currency: "MAD", low: 4000, high: 8000, perDay: 600 },
    "Greece": { currency: "EUR", low: 700, high: 1400, perDay: 100 },
    "Vietnam": { currency: "VND", low: 10000000, high: 20000000, perDay: 1500000 },
    "Canada": { currency: "CAD", low: 1000, high: 2000, perDay: 150 },
    "Spain": { currency: "EUR", low: 750, high: 1500, perDay: 110 },
    "India": { currency: "INR", low: 30000, high: 70000, perDay: 5000 },
    "New Zealand": { currency: "NZD", low: 1300, high: 2600, perDay: 200 },
    "South Africa": { currency: "ZAR", low: 8000, high: 15000, perDay: 1200 },
    "Brazil": { currency: "BRL", low: 2500, high: 5000, perDay: 400 },
    "default": { currency: "USD", low: 800, high: 1600, perDay: 120 }
  };
  
  const budget = baseBudgets[country] || baseBudgets.default;
  
  // Multiplier based on duration
  let durationMultiplier = 1;
  if (duration === "week") durationMultiplier = 7;
  else if (duration === "two weeks") durationMultiplier = 14;
  else if (duration === "month") durationMultiplier = 30;
  else durationMultiplier = 3; // weekend
  
  // Generic activities by category
  const categoryActivities: Record<string, string[]> = {
    "beach": ["Sunbathing at top beaches", "Snorkeling to see marine life", "Beach volleyball", "Sunset cruise", "Beach club hopping"],
    "mountain": ["Hiking popular trails", "Mountain biking", "Scenic photography", "Visiting mountain villages", "Trying local highland cuisine"],
    "city": ["City walking tour", "Museum visits", "Local shopping", "City skyline view", "Fine dining experience"],
    "culture": ["Visit historical monuments", "Local art gallery tour", "Traditional craft workshops", "Cultural performance", "Historical walking tour"],
    "adventure": ["Whitewater rafting", "Zip-lining", "Rock climbing", "Off-road exploration", "Bungee jumping"],
    "food": ["Local food tour", "Cooking class", "Wine/spirit tasting", "Visit to food markets", "Dining at famous restaurants"],
    "wellness": ["Spa treatments", "Yoga retreat", "Meditation sessions", "Hot springs visit", "Healthy cooking class"],
    "nature": ["Wildlife spotting", "National park visit", "Bird watching", "Nature photography", "Camping under stars"],
    "history": ["Historical site tours", "Museum visits", "Guided historical walks", "Ancient ruins exploration", "Historical reenactments"],
    "luxury": ["Five-star hotel stay", "Private guided tours", "Exclusive dining", "Luxury shopping", "VIP experiences"]
  };
  
  // Transportation options based on country
  const transportOptions: Record<string, string[]> = {
    "Japan": ["Shinkansen (bullet train)", "Metro system", "Local buses", "Taxi service", "Bicycle rental"],
    "Italy": ["High-speed trains", "Local buses", "Vespa rental", "Water taxis in Venice", "Car rental"],
    "default": ["Public transportation", "Taxis/ride-sharing", "Car rental", "Shuttle services", "Walking tours"]
  };
  
  // Accommodation suggestions
  const accommodationByCategory: Record<string, string[]> = {
    "beach": ["Beachfront resort", "Private beach villa", "Surf hostel"],
    "mountain": ["Mountain lodge", "Cabin rental", "Ski resort"],
    "city": ["Boutique hotel", "City apartment", "Historic hotel"],
    "luxury": ["Five-star hotel", "Luxury resort", "Exclusive villa"],
    "default": ["Mid-range hotel", "Local guesthouse", "Budget-friendly hostel"]
  };
  
  return {
    destination: `${country} - ${category.charAt(0).toUpperCase() + category.slice(1)} Experience`,
    description: `Explore the ${category} attractions of ${country} on this ${duration} trip. Perfect for travelers who want to enjoy ${country}'s famous ${category} offerings with a blend of authentic local experiences.`,
    activities: categoryActivities[category] || categoryActivities.default || ["Sightseeing", "Local cuisine tasting", "Cultural visits", "Relaxation", "Shopping"],
    budget: {
      currency: budget.currency,
      range: {
        min: budget.low * durationMultiplier,
        max: budget.high * durationMultiplier
      },
      perDay: budget.perDay
    },
    bestTimeToVisit: getSeasonsByCountry(country),
    transportationOptions: transportOptions[country] || transportOptions.default,
    accommodationSuggestions: accommodationByCategory[category] || accommodationByCategory.default,
    localCuisine: getLocalCuisine(country),
    culturalTips: getCulturalTips(country),
    imageUrl: getFallbackImage(category)
  };
};

// Helper functions for fallback content
const getSeasonsByCountry = (country: string): string[] => {
  const seasonsByCountry: Record<string, string[]> = {
    "Japan": ["March-May (Cherry Blossoms)", "October-November (Autumn colors)"],
    "Italy": ["April-June", "September-October"],
    "Thailand": ["November-February (dry season)"],
    "Peru": ["May-September (dry season)"],
    "Australia": ["September-November", "March-May"],
    "default": ["Spring", "Fall"]
  };
  
  return seasonsByCountry[country] || seasonsByCountry.default;
};

const getLocalCuisine = (country: string): string[] => {
  const cuisineByCountry: Record<string, string[]> = {
    "Japan": ["Sushi and Sashimi", "Ramen", "Tempura"],
    "Italy": ["Authentic Pasta", "Regional Pizza", "Gelato"],
    "Thailand": ["Pad Thai", "Green Curry", "Mango Sticky Rice"],
    "Peru": ["Ceviche", "Lomo Saltado", "Pisco Sour"],
    "India": ["Butter Chicken", "Masala Dosa", "Biryani"],
    "France": ["Croissants", "Coq au Vin", "Beef Bourguignon"],
    "default": ["Local Specialty", "Traditional Dishes", "Regional Treats"]
  };
  
  return cuisineByCountry[country] || cuisineByCountry.default;
};

const getCulturalTips = (country: string): string[] => {
  const tipsByCountry: Record<string, string[]> = {
    "Japan": ["Bow when greeting", "Remove shoes before entering homes", "Don't tip at restaurants"],
    "Italy": ["Greet with cheek kisses", "Dinner is usually after 8pm", "Order coffee at the bar to save money"],
    "Thailand": ["Respect the monarchy", "Remove shoes before entering temples", "Don't touch people's heads"],
    "India": ["Use right hand for eating", "Remove shoes at temples", "Head wobble can mean 'yes'"],
    "default": ["Learn basic local phrases", "Respect local customs", "Be aware of appropriate dress codes"]
  };
  
  return tipsByCountry[country] || tipsByCountry.default;
};

// API routes for trip inspiration
export const registerTripInspirationRoutes = (app: Express) => {
  // Schema for validating query parameters
  const inspirationQuerySchema = z.object({
    category: z.string().optional(),
    preference: z.string().optional()
  });

  // Get a random trip inspiration
  app.get('/api/trip-inspiration/random', async (req: Request, res: Response) => {
    try {
      const parsedQuery = inspirationQuerySchema.safeParse(req.query);
      
      if (!parsedQuery.success) {
        return res.status(400).json({ error: 'Invalid query parameters' });
      }
      
      const { category, preference } = parsedQuery.data;
      const inspiration = await generateTripInspiration(category, preference);
      
      res.json(inspiration);
    } catch (error) {
      console.error('Error in trip inspiration route:', error);
      res.status(500).json({ error: 'Failed to generate trip inspiration' });
    }
  });
};