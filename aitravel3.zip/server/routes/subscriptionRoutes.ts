import { Router, Request, Response } from 'express';
import { subscriptionService } from '../services/subscriptionService';
import { paymentService } from '../services/paymentService';
import { SubscriptionTier } from '../../shared/schema';
import { calculateCommission } from '../utils/helpers';

const router = Router();

// Get pricing information
router.get('/pricing', async (req: Request, res: Response) => {
  const pricingInfo = {
    tiers: [
      {
        id: SubscriptionTier.FREE,
        name: 'Free',
        price: 0,
        period: 'month',
        features: [
          'Basic travel planning',
          'Flight and hotel search',
          'Restaurant booking',
          'Community access',
          'Ad-supported experience'
        ],
        mostPopular: false
      },
      {
        id: SubscriptionTier.PREMIUM,
        name: 'Premium',
        price: 9.99,
        period: 'month',
        features: [
          'Ad-free experience',
          'Priority customer support',
          'Advanced AI travel planning',
          'Exclusive deals and discounts',
          'Flight price alerts and predictions',
          'Unlimited trip soundtrack generation',
          'Emergency travel assistance'
        ],
        mostPopular: true
      },
      {
        id: SubscriptionTier.BUSINESS,
        name: 'Business',
        price: 49.99,
        period: 'month',
        features: [
          'All Premium features',
          'Team management for corporate travel',
          'Expense tracking and reporting',
          'Custom travel policy enforcement',
          'Advanced analytics and reporting',
          'Dedicated account manager',
          'Team collaboration tools'
        ],
        mostPopular: false
      }
    ],
    discounts: [
      {
        id: 'annual',
        name: 'Annual subscription',
        description: 'Save 20% with annual billing',
        percentage: 20
      },
      {
        id: 'referral',
        name: 'Referral discount',
        description: 'Get $10 off for each friend who joins',
        amount: 10
      }
    ]
  };

  res.json(pricingInfo);
});

// Get current user's subscription
router.get('/user-subscription', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const subscription = await subscriptionService.getUserSubscription(req.user.id);
    res.json(subscription || { tier: SubscriptionTier.FREE });
  } catch (error) {
    console.error('Error fetching user subscription:', error);
    res.status(500).json({ error: 'Failed to fetch subscription information' });
  }
});

// Create subscription payment intent
router.post('/create-subscription', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const { tier, billingPeriod } = req.body;

  if (!tier || !['monthly', 'annual'].includes(billingPeriod)) {
    return res.status(400).json({ error: 'Invalid subscription parameters' });
  }

  try {
    // Determine price based on tier and billing period
    let amount = 0;
    let months = billingPeriod === 'annual' ? 12 : 1;
    let discount = billingPeriod === 'annual' ? 0.2 : 0; // 20% discount for annual

    if (tier === SubscriptionTier.PREMIUM) {
      amount = 9.99 * months * (1 - discount);
    } else if (tier === SubscriptionTier.BUSINESS) {
      amount = 49.99 * months * (1 - discount);
    }

    // Round to 2 decimal places
    amount = Math.round(amount * 100) / 100;

    // Create payment intent
    const paymentIntent = await paymentService.createPaymentIntent(
      amount * 100, // Convert to cents for Stripe
      'subscription',
      {
        userId: req.user.id,
        tier,
        billingPeriod,
        months
      }
    );

    res.json({
      clientSecret: paymentIntent.client_secret,
      amount,
      tier,
      billingPeriod
    });
  } catch (error) {
    console.error('Error creating subscription:', error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
});

// Handle successful subscription payment
router.post('/confirm-subscription', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const { paymentIntentId, tier, months } = req.body;

  if (!paymentIntentId || !tier || !months) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  try {
    // Confirm payment
    await paymentService.confirmPayment(paymentIntentId);

    // Calculate expiry date
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + parseInt(months));

    // Create subscription
    const subscription = await subscriptionService.createOrUpdateSubscription(
      req.user.id,
      tier,
      endDate,
      paymentIntentId
    );

    // Also check if user was referred and complete referral
    if (req.user.referred_by) {
      const referrals = await subscriptionService.completeReferral(req.user.referred_by);
    }

    res.json({
      success: true,
      subscription
    });
  } catch (error) {
    console.error('Error confirming subscription:', error);
    res.status(500).json({ error: 'Failed to confirm subscription' });
  }
});

// Cancel subscription
router.post('/cancel-subscription', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const { subscriptionId } = req.body;

  if (!subscriptionId) {
    return res.status(400).json({ error: 'Missing subscription ID' });
  }

  try {
    const cancelled = await subscriptionService.cancelSubscription(parseInt(subscriptionId));
    
    if (cancelled) {
      res.json({ success: true, message: 'Subscription cancelled successfully' });
    } else {
      res.status(404).json({ error: 'Subscription not found or already cancelled' });
    }
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
});

// Generate referral code
router.post('/generate-referral-code', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const code = await subscriptionService.createReferralCode(req.user.id);
    res.json({ success: true, referralCode: code });
  } catch (error) {
    console.error('Error generating referral code:', error);
    res.status(500).json({ error: 'Failed to generate referral code' });
  }
});

// Apply referral code during registration
router.post('/apply-referral', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const { referralCode } = req.body;

  if (!referralCode) {
    return res.status(400).json({ error: 'Missing referral code' });
  }

  try {
    const referral = await subscriptionService.processReferral(referralCode, req.user.id);
    
    if (referral) {
      res.json({ success: true, referral });
    } else {
      res.status(404).json({ error: 'Invalid referral code' });
    }
  } catch (error) {
    console.error('Error applying referral code:', error);
    res.status(500).json({ error: 'Failed to apply referral code' });
  }
});

// Create business account
router.post('/create-business-account', async (req: Request, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const { name, contactEmail, maxUsers, address, taxId, contactPhone } = req.body;

  if (!name || !contactEmail) {
    return res.status(400).json({ error: 'Missing required business information' });
  }

  try {
    const businessAccount = await subscriptionService.createBusinessAccount(
      name,
      contactEmail,
      maxUsers,
      address,
      taxId,
      contactPhone
    );

    // Assign the creating user to this business account
    await subscriptionService.assignUserToBusinessAccount(req.user.id, businessAccount.id);

    res.json({
      success: true,
      businessAccount
    });
  } catch (error) {
    console.error('Error creating business account:', error);
    res.status(500).json({ error: 'Failed to create business account' });
  }
});

// Record booking commission
router.post('/record-commission', async (req: Request, res: Response) => {
  // This would typically be an internal API called by booking services
  // For security, let's restrict it to authenticated admin users in a real app
  
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const { bookingId, userId, bookingType, amount, partnerName, partnerReferenceId } = req.body;

  if (!bookingId || !userId || !bookingType || !amount) {
    return res.status(400).json({ error: 'Missing required commission parameters' });
  }

  try {
    // Calculate commission rate based on booking type
    const commissionRate = calculateCommission(bookingType, parseFloat(amount));
    
    const commission = await subscriptionService.recordCommission(
      parseInt(bookingId),
      parseInt(userId),
      bookingType,
      parseFloat(amount),
      commissionRate,
      partnerName,
      partnerReferenceId
    );
    
    res.json({
      success: true,
      commission
    });
  } catch (error) {
    console.error('Error recording commission:', error);
    res.status(500).json({ error: 'Failed to record commission' });
  }
});

export default router;