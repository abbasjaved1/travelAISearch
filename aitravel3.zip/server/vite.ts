import express, { type Express } from "express";
import fs from "fs";
import path, { dirname } from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer, createLogger } from "vite";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
import { type Server } from "http";
import viteConfig from "../vite.config";
import { nanoid } from "nanoid";

const viteLogger = createLogger();

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      },
    },
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(
        __dirname,
        "..",
        "client",
        "index.html",
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`,
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath = path.resolve(__dirname, "../dist");
  const clientPath = path.join(distPath, "client");
  const publicPath = path.join(distPath, "public");
  
  // Ensure directories exist
  [clientPath, publicPath].forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });

  // In production, serve from both client and public directories
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(clientPath));
    app.use(express.static(publicPath));
  }

  // Serve index.html for all routes (SPA fallback)
  app.use("*", (req, res) => {
    try {
      // Check in order: client/index.html -> public/index.html -> development index.html
      const indexPaths = [
        path.join(clientPath, "index.html"),
        path.join(publicPath, "index.html"),
        path.resolve(__dirname, "../client/index.html")
      ];

      for (const indexPath of indexPaths) {
        if (fs.existsSync(indexPath)) {
          return res.sendFile(indexPath);
        }
      }

      // Fallback loading page
      res.status(200).send(`
        <!DOCTYPE html>
        <html>
          <head><title>Loading...</title></head>
          <body>
            <h1>Application is starting...</h1>
            <p>Please wait while the build completes.</p>
          </body>
        </html>
      `);
    } catch (error) {
      console.error('Error serving static files:', error);
      res.status(500).send('Internal Server Error');
    }
  });
}
